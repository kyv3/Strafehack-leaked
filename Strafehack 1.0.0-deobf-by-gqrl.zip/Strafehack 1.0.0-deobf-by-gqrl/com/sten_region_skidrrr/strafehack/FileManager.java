// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.File;
import com.google.gson.Gson;

public class FileManager
{
    private static Gson gson;
    private static File ROOT_DIR;
    private static File MODS_DIR;
    private static String[] 423363385;
    private static String[] 2023018909;
    private static long 1393452643;
    private static int 1663610808;
    private static int 1050395210;
    private static int 1104462031;
    private static int 631357082;
    private static int -848740913;
    private static long 680200358;
    private static long -1167018247;
    private static int -1006870054;
    private static long 202740922;
    private static long -763645731;
    private static int 1002044724;
    private static int 100291166;
    
    public static void Init() {
        if (!invokedynamic(622335859:(Ljava/lang/Object;)Z, FileManager.ROOT_DIR)) {
        }
        // invokedynamic(-1923132318:(Ljava/lang/Object;)Z, FileManager.ROOT_DIR)
        if (!invokedynamic(-1992113696:(Ljava/lang/Object;)Z, FileManager.MODS_DIR)) {
        }
        // invokedynamic(756287414:(Ljava/lang/Object;)Z, FileManager.MODS_DIR)
    }
    
    public static Gson getGson() {
        return FileManager.gson;
    }
    
    public static File getMODS_DIR() {
        return FileManager.MODS_DIR;
    }
    
    public static File getROOT_DIR() {
        return FileManager.ROOT_DIR;
    }
    
    public static boolean writeJsonToFile(final File -713148794, final Object -112469863) {
        try {
            if (!invokedynamic(-1245267879:(Ljava/lang/Object;)Z, -713148794)) {
            }
            // invokedynamic(-1376347243:(Ljava/lang/Object;)Z, -713148794)
            final FileOutputStream 905255528 = new FileOutputStream(-713148794);
            // invokedynamic(218401935:(Ljava/lang/Object;[B)V, 905255528, (byte[])invokedynamic(1574367119:(Ljava/lang/Object;)[B, invokedynamic(1513089053:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/String;, FileManager.gson, -112469863)))
            // invokedynamic(608598998:(Ljava/lang/Object;)V, 905255528)
            // invokedynamic(-1780481704:(Ljava/lang/Object;)V, 905255528)
            return FileManager.1663610808 != 0;
        }
        catch (IOException ex) {
            // invokedynamic(879511027:(Ljava/lang/Object;)V, ex)
            return FileManager.1050395210 != 0;
        }
    }
    
    public static <T> T readFromJson(final File -1097135388, final Class<T> 1547030816) {
        try {
            final FileInputStream 1547030817 = new FileInputStream(-1097135388);
            final InputStreamReader 1547030818 = new InputStreamReader(1547030817);
            final BufferedReader 1547030819 = new BufferedReader(1547030818);
            final StringBuilder sb = new StringBuilder();
            String 1547030820;
            while ((1547030820 = invokedynamic(1389864248:(Ljava/lang/Object;)Ljava/lang/String;, 1547030819)) != null) {
            }
            // invokedynamic(1978722806:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, sb, 1547030820)
            // invokedynamic(2027929706:(Ljava/lang/Object;)V, 1547030819)
            // invokedynamic(583938571:(Ljava/lang/Object;)V, 1547030818)
            // invokedynamic(294525611:(Ljava/lang/Object;)V, 1547030817)
            return invokedynamic(1910280992:(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;, FileManager.gson, invokedynamic(412669537:(Ljava/lang/Object;)Ljava/lang/String;, sb), 1547030816);
        }
        catch (IOException ex) {
            // invokedynamic(1462322917:(Ljava/lang/Object;)V, ex)
            return null;
        }
    }
    
    static {
        FileManager.1002044724 = -37940649;
        FileManager.100291166 = 184;
        FileManager.1663610808 = (2048 >>> 43 | 2048 << ~0x2B + 1);
        FileManager.1050395210 = invokedynamic(-1391027210:(I)I, false);
        FileManager.1104462031 = ((2 >>> 224 | 2 << -224) & -1);
        FileManager.631357082 = invokedynamic(-1582666985:(I)I, 1073741824);
        FileManager.-848740913 = ((0 >>> 170 | 0 << ~0xAA + 1) & -1);
        FileManager.680200358 = invokedynamic(701578868:(J)J, -1126195428476304068L);
        FileManager.-1167018247 = invokedynamic(1744493419:(J)J, 2882303761517117440L);
        FileManager.-1006870054 = invokedynamic(-211560976:(I)I, Integer.MIN_VALUE);
        FileManager.202740922 = invokedynamic(-1602124732:(J)J, -1126195428476304068L);
        FileManager.-763645731 = invokedynamic(544070425:(J)J, 2882303761517117440L);
        FileManager.423363385 = new String[FileManager.1104462031];
        FileManager.2023018909 = new String[FileManager.631357082];
        // invokedynamic(-749632352:()V)
        FileManager.gson = new Gson();
        FileManager.ROOT_DIR = new File(invokedynamic(-1732583411:(IJ)Ljava/lang/String;, FileManager.-848740913, FileManager.680200358 ^ FileManager.-1167018247));
        FileManager.MODS_DIR = new File(FileManager.ROOT_DIR, invokedynamic(-1241477505:(IJ)Ljava/lang/String;, FileManager.-1006870054, FileManager.202740922 ^ FileManager.-763645731));
    }
    
    private static Object -1130638809(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(FileManager.class, "1131375027", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", FileManager.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/FileManager:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String 1131375027(final int n, long n2) {
        n2 ^= 0x14L;
        n2 ^= 0x832B57BF1302389CL;
        if (FileManager.423363385[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/FileManager");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            FileManager.423363385[n] = new String(instance.doFinal(Base64.getDecoder().decode(FileManager.2023018909[n])));
        }
        return FileManager.423363385[n];
    }
    
    private static void 1151614581() {
        FileManager.1393452643 = 4369054870306519567L;
        final long n = FileManager.1393452643 ^ 0x832B57BF1302389CL;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    FileManager.2023018909[0] = "XVu2IJ+zsoK9dDeNUTh3sg==";
                    FileManager.2023018909[1] = "clwOQYPvYp0=";
                    break;
                }
                case 1: {
                    FileManager.2023018909[0] = "XVu2IJ+zsoLlIPtRGxwgpQ==";
                    FileManager.2023018909[1] = "BRWKOX6XzaU=";
                    break;
                }
                case 2: {
                    FileManager.2023018909[0] = "3nRofGCowZY=";
                    break;
                }
                case 4: {
                    FileManager.2023018909[0] = "vpwMHP2kTuhdxPHqSLC2nQ==";
                    break;
                }
            }
        }
    }
    
    public static Object 1435687099(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4) throws Exception {
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if ((int)o == 184) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

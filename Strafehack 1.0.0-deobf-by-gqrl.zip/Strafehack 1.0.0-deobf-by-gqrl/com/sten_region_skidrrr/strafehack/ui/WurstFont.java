// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.ui;

import java.lang.invoke.MutableCallSite;
import javax.xml.bind.DatatypeConverter;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import java.awt.FontMetrics;
import java.awt.RenderingHints;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.Font;

public class WurstFont
{
    public int IMAGE_WIDTH;
    public int IMAGE_HEIGHT;
    private int texID;
    private final IntObject[] chars;
    private final Font font;
    private boolean antiAlias;
    private int fontHeight;
    private int charOffset;
    private static int 1322086444;
    private static int 1500672764;
    private static int 1280316484;
    private static int -1729201724;
    private static int -1863799874;
    private static int -114618376;
    private static int -881828948;
    private static int 403284223;
    private static int -1996225414;
    private static int 530543804;
    private static int 1211374417;
    private static int -647031593;
    private static int 960684112;
    private static int 2007358434;
    private static int -2074499040;
    private static int 439538896;
    private static int 282222777;
    private static int -476408104;
    private static int 201299624;
    private static int -958436022;
    private static int 167670352;
    private static int -2062044472;
    private static int -537222771;
    private static int -308394832;
    private static int 842616179;
    private static int -2087510833;
    private static int 379017068;
    private static int -1037124662;
    private static int -11271924;
    private static int 1284159678;
    private static int -1918982088;
    private static int -930201064;
    private static int -512541147;
    private static int 837082647;
    private static int -1553397028;
    private static int 953408249;
    private static int 1355983434;
    private static int -881691210;
    private static int 904358658;
    private static int -1765705909;
    private static int -962072942;
    private static int -969721723;
    private static int 1200184741;
    private static int 138730030;
    private static int -505605518;
    private static int 1879329094;
    private static int -1360303251;
    private static int 812582925;
    private static int 1807262460;
    private static int 713814939;
    private static double -1399266880;
    private static double 491666770;
    private static double 1448879905;
    private static double -1476261942;
    private static double -1455063820;
    private static double 1947003219;
    private static float -886146660;
    private static float 169549593;
    private static float 680469685;
    private static float -2004261844;
    private static int 1586754969;
    private static float 644415553;
    private static float -1351786037;
    private static float 343991850;
    private static float -194092114;
    private static int -375880381;
    private static int 1419829975;
    private static int -276341570;
    private static int 608684786;
    private static int 1421461938;
    private static int -798785125;
    private static int -1034374108;
    private static int -1869944492;
    private static int 565027655;
    private static int 335880405;
    
    public WurstFont(final Font -1578726662, final boolean 1153880402, final int -857328489) {
        this.IMAGE_WIDTH = WurstFont.1322086444;
        this.IMAGE_HEIGHT = WurstFont.1500672764;
        this.chars = new IntObject[WurstFont.1280316484];
        this.fontHeight = WurstFont.-1729201724;
        this.charOffset = WurstFont.-1863799874;
        this.font = -1578726662;
        this.antiAlias = 1153880402;
        this.charOffset = -857328489;
        this.setupTexture(1153880402);
    }
    
    public WurstFont(final Font -2095134444, final boolean -767226581) {
        this.IMAGE_WIDTH = WurstFont.-114618376;
        this.IMAGE_HEIGHT = WurstFont.-881828948;
        this.chars = new IntObject[WurstFont.403284223];
        this.fontHeight = WurstFont.-1996225414;
        this.charOffset = WurstFont.530543804;
        this.font = -2095134444;
        this.antiAlias = -767226581;
        this.charOffset = WurstFont.1211374417;
        this.setupTexture(-767226581);
    }
    
    private void setupTexture(final boolean 1083003469) {
        if (invokedynamic(411020322:(Ljava/lang/Object;)I, this.font) <= WurstFont.-647031593) {
            this.IMAGE_WIDTH = WurstFont.960684112;
            this.IMAGE_HEIGHT = WurstFont.2007358434;
        }
        if (invokedynamic(-1709208291:(Ljava/lang/Object;)I, this.font) <= WurstFont.-2074499040) {
            this.IMAGE_WIDTH = WurstFont.439538896;
            this.IMAGE_HEIGHT = WurstFont.282222777;
        }
        else if (invokedynamic(636017352:(Ljava/lang/Object;)I, this.font) <= WurstFont.-476408104) {
            this.IMAGE_WIDTH = WurstFont.201299624;
            this.IMAGE_HEIGHT = WurstFont.-958436022;
        }
        else {
            this.IMAGE_WIDTH = WurstFont.167670352;
            this.IMAGE_HEIGHT = WurstFont.-2062044472;
        }
        final BufferedImage bufferedImage = new BufferedImage(this.IMAGE_WIDTH, this.IMAGE_HEIGHT, WurstFont.-537222771);
        final Graphics2D graphics2D = (Graphics2D)invokedynamic(1165882815:(Ljava/lang/Object;)Ljava/awt/Graphics;, bufferedImage);
        // invokedynamic(1300895875:(Ljava/lang/Object;Ljava/lang/Object;)V, graphics2D, this.font)
        // invokedynamic(-1727162651:(Ljava/lang/Object;Ljava/lang/Object;)V, graphics2D, new Color(WurstFont.-308394832, WurstFont.842616179, WurstFont.-2087510833, WurstFont.379017068))
        // invokedynamic(-934819108:(Ljava/lang/Object;IIII)V, graphics2D, WurstFont.-1037124662, WurstFont.-11271924, this.IMAGE_WIDTH, this.IMAGE_HEIGHT)
        // invokedynamic(-570890979:(Ljava/lang/Object;Ljava/lang/Object;)V, graphics2D, Color.white)
        int n = WurstFont.1284159678;
        int storedX = WurstFont.-1918982088;
        int -930201064 = WurstFont.-930201064;
        for (int i = WurstFont.-512541147; i < WurstFont.837082647; ++i) {
            final char 1083003470 = (char)i;
            final BufferedImage fontImage = this.getFontImage(1083003470, 1083003469);
            final IntObject 1083003471 = new IntObject();
            1083003471.width = invokedynamic(-1450233511:(Ljava/lang/Object;)I, fontImage);
            1083003471.height = invokedynamic(-1975723660:(Ljava/lang/Object;)I, fontImage);
            if (storedX + 1083003471.width >= this.IMAGE_WIDTH) {
                storedX = WurstFont.-1553397028;
                -930201064 += n;
                n = WurstFont.953408249;
            }
            1083003471.storedX = storedX;
            1083003471.storedY = -930201064;
            if (1083003471.height > this.fontHeight) {
                this.fontHeight = 1083003471.height;
            }
            if (1083003471.height > n) {
                n = 1083003471.height;
            }
            this.chars[i] = 1083003471;
            // invokedynamic(748673082:(Ljava/lang/Object;Ljava/lang/Object;IILjava/lang/Object;)Z, graphics2D, fontImage, storedX, -930201064, null)
            storedX += 1083003471.width;
        }
        try {
            this.texID = invokedynamic(1896195893:(ILjava/lang/Object;ZZ)I, invokedynamic(-1297870104:()I), bufferedImage, WurstFont.1355983434, WurstFont.-881691210);
        }
        catch (NullPointerException 1083003472) {
        }
        // invokedynamic(-1207219829:(Ljava/lang/Object;)V, 1083003472)
    }
    
    private BufferedImage getFontImage(final char 1266505727, final boolean -1485097083) {
        final BufferedImage 1266505728 = new BufferedImage(WurstFont.904358658, WurstFont.-1765705909, WurstFont.-962072942);
        final Graphics2D graphics2D = (Graphics2D)invokedynamic(-532256734:(Ljava/lang/Object;)Ljava/awt/Graphics;, 1266505728);
        if (-1485097083) {
        }
        // invokedynamic(1499676901:(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V, graphics2D, RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON)
        else {
        }
        // invokedynamic(-54559160:(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V, graphics2D, RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF)
        // invokedynamic(1438782312:(Ljava/lang/Object;Ljava/lang/Object;)V, graphics2D, this.font)
        final FontMetrics fontMetrics = invokedynamic(181768519:(Ljava/lang/Object;)Ljava/awt/FontMetrics;, graphics2D);
        int 1266505729 = invokedynamic(-1345102318:(Ljava/lang/Object;C)I, fontMetrics, 1266505727) + WurstFont.-969721723;
        if (1266505729 <= 0) {
            1266505729 = WurstFont.1200184741;
        }
        int height = invokedynamic(433762894:(Ljava/lang/Object;)I, fontMetrics) + WurstFont.138730030;
        if (height <= 0) {
            height = invokedynamic(-1093725141:(Ljava/lang/Object;)I, this.font);
        }
        final BufferedImage bufferedImage = new BufferedImage(1266505729, height, WurstFont.-505605518);
        final Graphics2D graphics2D2 = (Graphics2D)invokedynamic(-1297864648:(Ljava/lang/Object;)Ljava/awt/Graphics;, bufferedImage);
        if (-1485097083) {
        }
        // invokedynamic(1693004538:(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V, graphics2D2, RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON)
        else {
        }
        // invokedynamic(240086214:(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V, graphics2D2, RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF)
        // invokedynamic(337970387:(Ljava/lang/Object;Ljava/lang/Object;)V, graphics2D2, this.font)
        // invokedynamic(-777045904:(Ljava/lang/Object;Ljava/lang/Object;)V, graphics2D2, Color.WHITE)
        final int 1266505730 = WurstFont.1879329094;
        final int -1485097084 = WurstFont.-1360303251;
        // invokedynamic(1167245250:(Ljava/lang/Object;Ljava/lang/Object;II)V, graphics2D2, invokedynamic(1834298533:(C)Ljava/lang/String;, 1266505727), WurstFont.812582925, WurstFont.1807262460 + invokedynamic(-753034354:(Ljava/lang/Object;)I, fontMetrics))
        return bufferedImage;
    }
    
    public void drawChar(final char -26441601, final float 1282643324, final float -15017043) throws ArrayIndexOutOfBoundsException {
        try {
            this.drawQuad(1282643324, -15017043, (float)this.chars[-26441601].width, (float)this.chars[-26441601].height, (float)this.chars[-26441601].storedX, (float)this.chars[-26441601].storedY, (float)this.chars[-26441601].width, (float)this.chars[-26441601].height);
        }
        catch (Exception 1282643325) {
        }
        // invokedynamic(1235772379:(Ljava/lang/Object;)V, 1282643325)
    }
    
    private void drawQuad(final float 2084653885, final float 910369307, final float 540662751, final float -190766770, final float 1700966628, final float 203618953, final float 1428769541, final float -835785429) {
        final float n = 1700966628 / this.IMAGE_WIDTH;
        final float n2 = 203618953 / this.IMAGE_HEIGHT;
        final float n3 = 1428769541 / this.IMAGE_WIDTH;
        final float n4 = -835785429 / this.IMAGE_HEIGHT;
    }
    // invokedynamic(737078986:(I)V, WurstFont.713814939)
    // invokedynamic(7712961:(FF)V, n + n3, n2)
    // invokedynamic(-1852191269:(DD)V, (double)2084653885 + 540662751, (double)910369307)
    // invokedynamic(1901760296:(FF)V, n, n2)
    // invokedynamic(-260773021:(DD)V, (double)2084653885, (double)910369307)
    // invokedynamic(788056293:(FF)V, n, n2 + n4)
    // invokedynamic(1008235113:(DD)V, (double)2084653885, (double)910369307 + -190766770)
    // invokedynamic(357078047:(FF)V, n, n2 + n4)
    // invokedynamic(2012187664:(DD)V, (double)2084653885, (double)910369307 + -190766770)
    // invokedynamic(1971726820:(FF)V, n + n3, n2 + n4)
    // invokedynamic(1334196148:(DD)V, (double)2084653885 + 540662751, (double)910369307 + -190766770)
    // invokedynamic(624843809:(FF)V, n + n3, n2)
    // invokedynamic(-366037882:(DD)V, (double)2084653885 + 540662751, (double)910369307)
    // invokedynamic(-763229365:()V)
    
    public void drawString(final String -314557303, double 317405373, double -272887308, final Color -2139727272, final boolean 860575021) {
        317405373 *= WurstFont.-1399266880;
        -272887308 = -272887308 * WurstFont.491666770 - WurstFont.1448879905;
        // invokedynamic(-1136717492:()V)
        // invokedynamic(-1443373993:(DDD)V, WurstFont.-1476261942, WurstFont.-1455063820, WurstFont.1947003219)
        // invokedynamic(-1065051927:(I)V, this.texID)
        // invokedynamic(91604601:(Ljava/lang/Object;Ljava/lang/Object;)V, this, 860575021 ? new Color(WurstFont.-886146660, WurstFont.169549593, WurstFont.680469685, (float)invokedynamic(-965677652:(Ljava/lang/Object;)I, -2139727272) / WurstFont.-2004261844) : -2139727272)
        for (int 860575022 = invokedynamic(-1292118821:(Ljava/lang/Object;)I, -314557303), i = WurstFont.1586754969; i < 860575022; ++i) {
            final char c = invokedynamic(-60777824:(Ljava/lang/Object;I)C, -314557303, i);
            if (c < this.chars.length && c >= '\0') {
                // invokedynamic(1551814241:(Ljava/lang/Object;CFF)V, this, c, (float)317405373, (float)-272887308)
                317405373 += this.chars[c].width - this.charOffset;
            }
        }
    }
    // invokedynamic(2050958962:()V)
    
    public void glColor(final Color 1968963106) {
        final float 1968963107 = (float)invokedynamic(-1507333727:(Ljava/lang/Object;)I, 1968963106) / WurstFont.644415553;
        final float n = (float)invokedynamic(-1252166143:(Ljava/lang/Object;)I, 1968963106) / WurstFont.-1351786037;
        final float n2 = (float)invokedynamic(608252167:(Ljava/lang/Object;)I, 1968963106) / WurstFont.343991850;
        final float n3 = (float)invokedynamic(-1945446354:(Ljava/lang/Object;)I, 1968963106) / WurstFont.-194092114;
    }
    // invokedynamic(-1465930024:(FFFF)V, 1968963107, n, n2, n3)
    
    public int getStringHeight(final String -1117379484) {
        int 2059683132 = WurstFont.-375880381;
        final char[] array = (char[])invokedynamic(794131501:(Ljava/lang/Object;)[C, -1117379484);
        for (int length = array.length, i = WurstFont.1419829975; i < length; ++i) {
            final char 2059683133 = array[i];
            if (2059683133 == WurstFont.-276341570) {
                ++2059683132;
            }
        }
        return (this.fontHeight - this.charOffset) / WurstFont.608684786 * 2059683132;
    }
    
    public int getHeight() {
        return (this.fontHeight - this.charOffset) / WurstFont.1421461938;
    }
    
    public int getStringWidth(final String -350476260) {
        int 351740954 = WurstFont.-798785125;
        final char[] array = (char[])invokedynamic(1430114061:(Ljava/lang/Object;)[C, -350476260);
        for (int length = array.length, i = WurstFont.-1034374108; i < length; ++i) {
            final char 351740955 = array[i];
            if (351740955 < this.chars.length && 351740955 >= '\0') {
                351740954 += this.chars[351740955].width - this.charOffset;
            }
        }
        return 351740954 / WurstFont.-1869944492;
    }
    
    public boolean isAntiAlias() {
        return this.antiAlias;
    }
    
    public void setAntiAlias(final boolean 1755264141) {
        if (this.antiAlias != 1755264141) {
            this.setupTexture(this.antiAlias = 1755264141);
        }
    }
    
    public Font getFont() {
        return this.font;
    }
    
    static {
        WurstFont.565027655 = 484145804;
        WurstFont.335880405 = 184;
        WurstFont.1322086444 = (32 >>> 27 | 32 << -27);
        WurstFont.1500672764 = ((16777216 >>> 46 | 16777216 << -46) & -1);
        WurstFont.1280316484 = (67108864 >>> 15 | 67108864 << -15);
        WurstFont.-1729201724 = invokedynamic(-489117882:(I)I, -1);
        WurstFont.-1863799874 = invokedynamic(-114870898:(I)I, 268435456);
        WurstFont.-114618376 = (67108864 >>> 240 | 67108864 << -240);
        WurstFont.-881828948 = invokedynamic(-947181276:(I)I, 2097152);
        WurstFont.403284223 = ((1073741824 >>> 179 | 1073741824 << ~0xB3 + 1) & -1);
        WurstFont.-1996225414 = (-1 >>> 28 | -1 << ~0x1C + 1);
        WurstFont.530543804 = invokedynamic(-1104415383:(I)I, 268435456);
        WurstFont.1211374417 = invokedynamic(-1751206356:(I)I, 268435456);
        WurstFont.-647031593 = invokedynamic(1780143406:(I)I, -268435456);
        WurstFont.960684112 = invokedynamic(-989428402:(I)I, 8388608);
        WurstFont.2007358434 = invokedynamic(1958030440:(I)I, 8388608);
        WurstFont.-2074499040 = ((1376 >>> 197 | 1376 << ~0xC5 + 1) & -1);
        WurstFont.439538896 = (262144 >>> 9 | 262144 << ~0x9 + 1);
        WurstFont.282222777 = invokedynamic(-1018414781:(I)I, 4194304);
        WurstFont.-476408104 = invokedynamic(-2115699073:(I)I, -637534208);
        WurstFont.201299624 = invokedynamic(1007234344:(I)I, 2097152);
        WurstFont.-958436022 = invokedynamic(-249641951:(I)I, 2097152);
        WurstFont.167670352 = (1073741824 >>> 147 | 1073741824 << -147);
        WurstFont.-2062044472 = (32 >>> 122 | 32 << ~0x7A + 1);
        WurstFont.-537222771 = ((8 >>> 98 | 8 << ~0x62 + 1) & -1);
        WurstFont.-308394832 = invokedynamic(-655934479:(I)I, -16777216);
        WurstFont.842616179 = invokedynamic(274198566:(I)I, -16777216);
        WurstFont.-2087510833 = invokedynamic(-1047359426:(I)I, -16777216);
        WurstFont.379017068 = ((0 >>> 244 | 0 << -244) & -1);
        WurstFont.-1037124662 = invokedynamic(1390475295:(I)I, false);
        WurstFont.-11271924 = ((0 >>> 70 | 0 << -70) & -1);
        WurstFont.1284159678 = ((0 >>> 38 | 0 << ~0x26 + 1) & -1);
        WurstFont.-1918982088 = invokedynamic(-1534902228:(I)I, false);
        WurstFont.-930201064 = ((0 >>> 21 | 0 << ~0x15 + 1) & -1);
        WurstFont.-512541147 = invokedynamic(1062676251:(I)I, false);
        WurstFont.837082647 = invokedynamic(735206359:(I)I, 1048576);
        WurstFont.-1553397028 = (0 >>> 58 | 0 << ~0x3A + 1);
        WurstFont.953408249 = (0 >>> 110 | 0 << ~0x6E + 1);
        WurstFont.1355983434 = ((64 >>> 230 | 64 << -230) & -1);
        WurstFont.-881691210 = invokedynamic(815030481:(I)I, Integer.MIN_VALUE);
        WurstFont.904358658 = invokedynamic(1408279957:(I)I, Integer.MIN_VALUE);
        WurstFont.-1765705909 = ((8388608 >>> 23 | 8388608 << ~0x17 + 1) & -1);
        WurstFont.-962072942 = invokedynamic(-993645566:(I)I, 1073741824);
        WurstFont.-969721723 = (268435456 >>> 121 | 268435456 << -121);
        WurstFont.1200184741 = (114688 >>> 174 | 114688 << -174);
        WurstFont.138730030 = invokedynamic(-705749026:(I)I, -1073741824);
        WurstFont.-505605518 = (2097152 >>> 244 | 2097152 << ~0xF4 + 1);
        WurstFont.1879329094 = invokedynamic(-950463471:(I)I, -1073741824);
        WurstFont.-1360303251 = (1048576 >>> 116 | 1048576 << ~0x74 + 1);
        WurstFont.812582925 = ((49152 >>> 46 | 49152 << -46) & -1);
        WurstFont.1807262460 = invokedynamic(281130747:(I)I, Integer.MIN_VALUE);
        WurstFont.713814939 = invokedynamic(-602944947:(I)I, 536870912);
        WurstFont.-1399266880 = invokedynamic(-1235196784:(J)D, invokedynamic(1446617371:(J)J, 2L));
        WurstFont.491666770 = invokedynamic(-1327235352:(J)D, invokedynamic(-113298720:(J)J, 2L));
        WurstFont.1448879905 = invokedynamic(-1934674981:(J)D, invokedynamic(-1996080777:(J)J, 2L));
        WurstFont.-1476261942 = invokedynamic(-516662085:(J)D, invokedynamic(-674133586:(J)J, 3068L));
        WurstFont.-1455063820 = invokedynamic(-231479201:(J)D, invokedynamic(-242649543:(J)J, 3068L));
        WurstFont.1947003219 = invokedynamic(-1607737998:(J)D, invokedynamic(45124054:(J)J, 3068L));
        WurstFont.-886146660 = invokedynamic(-762479842:(I)F, 1288490301 >>> 8 | 1288490301 << -8);
        WurstFont.169549593 = invokedynamic(-695257838:(I)F, invokedynamic(-796609739:(I)I, -1288490308));
        WurstFont.680469685 = invokedynamic(-706740981:(I)F, invokedynamic(-1638929202:(I)I, -1288490308));
        WurstFont.-2004261844 = invokedynamic(-838450170:(I)F, invokedynamic(1693728798:(I)I, 65218));
        WurstFont.1586754969 = invokedynamic(359255847:(I)I, false);
        WurstFont.644415553 = invokedynamic(-1227728230:(I)F, (70774784 >>> 220 | 70774784 << -220) & -1);
        WurstFont.-1351786037 = invokedynamic(744050470:(I)F, (283099136 >>> 222 | 283099136 << ~0xDE + 1) & -1);
        WurstFont.343991850 = invokedynamic(-24668160:(I)F, invokedynamic(118368890:(I)I, 65218));
        WurstFont.-194092114 = invokedynamic(1749521259:(I)F, (17279 >>> 80 | 17279 << ~0x50 + 1) & -1);
        WurstFont.-375880381 = (8388608 >>> 183 | 8388608 << ~0xB7 + 1);
        WurstFont.1419829975 = invokedynamic(-195192687:(I)I, false);
        WurstFont.-276341570 = invokedynamic(-1977336474:(I)I, 1342177280);
        WurstFont.608684786 = invokedynamic(160910130:(I)I, 1073741824);
        WurstFont.1421461938 = invokedynamic(1141895913:(I)I, 1073741824);
        WurstFont.-798785125 = (0 >>> 2 | 0 << -2);
        WurstFont.-1034374108 = (0 >>> 43 | 0 << ~0x2B + 1);
        WurstFont.-1869944492 = (268435456 >>> 251 | 268435456 << ~0xFB + 1);
    }
    
    public static Object -653644952(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7, final Object o8, final Object o9) throws Exception {
        final int n = ((int)o ^ WurstFont.565027655) & 0xFF;
        final Integer value = WurstFont.335880405;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
    
    private class IntObject
    {
        public int width;
        public int height;
        public int storedX;
        public int storedY;
    }
}

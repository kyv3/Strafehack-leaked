// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.ui;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import net.minecraft.init.SoundEvents;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import net.minecraft.client.gui.GuiButton;

public class Button extends GuiButton
{
    protected static final ResourceLocation BUTTON_TEXTURES;
    protected int field_146120_f;
    protected int field_146121_g;
    public int field_146128_h;
    public int field_146129_i;
    public String field_146126_j;
    public int field_146127_k;
    public boolean field_146124_l;
    public boolean field_146125_m;
    public boolean field_146123_n;
    public int backColor;
    public int borderColor;
    private static String[] 1003091841;
    private static String[] -1321061760;
    private static long -1613616981;
    private static int 676032894;
    private static int -724308394;
    private static int 67365172;
    private static int 942592460;
    private static int -1540051923;
    private static int 1046524222;
    private static int -718452039;
    private static int 728349470;
    private static int 1692306555;
    private static int 50606396;
    private static int 2019067098;
    private static int 744620999;
    private static int 891020490;
    private static int 337335950;
    private static int -1063058607;
    private static int -351562910;
    private static int 486002561;
    private static int 420147304;
    private static int -117199214;
    private static int 1951244662;
    private static int 1060730328;
    private static int -38152796;
    private static int 1811289162;
    private static float 719664944;
    private static int -1928437779;
    private static int -1992519967;
    private static int 384841578;
    private static int -1584436239;
    private static int 618102083;
    private static int -537216122;
    private static int 1974321188;
    private static int 1121193365;
    private static int 39617271;
    private static int 2013945596;
    private static int 267299574;
    private static int 114401055;
    private static int 2072047933;
    private static int 955316681;
    private static int -1886867826;
    private static long -706712597;
    private static long -1225591023;
    private static int 1728772296;
    private static int -404918204;
    
    public Button(final int 614994126, final int -1160608728, final int -1866787697, final String 737141398) {
        this(614994126, -1160608728, -1866787697, Button.676032894, Button.-724308394, 737141398);
    }
    
    public Button(final int 1838368323, final int -1535796423, final int 1801484330, final int 496365415, final int 1171228499, final String 1846706414) {
        super(1838368323, -1535796423, 1801484330, Button.67365172, Button.942592460, 1846706414);
        this.field_146120_f = Button.-1540051923;
        this.field_146121_g = Button.1046524222;
        this.field_146124_l = (Button.-718452039 != 0);
        this.field_146125_m = (Button.728349470 != 0);
        this.field_146127_k = 1838368323;
        this.field_146128_h = -1535796423;
        this.field_146129_i = 1801484330;
        this.field_146120_f = 496365415;
        this.field_146121_g = 1171228499;
        this.field_146126_j = 1846706414;
    }
    
    protected int func_146114_a(final boolean 1481258915) {
        int 1481258916 = Button.1692306555;
        if (!this.field_146124_l) {
            1481258916 = Button.50606396;
        }
        else if (1481258915) {
            1481258916 = Button.2019067098;
        }
        return 1481258916;
    }
    
    public void func_191745_a(final Minecraft 160943350, final int -918213651, final int 1049897790, final float -1638601878) {
        if (this.field_146125_m) {
            final FontRenderer field_71466_p = 160943350.field_71466_p;
            if (!(this.field_146123_n = (((-918213651 >= this.field_146128_h && 1049897790 >= this.field_146129_i && -918213651 < this.field_146128_h + this.field_146120_f && 1049897790 < this.field_146129_i + this.field_146121_g) ? Button.744620999 : Button.891020490) != 0))) {
            }
            // invokedynamic(1380425572:(IIIII)V, this.field_146128_h, this.field_146129_i, this.field_146128_h + this.field_146120_f, this.field_146129_i + this.field_146121_g, this.backColor)
            else {
            }
            // invokedynamic(450680761:(IIIII)V, this.field_146128_h, this.field_146129_i, this.field_146128_h + this.field_146120_f, this.field_146129_i + this.field_146121_g, invokedynamic(1218978744:(I)I, this.backColor))
            // invokedynamic(97120458:(Ljava/lang/Object;IIII)V, this, this.field_146128_h, this.field_146128_h + this.field_146120_f - Button.337335950, this.field_146129_i, this.borderColor)
            // invokedynamic(-1663325964:(Ljava/lang/Object;IIII)V, this, this.field_146128_h, this.field_146128_h + this.field_146120_f - Button.-1063058607, this.field_146129_i + this.field_146121_g - Button.-351562910, this.borderColor)
            // invokedynamic(-656332369:(Ljava/lang/Object;IIII)V, this, this.field_146128_h, this.field_146129_i, this.field_146129_i + this.field_146121_g, this.borderColor)
            // invokedynamic(1717641583:(Ljava/lang/Object;IIII)V, this, this.field_146128_h + this.field_146120_f - Button.486002561, this.field_146129_i, this.field_146129_i + this.field_146121_g, this.borderColor)
        }
        // invokedynamic(-1064525330:(Ljava/lang/Object;III)V, this.field_146126_j, this.field_146128_h + this.field_146120_f / Button.420147304, this.field_146129_i + this.field_146121_g - Button.-117199214 / Button.1951244662, Button.1060730328)
    }
    
    private void drawCenteredStringWithoutShadow(final FontRenderer 1308771399, final String 740249486, final int -1344822758, final int -1254459243, final int 1668224699) {
    }
    // invokedynamic(1142426997:(Ljava/lang/Object;Ljava/lang/Object;FFIZ)I, 1308771399, 740249486, (float)-1344822758 - invokedynamic(-1256374037:(Ljava/lang/Object;Ljava/lang/Object;)I, 1308771399, 740249486) / Button.-38152796, (float)-1254459243, 1668224699, Button.1811289162)
    
    public static int returnDarkerColor(final int 1625354826) {
        final float 1625354827 = Button.719664944;
        final int n = 1625354826 >> Button.-1928437779 & Button.-1992519967;
        final int n2 = (int)((1625354826 >> Button.384841578 & Button.-1584436239) * 1625354827);
        final int n3 = (int)((1625354826 >> Button.618102083 & Button.-537216122) * 1625354827);
        final int n4 = (int)((1625354826 & Button.1974321188) * 1625354827);
        return n << Button.1121193365 | n2 << Button.39617271 | n3 << Button.2013945596 | n4;
    }
    
    protected void func_146119_b(final Minecraft -1817997942, final int 1200904359, final int 21593690) {
    }
    
    public void func_146118_a(final int 1273599300, final int -619579768) {
    }
    
    public boolean func_146116_c(final Minecraft 1365522465, final int 1211970810, final int 1715470369) {
        return ((this.field_146124_l && this.field_146125_m && 1211970810 >= this.field_146128_h && 1715470369 >= this.field_146129_i && 1211970810 < this.field_146128_h + this.field_146120_f && 1715470369 < this.field_146129_i + this.field_146121_g) ? Button.267299574 : Button.114401055) != 0;
    }
    
    public boolean func_146115_a() {
        return this.field_146123_n;
    }
    
    public void func_146111_b(final int 1601760377, final int -362824560) {
    }
    
    public void func_146113_a(final SoundHandler 695963734) {
    }
    // invokedynamic(-599314178:(Ljava/lang/Object;Ljava/lang/Object;)V, 695963734, invokedynamic(751893207:(Ljava/lang/Object;F)Lnet/minecraft/client/audio/PositionedSoundRecord;, SoundEvents.field_187909_gi, 1.0f))
    
    public int func_146117_b() {
        return this.field_146120_f;
    }
    
    public void func_175211_a(final int 1075361182) {
        this.field_146120_f = 1075361182;
    }
    
    static {
        Button.1728772296 = 1253139094;
        Button.-404918204 = 184;
        Button.676032894 = (13107200 >>> 16 | 13107200 << ~0x10 + 1);
        Button.-724308394 = invokedynamic(-1425849649:(I)I, 671088640);
        Button.67365172 = invokedynamic(920200881:(I)I, 318767104);
        Button.942592460 = (5242880 >>> 146 | 5242880 << ~0x92 + 1);
        Button.-1540051923 = invokedynamic(-1731643835:(I)I, 318767104);
        Button.1046524222 = ((2560 >>> 167 | 2560 << ~0xA7 + 1) & -1);
        Button.-718452039 = invokedynamic(-588277555:(I)I, Integer.MIN_VALUE);
        Button.728349470 = invokedynamic(-598866737:(I)I, Integer.MIN_VALUE);
        Button.1692306555 = (16384 >>> 78 | 16384 << -78);
        Button.50606396 = invokedynamic(-1177927342:(I)I, false);
        Button.2019067098 = invokedynamic(1128176345:(I)I, 1073741824);
        Button.744620999 = invokedynamic(-712367557:(I)I, Integer.MIN_VALUE);
        Button.891020490 = invokedynamic(90054040:(I)I, false);
        Button.337335950 = invokedynamic(-571500606:(I)I, Integer.MIN_VALUE);
        Button.-1063058607 = (2 >>> 225 | 2 << ~0xE1 + 1);
        Button.-351562910 = ((524288 >>> 51 | 524288 << -51) & -1);
        Button.486002561 = invokedynamic(-2040581847:(I)I, Integer.MIN_VALUE);
        Button.420147304 = (32768 >>> 46 | 32768 << ~0x2E + 1);
        Button.-117199214 = (1703936 >>> 177 | 1703936 << -177);
        Button.1951244662 = ((1024 >>> 233 | 1024 << ~0xE9 + 1) & -1);
        Button.1060730328 = invokedynamic(2023781618:(I)I, -256);
        Button.-38152796 = ((32 >>> 36 | 32 << -36) & -1);
        Button.1811289162 = (0 >>> 95 | 0 << ~0x5F + 1);
        Button.719664944 = invokedynamic(321505201:(I)F, invokedynamic(-1526441017:(I)I, -1288489220));
        Button.-1928437779 = (-2147483647 >>> 220 | -2147483647 << -220);
        Button.-1992519967 = invokedynamic(-40117240:(I)I, -16777216);
        Button.384841578 = ((1 >>> 28 | 1 << ~0x1C + 1) & -1);
        Button.-1584436239 = invokedynamic(-34272042:(I)I, -16777216);
        Button.618102083 = invokedynamic(-751372364:(I)I, 268435456);
        Button.-537216122 = invokedynamic(-1060489575:(I)I, -16777216);
        Button.1974321188 = invokedynamic(1040310530:(I)I, -16777216);
        Button.1121193365 = (6144 >>> 72 | 6144 << ~0x48 + 1);
        Button.39617271 = (16 >>> 192 | 16 << -192);
        Button.2013945596 = invokedynamic(402981557:(I)I, 268435456);
        Button.267299574 = (65536 >>> 208 | 65536 << -208);
        Button.114401055 = ((0 >>> 123 | 0 << -123) & -1);
        Button.2072047933 = invokedynamic(1511830905:(I)I, Integer.MIN_VALUE);
        Button.955316681 = ((536870912 >>> 29 | 536870912 << ~0x1D + 1) & -1);
        Button.-1886867826 = invokedynamic(356419472:(I)I, false);
        Button.-706712597 = invokedynamic(-1370531616:(J)J, 803743207192402261L);
        Button.-1225591023 = invokedynamic(-798131227:(J)J, -6052837899185946624L);
        Button.1003091841 = new String[Button.2072047933];
        Button.-1321061760 = new String[Button.955316681];
        // invokedynamic(-1419166758:()V)
        BUTTON_TEXTURES = new ResourceLocation(invokedynamic(-802132501:(IJ)Ljava/lang/String;, Button.-1886867826, Button.-706712597 ^ Button.-1225591023));
    }
    
    private static Object -574102452(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(Button.class, "-1820514869", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", Button.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/ui/Button:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String -1820514869(final int n, long n2) {
        n2 ^= 0x35L;
        n2 ^= 0x4516996C08EF630FL;
        if (Button.1003091841[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/ui/Button");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            Button.1003091841[n] = new String(instance.doFinal(Base64.getDecoder().decode(Button.-1321061760[n])));
        }
        return Button.1003091841[n];
    }
    
    private static void -38730092() {
        Button.-1613616981 = -6154051509142231856L;
        final long n = Button.-1613616981 ^ 0x4516996C08EF630FL;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    Button.-1321061760[0] = "GzMsaClyHnMpYqMRIZumRtXHY+FOG1b7zDBVEV3a5dI=";
                    break;
                }
                case 1: {
                    Button.-1321061760[0] = "GzMsaClyHnMpYqMRIZumRtXHY+FOG1b7wkyoypK7z9s=";
                    break;
                }
                case 2: {
                    Button.-1321061760[0] = "xHv4WjpBvDH+kCqzKLl+2w==";
                    break;
                }
                case 4: {
                    Button.-1321061760[0] = "1pXgIeU4Lv4XMS5EwZ59SL8beOtrJrSO";
                    break;
                }
            }
        }
    }
    
    public static Object -177526437(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6) throws Exception {
        final int n = ((int)o ^ Button.1728772296) & 0xFF;
        final Integer value = Button.-404918204;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

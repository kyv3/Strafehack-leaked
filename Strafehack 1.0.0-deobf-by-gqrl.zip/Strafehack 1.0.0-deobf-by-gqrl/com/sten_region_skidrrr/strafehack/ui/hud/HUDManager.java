// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.ui.hud;

import java.lang.invoke.MutableCallSite;
import javax.xml.bind.DatatypeConverter;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import com.sten_region_skidrrr.strafehack.module.Properties;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import java.util.Iterator;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import java.util.Collection;
import net.minecraft.client.Minecraft;
import java.util.Set;

public class HUDManager
{
    private static HUDManager instance;
    private Set<IRenderer> registeredRenderers;
    private Minecraft mc;
    private static int 1897314026;
    private static int 673167092;
    private static double 335278616;
    private static double -1410505035;
    private static int -1959633596;
    private static int 885106;
    
    private HUDManager() {
        this.registeredRenderers = invokedynamic(99891392:()Ljava/util/HashSet;);
        this.mc = invokedynamic(1901609313:()Lnet/minecraft/client/Minecraft;);
    }
    
    public static HUDManager getInstance() {
        if (HUDManager.instance != null) {
            return HUDManager.instance;
        }
        return HUDManager.instance = new HUDManager();
    }
    
    public void register(final IRenderer... 637101839) {
        for (int length = 637101839.length, i = HUDManager.1897314026; i < length; ++i) {
            final IRenderer 637101840 = 637101839[i];
        }
        // invokedynamic(763758408:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.registeredRenderers, 637101840)
    }
    
    public void unregister(final IRenderer... -2074562719) {
        for (int length = -2074562719.length, i = HUDManager.673167092; i < length; ++i) {
            final IRenderer 633497197 = -2074562719[i];
        }
        // invokedynamic(534811946:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.registeredRenderers, 633497197)
    }
    
    public Collection<IRenderer> getRegistereRenderers() {
        return invokedynamic(303605486:(Ljava/lang/Object;)Ljava/util/HashSet;, this.registeredRenderers);
    }
    
    public void openConfigScreen() {
    }
    // invokedynamic(-1231722075:(Ljava/lang/Object;Ljava/lang/Object;)V, this.mc, new HUDConfigScreen(this))
    
    @SubscribeEvent
    public void onRender2D(final RenderGameOverlayEvent -1030397039) {
        final Iterator iterator = invokedynamic(897094040:(Ljava/lang/Object;)Ljava/util/Iterator;, this.registeredRenderers);
        while (invokedynamic(-1878123216:(Ljava/lang/Object;)Z, iterator)) {
            final IRenderer 408140959 = (IRenderer)invokedynamic(-339145469:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
            this.callRenderer(408140959);
        }
    }
    
    private void callRenderer(final IRenderer 1584276607) {
        if (!invokedynamic(936968046:(Ljava/lang/Object;)Z, 1584276607)) {
            return;
        }
        final Properties 1584276608 = invokedynamic(104392521:(Ljava/lang/Object;)Lcom/sten_region_skidrrr/strafehack/module/Properties;, 1584276607);
        if (1584276608.pos == null) {
            1584276608.pos = invokedynamic(-615166347:(DD)Lcom/sten_region_skidrrr/strafehack/ui/hud/ScreenPosition;, HUDManager.335278616, HUDManager.-1410505035);
        }
    }
    // invokedynamic(642740567:(Ljava/lang/Object;Ljava/lang/Object;)V, 1584276607, 1584276608.pos)
    
    static {
        HUDManager.-1959633596 = -1043593121;
        HUDManager.885106 = 184;
        HUDManager.1897314026 = (0 >>> 118 | 0 << -118);
        HUDManager.673167092 = invokedynamic(-296965771:(I)I, false);
        HUDManager.335278616 = invokedynamic(-1255695003:(J)D, invokedynamic(-183146268:(J)J, 2044L));
        HUDManager.-1410505035 = invokedynamic(-1991019019:(J)D, invokedynamic(-1713173211:(J)J, 2044L));
        HUDManager.instance = null;
    }
    
    public static Object 1571688287(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7, final Object o8, final Object o9) throws Exception {
        final int n = ((int)o ^ HUDManager.-1959633596) & 0xFF;
        final Integer value = HUDManager.885106;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

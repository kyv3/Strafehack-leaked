// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.ui.hud;

import com.sten_region_skidrrr.strafehack.module.Properties;

public interface IRenderConfig
{
    void save();
    
    Properties load();
}

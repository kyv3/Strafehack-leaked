// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.ui.hud;

import java.util.function.Predicate;
import java.lang.invoke.MutableCallSite;
import javax.xml.bind.DatatypeConverter;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import java.util.Map;
import net.minecraft.client.gui.ScaledResolution;
import java.io.IOException;
import java.util.Iterator;
import java.util.Collection;
import java.util.Optional;
import com.sten_region_skidrrr.strafehack.module.Properties;
import java.util.HashMap;
import net.minecraft.client.gui.GuiScreen;

public class HUDConfigScreen extends GuiScreen
{
    private final HashMap<IRenderer, Properties> renderers;
    private Optional<IRenderer> selectedRenderer;
    private int prevX;
    private int prevY;
    private static double 1479188241;
    private static double 1484605227;
    private static float -285208833;
    private static int 1286892902;
    private static int -213205499;
    private static int -210342053;
    private static int 1034903606;
    private static int -1638852907;
    private static int 1632182470;
    private static int 1503396983;
    private static int -1994620275;
    private static int -1223646033;
    private static int 1141098729;
    private static int 1289514915;
    private static int -1893241817;
    private static int 602432192;
    private static int -1413330999;
    private static int 812728297;
    private static int -1156076448;
    private static int -1904667666;
    private static int -2118843464;
    
    public HUDConfigScreen(final HUDManager -371275115) {
        this.renderers = new HashMap<IRenderer, Properties>();
        this.selectedRenderer = invokedynamic(-1535923468:()Ljava/util/Optional;);
        final Collection<IRenderer> collection = invokedynamic(1925438214:(Ljava/lang/Object;)Ljava/util/Collection;, -371275115);
        final Iterator iterator = invokedynamic(-674773806:(Ljava/lang/Object;)Ljava/util/Iterator;, collection);
        while (invokedynamic(-2135928947:(Ljava/lang/Object;)Z, iterator)) {
            final IRenderer 1170846273 = (IRenderer)invokedynamic(-958977279:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
            if (!invokedynamic(1549613656:(Ljava/lang/Object;)Z, 1170846273)) {
                continue;
            }
            final Properties 1170846274 = invokedynamic(-1732486809:(Ljava/lang/Object;)Lcom/sten_region_skidrrr/strafehack/module/Properties;, 1170846273);
            if (1170846274.pos == null) {
                1170846274.pos = invokedynamic(-1748981170:(DD)Lcom/sten_region_skidrrr/strafehack/ui/hud/ScreenPosition;, HUDConfigScreen.1479188241, HUDConfigScreen.1484605227);
            }
            this.adjustBounds(1170846273, 1170846274.pos);
        }
        // invokedynamic(-1455731749:(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;, this.renderers, 1170846273, 1170846274)
    }
    
    public void func_73863_a(final int -758191547, final int -2134800813, final float -1016580316) {
        super.func_146276_q_();
        final float 198873481 = this.field_73735_i;
        this.field_73735_i = HUDConfigScreen.-285208833;
        // invokedynamic(714958752:(IIIIII)V, HUDConfigScreen.1286892902, HUDConfigScreen.-213205499, this.field_146294_l - HUDConfigScreen.-210342053, this.field_146295_m - HUDConfigScreen.1034903606, HUDConfigScreen.-1638852907, HUDConfigScreen.1632182470)
        final Iterator iterator = invokedynamic(404736051:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(-350516923:(Ljava/lang/Object;)Ljava/util/Set;, this.renderers));
        while (invokedynamic(-527987384:(Ljava/lang/Object;)Z, iterator)) {
            final IRenderer renderer = (IRenderer)invokedynamic(-977056749:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
            final Properties 198873482 = (Properties)invokedynamic(-89493917:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;, this.renderers, renderer);
        }
        // invokedynamic(1600416966:(Ljava/lang/Object;Ljava/lang/Object;)V, renderer, 198873482.pos)
        // invokedynamic(-1587924404:(IIIIII)V, invokedynamic(434561197:(Ljava/lang/Object;)I, 198873482.pos) - HUDConfigScreen.1503396983, invokedynamic(-1863083010:(Ljava/lang/Object;)I, 198873482.pos), invokedynamic(1824232028:(Ljava/lang/Object;)I, renderer) + HUDConfigScreen.-1994620275, invokedynamic(978839387:(Ljava/lang/Object;)I, renderer), HUDConfigScreen.-1223646033, HUDConfigScreen.1141098729)
        this.field_73735_i = 198873481;
    }
    
    private void drawHollowRect(final int -571681871, final int 334992406, final int -742787418, final int 2114489729, final int -889366395) {
    }
    // invokedynamic(1310118754:(Ljava/lang/Object;IIII)V, this, -571681871, -571681871 + -742787418, 334992406, -889366395)
    // invokedynamic(-1401550645:(Ljava/lang/Object;IIII)V, this, -571681871, -571681871 + -742787418, 334992406 + 2114489729, -889366395)
    // invokedynamic(441811142:(Ljava/lang/Object;IIII)V, this, -571681871, 334992406, 334992406 + 2114489729, -889366395)
    // invokedynamic(-263017163:(Ljava/lang/Object;IIII)V, this, -571681871 + -742787418, 334992406, 334992406 + 2114489729, -889366395)
    
    protected void func_73869_a(final char -75018607, final int -1790800885) throws IOException {
        if (-1790800885 == HUDConfigScreen.1289514915) {
        }
        // invokedynamic(-1182998953:(Ljava/lang/Object;Ljava/lang/Object;)V, invokedynamic(-1017446267:(Ljava/lang/Object;)Ljava/util/Set;, this.renderers), 1598366770 -> {
    return;
})
        // invokedynamic(1320516928:(Ljava/lang/Object;Ljava/lang/Object;)V, this.field_146297_k, null)
    }
    
    protected void func_146273_a(final int 1382898589, final int -885191201, final int -205145684, final long -613978078) {
        if (invokedynamic(63963913:(Ljava/lang/Object;)Z, this.selectedRenderer)) {
            this.moveSelectedRendererBy(1382898589 - this.prevX, -885191201 - this.prevY);
        }
        this.prevX = 1382898589;
        this.prevY = -885191201;
    }
    
    private void moveSelectedRendererBy(final int -59999600, final int -313058583) {
        final IRenderer 1837820533 = (IRenderer)invokedynamic(-876702333:(Ljava/lang/Object;)Ljava/lang/Object;, this.selectedRenderer);
        final Properties properties = (Properties)invokedynamic(-33102473:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;, this.renderers, 1837820533);
        // invokedynamic(1864737525:(Ljava/lang/Object;II)V, properties.pos, invokedynamic(175177822:(Ljava/lang/Object;)I, properties.pos) + -59999600, invokedynamic(1673883230:(Ljava/lang/Object;)I, properties.pos) + -313058583)
        this.adjustBounds(1837820533, properties.pos);
    }
    
    public void func_146281_b() {
        final Iterator iterator = invokedynamic(-2128098317:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(1594311944:(Ljava/lang/Object;)Ljava/util/Set;, this.renderers));
        while (invokedynamic(-919442282:(Ljava/lang/Object;)Z, iterator)) {
            final IRenderer renderer = (IRenderer)invokedynamic(-454603298:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
        }
        // invokedynamic(828616671:(Ljava/lang/Object;)V, renderer)
    }
    // invokedynamic(2091690451:()V)
    
    public boolean func_73868_f() {
        return HUDConfigScreen.-1893241817 != 0;
    }
    
    private void adjustBounds(final IRenderer -1095403204, final ScreenPosition -1976356103) {
        final ScaledResolution scaledResolution = new ScaledResolution(invokedynamic(-769212311:()Lnet/minecraft/client/Minecraft;));
        final int 557929657 = invokedynamic(-141108803:(Ljava/lang/Object;)I, scaledResolution);
        final int 557929658 = invokedynamic(466858049:(Ljava/lang/Object;)I, scaledResolution);
        final int 557929659 = invokedynamic(223908505:(II)I, HUDConfigScreen.602432192, invokedynamic(-2041306394:(II)I, invokedynamic(-1686055113:(Ljava/lang/Object;)I, -1976356103), invokedynamic(-1824410249:(II)I, 557929657 - invokedynamic(-517568878:(Ljava/lang/Object;)I, -1095403204), HUDConfigScreen.-1413330999)));
        final int 557929660 = invokedynamic(-589583766:(II)I, HUDConfigScreen.812728297, invokedynamic(-33000451:(II)I, invokedynamic(-1954308727:(Ljava/lang/Object;)I, -1976356103), invokedynamic(-950198514:(II)I, 557929658 - invokedynamic(-893640279:(Ljava/lang/Object;)I, -1095403204), HUDConfigScreen.-1156076448)));
    }
    // invokedynamic(-1504562894:(Ljava/lang/Object;II)V, -1976356103, 557929659, 557929660)
    
    protected void func_73864_a(final int -1319167408, final int -1977744480, final int -951894193) throws IOException {
        this.loadMouseOver(this.prevX = -1319167408, this.prevY = -1977744480);
    }
    
    private void loadMouseOver(final int 924042511, final int 175055324) {
        this.selectedRenderer = invokedynamic(-1118302660:(Ljava/lang/Object;)Ljava/util/Optional;, invokedynamic(1873493873:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/stream/Stream;, invokedynamic(-798230000:(Ljava/lang/Object;)Ljava/util/stream/Stream;, invokedynamic(1626078732:(Ljava/lang/Object;)Ljava/util/Set;, this.renderers)), new MouseOverFinder(924042511, 175055324)));
    }
    
    static {
        HUDConfigScreen.-1904667666 = 1027510555;
        HUDConfigScreen.-2118843464 = 184;
        HUDConfigScreen.1479188241 = invokedynamic(-94967637:(J)D, invokedynamic(1063124781:(J)J, 2044L));
        HUDConfigScreen.1484605227 = invokedynamic(-892929881:(J)D, invokedynamic(49513654:(J)J, 2044L));
        HUDConfigScreen.-285208833 = invokedynamic(268320771:(I)F, invokedynamic(134274463:(I)I, 4802));
        HUDConfigScreen.1286892902 = invokedynamic(-690414988:(I)I, false);
        HUDConfigScreen.-213205499 = (0 >>> 14 | 0 << -14);
        HUDConfigScreen.-210342053 = invokedynamic(-1159774279:(I)I, Integer.MIN_VALUE);
        HUDConfigScreen.1034903606 = ((524288 >>> 243 | 524288 << ~0xF3 + 1) & -1);
        HUDConfigScreen.-1638852907 = invokedynamic(-1812408413:(I)I, -256);
        HUDConfigScreen.1632182470 = (536862720 >>> 253 | 536862720 << -253);
        HUDConfigScreen.1503396983 = ((32 >>> 164 | 32 << ~0xA4 + 1) & -1);
        HUDConfigScreen.-1994620275 = ((1073741824 >>> 29 | 1073741824 << ~0x1D + 1) & -1);
        HUDConfigScreen.-1223646033 = invokedynamic(-1855464014:(I)I, -256);
        HUDConfigScreen.1141098729 = invokedynamic(-1827888809:(I)I, -16187137);
        HUDConfigScreen.1289514915 = (134217728 >>> 251 | 134217728 << -251);
        HUDConfigScreen.-1893241817 = (0 >>> 139 | 0 << ~0x8B + 1);
        HUDConfigScreen.602432192 = (0 >>> 134 | 0 << -134);
        HUDConfigScreen.-1413330999 = (0 >>> 21 | 0 << -21);
        HUDConfigScreen.812728297 = invokedynamic(-1173268808:(I)I, false);
        HUDConfigScreen.-1156076448 = invokedynamic(224869795:(I)I, false);
    }
    
    public static Object 1149954566(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7, final Object o8) throws Exception {
        final int n = ((int)o ^ HUDConfigScreen.-1904667666) & 0xFF;
        final Integer value = HUDConfigScreen.-2118843464;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
    
    private class MouseOverFinder implements Predicate<IRenderer>
    {
        private int mouseX;
        private int mouseY;
        private static int -30033534;
        private static int 892507215;
        
        public MouseOverFinder(final int -2126011382, final int -1393618992) {
            this.mouseX = -2126011382;
            this.mouseY = -1393618992;
        }
        
        @Override
        public boolean test(final IRenderer 1312026896) {
            final Properties 1312026897 = HUDConfigScreen.this.renderers.get(1312026896);
            final int 1312026898 = 1312026897.pos.getAbsoluteX();
            final int absoluteY = 1312026897.pos.getAbsoluteY();
            if (this.mouseX >= 1312026898 && this.mouseX <= 1312026898 + 1312026896.getWidth() && this.mouseY >= absoluteY && this.mouseY <= absoluteY + 1312026896.getHeight()) {
                return MouseOverFinder.-30033534 != 0;
            }
            return MouseOverFinder.892507215 != 0;
        }
        
        static {
            MouseOverFinder.-30033534 = Integer.reverse(Integer.MIN_VALUE);
            MouseOverFinder.892507215 = ((0 >>> 243 | 0 << ~0xF3 + 1) & -1);
        }
    }
}

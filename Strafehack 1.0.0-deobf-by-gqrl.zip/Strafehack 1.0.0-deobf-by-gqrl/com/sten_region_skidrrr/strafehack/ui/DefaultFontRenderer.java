// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.ui;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import java.util.List;
import java.util.Iterator;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import java.util.Locale;
import com.ibm.icu.text.ArabicShapingException;
import com.ibm.icu.text.Bidi;
import com.ibm.icu.text.ArabicShaping;
import net.minecraft.client.resources.IResource;
import java.io.IOException;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.renderer.texture.TextureManager;
import java.util.Random;
import net.minecraft.util.ResourceLocation;
import net.minecraft.client.resources.IResourceManagerReloadListener;

public class DefaultFontRenderer implements IResourceManagerReloadListener
{
    private static final ResourceLocation[] UNICODE_PAGE_LOCATIONS;
    private final int[] charWidth;
    public int FONT_HEIGHT;
    public Random fontRandom;
    private final byte[] glyphWidth;
    private final int[] colorCode;
    private final ResourceLocation locationFontTexture;
    private final TextureManager renderEngine;
    private float posX;
    private float posY;
    private boolean unicodeFlag;
    private boolean bidiFlag;
    private float red;
    private float blue;
    private float green;
    private float alpha;
    private int textColor;
    private boolean randomStyle;
    private boolean boldStyle;
    private boolean italicStyle;
    private boolean underlineStyle;
    private boolean strikethroughStyle;
    private static String[] 898803100;
    private static String[] 328005472;
    private static long -1373764231;
    private static int -1453150902;
    private static int 254060907;
    private static int 449599421;
    private static int 1849622715;
    private static int 448453425;
    private static int -1719897121;
    private static int 1293563697;
    private static int 1189723113;
    private static int 1908163595;
    private static int 1163820404;
    private static int 674345949;
    private static int -1756620832;
    private static int -1539836587;
    private static int -1471637786;
    private static int -987413141;
    private static int 338693874;
    private static int 316249348;
    private static int -1072391832;
    private static int -454257820;
    private static int 331267119;
    private static int -1011105741;
    private static int 1062007202;
    private static int -95496059;
    private static int -1473979772;
    private static int -499237829;
    private static int -835071219;
    private static int -1392794881;
    private static int 943192502;
    private static int 1813599004;
    private static int -1578657598;
    private static int 1698204515;
    private static int 1633137594;
    private static int 1944475859;
    private static int -1512283139;
    private static int -1870032964;
    private static int 115648802;
    private static int -1746567409;
    private static int 1921188038;
    private static int -716611144;
    private static int 2114191371;
    private static int 67517030;
    private static int -122797165;
    private static int -513997826;
    private static int 1874446950;
    private static float -2141955285;
    private static int 955046710;
    private static int 1965429457;
    private static int 603800558;
    private static int 812632689;
    private static int -2017023537;
    private static int 1328935291;
    private static int 1167846246;
    private static int 1408829336;
    private static int 1512581215;
    private static int 1084832359;
    private static int 927000521;
    private static int 1303823511;
    private static double 109013498;
    private static int 287720196;
    private static int -1352561517;
    private static long -1557011994;
    private static long 2087395094;
    private static int 331557751;
    private static float -1324596318;
    private static int 105092698;
    private static long -539026635;
    private static long -1025199296;
    private static int -1992028866;
    private static int -1741808781;
    private static int -1355021701;
    private static int -1691755655;
    private static int 1491608937;
    private static int 1032330164;
    private static int 2013576140;
    private static int 867530460;
    private static float 716063613;
    private static int -1285269350;
    private static float -542818256;
    private static float 1373893244;
    private static float -605158025;
    private static float -799377377;
    private static float -1868452578;
    private static float -1477367034;
    private static float 1747659578;
    private static float 744075672;
    private static float 1187851497;
    private static float -1203041778;
    private static float 1408779989;
    private static float -947784204;
    private static int -488620264;
    private static int 1985601658;
    private static long -2120435923;
    private static int -804873137;
    private static int 411281260;
    private static int -380744251;
    private static int 857744730;
    private static int 294498048;
    private static int -595854382;
    private static int 314276461;
    private static int -1478232489;
    private static int 1909769837;
    private static int -1980749507;
    private static int 304652800;
    private static int 1770500495;
    private static float 2087839818;
    private static int 1169876792;
    private static float -1865743087;
    private static float 1254283349;
    private static float -1090891920;
    private static float -1605825873;
    private static float -1437672188;
    private static float 1542444372;
    private static float 321413922;
    private static float -280828612;
    private static float 1168622080;
    private static float 230186509;
    private static float 1077114130;
    private static float 1890623882;
    private static int 701986049;
    private static int -1444282210;
    private static int -1476647955;
    private static int -1439367578;
    private static int 898187629;
    private static int 835912814;
    private static int 2029190771;
    private static int 1350998234;
    private static int 1205071217;
    private static int -194664068;
    private static int 348908411;
    private static int 200263673;
    private static int -723276621;
    private static int -787904648;
    private static int -452852760;
    private static int -1905339005;
    private static int 1526672307;
    private static int -2140249020;
    private static int 129500960;
    private static int -2021398559;
    private static int -20861638;
    private static long -446026325;
    private static int 997049004;
    private static int -196496190;
    private static int -72063343;
    private static int -858952217;
    private static int -1877282383;
    private static int 1862862030;
    private static int -1587269975;
    private static int 1096027086;
    private static int 259137801;
    private static int -866058454;
    private static int 575158032;
    private static float 1952941104;
    private static int -1026637499;
    private static int 614274211;
    private static float 2085735197;
    private static int 434871327;
    private static float -126778924;
    private static int -512235540;
    private static int 187830947;
    private static int -1543071560;
    private static int -413210913;
    private static int -1885196578;
    private static int 1946280844;
    private static int -1028356161;
    private static int -808413401;
    private static int -2057613812;
    private static int -1372634685;
    private static int 430906890;
    private static int -973074628;
    private static int 894634260;
    private static int -1348471915;
    private static int -1989017609;
    private static int -826061099;
    private static int 1597984340;
    private static int -625190533;
    private static long -83979946;
    private static int 812340247;
    private static int -924973772;
    private static long 546719212;
    private static long 2002200244;
    private static int -1078953918;
    private static int 1556965377;
    private static long -997195022;
    private static float 841664975;
    private static int -1347701215;
    private static int 905714767;
    private static int 841197324;
    private static int -1603516927;
    private static int -213521724;
    private static int 246582283;
    private static int 1629485213;
    private static int -1816703672;
    private static int -1230639345;
    private static int 193571795;
    private static int 969661664;
    private static int -831742397;
    private static int 1843738394;
    private static int -426407100;
    private static int -1101705964;
    private static int 1029625663;
    private static int 20971521;
    private static int 1143015628;
    private static int -1526643807;
    private static float 367475671;
    private static int -1115412612;
    private static int 571201062;
    private static float 907315648;
    private static int -1019323912;
    private static float 709390555;
    private static int 74272226;
    private static int 188531389;
    private static float -1021349709;
    private static int 743696424;
    private static int 900276168;
    private static int -1945037152;
    private static int 1773886833;
    private static int 872041580;
    private static int -789917758;
    private static int 606287899;
    private static int 625833794;
    private static int -1573899014;
    private static int -1300642643;
    private static int -1252521161;
    private static int -137257524;
    private static int -1677527038;
    private static int 2103013241;
    private static int -1848148599;
    private static int 251226888;
    private static int -1242483311;
    private static long -1692478925;
    private static long -724314126;
    private static int -3478804;
    private static int -1948874377;
    private static int 65436662;
    private static int -1810819144;
    private static int 263155024;
    private static int 1003917727;
    private static int 455184740;
    private static int 591171472;
    private static int -1666912223;
    private static int -562527499;
    private static int 454590311;
    private static int 568255449;
    private static int 1974873037;
    private static int 1207791671;
    private static int -1960286972;
    private static int 41514959;
    private static int 1856951787;
    private static int 1673267604;
    private static int -704058655;
    private static int 1358447145;
    private static int 111525544;
    private static int 1985374168;
    private static int 2119893591;
    private static int -997449816;
    private static int -679005536;
    private static int -341684635;
    private static long 698907838;
    private static int 681212998;
    private static int 530785939;
    private static int 283566964;
    private static int 1284660843;
    private static long -1925767797;
    private static long -100990464;
    private static int -482029747;
    private static int 199707579;
    private static int -472230925;
    private static int -1231515295;
    private static int 798858860;
    private static int -335930534;
    private static int 138530062;
    private static int -87314659;
    private static long -1594668717;
    private static long -267935421;
    private static int -226309644;
    private static int 270950746;
    private static int 455020651;
    private static int -1745934193;
    private static int -44935216;
    private static int -333121991;
    private static int -1499116432;
    private static int 928007183;
    private static int -1951968517;
    private static int -407417858;
    private static int -574743475;
    private static int 1304581735;
    private static int -1213284445;
    private static int 285983960;
    private static int 1764598494;
    private static int 1278312757;
    private static int 2114452709;
    private static int -1892850863;
    private static int -818895923;
    private static int 1264075310;
    private static int -393076374;
    private static int 2056900899;
    private static int 1018530334;
    private static int -1089010893;
    private static int 1112455095;
    private static int -60475535;
    private static int 258186620;
    private static int 767710563;
    private static int 1353662555;
    private static int -414797356;
    private static long 1790964437;
    private static long 244292876;
    private static int -921186043;
    private static int -699221793;
    private static int 638899756;
    private static int -742980479;
    private static int 938375914;
    private static int -845646242;
    private static int 1390745;
    private static long 1375430100;
    private static long 1891256302;
    private static int -621089176;
    private static long 1306892678;
    private static int -1518622047;
    private static long -441965283;
    private static int -740987382;
    private static int 1228133838;
    private static int -1245954017;
    private static int 1592755514;
    private static int 1146016243;
    private static int 124033335;
    
    public DefaultFontRenderer(final GameSettings -1264568947, final ResourceLocation -1132826743, final TextureManager 513021500, final boolean 1902684334) {
        this.charWidth = new int[DefaultFontRenderer.-1453150902];
        this.FONT_HEIGHT = DefaultFontRenderer.254060907;
        this.fontRandom = new Random();
        this.glyphWidth = new byte[DefaultFontRenderer.449599421];
        this.colorCode = new int[DefaultFontRenderer.1849622715];
        this.locationFontTexture = -1132826743;
        this.renderEngine = 513021500;
        this.unicodeFlag = 1902684334;
        // invokedynamic(-1811876215:(Ljava/lang/Object;Ljava/lang/Object;)V, 513021500, this.locationFontTexture)
        for (int 1902684335 = DefaultFontRenderer.448453425; 1902684335 < DefaultFontRenderer.-1719897121; ++1902684335) {
            final int 1902684336 = (1902684335 >> DefaultFontRenderer.1293563697 & DefaultFontRenderer.1189723113) * DefaultFontRenderer.1908163595;
            int 1902684337 = (1902684335 >> DefaultFontRenderer.1163820404 & DefaultFontRenderer.674345949) * DefaultFontRenderer.-1756620832 + 1902684336;
            int 1902684338 = (1902684335 >> DefaultFontRenderer.-1539836587 & DefaultFontRenderer.-1471637786) * DefaultFontRenderer.-987413141 + 1902684336;
            int n = (1902684335 >> DefaultFontRenderer.338693874 & DefaultFontRenderer.316249348) * DefaultFontRenderer.-1072391832 + 1902684336;
            if (1902684335 == DefaultFontRenderer.-454257820) {
                1902684337 += 85;
            }
            if (-1264568947.field_74337_g) {
                final int n2 = (1902684337 * DefaultFontRenderer.331267119 + 1902684338 * DefaultFontRenderer.-1011105741 + n * DefaultFontRenderer.1062007202) / DefaultFontRenderer.-95496059;
                final int 1902684339 = (1902684337 * DefaultFontRenderer.-1473979772 + 1902684338 * DefaultFontRenderer.-499237829) / DefaultFontRenderer.-835071219;
                final int 1902684340 = (1902684337 * DefaultFontRenderer.-1392794881 + n * DefaultFontRenderer.943192502) / DefaultFontRenderer.1813599004;
                1902684337 = n2;
                1902684338 = 1902684339;
                n = 1902684340;
            }
            if (1902684335 >= DefaultFontRenderer.-1578657598) {
                1902684337 /= DefaultFontRenderer.1698204515;
                1902684338 /= DefaultFontRenderer.1633137594;
                n /= DefaultFontRenderer.1944475859;
            }
            this.colorCode[1902684335] = ((1902684337 & DefaultFontRenderer.-1512283139) << DefaultFontRenderer.-1870032964 | (1902684338 & DefaultFontRenderer.115648802) << DefaultFontRenderer.-1746567409 | (n & DefaultFontRenderer.1921188038));
        }
        this.readGlyphSizes();
    }
    
    public void func_110549_a(final IResourceManager -1250756158) {
        this.readFontTexture();
        this.readGlyphSizes();
    }
    
    private void readFontTexture() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: astore_1        /* 414908115 */
        //     2: invokedynamic   BootstrapMethod #1, -1919948257:()Lnet/minecraft/client/Minecraft;
        //     7: invokedynamic   BootstrapMethod #2, 264221553:(Ljava/lang/Object;)Lnet/minecraft/client/resources/IResourceManager;
        //    12: aload_0         /* 1038301240 */
        //    13: getfield        com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer.locationFontTexture:Lnet/minecraft/util/ResourceLocation;
        //    16: invokedynamic   BootstrapMethod #3, 1563442897:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/client/resources/IResource;
        //    21: astore_1        /* 414908115 */
        //    22: aload_1         /* 414908115 */
        //    23: invokedynamic   BootstrapMethod #4, 803343198:(Ljava/lang/Object;)Ljava/io/InputStream;
        //    28: invokedynamic   BootstrapMethod #5, 949110739:(Ljava/lang/Object;)Ljava/awt/image/BufferedImage;
        //    33: astore_2        /* 399411207 */
        //    34: aload_1         /* 414908115 */
        //    35: invokedynamic   BootstrapMethod #6, -1576249138:(Ljava/lang/Object;)V
        //    40: goto            64
        //    43: astore_3        /* 356137826 */
        //    44: new             Ljava/lang/RuntimeException;
        //    47: dup            
        //    48: aload_3         /* 356137826 */
        //    49: invokespecial   java/lang/RuntimeException.<init>:(Ljava/lang/Throwable;)V
        //    52: athrow         
        //    53: astore          4
        //    55: aload_1         /* 414908115 */
        //    56: invokedynamic   BootstrapMethod #7, -227154581:(Ljava/lang/Object;)V
        //    61: aload           4
        //    63: athrow         
        //    64: aload_2         /* 1254108535 */
        //    65: invokedynamic   BootstrapMethod #8, -1589378472:(Ljava/lang/Object;)I
        //    70: istore_3        /* 759809293 */
        //    71: aload_2         /* 1254108535 */
        //    72: invokedynamic   BootstrapMethod #9, 2044561400:(Ljava/lang/Object;)I
        //    77: istore          1101325033
        //    79: iload_3         /* 759809293 */
        //    80: iload           1101325033
        //    82: imul           
        //    83: newarray        I
        //    85: astore          986374465
        //    87: aload_2         /* 1254108535 */
        //    88: getstatic       com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer.-716611144:I
        //    91: getstatic       com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer.2114191371:I
        //    94: iload_3         /* 759809293 */
        //    95: iload           1101325033
        //    97: aload           986374465
        //    99: getstatic       com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer.67517030:I
        //   102: iload_3         /* 759809293 */
        //   103: invokedynamic   BootstrapMethod #10, -1939621329:(Ljava/lang/Object;IIII[III)[I
        //   108: checkcast       [I
        //   111: pop            
        //   112: iload           1101325033
        //   114: getstatic       com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer.-122797165:I
        //   117: idiv           
        //   118: istore          509485986
        //   120: iload_3         /* 759809293 */
        //   121: getstatic       com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer.-513997826:I
        //   124: idiv           
        //   125: istore          -570980809
        //   127: getstatic       com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer.1874446950:I
        //   130: istore          1189242697
        //   132: getstatic       com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer.-2141955285:F
        //   135: iload           -570980809
        //   137: i2f            
        //   138: fdiv           
        //   139: fstore          2102522107
        //   141: getstatic       com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer.955046710:I
        //   144: istore          -951861672
        //   146: iload           -951861672
        //   148: getstatic       com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer.1965429457:I
        //   151: if_icmpge       321
        //   154: iload           -951861672
        //   156: getstatic       com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer.603800558:I
        //   159: irem           
        //   160: istore          -1523100690
        //   162: iload           -951861672
        //   164: getstatic       com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer.812632689:I
        //   167: idiv           
        //   168: istore          -2067548557
        //   170: iload           -951861672
        //   172: getstatic       com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer.-2017023537:I
        //   175: if_icmpne       188
        //   178: aload_0         /* 1038301240 */
        //   179: getfield        com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer.charWidth:[I
        //   182: iload           -951861672
        //   184: getstatic       com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer.1328935291:I
        //   187: iastore        
        //   188: iload           -570980809
        //   190: getstatic       com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer.1167846246:I
        //   193: isub           
        //   194: istore          -261375021
        //   196: iload           -261375021
        //   198: iflt            289
        //   201: iload           -1523100690
        //   203: iload           -570980809
        //   205: imul           
        //   206: iload           -261375021
        //   208: iadd           
        //   209: istore          168424765
        //   211: getstatic       com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer.1408829336:I
        //   214: istore          1390061203
        //   216: getstatic       com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer.1512581215:I
        //   219: istore          -760033248
        //   221: iload           -760033248
        //   223: iload           509485986
        //   225: if_icmpge       275
        //   228: iload           1390061203
        //   230: ifeq            275
        //   233: iload           -2067548557
        //   235: iload           -570980809
        //   237: imul           
        //   238: iload           -760033248
        //   240: iadd           
        //   241: iload_3         /* 759809293 */
        //   242: imul           
        //   243: istore          -1616116858
        //   245: aload           986374465
        //   247: iload           168424765
        //   249: iload           -1616116858
        //   251: iadd           
        //   252: iaload         
        //   253: getstatic       com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer.1084832359:I
        //   256: ishr           
        //   257: getstatic       com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer.927000521:I
        //   260: iand           
        //   261: ifeq            269
        //   264: getstatic       com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer.1303823511:I
        //   267: istore          1390061203
        //   269: iinc            -760033248, 1
        //   272: goto            221
        //   275: iload           1390061203
        //   277: ifne            283
        //   280: goto            289
        //   283: iinc            -261375021, -1
        //   286: goto            196
        //   289: iinc            -261375021, 1
        //   292: aload_0         /* 1038301240 */
        //   293: getfield        com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer.charWidth:[I
        //   296: iload           -951861672
        //   298: getstatic       com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer.109013498:D
        //   301: iload           -261375021
        //   303: i2f            
        //   304: fload           2102522107
        //   306: fmul           
        //   307: f2d            
        //   308: dadd           
        //   309: d2i            
        //   310: getstatic       com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer.287720196:I
        //   313: iadd           
        //   314: iastore        
        //   315: iinc            -951861672, 1
        //   318: goto            146
        //   321: return         
        //    StackMapTable: 00 0C FF 00 2B 00 02 07 00 03 07 02 EE 00 01 07 02 10 49 07 02 F0 FC 00 0A 07 02 F2 FF 00 51 00 0B 07 00 03 07 02 EE 07 02 F2 01 01 07 02 B1 01 01 01 02 01 00 00 FD 00 29 01 01 FC 00 07 01 FE 00 18 01 01 01 FC 00 2F 01 FA 00 05 07 F8 00 05 F8 00 1F
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  2      34     43     53     Ljava/io/IOException;
        //  2      34     53     64     Any
        //  43     55     53     64     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.NullPointerException
        //     at com.strobel.decompiler.ast.AstBuilder.convertLocalVariables(AstBuilder.java:2895)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2445)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private void readGlyphSizes() {
        IResource resource = null;
        try {
            resource = invokedynamic(865338202:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/client/resources/IResource;, invokedynamic(309071283:(Ljava/lang/Object;)Lnet/minecraft/client/resources/IResourceManager;, invokedynamic(1421819917:()Lnet/minecraft/client/Minecraft;)), new ResourceLocation(invokedynamic(1442372269:(IJ)Ljava/lang/String;, DefaultFontRenderer.-1352561517, DefaultFontRenderer.-1557011994 ^ DefaultFontRenderer.2087395094)));
        }
        // invokedynamic(1972999119:(Ljava/lang/Object;[B)I, invokedynamic(-451202769:(Ljava/lang/Object;)Ljava/io/InputStream;, resource), this.glyphWidth)
        catch (IOException cause) {
            throw new RuntimeException(cause);
        }
        finally {
        }
        // invokedynamic(1177624177:(Ljava/lang/Object;)V, resource)
    }
    
    private float renderChar(final char 1228679329, final boolean -698998791) {
        if (1228679329 == DefaultFontRenderer.331557751) {
            return DefaultFontRenderer.-1324596318;
        }
        final int -698998792 = invokedynamic(-373362441:(Ljava/lang/Object;I)I, invokedynamic(-720886028:(IJ)Ljava/lang/String;, DefaultFontRenderer.105092698, DefaultFontRenderer.-539026635 ^ DefaultFontRenderer.-1025199296), 1228679329);
        return (-698998792 != DefaultFontRenderer.-1992028866 && !this.unicodeFlag) ? this.renderDefaultChar(-698998792, -698998791) : this.renderUnicodeChar(1228679329, -698998791);
    }
    
    public void drawCenteredString(final String -1246243135, final int -1986948718, final int 1034408890, final int 518033970) {
    }
    // invokedynamic(875716716:(Ljava/lang/Object;Ljava/lang/Object;III)I, this, -1246243135, -1986948718 - invokedynamic(-970004361:(Ljava/lang/Object;Ljava/lang/Object;)I, this, -1246243135) / DefaultFontRenderer.-1741808781, 1034408890, 518033970)
    
    private float renderDefaultChar(final int -555141254, final boolean -1107609936) {
        final int 2042936116 = -555141254 % DefaultFontRenderer.-1355021701 * DefaultFontRenderer.-1691755655;
        final int n = -555141254 / DefaultFontRenderer.1491608937 * DefaultFontRenderer.1032330164;
        final int 2042936117 = -1107609936 ? DefaultFontRenderer.2013576140 : DefaultFontRenderer.867530460;
        // invokedynamic(-1206553509:(Ljava/lang/Object;Ljava/lang/Object;)V, this.renderEngine, this.locationFontTexture)
        final int 2042936118 = this.charWidth[-555141254];
        final float 2042936119 = 2042936118 - DefaultFontRenderer.716063613;
        // invokedynamic(-642796853:(I)V, DefaultFontRenderer.-1285269350)
        // invokedynamic(1150644129:(FF)V, (float)2042936116 / DefaultFontRenderer.-542818256, (float)n / DefaultFontRenderer.1373893244)
        // invokedynamic(-1814399128:(FFF)V, this.posX + (float)2042936117, this.posY, 0.0f)
        // invokedynamic(615527572:(FF)V, (float)2042936116 / DefaultFontRenderer.-605158025, (float)n + DefaultFontRenderer.-799377377 / DefaultFontRenderer.-1868452578)
        // invokedynamic(-627585266:(FFF)V, this.posX - (float)2042936117, this.posY + DefaultFontRenderer.-1477367034, 0.0f)
        // invokedynamic(-821001150:(FF)V, (float)2042936116 + 2042936119 - 1.0f / DefaultFontRenderer.1747659578, (float)n / DefaultFontRenderer.744075672)
        // invokedynamic(568419900:(FFF)V, this.posX + 2042936119 - 1.0f + (float)2042936117, this.posY, 0.0f)
        // invokedynamic(-63192291:(FF)V, (float)2042936116 + 2042936119 - 1.0f / DefaultFontRenderer.1187851497, (float)n + DefaultFontRenderer.-1203041778 / DefaultFontRenderer.1408779989)
        // invokedynamic(1902460892:(FFF)V, this.posX + 2042936119 - 1.0f - (float)2042936117, this.posY + DefaultFontRenderer.-947784204, 0.0f)
        // invokedynamic(1210671136:()V)
        return (float)2042936118;
    }
    
    private ResourceLocation getUnicodePageLocation(final int 414804053) {
        if (DefaultFontRenderer.UNICODE_PAGE_LOCATIONS[414804053] == null) {
            final ResourceLocation[] unicode_PAGE_LOCATIONS = DefaultFontRenderer.UNICODE_PAGE_LOCATIONS;
            final String s = invokedynamic(-1353850441:(IJ)Ljava/lang/String;, DefaultFontRenderer.-488620264 & DefaultFontRenderer.1985601658, DefaultFontRenderer.-2120435923);
            final Object[] array = new Object[DefaultFontRenderer.-804873137];
            array[DefaultFontRenderer.411281260] = invokedynamic(-1930806200:(I)Ljava/lang/Integer;, 414804053);
            unicode_PAGE_LOCATIONS[414804053] = new ResourceLocation(invokedynamic(1133405618:(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/String;, s, array));
        }
        return DefaultFontRenderer.UNICODE_PAGE_LOCATIONS[414804053];
    }
    
    private void loadGlyphTexture(final int 606218505) {
    }
    // invokedynamic(1329152837:(Ljava/lang/Object;Ljava/lang/Object;)V, this.renderEngine, this.getUnicodePageLocation(606218505))
    
    private float renderUnicodeChar(final char 171582117, final boolean 1655819549) {
        final int n = this.glyphWidth[171582117] & DefaultFontRenderer.-380744251;
        if (n == 0) {
            return 0.0f;
        }
        final int 1655819550 = 171582117 / DefaultFontRenderer.857744730;
        this.loadGlyphTexture(1655819550);
        final int 1655819551 = n >>> DefaultFontRenderer.294498048;
        final int n2 = n & DefaultFontRenderer.-595854382;
        final float 1655819552 = (float)1655819551;
        final float n3 = (float)(n2 + DefaultFontRenderer.314276461);
        final float 1655819553 = 171582117 % DefaultFontRenderer.-1478232489 * DefaultFontRenderer.1909769837 + 1655819552;
        final float n4 = (float)((171582117 & DefaultFontRenderer.-1980749507) / DefaultFontRenderer.304652800 * DefaultFontRenderer.1770500495);
        final float 1655819554 = n3 - 1655819552 - DefaultFontRenderer.2087839818;
        final float n5 = 1655819549 ? 1.0f : 0.0f;
        // invokedynamic(2141391182:(I)V, DefaultFontRenderer.1169876792)
        // invokedynamic(-1176238090:(FF)V, 1655819553 / DefaultFontRenderer.-1865743087, n4 / DefaultFontRenderer.1254283349)
        // invokedynamic(-798557951:(FFF)V, this.posX + n5, this.posY, 0.0f)
        // invokedynamic(2011436547:(FF)V, 1655819553 / DefaultFontRenderer.-1090891920, n4 + DefaultFontRenderer.-1605825873 / DefaultFontRenderer.-1437672188)
        // invokedynamic(1533018213:(FFF)V, this.posX - n5, this.posY + DefaultFontRenderer.1542444372, 0.0f)
        // invokedynamic(1725609953:(FF)V, 1655819553 + 1655819554 / DefaultFontRenderer.321413922, n4 / DefaultFontRenderer.-280828612)
        // invokedynamic(-1935037520:(FFF)V, this.posX + 1655819554 / 2.0f + n5, this.posY, 0.0f)
        // invokedynamic(-723613455:(FF)V, 1655819553 + 1655819554 / DefaultFontRenderer.1168622080, n4 + DefaultFontRenderer.230186509 / DefaultFontRenderer.1077114130)
        // invokedynamic(269543235:(FFF)V, this.posX + 1655819554 / 2.0f - n5, this.posY + DefaultFontRenderer.1890623882, 0.0f)
        // invokedynamic(2105914403:()V)
        return (n3 - 1655819552) / 2.0f + 1.0f;
    }
    
    public int drawStringWithShadow(final String -206693228, final float -1415533969, final float -604633356, final int 1449167669) {
        return invokedynamic(-420463535:(Ljava/lang/Object;Ljava/lang/Object;FFIZ)I, this, -206693228, -1415533969, -604633356, 1449167669, DefaultFontRenderer.701986049);
    }
    
    public void drawCenteredStringWithShadow(final String -1129047195, final int 348782496, final int 1809682719, final int -2118718025) {
    }
    // invokedynamic(-344323161:(Ljava/lang/Object;Ljava/lang/Object;FFIZ)I, this, -1129047195, (float)348782496 - invokedynamic(-2096641165:(Ljava/lang/Object;Ljava/lang/Object;)I, this, -1129047195) / DefaultFontRenderer.-1444282210, (float)1809682719, -2118718025, DefaultFontRenderer.-1476647955)
    
    public int drawString(final String -853873128, final int -1416873622, final int 2125144187, final int -618534053) {
        return invokedynamic(-1121121623:(Ljava/lang/Object;Ljava/lang/Object;FFIZ)I, this, -853873128, (float)-1416873622, (float)2125144187, -618534053, DefaultFontRenderer.-1439367578);
    }
    
    public int drawString(final String -672366992, final float -1484952159, final float -1442346415, final int 588234044, final boolean -1696272110) {
        // invokedynamic(-1618841119:()V)
        this.resetStyles();
        int n = DefaultFontRenderer.898187629;
        if (-1696272110) {
            n = this.renderString(-672366992, -1484952159 + 1.0f, -1442346415 + 1.0f, 588234044, (boolean)(DefaultFontRenderer.835912814 != 0));
            n = invokedynamic(1955424044:(II)I, n, this.renderString(-672366992, -1484952159, -1442346415, 588234044, (boolean)(DefaultFontRenderer.2029190771 != 0)));
        }
        else {
            n = this.renderString(-672366992, -1484952159, -1442346415, 588234044, (boolean)(DefaultFontRenderer.1350998234 != 0));
        }
        return n;
    }
    
    private String bidiReorder(final String -92814584) {
        try {
            final Bidi 666970400 = new Bidi(invokedynamic(-1431061208:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/String;, new ArabicShaping(DefaultFontRenderer.1205071217), -92814584), DefaultFontRenderer.-194664068);
            // invokedynamic(1212490594:(Ljava/lang/Object;I)V, 666970400, DefaultFontRenderer.348908411)
            return invokedynamic(1786473553:(Ljava/lang/Object;I)Ljava/lang/String;, 666970400, DefaultFontRenderer.200263673);
        }
        catch (ArabicShapingException 666970401) {
            return -92814584;
        }
    }
    
    private void resetStyles() {
        this.randomStyle = (DefaultFontRenderer.-723276621 != 0);
        this.boldStyle = (DefaultFontRenderer.-787904648 != 0);
        this.italicStyle = (DefaultFontRenderer.-452852760 != 0);
        this.underlineStyle = (DefaultFontRenderer.-1905339005 != 0);
        this.strikethroughStyle = (DefaultFontRenderer.1526672307 != 0);
    }
    
    private void renderStringAtPos(final String 1945824642, final boolean -154956535) {
        for (int i = DefaultFontRenderer.-2140249020; i < invokedynamic(-847789010:(Ljava/lang/Object;)I, 1945824642); ++i) {
            char 1945824643 = invokedynamic(1166683170:(Ljava/lang/Object;I)C, 1945824642, i);
            if (1945824643 == DefaultFontRenderer.129500960 && i + DefaultFontRenderer.-2021398559 < invokedynamic(1744148115:(Ljava/lang/Object;)I, 1945824642)) {
                int -154956536 = invokedynamic(1117960103:(Ljava/lang/Object;I)I, invokedynamic(-1583065143:(IJ)Ljava/lang/String;, DefaultFontRenderer.-20861638, DefaultFontRenderer.-446026325), invokedynamic(1627534854:(Ljava/lang/Object;I)C, invokedynamic(2133998257:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-1591735207:(C)Ljava/lang/String;, invokedynamic(-199978394:(Ljava/lang/Object;I)C, 1945824642, i + DefaultFontRenderer.997049004)), Locale.ROOT), DefaultFontRenderer.-196496190));
                if (-154956536 < DefaultFontRenderer.-72063343) {
                    this.randomStyle = (DefaultFontRenderer.-858952217 != 0);
                    this.boldStyle = (DefaultFontRenderer.-1877282383 != 0);
                    this.strikethroughStyle = (DefaultFontRenderer.1862862030 != 0);
                    this.underlineStyle = (DefaultFontRenderer.-1587269975 != 0);
                    this.italicStyle = (DefaultFontRenderer.1096027086 != 0);
                    if (-154956536 < 0 || -154956536 > DefaultFontRenderer.259137801) {
                        -154956536 = DefaultFontRenderer.-866058454;
                    }
                    if (-154956535) {
                        -154956536 += 16;
                    }
                    final int 1945824644 = this.colorCode[-154956536];
                    this.textColor = 1945824644;
                }
                // invokedynamic(1414189009:(FFFF)V, (float)1945824644 >> DefaultFontRenderer.575158032 / DefaultFontRenderer.1952941104, (float)1945824644 >> DefaultFontRenderer.-1026637499 & DefaultFontRenderer.614274211 / DefaultFontRenderer.2085735197, (float)1945824644 & DefaultFontRenderer.434871327 / DefaultFontRenderer.-126778924, this.alpha)
                else if (-154956536 == DefaultFontRenderer.-512235540) {
                    this.randomStyle = (DefaultFontRenderer.187830947 != 0);
                }
                else if (-154956536 == DefaultFontRenderer.-1543071560) {
                    this.boldStyle = (DefaultFontRenderer.-413210913 != 0);
                }
                else if (-154956536 == DefaultFontRenderer.-1885196578) {
                    this.strikethroughStyle = (DefaultFontRenderer.1946280844 != 0);
                }
                else if (-154956536 == DefaultFontRenderer.-1028356161) {
                    this.underlineStyle = (DefaultFontRenderer.-808413401 != 0);
                }
                else if (-154956536 == DefaultFontRenderer.-2057613812) {
                    this.italicStyle = (DefaultFontRenderer.-1372634685 != 0);
                }
                else if (-154956536 == DefaultFontRenderer.430906890) {
                    this.randomStyle = (DefaultFontRenderer.-973074628 != 0);
                    this.boldStyle = (DefaultFontRenderer.894634260 != 0);
                    this.strikethroughStyle = (DefaultFontRenderer.-1348471915 != 0);
                    this.underlineStyle = (DefaultFontRenderer.-1989017609 != 0);
                    this.italicStyle = (DefaultFontRenderer.-826061099 != 0);
                }
                // invokedynamic(-1678876459:(FFFF)V, this.red, this.blue, this.green, this.alpha)
                ++i;
            }
            else {
                int n = invokedynamic(-1231512229:(Ljava/lang/Object;I)I, invokedynamic(-974828964:(IJ)Ljava/lang/String;, DefaultFontRenderer.1597984340 & DefaultFontRenderer.-625190533, DefaultFontRenderer.-83979946), 1945824643);
                if (this.randomStyle && n != DefaultFontRenderer.812340247) {
                    final int 1945824645 = invokedynamic(1891391342:(Ljava/lang/Object;C)I, this, 1945824643);
                    char 1945824646;
                    do {
                        n = invokedynamic(1869136027:(Ljava/lang/Object;I)I, this.fontRandom, invokedynamic(507279006:(Ljava/lang/Object;)I, invokedynamic(-280771899:(IJ)Ljava/lang/String;, DefaultFontRenderer.-924973772, DefaultFontRenderer.546719212 ^ DefaultFontRenderer.2002200244)));
                        1945824646 = invokedynamic(-371917283:(Ljava/lang/Object;I)C, invokedynamic(-2129462208:(IJ)Ljava/lang/String;, DefaultFontRenderer.-1078953918 & DefaultFontRenderer.1556965377, DefaultFontRenderer.-997195022), n);
                    } while (1945824645 != invokedynamic(-1760084152:(Ljava/lang/Object;C)I, this, 1945824646));
                    1945824643 = 1945824646;
                }
                final float n2 = this.unicodeFlag ? DefaultFontRenderer.841664975 : 1.0f;
                final boolean 1945824647 = (((1945824643 == '\0' || n == DefaultFontRenderer.-1347701215 || this.unicodeFlag) && -154956535) ? DefaultFontRenderer.905714767 : DefaultFontRenderer.841197324) != 0;
                if (1945824647) {
                    this.posX -= n2;
                    this.posY -= n2;
                }
                float 1945824648 = this.renderChar(1945824643, this.italicStyle);
                if (1945824647) {
                    this.posX += n2;
                    this.posY += n2;
                }
                if (this.boldStyle) {
                    this.posX += n2;
                    if (1945824647) {
                        this.posX -= n2;
                        this.posY -= n2;
                    }
                    this.renderChar(1945824643, this.italicStyle);
                    this.posX -= n2;
                    if (1945824647) {
                        this.posX += n2;
                        this.posY += n2;
                    }
                    ++1945824648;
                }
                if (this.strikethroughStyle) {
                    final Tessellator tessellator = invokedynamic(-190766973:()Lnet/minecraft/client/renderer/Tessellator;);
                    final BufferBuilder bufferBuilder = invokedynamic(-921505719:(Ljava/lang/Object;)Lnet/minecraft/client/renderer/BufferBuilder;, tessellator);
                }
                // invokedynamic(1329599370:()V)
                // invokedynamic(1608955671:(Ljava/lang/Object;ILjava/lang/Object;)V, bufferBuilder, DefaultFontRenderer.-1603516927, DefaultVertexFormats.field_181705_e)
                // invokedynamic(-2135999852:(Ljava/lang/Object;)V, invokedynamic(-758415786:(Ljava/lang/Object;DDD)Lnet/minecraft/client/renderer/BufferBuilder;, bufferBuilder, (double)this.posX, (double)this.posY + (float)this.FONT_HEIGHT / DefaultFontRenderer.-213521724, 0.0))
                // invokedynamic(-1267768546:(Ljava/lang/Object;)V, invokedynamic(-1031317806:(Ljava/lang/Object;DDD)Lnet/minecraft/client/renderer/BufferBuilder;, bufferBuilder, (double)this.posX + 1945824648, (double)this.posY + (float)this.FONT_HEIGHT / DefaultFontRenderer.246582283, 0.0))
                // invokedynamic(1299816552:(Ljava/lang/Object;)V, invokedynamic(-2066487131:(Ljava/lang/Object;DDD)Lnet/minecraft/client/renderer/BufferBuilder;, bufferBuilder, (double)this.posX + 1945824648, (double)this.posY + (float)this.FONT_HEIGHT / DefaultFontRenderer.1629485213 - 1.0f, 0.0))
                // invokedynamic(429179631:(Ljava/lang/Object;)V, invokedynamic(218976156:(Ljava/lang/Object;DDD)Lnet/minecraft/client/renderer/BufferBuilder;, bufferBuilder, (double)this.posX, (double)this.posY + (float)this.FONT_HEIGHT / DefaultFontRenderer.-1816703672 - 1.0f, 0.0))
                // invokedynamic(-218986291:(Ljava/lang/Object;)V, tessellator)
                // invokedynamic(-83489328:()V)
                if (this.underlineStyle) {
                    final Tessellator tessellator2 = invokedynamic(2134090303:()Lnet/minecraft/client/renderer/Tessellator;);
                    final BufferBuilder 1945824649 = invokedynamic(864292182:(Ljava/lang/Object;)Lnet/minecraft/client/renderer/BufferBuilder;, tessellator2);
                    // invokedynamic(1573782094:()V)
                    // invokedynamic(-1210980002:(Ljava/lang/Object;ILjava/lang/Object;)V, 1945824649, DefaultFontRenderer.-1230639345, DefaultVertexFormats.field_181705_e)
                    final int 1945824650 = this.underlineStyle ? DefaultFontRenderer.193571795 : DefaultFontRenderer.969661664;
                }
                // invokedynamic(850875:(Ljava/lang/Object;)V, invokedynamic(-894759226:(Ljava/lang/Object;DDD)Lnet/minecraft/client/renderer/BufferBuilder;, 1945824649, (double)this.posX + (float)1945824650, (double)this.posY + (float)this.FONT_HEIGHT, 0.0))
                // invokedynamic(1187611164:(Ljava/lang/Object;)V, invokedynamic(-152409144:(Ljava/lang/Object;DDD)Lnet/minecraft/client/renderer/BufferBuilder;, 1945824649, (double)this.posX + 1945824648, (double)this.posY + (float)this.FONT_HEIGHT, 0.0))
                // invokedynamic(-639333501:(Ljava/lang/Object;)V, invokedynamic(-62679950:(Ljava/lang/Object;DDD)Lnet/minecraft/client/renderer/BufferBuilder;, 1945824649, (double)this.posX + 1945824648, (double)this.posY + (float)this.FONT_HEIGHT - 1.0f, 0.0))
                // invokedynamic(267821009:(Ljava/lang/Object;)V, invokedynamic(-691815070:(Ljava/lang/Object;DDD)Lnet/minecraft/client/renderer/BufferBuilder;, 1945824649, (double)this.posX + (float)1945824650, (double)this.posY + (float)this.FONT_HEIGHT - 1.0f, 0.0))
                // invokedynamic(1251565874:(Ljava/lang/Object;)V, tessellator2)
                // invokedynamic(521897572:()V)
                this.posX += (int)1945824648;
            }
        }
    }
    
    private int renderStringAligned(final String 544069931, int 275860436, final int 22566692, final int -141114912, final int -909736030, final boolean -1144265483) {
        if (this.bidiFlag) {
            final int 544069932 = invokedynamic(-399897791:(Ljava/lang/Object;Ljava/lang/Object;)I, this, this.bidiReorder(544069931));
            275860436 = 275860436 + -141114912 - 544069932;
        }
        return this.renderString(544069931, (float)275860436, (float)22566692, -909736030, -1144265483);
    }
    
    private int renderString(String 188512200, final float 394292297, final float 9148580, int -1765365655, final boolean -187886975) {
        if (188512200 == null) {
            return DefaultFontRenderer.-831742397;
        }
        if (this.bidiFlag) {
            188512200 = this.bidiReorder(188512200);
        }
        if ((-1765365655 & DefaultFontRenderer.1843738394) == 0x0) {
            -1765365655 |= DefaultFontRenderer.-426407100;
        }
        if (-187886975) {
            -1765365655 = ((-1765365655 & DefaultFontRenderer.-1101705964) >> DefaultFontRenderer.1029625663 | (-1765365655 & DefaultFontRenderer.20971521));
        }
        this.red = (-1765365655 >> DefaultFontRenderer.1143015628 & DefaultFontRenderer.-1526643807) / DefaultFontRenderer.367475671;
        this.blue = (-1765365655 >> DefaultFontRenderer.-1115412612 & DefaultFontRenderer.571201062) / DefaultFontRenderer.907315648;
        this.green = (-1765365655 & DefaultFontRenderer.-1019323912) / DefaultFontRenderer.709390555;
        this.alpha = (-1765365655 >> DefaultFontRenderer.74272226 & DefaultFontRenderer.188531389) / DefaultFontRenderer.-1021349709;
        // invokedynamic(-1600624748:(FFFF)V, this.red, this.blue, this.green, this.alpha)
        this.posX = 394292297;
        this.posY = 9148580;
        this.renderStringAtPos(188512200, -187886975);
        // invokedynamic(-45934826:()V)
        return (int)this.posX;
    }
    
    public int getStringWidth(final String 2005668157) {
        if (2005668157 == null) {
            return DefaultFontRenderer.743696424;
        }
        int 2005668160 = DefaultFontRenderer.900276168;
        boolean 2005668158 = DefaultFontRenderer.-1945037152 != 0;
        for (int 2005668159 = DefaultFontRenderer.1773886833; 2005668159 < invokedynamic(-105301027:(Ljava/lang/Object;)I, 2005668157); ++2005668159) {
            char c = invokedynamic(432913480:(Ljava/lang/Object;I)C, 2005668157, 2005668159);
            int -137257524 = invokedynamic(599492224:(Ljava/lang/Object;C)I, this, c);
            if (-137257524 < 0 && 2005668159 < invokedynamic(-1153599769:(Ljava/lang/Object;)I, 2005668157) - DefaultFontRenderer.872041580) {
                ++2005668159;
                c = invokedynamic(-120440888:(Ljava/lang/Object;I)C, 2005668157, 2005668159);
                if (c != DefaultFontRenderer.-789917758 && c != DefaultFontRenderer.606287899) {
                    if (c == DefaultFontRenderer.625833794 || c == DefaultFontRenderer.-1573899014) {
                        2005668158 = (DefaultFontRenderer.-1300642643 != 0);
                    }
                }
                else {
                    2005668158 = (DefaultFontRenderer.-1252521161 != 0);
                }
                -137257524 = DefaultFontRenderer.-137257524;
            }
            2005668160 += -137257524;
            if (2005668158 && -137257524 > 0) {
                ++2005668160;
            }
        }
        return 2005668160;
    }
    
    public int getCharWidth(final char -1379986833) {
        if (-1379986833 == DefaultFontRenderer.-1677527038) {
            return DefaultFontRenderer.2103013241;
        }
        if (-1379986833 == DefaultFontRenderer.-1848148599) {
            return DefaultFontRenderer.251226888;
        }
        final int n = invokedynamic(631381303:(Ljava/lang/Object;I)I, invokedynamic(311473833:(IJ)Ljava/lang/String;, DefaultFontRenderer.-1242483311, DefaultFontRenderer.-1692478925 ^ DefaultFontRenderer.-724314126), -1379986833);
        if (-1379986833 > '\0' && n != DefaultFontRenderer.-3478804 && !this.unicodeFlag) {
            return this.charWidth[n];
        }
        if (this.glyphWidth[-1379986833] != 0) {
            final int n2 = this.glyphWidth[-1379986833] & DefaultFontRenderer.-1948874377;
            final int 1772028556 = n2 >>> DefaultFontRenderer.65436662;
            int 1772028557 = n2 & DefaultFontRenderer.-1810819144;
            return (++1772028557 - 1772028556) / DefaultFontRenderer.263155024 + DefaultFontRenderer.1003917727;
        }
        return DefaultFontRenderer.455184740;
    }
    
    public String trimStringToWidth(final String -548537504, final int 47862956) {
        return invokedynamic(-1269494871:(Ljava/lang/Object;Ljava/lang/Object;IZ)Ljava/lang/String;, this, -548537504, 47862956, DefaultFontRenderer.591171472);
    }
    
    public String trimStringToWidth(final String 2051058168, final int -226159437, final boolean 1099903379) {
        final StringBuilder 2051058169 = new StringBuilder();
        int -226159438 = DefaultFontRenderer.-1666912223;
        final int n = 1099903379 ? (invokedynamic(-1644991192:(Ljava/lang/Object;)I, 2051058168) - DefaultFontRenderer.-562527499) : DefaultFontRenderer.454590311;
        final int 2051058170 = 1099903379 ? DefaultFontRenderer.568255449 : DefaultFontRenderer.1974873037;
        boolean 2051058171 = DefaultFontRenderer.1207791671 != 0;
        boolean 2051058172 = DefaultFontRenderer.-1960286972 != 0;
        for (int 2051058173 = n; 2051058173 >= 0 && 2051058173 < invokedynamic(-588399864:(Ljava/lang/Object;)I, 2051058168) && -226159438 < -226159437; 2051058173 += 2051058170) {
            final char c = invokedynamic(-1910166268:(Ljava/lang/Object;I)C, 2051058168, 2051058173);
            final int 2051058174 = invokedynamic(-1476818680:(Ljava/lang/Object;C)I, this, c);
            if (2051058171) {
                2051058171 = (DefaultFontRenderer.41514959 != 0);
                if (c != DefaultFontRenderer.1856951787 && c != DefaultFontRenderer.1673267604) {
                    if (c == DefaultFontRenderer.-704058655 || c == DefaultFontRenderer.1358447145) {
                        2051058172 = (DefaultFontRenderer.111525544 != 0);
                    }
                }
                else {
                    2051058172 = (DefaultFontRenderer.1985374168 != 0);
                }
            }
            else if (2051058174 < 0) {
                2051058171 = (DefaultFontRenderer.2119893591 != 0);
            }
            else {
                -226159438 += 2051058174;
                if (2051058172) {
                    ++-226159438;
                }
            }
            if (-226159438 > -226159437) {
                break;
            }
            if (1099903379) {
            }
            // invokedynamic(41294774:(Ljava/lang/Object;IC)Ljava/lang/StringBuilder;, 2051058169, DefaultFontRenderer.-997449816, c)
            else {
            }
            // invokedynamic(-304579893:(Ljava/lang/Object;C)Ljava/lang/StringBuilder;, 2051058169, c)
        }
        return invokedynamic(1571524018:(Ljava/lang/Object;)Ljava/lang/String;, 2051058169);
    }
    
    private String trimStringNewline(String -503583151) {
        while (-503583151 != null && invokedynamic(1111350406:(Ljava/lang/Object;Ljava/lang/Object;)Z, -503583151, invokedynamic(17898977:(IJ)Ljava/lang/String;, DefaultFontRenderer.-679005536 & DefaultFontRenderer.-341684635, DefaultFontRenderer.698907838))) {
            -503583151 = invokedynamic(-1365865183:(Ljava/lang/Object;II)Ljava/lang/String;, -503583151, DefaultFontRenderer.681212998, invokedynamic(535711242:(Ljava/lang/Object;)I, -503583151) - DefaultFontRenderer.530785939);
        }
        return -503583151;
    }
    
    public void drawSplitString(String 1778031299, final int -414479404, final int 237950939, final int 518441533, final int -498228175) {
        this.resetStyles();
        this.textColor = -498228175;
        1778031299 = this.trimStringNewline(1778031299);
        this.renderSplitString(1778031299, -414479404, 237950939, 518441533, (boolean)(DefaultFontRenderer.283566964 != 0));
    }
    
    private void renderSplitString(final String -1632156352, final int -1027558083, int 1955966347, final int 1932129300, final boolean -127705654) {
        final Iterator iterator = invokedynamic(188419372:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(-1265291054:(Ljava/lang/Object;Ljava/lang/Object;I)Ljava/util/List;, this, -1632156352, 1932129300));
        while (invokedynamic(-1699009530:(Ljava/lang/Object;)Z, iterator)) {
            final String 1955966348 = (String)invokedynamic(963444495:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
            this.renderStringAligned(1955966348, -1027558083, 1955966347, 1932129300, this.textColor, -127705654);
            1955966347 += this.FONT_HEIGHT;
        }
    }
    
    public int getWordWrappedHeight(final String 1673871305, final int 1863215729) {
        return this.FONT_HEIGHT * invokedynamic(-1786458978:(Ljava/lang/Object;)I, invokedynamic(-245639342:(Ljava/lang/Object;Ljava/lang/Object;I)Ljava/util/List;, this, 1673871305, 1863215729));
    }
    
    public void setUnicodeFlag(final boolean 1100578638) {
        this.unicodeFlag = 1100578638;
    }
    
    public boolean getUnicodeFlag() {
        return this.unicodeFlag;
    }
    
    public void setBidiFlag(final boolean -1697379606) {
        this.bidiFlag = -1697379606;
    }
    
    public List<String> listFormattedStringToWidth(final String -1255212061, final int -844421826) {
        return invokedynamic(1767994568:([Ljava/lang/Object;)Ljava/util/List;, (String[])invokedynamic(1774468244:(Ljava/lang/Object;Ljava/lang/Object;)[Ljava/lang/String;, invokedynamic(2052401376:(Ljava/lang/Object;Ljava/lang/Object;I)Ljava/lang/String;, this, -1255212061, -844421826), invokedynamic(-207850074:(IJ)Ljava/lang/String;, DefaultFontRenderer.1284660843, DefaultFontRenderer.-1925767797 ^ DefaultFontRenderer.-100990464)));
    }
    
    protected String wrapFormattedStringToWidth(final String 1401295644, final int 925369004) {
        final int sizeStringToWidth = this.sizeStringToWidth(1401295644, 925369004);
        if (invokedynamic(-97783007:(Ljava/lang/Object;)I, 1401295644) <= sizeStringToWidth) {
            return 1401295644;
        }
        final String 1401295645 = invokedynamic(-1803918406:(Ljava/lang/Object;II)Ljava/lang/String;, 1401295644, DefaultFontRenderer.-482029747, sizeStringToWidth);
        final char 1401295646 = invokedynamic(-2120307238:(Ljava/lang/Object;I)C, 1401295644, sizeStringToWidth);
        final boolean 1401295647 = ((1401295646 == DefaultFontRenderer.199707579 || 1401295646 == DefaultFontRenderer.-472230925) ? DefaultFontRenderer.-1231515295 : DefaultFontRenderer.798858860) != 0;
        final String 1401295648 = invokedynamic(1706688086:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(117936722:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(925046351:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), invokedynamic(-1883641105:(Ljava/lang/Object;)Ljava/lang/String;, 1401295645)), invokedynamic(-162662937:(Ljava/lang/Object;I)Ljava/lang/String;, 1401295644, sizeStringToWidth + (1401295647 ? DefaultFontRenderer.-335930534 : DefaultFontRenderer.138530062))));
        return invokedynamic(-2123191813:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(1171045563:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(1726227291:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-373964091:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), 1401295645), invokedynamic(-591483672:(IJ)Ljava/lang/String;, DefaultFontRenderer.-87314659, DefaultFontRenderer.-1594668717 ^ DefaultFontRenderer.-267935421)), invokedynamic(-355080989:(Ljava/lang/Object;Ljava/lang/Object;I)Ljava/lang/String;, this, 1401295648, 925369004)));
    }
    
    private int sizeStringToWidth(final String -1904300390, final int 827275437) {
        final int 827275438 = invokedynamic(-2113018865:(Ljava/lang/Object;)I, -1904300390);
        int -1904300391 = DefaultFontRenderer.-226309644;
        int 827275439 = DefaultFontRenderer.270950746;
        int 827275440 = DefaultFontRenderer.455020651;
        boolean 827275441 = DefaultFontRenderer.-1745934193 != 0;
        while (827275439 < 827275438) {
            final char c = invokedynamic(-1104166112:(Ljava/lang/Object;I)C, -1904300390, 827275439);
            Label_0192: {
                switch (c) {
                    case '\n': {
                        --827275439;
                        break Label_0192;
                    }
                    case ' ': {
                        827275440 = 827275439;
                        break;
                    }
                    case '§': {
                        if (827275439 >= 827275438 - DefaultFontRenderer.-44935216) {
                            break Label_0192;
                        }
                        ++827275439;
                        final char 827275442 = invokedynamic(1505030337:(Ljava/lang/Object;I)C, -1904300390, 827275439);
                        if (827275442 == DefaultFontRenderer.-333121991 || 827275442 == DefaultFontRenderer.-1499116432) {
                            827275441 = (DefaultFontRenderer.-574743475 != 0);
                            break Label_0192;
                        }
                        if (827275442 == DefaultFontRenderer.928007183 || 827275442 == DefaultFontRenderer.-1951968517 || invokedynamic(239404072:(C)Z, 827275442)) {
                            827275441 = (DefaultFontRenderer.-407417858 != 0);
                        }
                        break Label_0192;
                    }
                }
                -1904300391 += invokedynamic(428109674:(Ljava/lang/Object;C)I, this, c);
                if (827275441) {
                    ++-1904300391;
                }
            }
            if (c == DefaultFontRenderer.1304581735) {
                827275440 = ++827275439;
                break;
            }
            if (-1904300391 > 827275437) {
                break;
            }
            ++827275439;
        }
        return (827275439 != 827275438 && 827275440 != DefaultFontRenderer.-1213284445 && 827275440 < 827275439) ? 827275440 : 827275439;
    }
    
    private static boolean isFormatColor(final char -1575359288) {
        return (((-1575359288 >= DefaultFontRenderer.285983960 && -1575359288 <= DefaultFontRenderer.1764598494) || (-1575359288 >= DefaultFontRenderer.1278312757 && -1575359288 <= DefaultFontRenderer.2114452709) || (-1575359288 >= DefaultFontRenderer.-1892850863 && -1575359288 <= DefaultFontRenderer.-818895923)) ? DefaultFontRenderer.1264075310 : DefaultFontRenderer.-393076374) != 0;
    }
    
    private static boolean isFormatSpecial(final char -858713747) {
        return (((-858713747 >= DefaultFontRenderer.2056900899 && -858713747 <= DefaultFontRenderer.1018530334) || (-858713747 >= DefaultFontRenderer.-1089010893 && -858713747 <= DefaultFontRenderer.1112455095) || -858713747 == DefaultFontRenderer.-60475535 || -858713747 == DefaultFontRenderer.258186620) ? DefaultFontRenderer.767710563 : DefaultFontRenderer.1353662555) != 0;
    }
    
    public static String getFormatFromString(final String -211231731) {
        String s = invokedynamic(476666227:(IJ)Ljava/lang/String;, DefaultFontRenderer.-414797356, DefaultFontRenderer.1790964437 ^ DefaultFontRenderer.244292876);
        int 206487194 = DefaultFontRenderer.-921186043;
        final int n = invokedynamic(1744690124:(Ljava/lang/Object;)I, -211231731);
        while ((206487194 = invokedynamic(1465425257:(Ljava/lang/Object;II)I, -211231731, DefaultFontRenderer.-699221793, 206487194 + DefaultFontRenderer.638899756)) != DefaultFontRenderer.-742980479) {
            if (206487194 < n - DefaultFontRenderer.938375914) {
                final char c = invokedynamic(-1286180969:(Ljava/lang/Object;I)C, -211231731, 206487194 + DefaultFontRenderer.-845646242);
                if (invokedynamic(1823016006:(C)Z, c)) {
                    s = invokedynamic(-1205976006:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-2024015972:(Ljava/lang/Object;C)Ljava/lang/StringBuilder;, invokedynamic(880273787:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), invokedynamic(-837009046:(IJ)Ljava/lang/String;, DefaultFontRenderer.1390745, DefaultFontRenderer.1375430100 ^ DefaultFontRenderer.1891256302)), c));
                }
                else {
                    if (!invokedynamic(-685307238:(C)Z, c)) {
                        continue;
                    }
                    s = invokedynamic(-275989757:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(2128975515:(Ljava/lang/Object;C)Ljava/lang/StringBuilder;, invokedynamic(659262210:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-1836306757:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), s), invokedynamic(-891450138:(IJ)Ljava/lang/String;, DefaultFontRenderer.-621089176, DefaultFontRenderer.1306892678)), c));
                }
            }
        }
        return s;
    }
    
    public boolean getBidiFlag() {
        return this.bidiFlag;
    }
    
    public int getColorCode(final char -1338259251) {
        final int n = invokedynamic(1165263051:(Ljava/lang/Object;I)I, invokedynamic(-1235885854:(IJ)Ljava/lang/String;, DefaultFontRenderer.-1518622047, DefaultFontRenderer.-441965283), -1338259251);
        return (n >= 0 && n < this.colorCode.length) ? this.colorCode[n] : DefaultFontRenderer.-740987382;
    }
    
    static {
        DefaultFontRenderer.1146016243 = 1419791383;
        DefaultFontRenderer.124033335 = 184;
        DefaultFontRenderer.-1453150902 = ((1 >>> 248 | 1 << -248) & -1);
        DefaultFontRenderer.254060907 = ((1073741826 >>> 222 | 1073741826 << ~0xDE + 1) & -1);
        DefaultFontRenderer.449599421 = invokedynamic(1154789372:(I)I, 32768);
        DefaultFontRenderer.1849622715 = invokedynamic(1310002423:(I)I, 67108864);
        DefaultFontRenderer.448453425 = invokedynamic(1956464416:(I)I, false);
        DefaultFontRenderer.-1719897121 = ((1048576 >>> 111 | 1048576 << ~0x6F + 1) & -1);
        DefaultFontRenderer.1293563697 = (-2147483647 >>> 95 | -2147483647 << ~0x5F + 1);
        DefaultFontRenderer.1189723113 = invokedynamic(2088502049:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.1908163595 = ((713031680 >>> 23 | 713031680 << ~0x17 + 1) & -1);
        DefaultFontRenderer.1163820404 = ((4096 >>> 75 | 4096 << -75) & -1);
        DefaultFontRenderer.674345949 = (1048576 >>> 116 | 1048576 << ~0x74 + 1);
        DefaultFontRenderer.-1756620832 = invokedynamic(-1668025346:(I)I, 1426063360);
        DefaultFontRenderer.-1539836587 = invokedynamic(-1115874250:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.-1471637786 = invokedynamic(-1715967803:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.-987413141 = invokedynamic(-774098742:(I)I, 1426063360);
        DefaultFontRenderer.338693874 = ((0 >>> 235 | 0 << -235) & -1);
        DefaultFontRenderer.316249348 = invokedynamic(725012745:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.-1072391832 = invokedynamic(-1831350776:(I)I, 1426063360);
        DefaultFontRenderer.-454257820 = (12582912 >>> 21 | 12582912 << ~0x15 + 1);
        DefaultFontRenderer.331267119 = ((120 >>> 98 | 120 << -98) & -1);
        DefaultFontRenderer.-1011105741 = invokedynamic(1211070192:(I)I, -603979776);
        DefaultFontRenderer.1062007202 = ((2883584 >>> 82 | 2883584 << ~0x52 + 1) & -1);
        DefaultFontRenderer.-95496059 = invokedynamic(891663851:(I)I, 637534208);
        DefaultFontRenderer.-1473979772 = invokedynamic(629934595:(I)I, 2013265920);
        DefaultFontRenderer.-499237829 = ((-2147483631 >>> 158 | -2147483631 << -158) & -1);
        DefaultFontRenderer.-835071219 = (26214400 >>> 114 | 26214400 << ~0x72 + 1);
        DefaultFontRenderer.-1392794881 = invokedynamic(1820680655:(I)I, 2013265920);
        DefaultFontRenderer.943192502 = invokedynamic(-767762842:(I)I, 1644167168);
        DefaultFontRenderer.1813599004 = ((200 >>> 33 | 200 << -33) & -1);
        DefaultFontRenderer.-1578657598 = ((2 >>> 157 | 2 << -157) & -1);
        DefaultFontRenderer.1698204515 = (1073741824 >>> 252 | 1073741824 << ~0xFC + 1);
        DefaultFontRenderer.1633137594 = ((8388608 >>> 21 | 8388608 << ~0x15 + 1) & -1);
        DefaultFontRenderer.1944475859 = ((1 >>> 30 | 1 << ~0x1E + 1) & -1);
        DefaultFontRenderer.-1512283139 = ((255 >>> 224 | 255 << -224) & -1);
        DefaultFontRenderer.-1870032964 = invokedynamic(1938353788:(I)I, 134217728);
        DefaultFontRenderer.115648802 = invokedynamic(1293564185:(I)I, -16777216);
        DefaultFontRenderer.-1746567409 = ((65536 >>> 77 | 65536 << ~0x4D + 1) & -1);
        DefaultFontRenderer.1921188038 = invokedynamic(289190035:(I)I, -16777216);
        DefaultFontRenderer.-716611144 = (0 >>> 170 | 0 << -170);
        DefaultFontRenderer.2114191371 = invokedynamic(-905078044:(I)I, false);
        DefaultFontRenderer.67517030 = invokedynamic(1719378979:(I)I, false);
        DefaultFontRenderer.-122797165 = (536870912 >>> 89 | 536870912 << -89);
        DefaultFontRenderer.-513997826 = ((2097152 >>> 209 | 2097152 << ~0xD1 + 1) & -1);
        DefaultFontRenderer.1874446950 = invokedynamic(-1164717418:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.-2141955285 = invokedynamic(1967967858:(I)F, invokedynamic(1519476921:(I)I, 130));
        DefaultFontRenderer.955046710 = (0 >>> 173 | 0 << ~0xAD + 1);
        DefaultFontRenderer.1965429457 = invokedynamic(409207183:(I)I, 8388608);
        DefaultFontRenderer.603800558 = invokedynamic(-257772287:(I)I, 134217728);
        DefaultFontRenderer.812632689 = ((128 >>> 35 | 128 << ~0x23 + 1) & -1);
        DefaultFontRenderer.-2017023537 = ((134217728 >>> 150 | 134217728 << ~0x96 + 1) & -1);
        DefaultFontRenderer.1328935291 = ((1 >>> 126 | 1 << ~0x7E + 1) & -1);
        DefaultFontRenderer.1167846246 = invokedynamic(-2001781705:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.1408829336 = invokedynamic(305487823:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.1512581215 = (0 >>> 170 | 0 << ~0xAA + 1);
        DefaultFontRenderer.1084832359 = invokedynamic(1212891593:(I)I, 402653184);
        DefaultFontRenderer.927000521 = invokedynamic(-375674760:(I)I, -16777216);
        DefaultFontRenderer.1303823511 = (0 >>> 218 | 0 << ~0xDA + 1);
        DefaultFontRenderer.109013498 = invokedynamic(1336754680:(J)D, invokedynamic(-564902666:(J)J, 2044L));
        DefaultFontRenderer.287720196 = ((2097152 >>> 53 | 2097152 << ~0x35 + 1) & -1);
        DefaultFontRenderer.-1352561517 = invokedynamic(-1719196063:(I)I, false);
        DefaultFontRenderer.-1557011994 = invokedynamic(-1019132822:(J)J, -2445127780270109593L);
        DefaultFontRenderer.2087395094 = invokedynamic(275810549:(J)J, 3026418949592973312L);
        DefaultFontRenderer.331557751 = invokedynamic(-836418083:(I)I, 67108864);
        DefaultFontRenderer.-1324596318 = invokedynamic(838439264:(I)F, 66048 >>> 114 | 66048 << -114);
        DefaultFontRenderer.105092698 = invokedynamic(945664460:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.-539026635 = invokedynamic(1528742721:(J)J, -2445127780270109593L);
        DefaultFontRenderer.-1025199296 = invokedynamic(-1670387557:(J)J, 3026418949592973312L);
        DefaultFontRenderer.-1992028866 = (-1 >>> 56 | -1 << -56);
        DefaultFontRenderer.-1741808781 = ((524288 >>> 50 | 524288 << ~0x32 + 1) & -1);
        DefaultFontRenderer.-1355021701 = (16 >>> 128 | 16 << -128);
        DefaultFontRenderer.-1691755655 = invokedynamic(-904561881:(I)I, 268435456);
        DefaultFontRenderer.1491608937 = invokedynamic(-635971911:(I)I, 134217728);
        DefaultFontRenderer.1032330164 = ((512 >>> 166 | 512 << -166) & -1);
        DefaultFontRenderer.2013576140 = invokedynamic(-1957026638:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.867530460 = invokedynamic(1314667951:(I)I, false);
        DefaultFontRenderer.716063613 = invokedynamic(-2086972487:(I)F, 601295420 >>> 136 | 601295420 << -136);
        DefaultFontRenderer.-1285269350 = (327680 >>> 240 | 327680 << -240);
        DefaultFontRenderer.-542818256 = invokedynamic(716687409:(I)F, invokedynamic(1994330484:(I)I, 194));
        DefaultFontRenderer.1373893244 = invokedynamic(471847793:(I)F, invokedynamic(-694141811:(I)I, 194));
        DefaultFontRenderer.-605158025 = invokedynamic(-824709003:(I)F, 2144 >>> 141 | 2144 << ~0x8D + 1);
        DefaultFontRenderer.-799377377 = invokedynamic(46997543:(I)F, invokedynamic(1475343230:(I)I, 678821634));
        DefaultFontRenderer.-1868452578 = invokedynamic(-1534122635:(I)F, 140509184 >>> 189 | 140509184 << ~0xBD + 1);
        DefaultFontRenderer.-1477367034 = invokedynamic(1989906718:(I)F, invokedynamic(2131247214:(I)I, 678821634));
        DefaultFontRenderer.1747659578 = invokedynamic(-887167073:(I)F, invokedynamic(1403782381:(I)I, 194));
        DefaultFontRenderer.744075672 = invokedynamic(1494917697:(I)F, invokedynamic(-1691258044:(I)I, 194));
        DefaultFontRenderer.1187851497 = invokedynamic(2145459095:(I)F, invokedynamic(-1034163777:(I)I, 194));
        DefaultFontRenderer.-1203041778 = invokedynamic(1265392755:(I)F, (-1202650114 >>> 18 | -1202650114 << ~0x12 + 1) & -1);
        DefaultFontRenderer.1408779989 = invokedynamic(654754098:(I)F, (137216 >>> 179 | 137216 << ~0xB3 + 1) & -1);
        DefaultFontRenderer.-947784204 = invokedynamic(-1219447054:(I)F, 272624517 >>> 62 | 272624517 << -62);
        DefaultFontRenderer.-488620264 = (16 >>> 67 | 16 << -67);
        DefaultFontRenderer.1985601658 = ((-1 >>> 217 | -1 << -217) & -1);
        DefaultFontRenderer.-2120435923 = invokedynamic(1295700045:(J)J, -859860711435695001L);
        DefaultFontRenderer.-804873137 = ((4 >>> 162 | 4 << -162) & -1);
        DefaultFontRenderer.411281260 = invokedynamic(-734098486:(I)I, false);
        DefaultFontRenderer.-380744251 = ((-16777216 >>> 88 | -16777216 << ~0x58 + 1) & -1);
        DefaultFontRenderer.857744730 = ((134217728 >>> 115 | 134217728 << -115) & -1);
        DefaultFontRenderer.294498048 = (16384 >>> 76 | 16384 << ~0x4C + 1);
        DefaultFontRenderer.-595854382 = invokedynamic(-614918731:(I)I, -268435456);
        DefaultFontRenderer.314276461 = invokedynamic(1165939641:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.-1478232489 = ((8388608 >>> 51 | 8388608 << ~0x33 + 1) & -1);
        DefaultFontRenderer.1909769837 = invokedynamic(367242067:(I)I, 134217728);
        DefaultFontRenderer.-1980749507 = ((2040 >>> 227 | 2040 << -227) & -1);
        DefaultFontRenderer.304652800 = invokedynamic(983108532:(I)I, 134217728);
        DefaultFontRenderer.1770500495 = ((2 >>> 253 | 2 << ~0xFD + 1) & -1);
        DefaultFontRenderer.2087839818 = invokedynamic(-1750725540:(I)F, invokedynamic(-1488283232:(I)I, 1357628732));
        DefaultFontRenderer.1169876792 = invokedynamic(-1318170175:(I)I, -1610612736);
        DefaultFontRenderer.-1865743087 = invokedynamic(2033098858:(I)F, invokedynamic(2042211667:(I)I, 450));
        DefaultFontRenderer.1254283349 = invokedynamic(1961133950:(I)F, 1080 >>> 172 | 1080 << ~0xAC + 1);
        DefaultFontRenderer.-1090891920 = invokedynamic(1630439571:(I)F, (540 >>> 43 | 540 << -43) & -1);
        DefaultFontRenderer.-1605825873 = invokedynamic(1556280002:(I)F, (402317636 >>> 4 | 402317636 << -4) & -1);
        DefaultFontRenderer.-1437672188 = invokedynamic(-1370330368:(I)F, (135 >>> 233 | 135 << -233) & -1);
        DefaultFontRenderer.1542444372 = invokedynamic(-1292082886:(I)F, -1374404353 >>> 48 | -1374404353 << ~0x30 + 1);
        DefaultFontRenderer.321413922 = invokedynamic(-666958322:(I)F, 1080 >>> 172 | 1080 << -172);
        DefaultFontRenderer.-280828612 = invokedynamic(1160992464:(I)F, invokedynamic(-80984624:(I)I, 450));
        DefaultFontRenderer.1168622080 = invokedynamic(1524682014:(I)F, invokedynamic(-1058775438:(I)I, 450));
        DefaultFontRenderer.230186509 = invokedynamic(-1790781374:(I)F, -1031262219 >>> 149 | -1031262219 << ~0x95 + 1);
        DefaultFontRenderer.1077114130 = invokedynamic(1749283157:(I)F, (17280 >>> 80 | 17280 << ~0x50 + 1) & -1);
        DefaultFontRenderer.1890623882 = invokedynamic(-899819923:(I)F, invokedynamic(-1302611563:(I)I, 678821634));
        DefaultFontRenderer.701986049 = ((65536 >>> 80 | 65536 << ~0x50 + 1) & -1);
        DefaultFontRenderer.-1444282210 = invokedynamic(967160839:(I)I, 1073741824);
        DefaultFontRenderer.-1476647955 = invokedynamic(2118853083:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.-1439367578 = invokedynamic(705308109:(I)I, false);
        DefaultFontRenderer.898187629 = invokedynamic(-1865040548:(I)I, false);
        DefaultFontRenderer.835912814 = (32 >>> 165 | 32 << ~0xA5 + 1);
        DefaultFontRenderer.2029190771 = ((0 >>> 128 | 0 << ~0x80 + 1) & -1);
        DefaultFontRenderer.1350998234 = invokedynamic(2144413294:(I)I, false);
        DefaultFontRenderer.1205071217 = invokedynamic(-1528433913:(I)I, 268435456);
        DefaultFontRenderer.-194664068 = invokedynamic(1798607949:(I)I, -33554432);
        DefaultFontRenderer.348908411 = (0 >>> 168 | 0 << -168);
        DefaultFontRenderer.200263673 = (16777216 >>> 23 | 16777216 << ~0x17 + 1);
        DefaultFontRenderer.-723276621 = (0 >>> 203 | 0 << ~0xCB + 1);
        DefaultFontRenderer.-787904648 = invokedynamic(-789784159:(I)I, false);
        DefaultFontRenderer.-452852760 = (0 >>> 182 | 0 << -182);
        DefaultFontRenderer.-1905339005 = ((0 >>> 210 | 0 << -210) & -1);
        DefaultFontRenderer.1526672307 = (0 >>> 202 | 0 << ~0xCA + 1);
        DefaultFontRenderer.-2140249020 = invokedynamic(-687045065:(I)I, false);
        DefaultFontRenderer.129500960 = ((21889024 >>> 209 | 21889024 << ~0xD1 + 1) & -1);
        DefaultFontRenderer.-2021398559 = invokedynamic(1127218295:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.-20861638 = invokedynamic(-610947964:(I)I, -1073741824);
        DefaultFontRenderer.-446026325 = invokedynamic(-1430925670:(J)J, -859860711435695001L);
        DefaultFontRenderer.997049004 = invokedynamic(1972580482:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.-196496190 = (0 >>> 84 | 0 << ~0x54 + 1);
        DefaultFontRenderer.-72063343 = ((1048576 >>> 80 | 1048576 << ~0x50 + 1) & -1);
        DefaultFontRenderer.-858952217 = (0 >>> 225 | 0 << -225);
        DefaultFontRenderer.-1877282383 = invokedynamic(-1205906422:(I)I, false);
        DefaultFontRenderer.1862862030 = invokedynamic(617367291:(I)I, false);
        DefaultFontRenderer.-1587269975 = invokedynamic(-1613687919:(I)I, false);
        DefaultFontRenderer.1096027086 = ((0 >>> 35 | 0 << ~0x23 + 1) & -1);
        DefaultFontRenderer.259137801 = ((503316480 >>> 25 | 503316480 << -25) & -1);
        DefaultFontRenderer.-866058454 = ((7680 >>> 137 | 7680 << -137) & -1);
        DefaultFontRenderer.575158032 = invokedynamic(-1980293843:(I)I, 134217728);
        DefaultFontRenderer.1952941104 = invokedynamic(-1302752854:(I)F, invokedynamic(-671962754:(I)I, 65218));
        DefaultFontRenderer.-1026637499 = invokedynamic(-793424452:(I)I, 268435456);
        DefaultFontRenderer.614274211 = invokedynamic(1893006256:(I)I, -16777216);
        DefaultFontRenderer.2085735197 = invokedynamic(-1798467589:(I)F, invokedynamic(851473993:(I)I, 65218));
        DefaultFontRenderer.434871327 = ((4177920 >>> 206 | 4177920 << ~0xCE + 1) & -1);
        DefaultFontRenderer.-126778924 = invokedynamic(1718111015:(I)F, 276464 >>> 180 | 276464 << -180);
        DefaultFontRenderer.-512235540 = invokedynamic(1456150277:(I)I, 134217728);
        DefaultFontRenderer.187830947 = (32768 >>> 207 | 32768 << ~0xCF + 1);
        DefaultFontRenderer.-1543071560 = (557056 >>> 47 | 557056 << -47);
        DefaultFontRenderer.-413210913 = invokedynamic(-968554957:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.-1885196578 = invokedynamic(346584165:(I)I, 1207959552);
        DefaultFontRenderer.1946280844 = (16384 >>> 174 | 16384 << -174);
        DefaultFontRenderer.-1028356161 = ((38 >>> 161 | 38 << -161) & -1);
        DefaultFontRenderer.-808413401 = invokedynamic(-1082398099:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.-2057613812 = ((40 >>> 161 | 40 << -161) & -1);
        DefaultFontRenderer.-1372634685 = invokedynamic(-792130886:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.430906890 = ((42 >>> 33 | 42 << -33) & -1);
        DefaultFontRenderer.-973074628 = invokedynamic(1210753079:(I)I, false);
        DefaultFontRenderer.894634260 = ((0 >>> 106 | 0 << ~0x6A + 1) & -1);
        DefaultFontRenderer.-1348471915 = (0 >>> 154 | 0 << ~0x9A + 1);
        DefaultFontRenderer.-1989017609 = invokedynamic(-1830116109:(I)I, false);
        DefaultFontRenderer.-826061099 = invokedynamic(1612285117:(I)I, false);
        DefaultFontRenderer.1597984340 = (1024 >>> 8 | 1024 << -8);
        DefaultFontRenderer.-625190533 = invokedynamic(1779631518:(I)I, -1);
        DefaultFontRenderer.-83979946 = invokedynamic(-473559762:(J)J, -859860711435695001L);
        DefaultFontRenderer.812340247 = invokedynamic(305002826:(I)I, -1);
        DefaultFontRenderer.-924973772 = invokedynamic(2080163801:(I)I, -1610612736);
        DefaultFontRenderer.546719212 = invokedynamic(1838505725:(J)J, -2445127780270109593L);
        DefaultFontRenderer.2002200244 = invokedynamic(-2052864657:(J)J, 3026418949592973312L);
        DefaultFontRenderer.-1078953918 = (1536 >>> 168 | 1536 << ~0xA8 + 1);
        DefaultFontRenderer.1556965377 = invokedynamic(-1335127416:(I)I, -1);
        DefaultFontRenderer.-997195022 = invokedynamic(1631934202:(J)J, -859860711435695001L);
        DefaultFontRenderer.841664975 = invokedynamic(232241036:(I)F, invokedynamic(1388825809:(I)I, 252));
        DefaultFontRenderer.-1347701215 = invokedynamic(1315239623:(I)I, -1);
        DefaultFontRenderer.905714767 = ((16384 >>> 46 | 16384 << -46) & -1);
        DefaultFontRenderer.841197324 = invokedynamic(2094798291:(I)I, false);
        DefaultFontRenderer.-1603516927 = (7340032 >>> 52 | 7340032 << ~0x34 + 1);
        DefaultFontRenderer.-213521724 = ((32 >>> 4 | 32 << -4) & -1);
        DefaultFontRenderer.246582283 = (Integer.MIN_VALUE >>> 94 | Integer.MIN_VALUE << ~0x5E + 1);
        DefaultFontRenderer.1629485213 = invokedynamic(1371884252:(I)I, 1073741824);
        DefaultFontRenderer.-1816703672 = ((8192 >>> 204 | 8192 << ~0xCC + 1) & -1);
        DefaultFontRenderer.-1230639345 = (3670016 >>> 179 | 3670016 << ~0xB3 + 1);
        DefaultFontRenderer.193571795 = (-1 >>> 137 | -1 << -137);
        DefaultFontRenderer.969661664 = invokedynamic(1329634607:(I)I, false);
        DefaultFontRenderer.-831742397 = invokedynamic(313261168:(I)I, false);
        DefaultFontRenderer.1843738394 = invokedynamic(-1922360687:(I)I, 63);
        DefaultFontRenderer.-426407100 = invokedynamic(443357780:(I)I, 255);
        DefaultFontRenderer.-1101705964 = invokedynamic(148426873:(I)I, 1061109504);
        DefaultFontRenderer.1029625663 = invokedynamic(-509904881:(I)I, 1073741824);
        DefaultFontRenderer.20971521 = (8160 >>> 45 | 8160 << -45);
        DefaultFontRenderer.1143015628 = invokedynamic(1724601399:(I)I, 134217728);
        DefaultFontRenderer.-1526643807 = invokedynamic(-567583421:(I)I, -16777216);
        DefaultFontRenderer.367475671 = invokedynamic(-1609996086:(I)F, (2130706499 >>> 168 | 2130706499 << -168) & -1);
        DefaultFontRenderer.-1115412612 = (16 >>> 33 | 16 << -33);
        DefaultFontRenderer.571201062 = ((255 >>> 64 | 255 << -64) & -1);
        DefaultFontRenderer.907315648 = invokedynamic(-1160131487:(I)F, invokedynamic(-636392915:(I)I, 65218));
        DefaultFontRenderer.-1019323912 = (8160 >>> 165 | 8160 << ~0xA5 + 1);
        DefaultFontRenderer.709390555 = invokedynamic(735099641:(I)F, 34558 >>> 241 | 34558 << -241);
        DefaultFontRenderer.74272226 = (100663296 >>> 22 | 100663296 << ~0x16 + 1);
        DefaultFontRenderer.188531389 = (66846720 >>> 178 | 66846720 << -178);
        DefaultFontRenderer.-1021349709 = invokedynamic(-1306628327:(I)F, invokedynamic(-1357277605:(I)I, 65218));
        DefaultFontRenderer.743696424 = invokedynamic(184401559:(I)I, false);
        DefaultFontRenderer.900276168 = (0 >>> 149 | 0 << -149);
        DefaultFontRenderer.-1945037152 = invokedynamic(-524380519:(I)I, false);
        DefaultFontRenderer.1773886833 = invokedynamic(-249241682:(I)I, false);
        DefaultFontRenderer.872041580 = invokedynamic(-73432136:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.-789917758 = invokedynamic(1915341886:(I)I, 905969664);
        DefaultFontRenderer.606287899 = ((1275068416 >>> 152 | 1275068416 << -152) & -1);
        DefaultFontRenderer.625833794 = ((119537664 >>> 20 | 119537664 << ~0x14 + 1) & -1);
        DefaultFontRenderer.-1573899014 = (687865856 >>> 87 | 687865856 << -87);
        DefaultFontRenderer.-1300642643 = (0 >>> 247 | 0 << ~0xF7 + 1);
        DefaultFontRenderer.-1252521161 = invokedynamic(-1515370978:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.-137257524 = invokedynamic(-1533245573:(I)I, false);
        DefaultFontRenderer.-1677527038 = ((85504 >>> 169 | 85504 << -169) & -1);
        DefaultFontRenderer.2103013241 = invokedynamic(699181685:(I)I, -1);
        DefaultFontRenderer.-1848148599 = invokedynamic(1731637945:(I)I, 67108864);
        DefaultFontRenderer.251226888 = invokedynamic(-206928784:(I)I, 536870912);
        DefaultFontRenderer.-1242483311 = (1835008 >>> 242 | 1835008 << ~0xF2 + 1);
        DefaultFontRenderer.-1692478925 = invokedynamic(1793546800:(J)J, -2445127780270109593L);
        DefaultFontRenderer.-724314126 = invokedynamic(-107965107:(J)J, 3026418949592973312L);
        DefaultFontRenderer.-3478804 = invokedynamic(758964067:(I)I, -1);
        DefaultFontRenderer.-1948874377 = invokedynamic(-1999621373:(I)I, -16777216);
        DefaultFontRenderer.65436662 = invokedynamic(1056986689:(I)I, 536870912);
        DefaultFontRenderer.-1810819144 = (7864320 >>> 147 | 7864320 << -147);
        DefaultFontRenderer.263155024 = ((1073741824 >>> 253 | 1073741824 << -253) & -1);
        DefaultFontRenderer.1003917727 = ((128 >>> 167 | 128 << -167) & -1);
        DefaultFontRenderer.455184740 = invokedynamic(-326976759:(I)I, false);
        DefaultFontRenderer.591171472 = invokedynamic(-1058414304:(I)I, false);
        DefaultFontRenderer.-1666912223 = invokedynamic(1391045496:(I)I, false);
        DefaultFontRenderer.-562527499 = invokedynamic(908676320:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.454590311 = invokedynamic(1232958069:(I)I, false);
        DefaultFontRenderer.568255449 = invokedynamic(-1003356518:(I)I, -1);
        DefaultFontRenderer.1974873037 = invokedynamic(1316737815:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.1207791671 = (0 >>> 88 | 0 << -88);
        DefaultFontRenderer.-1960286972 = invokedynamic(-318967163:(I)I, false);
        DefaultFontRenderer.41514959 = ((0 >>> 198 | 0 << ~0xC6 + 1) & -1);
        DefaultFontRenderer.1856951787 = invokedynamic(-1910796101:(I)I, 905969664);
        DefaultFontRenderer.1673267604 = ((-1073741820 >>> 60 | -1073741820 << ~0x3C + 1) & -1);
        DefaultFontRenderer.-704058655 = (956301312 >>> 55 | 956301312 << -55);
        DefaultFontRenderer.1358447145 = invokedynamic(1497839953:(I)I, 1241513984);
        DefaultFontRenderer.111525544 = ((0 >>> 138 | 0 << -138) & -1);
        DefaultFontRenderer.1985374168 = invokedynamic(-1290986966:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.2119893591 = ((16384 >>> 14 | 16384 << ~0xE + 1) & -1);
        DefaultFontRenderer.-997449816 = (0 >>> 163 | 0 << ~0xA3 + 1);
        DefaultFontRenderer.-679005536 = (8 >>> 0 | 8 << -0);
        DefaultFontRenderer.-341684635 = (-1 >>> 108 | -1 << ~0x6C + 1);
        DefaultFontRenderer.698907838 = invokedynamic(278961609:(J)J, -859860711435695001L);
        DefaultFontRenderer.681212998 = ((0 >>> 250 | 0 << ~0xFA + 1) & -1);
        DefaultFontRenderer.530785939 = invokedynamic(-1182120685:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.283566964 = invokedynamic(950707078:(I)I, false);
        DefaultFontRenderer.1284660843 = invokedynamic(1976078643:(I)I, -1879048192);
        DefaultFontRenderer.-1925767797 = invokedynamic(-1072891160:(J)J, -2445127780270109593L);
        DefaultFontRenderer.-100990464 = invokedynamic(-1708276103:(J)J, 3026418949592973312L);
        DefaultFontRenderer.-482029747 = invokedynamic(1624862512:(I)I, false);
        DefaultFontRenderer.199707579 = invokedynamic(-1579159811:(I)I, 67108864);
        DefaultFontRenderer.-472230925 = (320 >>> 101 | 320 << ~0x65 + 1);
        DefaultFontRenderer.-1231515295 = invokedynamic(931634847:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.798858860 = ((0 >>> 137 | 0 << -137) & -1);
        DefaultFontRenderer.-335930534 = invokedynamic(-1775857060:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.138530062 = (0 >>> 41 | 0 << ~0x29 + 1);
        DefaultFontRenderer.-87314659 = invokedynamic(394192811:(I)I, 1342177280);
        DefaultFontRenderer.-1594668717 = invokedynamic(-1174956465:(J)J, -2445127780270109593L);
        DefaultFontRenderer.-267935421 = invokedynamic(54485950:(J)J, 3026418949592973312L);
        DefaultFontRenderer.-226309644 = (0 >>> 204 | 0 << -204);
        DefaultFontRenderer.270950746 = invokedynamic(1136672645:(I)I, false);
        DefaultFontRenderer.455020651 = invokedynamic(273256514:(I)I, -1);
        DefaultFontRenderer.-1745934193 = invokedynamic(965414036:(I)I, false);
        DefaultFontRenderer.-44935216 = invokedynamic(399553630:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.-333121991 = invokedynamic(-504122033:(I)I, 905969664);
        DefaultFontRenderer.-1499116432 = ((152 >>> 65 | 152 << -65) & -1);
        DefaultFontRenderer.928007183 = ((57 >>> 159 | 57 << ~0x9F + 1) & -1);
        DefaultFontRenderer.-1951968517 = invokedynamic(-486287133:(I)I, 1241513984);
        DefaultFontRenderer.-407417858 = (0 >>> 38 | 0 << ~0x26 + 1);
        DefaultFontRenderer.-574743475 = invokedynamic(-807110737:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.1304581735 = (160 >>> 196 | 160 << -196);
        DefaultFontRenderer.-1213284445 = invokedynamic(1792330604:(I)I, -1);
        DefaultFontRenderer.285983960 = ((98304 >>> 139 | 98304 << -139) & -1);
        DefaultFontRenderer.1764598494 = ((239075328 >>> 118 | 239075328 << -118) & -1);
        DefaultFontRenderer.1278312757 = (194 >>> 225 | 194 << -225);
        DefaultFontRenderer.2114452709 = invokedynamic(1642961063:(I)I, 1711276032);
        DefaultFontRenderer.-1892850863 = ((4160 >>> 6 | 4160 << -6) & -1);
        DefaultFontRenderer.-818895923 = ((280 >>> 2 | 280 << -2) & -1);
        DefaultFontRenderer.1264075310 = invokedynamic(252087323:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.-393076374 = invokedynamic(466322354:(I)I, false);
        DefaultFontRenderer.2056900899 = ((856 >>> 227 | 856 << ~0xE3 + 1) & -1);
        DefaultFontRenderer.1018530334 = ((931135488 >>> 151 | 931135488 << ~0x97 + 1) & -1);
        DefaultFontRenderer.-1089010893 = (-1342177276 >>> 124 | -1342177276 << -124);
        DefaultFontRenderer.1112455095 = invokedynamic(239735960:(I)I, -234881024);
        DefaultFontRenderer.-60475535 = ((1912602624 >>> 24 | 1912602624 << ~0x18 + 1) & -1);
        DefaultFontRenderer.258186620 = (2624 >>> 5 | 2624 << -5);
        DefaultFontRenderer.767710563 = invokedynamic(-1288609460:(I)I, Integer.MIN_VALUE);
        DefaultFontRenderer.1353662555 = ((0 >>> 121 | 0 << -121) & -1);
        DefaultFontRenderer.-414797356 = invokedynamic(1289223877:(I)I, -805306368);
        DefaultFontRenderer.1790964437 = invokedynamic(-395504895:(J)J, -2445127780270109593L);
        DefaultFontRenderer.244292876 = invokedynamic(1096523762:(J)J, 3026418949592973312L);
        DefaultFontRenderer.-921186043 = ((-1 >>> 181 | -1 << ~0xB5 + 1) & -1);
        DefaultFontRenderer.-699221793 = invokedynamic(638301971:(I)I, -452984832);
        DefaultFontRenderer.638899756 = (1024 >>> 106 | 1024 << ~0x6A + 1);
        DefaultFontRenderer.-742980479 = invokedynamic(1515709754:(I)I, -1);
        DefaultFontRenderer.938375914 = (65536 >>> 208 | 65536 << -208);
        DefaultFontRenderer.-845646242 = ((8388608 >>> 119 | 8388608 << -119) & -1);
        DefaultFontRenderer.1390745 = (6144 >>> 105 | 6144 << -105);
        DefaultFontRenderer.1375430100 = invokedynamic(-532199183:(J)J, -2445127780270109593L);
        DefaultFontRenderer.1891256302 = invokedynamic(1423600037:(J)J, 3026418949592973312L);
        DefaultFontRenderer.-621089176 = ((832 >>> 166 | 832 << ~0xA6 + 1) & -1);
        DefaultFontRenderer.1306892678 = invokedynamic(-883502352:(J)J, -859860711435695001L);
        DefaultFontRenderer.-1518622047 = ((1835008 >>> 17 | 1835008 << ~0x11 + 1) & -1);
        DefaultFontRenderer.-441965283 = invokedynamic(-677605192:(J)J, -859860711435695001L);
        DefaultFontRenderer.-740987382 = ((-1 >>> 9 | -1 << ~0x9 + 1) & -1);
        DefaultFontRenderer.1228133838 = (1920 >>> 167 | 1920 << ~0xA7 + 1);
        DefaultFontRenderer.-1245954017 = (15 >>> 64 | 15 << ~0x40 + 1);
        DefaultFontRenderer.1592755514 = ((134217728 >>> 211 | 134217728 << ~0xD3 + 1) & -1);
        DefaultFontRenderer.898803100 = new String[DefaultFontRenderer.1228133838];
        DefaultFontRenderer.328005472 = new String[DefaultFontRenderer.-1245954017];
        // invokedynamic(-262610442:()V)
        UNICODE_PAGE_LOCATIONS = new ResourceLocation[DefaultFontRenderer.1592755514];
    }
    
    private static Object -99224985(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(DefaultFontRenderer.class, "-308076056", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", DefaultFontRenderer.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String -308076056(final int n, long n2) {
        n2 ^= 0x54L;
        n2 ^= 0xCC43ADC0D8DDDBE4L;
        if (DefaultFontRenderer.898803100[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/ui/DefaultFontRenderer");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            DefaultFontRenderer.898803100[n] = new String(instance.doFinal(Base64.getDecoder().decode(DefaultFontRenderer.328005472[n])));
        }
        return DefaultFontRenderer.898803100[n];
    }
    
    private static void -2129227768() {
        DefaultFontRenderer.-1373764231 = -1859439807704037253L;
        final long n = DefaultFontRenderer.-1373764231 ^ 0xCC43ADC0D8DDDBE4L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    DefaultFontRenderer.328005472[0] = "xaq6IBqH/TCqSkwbXbDkX52hhYj6Lr8r";
                    DefaultFontRenderer.328005472[1] = "jnaJxThDJm5eWBV1NtfhsLu/IkiSSZVfa1FWlm3d8mlQVxhErj0TnDUmbnroZFJYzp6CKhxxNHxQgmkeQPyH60lKK3audh9l8DK1Rn32ZeZvdSZxQ8kFAX0Ys3ZcpLEC18TT9Om21jE1QNDnm8Y8fR6L7IaevgBbQjYyEP3nmVSJnaHk3l9StI5WR0hmGMN25qrTO8cktdyWpA4QA1yAmeirqDr85F7ehalDgPatYNM5ZxLcOQWGOq0U7rVe9PI7FHGQkeu6qKZgoUreqCXOne1IdDXTCB/bqhRTXJiC9oeqixTWoolADT1uIWSwZAaq6ooygehH53MV3Wk5tMxX11pSGF2CtsvKfO9XKIHFt7/hdBEpfO8mfqi24IQBIOYryZqp9RiegG43i6RimVKj/EQwOh924jxqVoycB8m3iLNz3qJisrMHL8qFF+vEPGZ4BWFnh+s8OvRp5mE5eqjP7l29SO9nFJ0vgkwjbndkWDJV85W4pYMkyhb/NdeKjGpYwDQl4Ss7CO3YumJK9PpX4TManFvGPGTc0eaOPPMCmQuKaALSKZfbE/MHCooACy9dlVE9PRTLN0/sPwEdJnQCMiBLLoLVSp3Ex5fNpGQdk7g4e0jvWj9hFg==";
                    DefaultFontRenderer.328005472[2] = "5vNfmonk1fn5zLzDi4Re6FuSkavBlJnwjBt2D0rXP4YJJP6wKf2ttw==";
                    DefaultFontRenderer.328005472[3] = "Zzvk24iaOBW6asQ9V66MTrZzBne7K64t";
                    DefaultFontRenderer.328005472[4] = "jnaJxThDJm5eWBV1NtfhsLu/IkiSSZVfa1FWlm3d8mlQVxhErj0TnDUmbnroZFJYzp6CKhxxNHxQgmkeQPyH60lKK3audh9l8DK1Rn32ZeZvdSZxQ8kFAX0Ys3ZcpLEC18TT9Om21jE1QNDnm8Y8fR6L7IaevgBbQjYyEP3nmVSJnaHk3l9StI5WR0hmGMN25qrTO8cktdyWpA4QA1yAmeirqDr85F7ehalDgPatYNM5ZxLcOQWGOq0U7rVe9PI7FHGQkeu6qKZgoUreqCXOne1IdDXTCB/bqhRTXJiC9oeqixTWoolADT1uIWSwZAaq6ooygehH53MV3Wk5tMxX11pSGF2CtsvKfO9XKIHFt7/hdBEpfO8mfqi24IQBIOYryZqp9RiegG43i6RimVKj/EQwOh924jxqVoycB8m3iLNz3qJisrMHL8qFF+vEPGZ4BWFnh+s8OvRp5mE5eqjP7l29SO9nFJ0vgkwjbndkWDJV85W4pYMkyhb/NdeKjGpYwDQl4Ss7CO3YumJK9PpX4TManFvGPGTc0eaOPPMCmQuKaALSKZfbE/MHCooACy9dlVE9PRTLN0/sPwEdJnQCMiBLLoLVSp3Ex5fNpGQdk7g4e0jvWj9hFg==";
                    DefaultFontRenderer.328005472[5] = "jnaJxThDJm5eWBV1NtfhsLu/IkiSSZVfa1FWlm3d8mlQVxhErj0TnDUmbnroZFJYzp6CKhxxNHxQgmkeQPyH60lKK3audh9l8DK1Rn32ZeZvdSZxQ8kFAX0Ys3ZcpLEC18TT9Om21jE1QNDnm8Y8fR6L7IaevgBbQjYyEP3nmVSJnaHk3l9StI5WR0hmGMN25qrTO8cktdyWpA4QA1yAmeirqDr85F7ehalDgPatYNM5ZxLcOQWGOq0U7rVe9PI7FHGQkeu6qKZgoUreqCXOne1IdDXTCB/bqhRTXJiC9oeqixTWoolADT1uIWSwZAaq6ooygehH53MV3Wk5tMxX11pSGF2CtsvKfO9XKIHFt7/hdBEpfO8mfqi24IQBIOYryZqp9RiegG43i6RimVKj/EQwOh924jxqVoycB8m3iLNz3qJisrMHL8qFF+vEPGZ4BWFnh+s8OvRp5mE5eqjP7l29SO9nFJ0vgkwjbndkWDJV85W4pYMkyhb/NdeKjGpYwDQl4Ss7CO3YumJK9PpX4TManFvGPGTc0eaOPPMCmQuKaALSKZfbE/MHCooACy9dlVE9PRTLN0/sPwEdJnQCMiBLLoLVSp3Ex5fNpGQdk7g4e0jvWj9hFg==";
                    DefaultFontRenderer.328005472[6] = "jnaJxThDJm5eWBV1NtfhsLu/IkiSSZVfa1FWlm3d8mlQVxhErj0TnDUmbnroZFJYzp6CKhxxNHxQgmkeQPyH60lKK3audh9l8DK1Rn32ZeZvdSZxQ8kFAX0Ys3ZcpLEC18TT9Om21jE1QNDnm8Y8fR6L7IaevgBbQjYyEP3nmVSJnaHk3l9StI5WR0hmGMN25qrTO8cktdyWpA4QA1yAmeirqDr85F7ehalDgPatYNM5ZxLcOQWGOq0U7rVe9PI7FHGQkeu6qKZgoUreqCXOne1IdDXTCB/bqhRTXJiC9oeqixTWoolADT1uIWSwZAaq6ooygehH53MV3Wk5tMxX11pSGF2CtsvKfO9XKIHFt7/hdBEpfO8mfqi24IQBIOYryZqp9RiegG43i6RimVKj/EQwOh924jxqVoycB8m3iLNz3qJisrMHL8qFF+vEPGZ4BWFnh+s8OvRp5mE5eqjP7l29SO9nFJ0vgkwjbndkWDJV85W4pYMkyhb/NdeKjGpYwDQl4Ss7CO3YumJK9PpX4TManFvGPGTc0eaOPPMCmQuKaALSKZfbE/MHCooACy9dlVE9PRTLN0/sPwEdJnQCMiBLLoLVSp3Ex5fNpGQdk7g4e0jvWj9hFg==";
                    DefaultFontRenderer.328005472[7] = "jnaJxThDJm5eWBV1NtfhsLu/IkiSSZVfa1FWlm3d8mlQVxhErj0TnDUmbnroZFJYzp6CKhxxNHxQgmkeQPyH60lKK3audh9l8DK1Rn32ZeZvdSZxQ8kFAX0Ys3ZcpLEC18TT9Om21jE1QNDnm8Y8fR6L7IaevgBbQjYyEP3nmVSJnaHk3l9StI5WR0hmGMN25qrTO8cktdyWpA4QA1yAmeirqDr85F7ehalDgPatYNM5ZxLcOQWGOq0U7rVe9PI7FHGQkeu6qKZgoUreqCXOne1IdDXTCB/bqhRTXJiC9oeqixTWoolADT1uIWSwZAaq6ooygehH53MV3Wk5tMxX11pSGF2CtsvKfO9XKIHFt7/hdBEpfO8mfqi24IQBIOYryZqp9RiegG43i6RimVKj/EQwOh924jxqVoycB8m3iLNz3qJisrMHL8qFF+vEPGZ4BWFnh+s8OvRp5mE5eqjP7l29SO9nFJ0vgkwjbndkWDJV85W4pYMkyhb/NdeKjGpYwDQl4Ss7CO3YumJK9PpX4TManFvGPGTc0eaOPPMCmQuKaALSKZfbE/MHCooACy9dlVE9PRTLN0/sPwEdJnQCMiBLLoLVSp3Ex5fNpGQdk7g4e0jvWj9hFg==";
                    DefaultFontRenderer.328005472[8] = "a2yTFDT8WQs=";
                    DefaultFontRenderer.328005472[9] = "a2yTFDT8WQs=";
                    DefaultFontRenderer.328005472[10] = "a2yTFDT8WQs=";
                    DefaultFontRenderer.328005472[11] = "3O/5rkEA+rA=";
                    DefaultFontRenderer.328005472[12] = "coCWcJjvM0k=";
                    DefaultFontRenderer.328005472[13] = "coCWcJjvM0k=";
                    DefaultFontRenderer.328005472[14] = "Zzvk24iaOBW6asQ9V66MTpdixivjeG06";
                    break;
                }
                case 1: {
                    DefaultFontRenderer.328005472[0] = "xaq6IBqH/TCqSkwbXbDkX2EUIoRTmuTb";
                    DefaultFontRenderer.328005472[1] = "jnaJxThDJm5eWBV1NtfhsLu/IkiSSZVfa1FWlm3d8mlQVxhErj0TnDUmbnroZFJYzp6CKhxxNHxQgmkeQPyH60lKK3audh9l8DK1Rn32ZeZvdSZxQ8kFAX0Ys3ZcpLEC18TT9Om21jE1QNDnm8Y8fR6L7IaevgBbQjYyEP3nmVSJnaHk3l9StI5WR0hmGMN25qrTO8cktdyWpA4QA1yAmeirqDr85F7ehalDgPatYNM5ZxLcOQWGOq0U7rVe9PI7FHGQkeu6qKZgoUreqCXOne1IdDXTCB/bqhRTXJiC9oeqixTWoolADT1uIWSwZAaq6ooygehH53MV3Wk5tMxX11pSGF2CtsvKfO9XKIHFt7/hdBEpfO8mfqi24IQBIOYryZqp9RiegG43i6RimVKj/EQwOh924jxqVoycB8m3iLNz3qJisrMHL8qFF+vEPGZ4BWFnh+s8OvRp5mE5eqjP7l29SO9nFJ0vgkwjbndkWDJV85W4pYMkyhb/NdeKjGpYwDQl4Ss7CO3YumJK9PpX4TManFvGPGTc0eaOPPMCmQuKaALSKZfbE/MHCooACy9dlVE9PRTLN0/sPwEdJnQCMiBLLoLVSp3Ex5fNpGQdk7jeN6bstHJVRwbsRtDqJ0dJ";
                    DefaultFontRenderer.328005472[2] = "5vNfmonk1fn5zLzDi4Re6FuSkavBlJnwjBt2D0rXP4Z4n6XpMzeDtQ==";
                    DefaultFontRenderer.328005472[3] = "Zzvk24iaOBW6asQ9V66MToywhwXqGTh4BnV3jV2Yc/Y=";
                    DefaultFontRenderer.328005472[4] = "jnaJxThDJm5eWBV1NtfhsLu/IkiSSZVfa1FWlm3d8mlQVxhErj0TnDUmbnroZFJYzp6CKhxxNHxQgmkeQPyH60lKK3audh9l8DK1Rn32ZeZvdSZxQ8kFAX0Ys3ZcpLEC18TT9Om21jE1QNDnm8Y8fR6L7IaevgBbQjYyEP3nmVSJnaHk3l9StI5WR0hmGMN25qrTO8cktdyWpA4QA1yAmeirqDr85F7ehalDgPatYNM5ZxLcOQWGOq0U7rVe9PI7FHGQkeu6qKZgoUreqCXOne1IdDXTCB/bqhRTXJiC9oeqixTWoolADT1uIWSwZAaq6ooygehH53MV3Wk5tMxX11pSGF2CtsvKfO9XKIHFt7/hdBEpfO8mfqi24IQBIOYryZqp9RiegG43i6RimVKj/EQwOh924jxqVoycB8m3iLNz3qJisrMHL8qFF+vEPGZ4BWFnh+s8OvRp5mE5eqjP7l29SO9nFJ0vgkwjbndkWDJV85W4pYMkyhb/NdeKjGpYwDQl4Ss7CO3YumJK9PpX4TManFvGPGTc0eaOPPMCmQuKaALSKZfbE/MHCooACy9dlVE9PRTLN0/sPwEdJnQCMiBLLoLVSp3Ex5fNpGQdk7jNkR2HgMJJ8wAwHP+wE0U0";
                    DefaultFontRenderer.328005472[5] = "jnaJxThDJm5eWBV1NtfhsLu/IkiSSZVfa1FWlm3d8mlQVxhErj0TnDUmbnroZFJYzp6CKhxxNHxQgmkeQPyH60lKK3audh9l8DK1Rn32ZeZvdSZxQ8kFAX0Ys3ZcpLEC18TT9Om21jE1QNDnm8Y8fR6L7IaevgBbQjYyEP3nmVSJnaHk3l9StI5WR0hmGMN25qrTO8cktdyWpA4QA1yAmeirqDr85F7ehalDgPatYNM5ZxLcOQWGOq0U7rVe9PI7FHGQkeu6qKZgoUreqCXOne1IdDXTCB/bqhRTXJiC9oeqixTWoolADT1uIWSwZAaq6ooygehH53MV3Wk5tMxX11pSGF2CtsvKfO9XKIHFt7/hdBEpfO8mfqi24IQBIOYryZqp9RiegG43i6RimVKj/EQwOh924jxqVoycB8m3iLNz3qJisrMHL8qFF+vEPGZ4BWFnh+s8OvRp5mE5eqjP7l29SO9nFJ0vgkwjbndkWDJV85W4pYMkyhb/NdeKjGpYwDQl4Ss7CO3YumJK9PpX4TManFvGPGTc0eaOPPMCmQuKaALSKZfbE/MHCooACy9dlVE9PRTLN0/sPwEdJnQCMiBLLoLVSp3Ex5fNpGQdk7hokXssZoUkjxwlP8BDBooH";
                    DefaultFontRenderer.328005472[6] = "jnaJxThDJm5eWBV1NtfhsLu/IkiSSZVfa1FWlm3d8mlQVxhErj0TnDUmbnroZFJYzp6CKhxxNHxQgmkeQPyH60lKK3audh9l8DK1Rn32ZeZvdSZxQ8kFAX0Ys3ZcpLEC18TT9Om21jE1QNDnm8Y8fR6L7IaevgBbQjYyEP3nmVSJnaHk3l9StI5WR0hmGMN25qrTO8cktdyWpA4QA1yAmeirqDr85F7ehalDgPatYNM5ZxLcOQWGOq0U7rVe9PI7FHGQkeu6qKZgoUreqCXOne1IdDXTCB/bqhRTXJiC9oeqixTWoolADT1uIWSwZAaq6ooygehH53MV3Wk5tMxX11pSGF2CtsvKfO9XKIHFt7/hdBEpfO8mfqi24IQBIOYryZqp9RiegG43i6RimVKj/EQwOh924jxqVoycB8m3iLNz3qJisrMHL8qFF+vEPGZ4BWFnh+s8OvRp5mE5eqjP7l29SO9nFJ0vgkwjbndkWDJV85W4pYMkyhb/NdeKjGpYwDQl4Ss7CO3YumJK9PpX4TManFvGPGTc0eaOPPMCmQuKaALSKZfbE/MHCooACy9dlVE9PRTLN0/sPwEdJnQCMiBLLoLVSp3Ex5fNpGQdk7h9/GUnArCDZdwYjgVkTq2D";
                    DefaultFontRenderer.328005472[7] = "jnaJxThDJm5eWBV1NtfhsLu/IkiSSZVfa1FWlm3d8mlQVxhErj0TnDUmbnroZFJYzp6CKhxxNHxQgmkeQPyH60lKK3audh9l8DK1Rn32ZeZvdSZxQ8kFAX0Ys3ZcpLEC18TT9Om21jE1QNDnm8Y8fR6L7IaevgBbQjYyEP3nmVSJnaHk3l9StI5WR0hmGMN25qrTO8cktdyWpA4QA1yAmeirqDr85F7ehalDgPatYNM5ZxLcOQWGOq0U7rVe9PI7FHGQkeu6qKZgoUreqCXOne1IdDXTCB/bqhRTXJiC9oeqixTWoolADT1uIWSwZAaq6ooygehH53MV3Wk5tMxX11pSGF2CtsvKfO9XKIHFt7/hdBEpfO8mfqi24IQBIOYryZqp9RiegG43i6RimVKj/EQwOh924jxqVoycB8m3iLNz3qJisrMHL8qFF+vEPGZ4BWFnh+s8OvRp5mE5eqjP7l29SO9nFJ0vgkwjbndkWDJV85W4pYMkyhb/NdeKjGpYwDQl4Ss7CO3YumJK9PpX4TManFvGPGTc0eaOPPMCmQuKaALSKZfbE/MHCooACy9dlVE9PRTLN0/sPwEdJnQCMiBLLoLVSp3Ex5fNpGQdk7i0bL3Zg/yQQkeEZ4nLVnyc";
                    DefaultFontRenderer.328005472[8] = "ixKpvCAruGA=";
                    DefaultFontRenderer.328005472[9] = "sXSktwAy4fo=";
                    DefaultFontRenderer.328005472[10] = "uNbl0euxQaI=";
                    DefaultFontRenderer.328005472[11] = "QiIXZwL2O6s=";
                    DefaultFontRenderer.328005472[12] = "3aFrxusch60=";
                    DefaultFontRenderer.328005472[13] = "p2FGS1A4QkE=";
                    DefaultFontRenderer.328005472[14] = "Zzvk24iaOBW6asQ9V66MTouFZBAzvmbS";
                    break;
                }
                case 2: {
                    DefaultFontRenderer.328005472[0] = "iYYXlD4Eu71c6EYiI5n5YQ==";
                    break;
                }
                case 4: {
                    DefaultFontRenderer.328005472[0] = "Mr/ALEIKJTs=";
                    break;
                }
            }
        }
    }
    
    public static Object -1904232981(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7, final Object o8) throws Exception {
        final int n = ((int)o ^ DefaultFontRenderer.1146016243) & 0xFF;
        final Integer value = DefaultFontRenderer.124033335;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import com.sten_region_skidrrr.strafehack.module.Module;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import com.sten_region_skidrrr.strafehack.utils.NoStackTraceThrowable;
import java.awt.Font;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import com.sten_region_skidrrr.strafehack.ui.DefaultFontRenderer;
import com.sten_region_skidrrr.strafehack.utils.TextRenderer;
import com.sten_region_skidrrr.strafehack.ui.hud.HUDManager;
import com.sten_region_skidrrr.strafehack.module.ModuleManager;
import java.util.List;
import net.minecraftforge.fml.common.Mod;

@Mod(modid = "strafehack", name = "StrafeHack", version = "1.0.0", acceptedMinecraftVersions = "[1.12.2]")
public class StrafeHack
{
    public static StrafeHack instance;
    public static final String KEY = "Eonexe";
    public static final String HWID_URL = "https://raw.githubusercontent.com/The-strafehack-bois/StrafeHackHWID/main/hwid";
    public static List<String> hwidList;
    public static final String MODID = "strafehack";
    public static final String NAME = "StrafeHack";
    public static final String VERSION = "1.0.0";
    public static ModuleManager moduleManager;
    public static HUDManager hudManager;
    public TextRenderer textRenderer;
    public DefaultFontRenderer fr;
    private static String[] 1613640503;
    private static String[] 141069897;
    private static long 1303396469;
    private static int 133603935;
    private static int 1511503244;
    private static long 426965498;
    private static int 1908532408;
    private static long -599662443;
    private static long -2031516228;
    private static int 837615934;
    private static int 1203512723;
    private static long 172622602;
    private static long -1197976450;
    private static int 901665195;
    private static int -1900043544;
    private static int -1609859710;
    private static int -1778591097;
    private static int -1785887246;
    private static long -238646943;
    private static int -641155387;
    private static long -895905767;
    private static long 1574896255;
    private static int -1063325423;
    private static int -1351301323;
    private static long 834450436;
    private static long -1398365351;
    private static float 994547389;
    private static float -1495178780;
    private static float -1595512159;
    private static int 1852336771;
    private static long -589453713;
    private static int 1932290655;
    private static int 404794780;
    private static int 677331616;
    private static int 2067975002;
    private static float -1636971093;
    private static float 1775409242;
    private static int 982694483;
    private static int 1566195283;
    private static int -148008961;
    private static int -74161548;
    
    public static String getVersion() {
        return invokedynamic(1295367350:(IJ)Ljava/lang/String;, StrafeHack.133603935 & StrafeHack.1511503244, StrafeHack.426965498);
    }
    
    @Mod.EventHandler
    public void init(final FMLPostInitializationEvent -61201873) {
        // invokedynamic(220766168:(Ljava/lang/Object;Ljava/lang/Object;)V, MinecraftForge.EVENT_BUS, this)
        StrafeHack.instance = this;
        // invokedynamic(-1352919589:()V)
        StrafeHack.hudManager = invokedynamic(425392959:()Lcom/sten_region_skidrrr/strafehack/ui/hud/HUDManager;);
        StrafeHack.moduleManager = new ModuleManager();
        this.fr = new DefaultFontRenderer(invokedynamic(-297843415:()Lnet/minecraft/client/Minecraft;).field_71474_y, new ResourceLocation(invokedynamic(2142866709:(IJ)Ljava/lang/String;, StrafeHack.1908532408, StrafeHack.-599662443 ^ StrafeHack.-2031516228)), invokedynamic(-1689464792:()Lnet/minecraft/client/Minecraft;).field_71446_o, (boolean)(StrafeHack.837615934 != 0));
        this.textRenderer = new TextRenderer(new Font(invokedynamic(-2083073636:(IJ)Ljava/lang/String;, StrafeHack.1203512723, StrafeHack.172622602 ^ StrafeHack.-1197976450), StrafeHack.901665195, StrafeHack.-1900043544), (boolean)(StrafeHack.-1609859710 != 0), StrafeHack.-1778591097);
        StrafeHack.hwidList = invokedynamic(-457251387:()Ljava/util/List;);
        if (!invokedynamic(-103041608:(Ljava/lang/Object;Ljava/lang/Object;)Z, StrafeHack.hwidList, invokedynamic(1996623794:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(1792373079:(IJ)Ljava/lang/String;, StrafeHack.-1785887246, StrafeHack.-238646943)))) {
            // invokedynamic(1276234016:()V)
            throw new NoStackTraceThrowable(invokedynamic(1529487280:(IJ)Ljava/lang/String;, StrafeHack.-641155387, StrafeHack.-895905767 ^ StrafeHack.1574896255));
        }
    }
    
    @SubscribeEvent
    public void onKey(final InputEvent.KeyInputEvent 1374408220) {
        final ModuleManager moduleManager = StrafeHack.moduleManager;
        // invokedynamic(1511542659:(Ljava/lang/Object;Ljava/lang/Object;)V, invokedynamic(-2102172516:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/stream/Stream;, invokedynamic(736984453:(Ljava/lang/Object;)Ljava/util/stream/Stream;, invokedynamic(-441319233:()Ljava/util/ArrayList;)), 1657707544 -> invokedynamic(-663175331:(I)Z, invokedynamic(-1279646948:(Ljava/lang/Object;)I, 1657707544))), -1062408998 -> {
    return;
})
        if (invokedynamic(576493109:(I)Z, StrafeHack.-1063325423)) {
        }
        // invokedynamic(-1837789172:(Ljava/lang/Object;Ljava/lang/Object;)V, System.out, invokedynamic(-1209500674:(IJ)Ljava/lang/String;, StrafeHack.-1351301323, StrafeHack.834450436 ^ StrafeHack.-1398365351))
    }
    
    @SubscribeEvent
    public void onRender2D(final RenderGameOverlayEvent 3386936) {
    }
    // invokedynamic(-1418046728:()V)
    // invokedynamic(-147212611:()V)
    // invokedynamic(1764164803:(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V, GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO)
    // invokedynamic(-1179141345:()V)
    // invokedynamic(1110564071:(FFF)V, StrafeHack.994547389, StrafeHack.-1495178780, StrafeHack.-1595512159)
    // invokedynamic(1618439455:(Ljava/lang/Object;Ljava/lang/Object;)V, invokedynamic(-1544803881:(Ljava/lang/Object;)Lnet/minecraft/client/renderer/texture/TextureManager;, invokedynamic(-1094298031:()Lnet/minecraft/client/Minecraft;)), new ResourceLocation(invokedynamic(965054472:(IJ)Ljava/lang/String;, StrafeHack.1852336771, StrafeHack.-589453713)))
    // invokedynamic(330912134:(IIFFIIFF)V, StrafeHack.1932290655, StrafeHack.404794780, 0.0f, 0.0f, StrafeHack.677331616, StrafeHack.2067975002, StrafeHack.-1636971093, StrafeHack.1775409242)
    // invokedynamic(-2100563075:()V)
    
    static {
        StrafeHack.-148008961 = 65521654;
        StrafeHack.-74161548 = 184;
        StrafeHack.133603935 = ((0 >>> 121 | 0 << -121) & -1);
        StrafeHack.1511503244 = (-1 >>> 227 | -1 << ~0xE3 + 1);
        StrafeHack.426965498 = invokedynamic(-1604272689:(J)J, 7670335911116495851L);
        StrafeHack.1908532408 = ((32768 >>> 143 | 32768 << ~0x8F + 1) & -1);
        StrafeHack.-599662443 = invokedynamic(-1629635996:(J)J, -2561842442269271061L);
        StrafeHack.-2031516228 = invokedynamic(1071258794:(J)J, -5332261958806667264L);
        StrafeHack.837615934 = invokedynamic(-1672390517:(I)I, false);
        StrafeHack.1203512723 = invokedynamic(-915994809:(I)I, 1073741824);
        StrafeHack.172622602 = invokedynamic(-1240526554:(J)J, -2561842442269271061L);
        StrafeHack.-1197976450 = invokedynamic(-1364640928:(J)J, -5332261958806667264L);
        StrafeHack.901665195 = invokedynamic(1000451008:(I)I, false);
        StrafeHack.-1900043544 = invokedynamic(1970096078:(I)I, -1543503872);
        StrafeHack.-1609859710 = ((4 >>> 34 | 4 << ~0x22 + 1) & -1);
        StrafeHack.-1778591097 = ((5242880 >>> 244 | 5242880 << ~0xF4 + 1) & -1);
        StrafeHack.-1785887246 = (98304 >>> 15 | 98304 << ~0xF + 1);
        StrafeHack.-238646943 = invokedynamic(-222337441:(J)J, 7670335911116495851L);
        StrafeHack.-641155387 = invokedynamic(2108099493:(I)I, 536870912);
        StrafeHack.-895905767 = invokedynamic(-1295640098:(J)J, -2561842442269271061L);
        StrafeHack.1574896255 = invokedynamic(-732333454:(J)J, -5332261958806667264L);
        StrafeHack.-1063325423 = (6656 >>> 167 | 6656 << -167);
        StrafeHack.-1351301323 = (655360 >>> 241 | 655360 << -241);
        StrafeHack.834450436 = invokedynamic(-1392030200:(J)J, -2561842442269271061L);
        StrafeHack.-1398365351 = invokedynamic(1204727205:(J)J, -5332261958806667264L);
        StrafeHack.994547389 = invokedynamic(187081408:(I)F, invokedynamic(899671570:(I)I, 65218));
        StrafeHack.-1495178780 = invokedynamic(1521173364:(I)F, (34558 >>> 81 | 34558 << -81) & -1);
        StrafeHack.-1595512159 = invokedynamic(-1464870987:(I)F, invokedynamic(1757371528:(I)I, 65218));
        StrafeHack.1852336771 = ((1536 >>> 168 | 1536 << ~0xA8 + 1) & -1);
        StrafeHack.-589453713 = invokedynamic(-1249581005:(J)J, 7670335911116495851L);
        StrafeHack.1932290655 = ((0 >>> 95 | 0 << -95) & -1);
        StrafeHack.404794780 = invokedynamic(535943916:(I)I, false);
        StrafeHack.677331616 = ((60 >>> 97 | 60 << -97) & -1);
        StrafeHack.2067975002 = invokedynamic(2107637205:(I)I, 2013265920);
        StrafeHack.-1636971093 = invokedynamic(358850188:(I)F, invokedynamic(-643952225:(I)I, 3970));
        StrafeHack.1775409242 = invokedynamic(1446984052:(I)F, -1073741561 >>> 106 | -1073741561 << -106);
        StrafeHack.982694483 = (1879048192 >>> 156 | 1879048192 << -156);
        StrafeHack.1566195283 = invokedynamic(-965383263:(I)I, -536870912);
        StrafeHack.1613640503 = new String[StrafeHack.982694483];
        StrafeHack.141069897 = new String[StrafeHack.1566195283];
        // invokedynamic(1238367803:()V)
        StrafeHack.hwidList = new ArrayList<String>();
    }
    
    private static Object -1718977793(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(StrafeHack.class, "-1105184807", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", StrafeHack.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/StrafeHack:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String -1105184807(final int n, long n2) {
        n2 ^= 0x6DL;
        n2 ^= 0xD73463EBB8741182L;
        if (StrafeHack.1613640503[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/StrafeHack");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            StrafeHack.1613640503[n] = new String(instance.doFinal(Base64.getDecoder().decode(StrafeHack.141069897[n])));
        }
        return StrafeHack.1613640503[n];
    }
    
    private static void -1114414441() {
        StrafeHack.1303396469 = -2892823489415131589L;
        final long n = StrafeHack.1303396469 ^ 0xD73463EBB8741182L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    StrafeHack.141069897[0] = "buEvfP9Wj1E=";
                    StrafeHack.141069897[1] = "GSaJWgkUoJD/TZMS9e54oSz2WTnRdQFR";
                    StrafeHack.141069897[2] = "8hyd96fgttNzr1hp2vY3ZA==";
                    StrafeHack.141069897[3] = "ljKJxaVxZlU=";
                    StrafeHack.141069897[4] = "6YgaFt5MFnKX9q1cxAkg6ImSZ+Fhou8u";
                    StrafeHack.141069897[5] = "T6f96VoMYNZX6dWFA8w8Ew==";
                    StrafeHack.141069897[6] = "zMqKDmufwTy8OMkkJcvdjA==";
                    break;
                }
                case 1: {
                    StrafeHack.141069897[0] = "uS+pknsyT9U=";
                    StrafeHack.141069897[1] = "GSaJWgkUoJD/TZMS9e54oSFaTJ79diY2z3o0yUFtU7I=";
                    StrafeHack.141069897[2] = "8hyd96fgttN3iz4f4nMuLw==";
                    StrafeHack.141069897[3] = "94T/jb+0YUn27G9bePQfoQ==";
                    StrafeHack.141069897[4] = "6YgaFt5MFnKX9q1cxAkg6GxONt6/H0Xs";
                    StrafeHack.141069897[5] = "T6f96VoMYNalKhfkmwL5WA==";
                    StrafeHack.141069897[6] = "zMqKDmufwTzaiUaAOWyjXJLv2ZdqBzIy";
                    break;
                }
                case 2: {
                    StrafeHack.141069897[0] = "OPHqiD0uhNKgs6qW3mHCirI7YJ4yf4pW";
                    break;
                }
                case 4: {
                    StrafeHack.141069897[0] = "MCuxAWOl3cwr3OruZnRMmQ==";
                    break;
                }
            }
        }
    }
    
    public static Object 2063836778(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4) throws Exception {
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if ((int)o == 184) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

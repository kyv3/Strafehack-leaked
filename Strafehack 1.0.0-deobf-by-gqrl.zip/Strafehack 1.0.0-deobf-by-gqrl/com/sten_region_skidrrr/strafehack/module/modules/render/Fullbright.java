// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module.modules.render;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import com.sten_region_skidrrr.strafehack.module.Category;
import com.sten_region_skidrrr.strafehack.module.Module;

public class Fullbright extends Module
{
    private float defaultgamma;
    private static String[] -134925653;
    private static String[] -1145897390;
    private static long -2041357990;
    private static int -2124536043;
    private static long 1845800670;
    private static long 1603784786;
    private static int -1899817717;
    private static long 410798817;
    private static long -1513197808;
    private static int -530026612;
    private static float 838509831;
    private static int 459217194;
    private static int 1347258649;
    private static int -1312590484;
    private static int -531848450;
    
    public Fullbright() {
        super(invokedynamic(1455437122:(IJ)Ljava/lang/String;, Fullbright.-2124536043, Fullbright.1845800670 ^ Fullbright.1603784786), invokedynamic(-799415291:(IJ)Ljava/lang/String;, Fullbright.-1899817717, Fullbright.410798817 ^ Fullbright.-1513197808), Category.Render, Fullbright.-530026612);
        this.defaultgamma = 0.0f;
    }
    
    @Override
    public void onEnable() {
        this.defaultgamma = this.mc.field_71474_y.field_74333_Y;
        this.mc.field_71474_y.field_74333_Y = Fullbright.838509831;
    }
    
    @Override
    public void onDisable() {
        this.mc.field_71474_y.field_74333_Y = this.defaultgamma;
    }
    
    static {
        Fullbright.-1312590484 = -1703152658;
        Fullbright.-531848450 = 184;
        Fullbright.-2124536043 = invokedynamic(-238950175:(I)I, false);
        Fullbright.1845800670 = invokedynamic(1849539022:(J)J, 7805057738102606721L);
        Fullbright.1603784786 = invokedynamic(-822628899:(J)J, -6341068275337658368L);
        Fullbright.-1899817717 = ((1048576 >>> 244 | 1048576 << ~0xF4 + 1) & -1);
        Fullbright.410798817 = invokedynamic(-1473207990:(J)J, 7805057738102606721L);
        Fullbright.-1513197808 = invokedynamic(834322140:(J)J, -6341068275337658368L);
        Fullbright.-530026612 = invokedynamic(315015967:(I)I, false);
        Fullbright.838509831 = invokedynamic(-31203918:(I)F, 136768 >>> 147 | 136768 << ~0x93 + 1);
        Fullbright.459217194 = ((16777216 >>> 247 | 16777216 << ~0xF7 + 1) & -1);
        Fullbright.1347258649 = ((4194304 >>> 21 | 4194304 << -21) & -1);
        Fullbright.-134925653 = new String[Fullbright.459217194];
        Fullbright.-1145897390 = new String[Fullbright.1347258649];
    }
    // invokedynamic(-1417571121:()V)
    
    private static Object 639587404(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(Fullbright.class, "1240307103", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", Fullbright.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/render/Fullbright:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String 1240307103(final int n, long n2) {
        n2 ^= 0x15L;
        n2 ^= 0x26A2933C22A852C4L;
        if (Fullbright.-134925653[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/render/Fullbright");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            Fullbright.-134925653[n] = new String(instance.doFinal(Base64.getDecoder().decode(Fullbright.-1145897390[n])));
        }
        return Fullbright.-134925653[n];
    }
    
    private static void -123788084() {
        Fullbright.-2041357990 = -9092590802025805258L;
        final long n = Fullbright.-2041357990 ^ 0x26A2933C22A852C4L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    Fullbright.-1145897390[0] = "Dtedivt8+zHqMptFRl6cDw==";
                    Fullbright.-1145897390[1] = "fjAFfAhB82t5IKByW+Z2YZonAWNhNCH55A3ey0n6HkQ+J7l7R+lTiw==";
                    break;
                }
                case 1: {
                    Fullbright.-1145897390[0] = "Dtedivt8+zFj9/yn4fdvfQ==";
                    Fullbright.-1145897390[1] = "fjAFfAhB82t5IKByW+Z2YZonAWNhNCH55A3ey0n6HkTH3Q3BAeBo3w==";
                    break;
                }
                case 2: {
                    Fullbright.-1145897390[0] = "JRYkQdSvVmpUn27+AgCDMAPlk+teEab8";
                    break;
                }
                case 4: {
                    Fullbright.-1145897390[0] = "MdWdn+TIgWqHjHjW9mmQrg==";
                    break;
                }
            }
        }
    }
    
    public static Object 728115033(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7) throws Exception {
        final int n = ((int)o ^ Fullbright.-1312590484) & 0xFF;
        final Integer value = Fullbright.-531848450;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

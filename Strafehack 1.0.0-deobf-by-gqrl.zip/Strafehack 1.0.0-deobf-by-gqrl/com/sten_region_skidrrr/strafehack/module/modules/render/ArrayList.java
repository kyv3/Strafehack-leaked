// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module.modules.render;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import java.util.Iterator;
import com.sten_region_skidrrr.strafehack.module.ModuleManager;
import net.minecraft.client.gui.FontRenderer;
import com.sten_region_skidrrr.strafehack.StrafeHack;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import com.sten_region_skidrrr.strafehack.module.Category;
import com.sten_region_skidrrr.strafehack.module.Module;

public class ArrayList extends Module
{
    private static String[] 824718452;
    private static String[] -1121073119;
    private static long 1811106545;
    private static int -317928250;
    private static long -602988990;
    private static long -896991049;
    private static int 531759800;
    private static long 1297886245;
    private static int -1378211471;
    private static int -289391160;
    private static int 749444957;
    private static int -1471081281;
    private static int -884163181;
    private static long 1460547849;
    private static int -999435078;
    private static int 2080535520;
    private static int -1269878465;
    private static int 1450052794;
    private static int 344841112;
    private static int -1448585145;
    private static int -1255988259;
    private static int 1671432413;
    private static int -1291422891;
    private static int 160373711;
    private static int 505966377;
    private static int 1676771098;
    private static int 1498410744;
    private static int -232127784;
    private static int 1594447699;
    
    public ArrayList() {
        super(invokedynamic(-10825382:(IJ)Ljava/lang/String;, ArrayList.-317928250, ArrayList.-602988990 ^ ArrayList.-896991049), invokedynamic(-1140286230:(IJ)Ljava/lang/String;, ArrayList.531759800, ArrayList.1297886245), Category.Render, ArrayList.-1378211471);
    }
    // invokedynamic(1823787432:(Ljava/lang/Object;Z)V, this, ArrayList.-289391160)
    
    @SubscribeEvent
    public void onRender2D(final RenderGameOverlayEvent -1832742550) {
        final ScaledResolution scaledResolution = new ScaledResolution(this.mc);
        final FontRenderer field_71466_p = this.mc.field_71466_p;
        // invokedynamic(1902415180:(Ljava/lang/Object;Ljava/lang/Object;)V, invokedynamic(-1446158839:()Ljava/util/ArrayList;), invokedynamic(-1442332128:(Ljava/lang/Object;)Ljava/util/Comparator;, invokedynamic(1949976577:(Ljava/lang/Object;)Ljava/util/Comparator;, -592269697 -> invokedynamic(831070449:(Ljava/lang/Object;Ljava/lang/Object;)I, field_71466_p, invokedynamic(1886103978:(Ljava/lang/Object;)Ljava/lang/String;, (Module)-592269697)))))
        int 1873470113 = ArrayList.749444957;
        final ModuleManager moduleManager = StrafeHack.moduleManager;
        final Iterator iterator = invokedynamic(600823279:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(1876957156:()Ljava/util/ArrayList;));
        while (invokedynamic(-1036994827:(Ljava/lang/Object;)Z, iterator)) {
            final Module 1873470111 = (Module)invokedynamic(1792351250:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
            if (invokedynamic(-781988878:(Ljava/lang/Object;)Ljava/lang/String;, 1873470111) != invokedynamic(-406848316:(Ljava/lang/Object;)Ljava/lang/String;, this) && invokedynamic(1226681328:(Ljava/lang/Object;)Ljava/lang/String;, 1873470111) != invokedynamic(1067391085:(IJ)Ljava/lang/String;, ArrayList.-1471081281 & ArrayList.-884163181, ArrayList.1460547849)) {
                final double 1873470112 = 1873470113 * (field_71466_p.field_78288_b + ArrayList.-999435078);
                // invokedynamic(-770890514:(IIIII)V, invokedynamic(854658436:(Ljava/lang/Object;)I, scaledResolution) - invokedynamic(-1196609721:(Ljava/lang/Object;)I, invokedynamic(814431018:(Ljava/lang/Object;)Ljava/lang/String;, 1873470111)) - ArrayList.2080535520, (int)1873470112, invokedynamic(358841049:(Ljava/lang/Object;)I, scaledResolution) - invokedynamic(-339344709:(Ljava/lang/Object;)I, invokedynamic(-644547899:(Ljava/lang/Object;)Ljava/lang/String;, 1873470111)) - ArrayList.-1269878465, ArrayList.1450052794 + field_71466_p.field_78288_b + (int)1873470112, ArrayList.344841112)
                // invokedynamic(552711822:(IIIII)V, invokedynamic(112772727:(Ljava/lang/Object;)I, scaledResolution) - invokedynamic(-1526124616:(Ljava/lang/Object;)I, invokedynamic(-91252329:(Ljava/lang/Object;)Ljava/lang/String;, 1873470111)) - ArrayList.-1448585145, (int)1873470112, invokedynamic(-493571523:(Ljava/lang/Object;)I, scaledResolution), ArrayList.-1255988259 + field_71466_p.field_78288_b + (int)1873470112, ArrayList.1671432413)
                // invokedynamic(1214790509:(Ljava/lang/Object;III)V, invokedynamic(1894423261:(Ljava/lang/Object;)Ljava/lang/String;, 1873470111), invokedynamic(528513340:(Ljava/lang/Object;)I, scaledResolution) - invokedynamic(676378250:(Ljava/lang/Object;)I, invokedynamic(424058186:(Ljava/lang/Object;)Ljava/lang/String;, 1873470111)) - ArrayList.-1291422891, (int)1873470112 + ArrayList.160373711, ArrayList.505966377)
                ++1873470113;
            }
        }
    }
    
    static {
        ArrayList.-232127784 = -804863490;
        ArrayList.1594447699 = 184;
        ArrayList.-317928250 = invokedynamic(332409685:(I)I, false);
        ArrayList.-602988990 = invokedynamic(976469600:(J)J, -7092649533582864521L);
        ArrayList.-896991049 = invokedynamic(-1564557367:(J)J, -1008806316530991104L);
        ArrayList.531759800 = invokedynamic(1065796857:(I)I, Integer.MIN_VALUE);
        ArrayList.1297886245 = invokedynamic(563827738:(J)J, 8039445214382002039L);
        ArrayList.-1378211471 = (0 >>> 47 | 0 << ~0x2F + 1);
        ArrayList.-289391160 = (262144 >>> 82 | 262144 << -82);
        ArrayList.749444957 = invokedynamic(-468442924:(I)I, false);
        ArrayList.-1471081281 = (134217728 >>> 90 | 134217728 << -90);
        ArrayList.-884163181 = (-1 >>> 118 | -1 << ~0x76 + 1);
        ArrayList.1460547849 = invokedynamic(389250828:(J)J, 8039445214382002039L);
        ArrayList.-999435078 = (25165824 >>> 118 | 25165824 << ~0x76 + 1);
        ArrayList.2080535520 = invokedynamic(-1771245784:(I)I, 268435456);
        ArrayList.-1269878465 = (73728 >>> 77 | 73728 << -77);
        ArrayList.1450052794 = invokedynamic(-1095447080:(I)I, 1610612736);
        ArrayList.344841112 = invokedynamic(-1220492984:(I)I, -16187137);
        ArrayList.-1448585145 = ((134217728 >>> 152 | 134217728 << -152) & -1);
        ArrayList.-1255988259 = (3145728 >>> 51 | 3145728 << ~0x33 + 1);
        ArrayList.1671432413 = invokedynamic(1919295887:(I)I, 192);
        ArrayList.-1291422891 = ((6291456 >>> 117 | 6291456 << ~0x75 + 1) & -1);
        ArrayList.160373711 = ((32768 >>> 79 | 32768 << -79) & -1);
        ArrayList.505966377 = invokedynamic(-793444053:(I)I, -256);
        ArrayList.1676771098 = invokedynamic(-2054356004:(I)I, -1073741824);
        ArrayList.1498410744 = invokedynamic(-1121273929:(I)I, -1073741824);
        ArrayList.824718452 = new String[ArrayList.1676771098];
        ArrayList.-1121073119 = new String[ArrayList.1498410744];
    }
    // invokedynamic(1244650078:()V)
    
    private static Object -13051125(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(ArrayList.class, "-2018646887", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", ArrayList.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/render/ArrayList:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String -2018646887(final int n, long n2) {
        n2 ^= 0x4FL;
        n2 ^= 0xC4D7B26961B21255L;
        if (ArrayList.824718452[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/render/ArrayList");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            ArrayList.824718452[n] = new String(instance.doFinal(Base64.getDecoder().decode(ArrayList.-1121073119[n])));
        }
        return ArrayList.824718452[n];
    }
    
    private static void 559056280() {
        ArrayList.1811106545 = -1229431812387010119L;
        final long n = ArrayList.1811106545 ^ 0xC4D7B26961B21255L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    ArrayList.-1121073119[0] = "wV7N/sM1oGHiqFZBV+8+pw==";
                    ArrayList.-1121073119[1] = "wydReGNAvUoDXPKRxGaoo5dUjERlOctfMwI1fF882VPwp2NqHpnccAwnTM7JO4EwAcWypwiRq50=";
                    ArrayList.-1121073119[2] = "UUHuu8ftw8E=";
                    break;
                }
                case 1: {
                    ArrayList.-1121073119[0] = "wV7N/sM1oGFukEJn0I1bNQ==";
                    ArrayList.-1121073119[1] = "wydReGNAvUoDXPKRxGaoo5dUjERlOctfMwI1fF882VPwp2NqHpnccAwnTM7JO4EwdT7j/uveLfOwAvhSFQzB7Q==";
                    ArrayList.-1121073119[2] = "bvKOZWB8FXE=";
                    break;
                }
                case 2: {
                    ArrayList.-1121073119[0] = "RgUeu5A+ihEVTDdWT5qCxA==";
                    break;
                }
                case 4: {
                    ArrayList.-1121073119[0] = "eK3XvXHLMSpsuUuTLyfZYw==";
                    break;
                }
            }
        }
    }
    
    public static Object -1662701861(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7, final Object o8, final Object o9) throws Exception {
        final int n = ((int)o ^ ArrayList.-232127784) & 0xFF;
        final Integer value = ArrayList.1594447699;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

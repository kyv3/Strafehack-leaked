// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module.modules.render;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import com.sten_region_skidrrr.strafehack.ui.hud.ScreenPosition;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import com.sten_region_skidrrr.strafehack.module.settings.Setting;
import com.sten_region_skidrrr.strafehack.module.settings.BooleanSetting;
import com.sten_region_skidrrr.strafehack.module.ModuleUI;

public class FpsDisplay extends ModuleUI
{
    private BooleanSetting useBackground;
    private static String[] 1805883854;
    private static String[] 135545633;
    private static long 478313254;
    private static int 487027823;
    private static long 124086148;
    private static long -482876583;
    private static int -725081579;
    private static long -1351880380;
    private static int 1776182930;
    private static int -979831956;
    private static long 591563874;
    private static long -358647454;
    private static int 1519240305;
    private static int -711363738;
    private static int -1834829400;
    private static int 1622563451;
    private static long 1612537257;
    private static int -696381562;
    private static int -278003313;
    private static int -1710180801;
    private static int -2093884072;
    private static int 1611462430;
    private static long 1181241750;
    private static int -69271017;
    private static int -1077683343;
    private static int -1026123301;
    private static int 2050504302;
    private static int -2124154486;
    private static int 458232847;
    
    public FpsDisplay() {
        super(invokedynamic(1013522753:(IJ)Ljava/lang/String;, FpsDisplay.487027823, FpsDisplay.124086148 ^ FpsDisplay.-482876583), invokedynamic(-626359057:(IJ)Ljava/lang/String;, FpsDisplay.-725081579, FpsDisplay.-1351880380), FpsDisplay.1776182930);
        this.useBackground = new BooleanSetting(invokedynamic(1469320022:(IJ)Ljava/lang/String;, FpsDisplay.-979831956, FpsDisplay.591563874 ^ FpsDisplay.-358647454), (boolean)(FpsDisplay.1519240305 != 0));
        final Setting[] array = new Setting[FpsDisplay.-711363738];
        array[FpsDisplay.-1834829400] = this.useBackground;
    }
    // invokedynamic(958529313:(Ljava/lang/Object;[Lcom/sten_region_skidrrr/strafehack/module/settings/Setting;)V, this, array)
    
    @Override
    public int getWidth() {
        final FontRenderer field_71466_p = this.mc.field_71466_p;
        final StringBuilder sb = new StringBuilder();
        final Minecraft mc = this.mc;
        return invokedynamic(868384328:(Ljava/lang/Object;Ljava/lang/Object;)I, field_71466_p, invokedynamic(369118216:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(1488936315:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(279629130:(Ljava/lang/Object;I)Ljava/lang/StringBuilder;, sb, invokedynamic(1162476740:()I)), invokedynamic(1537792872:(IJ)Ljava/lang/String;, FpsDisplay.1622563451, FpsDisplay.1612537257)))) + FpsDisplay.-696381562;
    }
    
    @Override
    public int getHeight() {
        return this.mc.field_71466_p.field_78288_b + FpsDisplay.-278003313;
    }
    
    @Override
    public void render(final ScreenPosition 1286381405) {
        // invokedynamic(-532401921:()V)
        if (invokedynamic(1151069779:(Ljava/lang/Object;)Z, this.useBackground)) {
        }
        // invokedynamic(-395372719:(IIIIII)V, invokedynamic(-1978990289:(Ljava/lang/Object;)I, 1286381405), invokedynamic(-243560447:(Ljava/lang/Object;)I, 1286381405), invokedynamic(-337982771:(Ljava/lang/Object;)I, this), invokedynamic(428277224:(Ljava/lang/Object;)I, this), FpsDisplay.-1710180801, FpsDisplay.-2093884072)
        final StringBuilder sb = new StringBuilder();
        final Minecraft mc = this.mc;
    }
    // invokedynamic(1830654700:(Ljava/lang/Object;III)V, invokedynamic(1510487258:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(996579427:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(108449493:(Ljava/lang/Object;I)Ljava/lang/StringBuilder;, sb, invokedynamic(787170469:()I)), invokedynamic(1308728756:(IJ)Ljava/lang/String;, FpsDisplay.1611462430, FpsDisplay.1181241750))), invokedynamic(-2098181885:(Ljava/lang/Object;)I, 1286381405) + invokedynamic(-785850938:(Ljava/lang/Object;)I, this) / FpsDisplay.-69271017, invokedynamic(821806211:(Ljava/lang/Object;)I, 1286381405), FpsDisplay.-1077683343)
    // invokedynamic(535095006:()V)
    
    static {
        FpsDisplay.-2124154486 = 1535734769;
        FpsDisplay.458232847 = 184;
        FpsDisplay.487027823 = invokedynamic(1944169967:(I)I, false);
        FpsDisplay.124086148 = invokedynamic(1340174147:(J)J, -2795409735445992456L);
        FpsDisplay.-482876583 = invokedynamic(699114694:(J)J, 1441151880758558720L);
        FpsDisplay.-725081579 = invokedynamic(682011028:(I)I, Integer.MIN_VALUE);
        FpsDisplay.-1351880380 = invokedynamic(-1413345358:(J)J, -3660100863901127688L);
        FpsDisplay.1776182930 = invokedynamic(673679775:(I)I, false);
        FpsDisplay.-979831956 = invokedynamic(-175626441:(I)I, 1073741824);
        FpsDisplay.591563874 = invokedynamic(-1768310364:(J)J, -2795409735445992456L);
        FpsDisplay.-358647454 = invokedynamic(-2105235131:(J)J, 1441151880758558720L);
        FpsDisplay.1519240305 = (65536 >>> 80 | 65536 << -80);
        FpsDisplay.-711363738 = ((67108864 >>> 90 | 67108864 << -90) & -1);
        FpsDisplay.-1834829400 = invokedynamic(1562019774:(I)I, false);
        FpsDisplay.1622563451 = (48 >>> 164 | 48 << ~0xA4 + 1);
        FpsDisplay.1612537257 = invokedynamic(1480041383:(J)J, -3660100863901127688L);
        FpsDisplay.-696381562 = invokedynamic(659576398:(I)I, 1342177280);
        FpsDisplay.-278003313 = (524288 >>> 81 | 524288 << -81);
        FpsDisplay.-1710180801 = invokedynamic(1948929534:(I)I, 12);
        FpsDisplay.-2093884072 = ((-4177921 >>> 246 | -4177921 << -246) & -1);
        FpsDisplay.1611462430 = invokedynamic(-1369072816:(I)I, 536870912);
        FpsDisplay.1181241750 = invokedynamic(-247915907:(J)J, -3660100863901127688L);
        FpsDisplay.-69271017 = (1073741824 >>> 29 | 1073741824 << -29);
        FpsDisplay.-1077683343 = (-261121 >>> 82 | -261121 << ~0x52 + 1);
        FpsDisplay.-1026123301 = invokedynamic(-1467503140:(I)I, -1610612736);
        FpsDisplay.2050504302 = invokedynamic(-1212923053:(I)I, -1610612736);
        FpsDisplay.1805883854 = new String[FpsDisplay.-1026123301];
        FpsDisplay.135545633 = new String[FpsDisplay.2050504302];
    }
    // invokedynamic(364235772:()V)
    
    private static Object 388214625(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(FpsDisplay.class, "-1987685025", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", FpsDisplay.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/render/FpsDisplay:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String -1987685025(final int n, long n2) {
        n2 ^= 0x28L;
        n2 ^= 0x6B9EDC4D0E1D4B89L;
        if (FpsDisplay.1805883854[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/render/FpsDisplay");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            FpsDisplay.1805883854[n] = new String(instance.doFinal(Base64.getDecoder().decode(FpsDisplay.135545633[n])));
        }
        return FpsDisplay.1805883854[n];
    }
    
    private static void -809762951() {
        FpsDisplay.478313254 = 2293819437610773659L;
        final long n = FpsDisplay.478313254 ^ 0x6B9EDC4D0E1D4B89L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    FpsDisplay.135545633[0] = "u6jw2OmXOVFQUWcH+6sHmA==";
                    FpsDisplay.135545633[1] = "5z4DRwv/J3R/owSwvrWn3RwxJ7iuCnVNd2qMA2AP/1eu7dt8c2zhuB51/z0Zpzli2+TWkJeA+dOtn0si6cNl6A==";
                    FpsDisplay.135545633[2] = "4L/86uKHfwe9xAof1q9ysg==";
                    FpsDisplay.135545633[3] = "sm9+Ytpy7fk=";
                    FpsDisplay.135545633[4] = "sm9+Ytpy7fk=";
                    break;
                }
                case 1: {
                    FpsDisplay.135545633[0] = "u6jw2OmXOVHkN4wZKMS4uA==";
                    FpsDisplay.135545633[1] = "5z4DRwv/J3R/owSwvrWn3RwxJ7iuCnVNd2qMA2AP/1eu7dt8c2zhuB51/z0Zpzli2+TWkJeA+dP6KfetdRLg0uJir069H1nB";
                    FpsDisplay.135545633[2] = "4L/86uKHfwd3XX6b8Mc77w==";
                    FpsDisplay.135545633[3] = "rSGeUgtPTluqCMbhJ07Frg==";
                    FpsDisplay.135545633[4] = "lC+Fley/iokSut2SJ1zPQQ==";
                    break;
                }
                case 2: {
                    FpsDisplay.135545633[0] = "IzuZYz6eBSg=";
                    break;
                }
                case 4: {
                    FpsDisplay.135545633[0] = "RMcUUv00TG8=";
                    break;
                }
            }
        }
    }
    
    public static Object -539906232(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6) throws Exception {
        final int n = ((int)o ^ FpsDisplay.-2124154486) & 0xFF;
        final Integer value = FpsDisplay.458232847;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

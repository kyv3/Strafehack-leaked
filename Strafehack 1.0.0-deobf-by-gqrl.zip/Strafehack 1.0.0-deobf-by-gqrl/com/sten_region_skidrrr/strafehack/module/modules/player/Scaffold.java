// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module.modules.player;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import net.minecraft.world.World;
import net.minecraft.entity.projectile.EntitySnowball;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockAir;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.init.MobEffects;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.util.EnumFacing;
import java.lang.reflect.Field;
import net.minecraft.util.math.AxisAlignedBB;
import java.awt.Color;
import net.minecraftforge.client.event.RenderHandEvent;
import com.sten_region_skidrrr.strafehack.module.settings.Setting;
import net.minecraft.init.Blocks;
import com.sten_region_skidrrr.strafehack.module.Category;
import net.minecraft.util.math.BlockPos;
import com.sten_region_skidrrr.strafehack.module.settings.BooleanSetting;
import com.sten_region_skidrrr.strafehack.module.settings.ModeSetting;
import com.sten_region_skidrrr.strafehack.module.settings.NumberSetting;
import com.sten_region_skidrrr.strafehack.utils.TimerUtil;
import net.minecraft.block.Block;
import java.util.List;
import com.sten_region_skidrrr.strafehack.module.Module;

public class Scaffold extends Module
{
    private List<Block> invalid;
    private TimerUtil timerMotion;
    private TimerUtil itemTimer;
    private BlockData blockData;
    private NumberSetting expand;
    private ModeSetting espMode;
    private BooleanSetting Switch;
    private BooleanSetting tower;
    private BooleanSetting center;
    private BooleanSetting keepY;
    private BooleanSetting sprint;
    private BooleanSetting esp;
    private BooleanSetting keepRots;
    private BooleanSetting replenishBlocks;
    private BooleanSetting down;
    private BooleanSetting swing;
    private int lastY;
    private float lastYaw;
    private float lastPitch;
    private BlockPos pos;
    private boolean teleported;
    private static String[] -1728576055;
    private static String[] 1078569619;
    private static long -927584011;
    private static int -1757805408;
    private static int -938873572;
    private static long -2017626160;
    private static int 1080825236;
    private static long -1931654621;
    private static int 1645752374;
    private static int 1689147936;
    private static int -1491463124;
    private static int 289267565;
    private static int 2046104560;
    private static int 201377824;
    private static int -1375758128;
    private static int -1814985787;
    private static int 1381086822;
    private static int -1407523321;
    private static int -1437440113;
    private static int -817770663;
    private static int -1746896709;
    private static int -411372581;
    private static int 896870368;
    private static int 1626298485;
    private static int 251239616;
    private static int 1390413670;
    private static int 1575666695;
    private static int 1646084800;
    private static int 190788461;
    private static int -1928547296;
    private static int -1133436447;
    private static int -109746347;
    private static int 474332574;
    private static int 739161886;
    private static int 457586468;
    private static int -1133280143;
    private static int 1940887124;
    private static int -1215880908;
    private static int -901255045;
    private static int 594802002;
    private static int -227024077;
    private static int 1610219731;
    private static int -944918307;
    private static int 375211841;
    private static int 1641556627;
    private static int 1978910525;
    private static int 904149025;
    private static int 1997071404;
    private static int -1807559045;
    private static int 579985113;
    private static int -1931569903;
    private static int 813742189;
    private static long -77136101;
    private static double -2075218138;
    private static int -2142976094;
    private static long -863766392;
    private static long -1774122415;
    private static int -1907867183;
    private static long 1239915542;
    private static int 2066504500;
    private static int 1590833282;
    private static int 742490285;
    private static int 617765572;
    private static long 425424758;
    private static int 332761283;
    private static int -1681889420;
    private static long 2120066936;
    private static long 807099167;
    private static int -1509774615;
    private static long -482926247;
    private static long 37865063;
    private static int -830974692;
    private static int -714106616;
    private static long 1853150999;
    private static long -1484345922;
    private static int -1218124734;
    private static int 702631571;
    private static int -944844310;
    private static long -1754729998;
    private static int -171308587;
    private static int -2112250412;
    private static long 1294366228;
    private static int 1107912271;
    private static int -1569225616;
    private static long -591088039;
    private static int -1824802144;
    private static int -1204682394;
    private static long -1754242383;
    private static long 1217423743;
    private static int -1082007302;
    private static int 1553809675;
    private static long -1837106085;
    private static int -1112703929;
    private static int -44097554;
    private static long -2053615656;
    private static int 1167249698;
    private static int -1787675632;
    private static int 742877607;
    private static long 1589140951;
    private static int -1942560193;
    private static int -401901947;
    private static long 655907153;
    private static long 2142637207;
    private static int 1403577773;
    private static int 165851456;
    private static int 1222352927;
    private static int 903890813;
    private static int -1742755606;
    private static int 2144335196;
    private static int 768739230;
    private static int 1660669649;
    private static int 815186617;
    private static int 1262753103;
    private static int -1341981211;
    private static int -1495942082;
    private static int 1053998506;
    private static int 2139554845;
    private static int -1822345186;
    private static long 460870522;
    private static long 546385214;
    private static int 179614941;
    private static int 798159631;
    private static int 984250250;
    private static long 476866765;
    private static int 1342262382;
    private static int 397830028;
    private static long -382794649;
    private static long -2035828310;
    private static int 767225231;
    private static int 100790970;
    private static long 1876602448;
    private static int 118583577;
    private static int -1151286472;
    private static long -1496318285;
    private static int -2041298644;
    private static int 626738280;
    private static long -1152071250;
    private static long 1283731613;
    private static int 1691572198;
    private static long 1461069685;
    private static int -290268276;
    private static int -180616842;
    private static long -530774641;
    private static long -733642252;
    private static int 2005469004;
    private static long 766652876;
    private static long -2095733632;
    private static int -1993110764;
    private static int 819753950;
    private static long -584617372;
    private static int -931102198;
    private static int -1376860412;
    private static int 459565375;
    private static int -110629301;
    private static int 788359805;
    private static int 1671449066;
    private static int 1718145353;
    private static double 116332616;
    private static double 131655105;
    private static double -1207107436;
    private static long -1187723891;
    private static double 1428996240;
    private static int -431904469;
    private static int 2075470134;
    private static int -108599672;
    private static int 1649403363;
    private static int -1135381693;
    private static double 63914693;
    private static int 1411299896;
    private static int -984510500;
    private static int 298641779;
    private static long 500120964;
    private static long 872922874;
    private static int 1725861965;
    private static long -1340831892;
    private static int 1398133380;
    private static int 791028632;
    private static int 913673326;
    private static int -1560039845;
    private static int 740667469;
    private static int 1089787589;
    private static int 497132895;
    private static int 974817115;
    private static int -997513601;
    private static double 258225863;
    private static double -1637571708;
    private static double 1530361711;
    private static double 373564555;
    private static float 19110609;
    private static double 1391561503;
    private static float -1114026407;
    private static double -645717918;
    private static float -975433472;
    private static double -560107224;
    private static float -915577915;
    private static int 1311543494;
    private static int 223289916;
    private static int -35482268;
    private static int 133732036;
    private static int -282491125;
    private static int 65449854;
    private static int -1847718566;
    private static int -1656927652;
    private static int 1807313339;
    private static int 1924659613;
    private static int 1239207657;
    private static int -343888879;
    private static int -2080030083;
    private static int -2145534657;
    private static int 743643918;
    private static int -1705025771;
    private static int 592698647;
    private static int -1261744748;
    private static int 661904155;
    private static int -901001903;
    private static int -1565766939;
    private static int -1701971277;
    private static int -2032594706;
    private static int -1951810933;
    private static int -469503027;
    private static int -213561088;
    private static int 667959669;
    private static int -956399102;
    private static int -95540063;
    private static int 1095736645;
    private static int 1385713505;
    private static int 800155507;
    private static int 2031087318;
    private static int 269622672;
    private static int -815576298;
    private static int 918343191;
    private static int -112489442;
    private static int 1778890455;
    private static int 1464055528;
    private static int -811808187;
    private static int 526974703;
    private static int 250866310;
    private static int -1503268165;
    private static int 2046945995;
    private static int 1237310079;
    private static int 67157437;
    private static int 1457942371;
    private static int 953611515;
    private static int -376383473;
    private static int 1681887528;
    private static int 1827913340;
    private static int -908104800;
    private static int -511150024;
    private static int -525439259;
    private static int -718646863;
    private static int 859058866;
    private static int -954262608;
    private static int 1212153146;
    private static int 328746372;
    private static int 328109306;
    private static int 1545562860;
    private static int 1160314559;
    private static int -64318028;
    private static int -1304060938;
    private static int -933643455;
    private static int -1704059422;
    private static int 702434098;
    private static int 1191188427;
    private static int 814261592;
    private static int 2862484;
    private static int 2044644149;
    private static int -406642439;
    private static int -697608325;
    private static int -383309913;
    private static int -2124499483;
    private static int 713352149;
    private static int -738850674;
    private static int -636678352;
    private static int 1608264402;
    private static int -1052603658;
    private static int 1858421051;
    private static int -410885468;
    private static int 1690859144;
    private static int 1227740583;
    private static int 1615513604;
    private static int 1075538583;
    private static int 553172933;
    private static int -1894193466;
    private static int -1157649433;
    private static int 971483928;
    private static int -646642048;
    private static int -1369991727;
    private static int -1409737857;
    private static int 951765279;
    private static int -1482239417;
    private static int -1364724388;
    private static int 72404236;
    private static int 1188522983;
    private static int 1914256543;
    private static int 2043970282;
    private static int -1238820845;
    private static int 1672350452;
    private static int -679812638;
    private static int -917949669;
    private static int 395372136;
    private static int -539023846;
    private static int 760583686;
    private static int 263725723;
    private static int 423857617;
    private static int 864961381;
    private static int 1122076485;
    private static int -1322443954;
    private static int -460468485;
    private static int -318661106;
    private static int -758021711;
    private static int -1127813035;
    private static int 354818245;
    private static int -49570033;
    private static int -77322661;
    private static int 1574513589;
    private static int 1478757043;
    private static int 328971719;
    private static int -856940360;
    private static int -1514889688;
    private static int -1958719977;
    private static int -897000645;
    private static int -1286659608;
    private static int -1265318711;
    private static int 133275407;
    private static int 1668755994;
    private static int -1869837300;
    private static int -1434626101;
    private static int -1590723753;
    private static int -881089765;
    private static int -2106998331;
    private static int -1787359107;
    private static int 1527561135;
    private static int -623210398;
    private static int -308359886;
    private static int 1607611660;
    private static int -1004238349;
    private static int -1864073970;
    private static int 708433236;
    private static int -667312884;
    private static int -564296682;
    private static int -2063201070;
    private static int 584581548;
    private static int 1447678899;
    private static int -232672382;
    private static int 578334303;
    private static int 244124494;
    private static int -753227775;
    private static int -1008825547;
    private static int -118187492;
    private static int -1123472217;
    private static int 625588216;
    private static int -1458020241;
    private static int 1167138627;
    private static int -452372985;
    private static int -1468104660;
    private static int 593107317;
    private static int -173647363;
    private static int 1304468407;
    private static int -937920963;
    private static int 1901871042;
    private static int 919939278;
    private static int -440940467;
    private static int -1358012136;
    private static int -551878264;
    private static int -1930442882;
    private static int -140008609;
    private static int 1798394312;
    private static int -1809878993;
    private static int -2028600758;
    private static int 1533275200;
    private static int -1449567609;
    private static int 174071966;
    private static int 1633145396;
    private static int 834394594;
    private static int 1677034447;
    private static int -1940003002;
    private static int -1421627471;
    private static int -1191489112;
    private static int 1045347062;
    private static int 1212107428;
    private static int -1861382242;
    private static int -1306359797;
    private static int -333458183;
    private static int 1897947774;
    private static int -703291284;
    private static int -1753961480;
    private static int -1491202890;
    private static int 913040537;
    private static int 1135854158;
    private static int -1056603771;
    private static int 1941285788;
    private static int -836361159;
    private static int -2133343849;
    private static int 374507953;
    private static int 1503845733;
    private static int -1821834573;
    private static int 1407074542;
    private static int -992685009;
    private static int -84844362;
    private static int -2037292337;
    private static int -1805277508;
    private static int 2032165445;
    private static int -1081526491;
    private static int 2084373415;
    private static int -1433385874;
    private static int -1285107974;
    private static int 379617126;
    private static int -1918438750;
    private static int 676341938;
    private static int -1949746352;
    private static int -1100457913;
    private static int 2064846248;
    private static int -414808013;
    private static int 146413447;
    private static int -512622707;
    private static int -2136955160;
    private static int 1871417772;
    private static int 842724534;
    private static int 1835804804;
    private static int -26875339;
    private static int -797768157;
    private static int 644897902;
    private static int -529157917;
    private static int 384545488;
    private static int 981055119;
    private static int 2091015257;
    private static int -1526026250;
    private static int -327245998;
    private static int -1871605255;
    private static int 444271936;
    private static int -1330639173;
    private static int 1502787897;
    private static int -662760536;
    private static int 1985157851;
    private static int 1094362227;
    private static int -1084342953;
    private static int 761983138;
    private static int -403181796;
    private static int -141361347;
    private static int -1729658219;
    private static int 1657711293;
    private static int -364699100;
    private static int -1811808381;
    private static int -229925817;
    private static int 1805637130;
    private static int 1726466905;
    private static int 1801093854;
    private static int 1607888025;
    private static int 1283346163;
    private static int -752364800;
    private static int -1283942996;
    private static int -780213265;
    private static int -1165667272;
    private static int 603114380;
    private static int 1432631340;
    private static int 41887433;
    private static int -40750410;
    private static int 1886411635;
    private static int 182999233;
    private static int -1931967739;
    private static int 1739596701;
    private static int -190732205;
    private static int -2098393896;
    private static int 995137568;
    private static int 668767894;
    private static int -732955744;
    private static int 49650709;
    private static int 755041987;
    private static int 2023278158;
    private static int 29391832;
    private static int -1060769107;
    private static int -1214154342;
    private static int 1753741252;
    private static int -1612589754;
    private static int 220568657;
    private static int -1369542515;
    private static int 2000161663;
    private static int 1456225880;
    private static int 898311863;
    private static int 408333837;
    private static int -956056609;
    private static int -244906113;
    private static int -1736965317;
    private static int -240829710;
    private static int -1903681495;
    private static int -783129586;
    private static int -2003947397;
    private static int -910142355;
    private static int 56078887;
    private static int 1834599076;
    private static int -713230295;
    private static int 948695496;
    private static int -431999122;
    private static int 1060738359;
    private static int -282442024;
    private static int 137103710;
    private static int -1993217795;
    private static int -1857033701;
    private static int 1536875952;
    private static int 343335421;
    private static int -552333303;
    private static int 903149975;
    private static int -667013257;
    private static int 329123242;
    private static int 397701923;
    private static int -2082543283;
    private static int -796863477;
    private static int 279818309;
    private static int -1796741738;
    private static int -2127306413;
    private static int -1874142893;
    private static int -132396127;
    private static int 554414290;
    private static int -1851006964;
    private static int -995540065;
    private static int 191462039;
    private static int -343272805;
    private static int 589139938;
    private static int 1026462315;
    private static int 1670825625;
    private static int 1366852202;
    private static int 1551156299;
    private static int 116414034;
    private static int -942586642;
    private static int -732812138;
    private static int -1035648944;
    private static int -1194727317;
    private static int 857256288;
    private static int -333322021;
    private static int 1239071497;
    private static int -1931448261;
    private static int -1406432673;
    private static int -1947057165;
    private static int -87756313;
    private static int -1572800863;
    private static int -653221871;
    private static int -1128168119;
    private static int -1653014703;
    private static int 1476319726;
    private static int 450171456;
    private static int 1911622971;
    private static int 449468212;
    private static int -1223626108;
    private static int -2089190939;
    private static int 66191962;
    private static int -1246350814;
    private static int 862322866;
    private static int 1191557094;
    private static int -1188876322;
    private static int 336337097;
    private static int 1343014990;
    private static int 978969130;
    private static int -158465404;
    private static int 425405273;
    private static int 1365265248;
    private static int 213587739;
    private static int 2018171206;
    private static int -365247928;
    private static int -1517302185;
    private static int 565116894;
    private static int -1251517979;
    private static int -1927175233;
    private static int -1590611448;
    private static int 683112321;
    private static int 1687291354;
    private static int -1417896005;
    private static int 8275926;
    private static int -735017145;
    private static int -1149668469;
    private static int 1794667874;
    private static int -1350431596;
    private static int -940403810;
    private static int -1992542179;
    private static int -167742274;
    private static int 1756302990;
    private static int 1256320985;
    private static int 1619576416;
    private static int -1581931672;
    private static int -1328504982;
    private static int -394624562;
    private static int -788039763;
    private static int -1905626891;
    private static int 1995929123;
    private static int -1255103363;
    private static int 309327565;
    private static int 881445210;
    private static int -185794572;
    private static int -864339298;
    private static int 22727020;
    private static int -1845867729;
    private static int -917426683;
    private static int 408628799;
    private static int -468744974;
    private static int -1545898706;
    private static int -1678729521;
    private static int -1657243592;
    private static int 1034256254;
    private static int 1305804443;
    private static int 2037316429;
    private static int -447614732;
    private static int -37358612;
    private static int 469806844;
    private static int -2113292560;
    private static int 132149995;
    private static int -38552936;
    private static int 1992302482;
    private static int -1126673859;
    private static int 2085576398;
    private static int -1185423638;
    private static int 607314796;
    private static int -1757754803;
    private static int -2133800739;
    private static int -563636279;
    private static int 1209008906;
    private static int 1683811009;
    private static int -1506486798;
    private static int -592887836;
    private static int 1458666383;
    private static int 1824928413;
    private static int -900726651;
    private static int -687756575;
    private static int 1606390229;
    private static int 1006708049;
    private static int 186719392;
    private static int 1293180608;
    private static int -1647539192;
    private static int 1725425925;
    private static int -343710105;
    private static int 437295657;
    private static int 2108306416;
    private static int -1555282005;
    private static int 715535872;
    private static int -704842020;
    private static int -799250257;
    private static int -1038432817;
    private static int -106233262;
    private static int -903174583;
    private static int -1271368224;
    private static int 791412783;
    private static int 632134644;
    private static int 2108214294;
    private static int -1990381331;
    private static int 816919105;
    private static int -1977678738;
    private static int 600036548;
    private static int 1252567012;
    private static int -2126815822;
    private static int -1855439297;
    private static int 153782979;
    private static int 277088018;
    private static int 1926178217;
    private static int 887722830;
    private static int -1138471376;
    private static int -1483521536;
    private static int 1161146524;
    private static int -300971711;
    private static int -1976027684;
    private static int -1922844515;
    private static int 940085249;
    private static int 1863967554;
    private static int -979431968;
    private static int -2122022447;
    private static int 630189588;
    private static int 813491319;
    private static int -65057435;
    private static int 774672983;
    private static int 1465255690;
    private static int -1469811211;
    private static int 1988754392;
    private static int -152754980;
    private static int -224921705;
    private static int -1379996120;
    private static int 1193645681;
    private static int -1456484935;
    private static int 980656556;
    private static int 2115468170;
    private static int 1445376120;
    private static int 272289033;
    private static int -714995732;
    private static int -2077508205;
    private static int -1425681619;
    private static int 1913159316;
    private static int -1058956607;
    private static int -396751331;
    private static int -1033058811;
    private static int 1600815497;
    private static int 790028706;
    private static int -316927055;
    private static int 1469420636;
    private static int 725765803;
    private static int 1901472883;
    private static int -384170936;
    private static int -934343442;
    private static int -1573140297;
    private static int 973944784;
    private static int -248654021;
    private static int 977880991;
    private static int 1180751564;
    private static int -1686088184;
    private static int 356736216;
    private static int 1041582978;
    private static int 457371154;
    private static int 1494653404;
    private static int 1142986045;
    private static int -326419743;
    private static int -1269886358;
    private static int 1456658393;
    private static int -934714452;
    private static int 1338487021;
    private static int 1184102419;
    private static int -2107675619;
    private static int 822667728;
    private static int 890072330;
    private static int -1485209785;
    private static int -716807429;
    private static int -1729764341;
    private static int -1040451988;
    private static int -537376229;
    private static int 1357677071;
    private static int 520659285;
    private static int -819419873;
    private static int 1023448724;
    private static int 953951292;
    private static int -184466375;
    private static int 814998549;
    private static int -688382819;
    private static int -286581046;
    private static int 1844491714;
    private static int 1204485815;
    private static int -233032194;
    private static int -1807681114;
    private static int 351999916;
    private static int 2125053485;
    private static int -252435436;
    private static int 1295976539;
    private static int -1166861977;
    private static int -1854038362;
    private static int 2090619777;
    private static int -157230286;
    private static int 531196010;
    private static int 1811608531;
    private static int 1688910858;
    private static int -802292767;
    private static int 2123483993;
    private static int 816488832;
    private static int 45801058;
    private static int 1915844304;
    private static int -287304689;
    private static double -1209657323;
    private static double 484239379;
    private static double -948211374;
    private static int 1529517446;
    private static int -1395634031;
    private static double -449671539;
    private static double -2053492680;
    private static float -181649210;
    private static int 997371932;
    private static double -1309540876;
    private static double 54187530;
    private static int -573356356;
    private static int -1743503692;
    private static int -962003851;
    private static int -671791991;
    
    public Scaffold() {
        super(invokedynamic(-787072185:(IJ)Ljava/lang/String;, Scaffold.-1757805408 & Scaffold.-938873572, Scaffold.-2017626160), invokedynamic(-1089496494:(IJ)Ljava/lang/String;, Scaffold.1080825236, Scaffold.-1931654621), Category.Player, Scaffold.1645752374);
        final Block[] array = new Block[Scaffold.1689147936];
        array[Scaffold.-1491463124] = Blocks.field_150467_bQ;
        array[Scaffold.289267565] = Blocks.field_150350_a;
        array[Scaffold.2046104560] = (Block)Blocks.field_150355_j;
        array[Scaffold.201377824] = (Block)Blocks.field_150480_ab;
        array[Scaffold.-1375758128] = (Block)Blocks.field_150358_i;
        array[Scaffold.-1814985787] = (Block)Blocks.field_150353_l;
        array[Scaffold.1381086822] = (Block)Blocks.field_150358_i;
        array[Scaffold.-1407523321] = (Block)Blocks.field_150486_ae;
        array[Scaffold.-1437440113] = Blocks.field_150381_bn;
        array[Scaffold.-817770663] = Blocks.field_150447_bR;
        array[Scaffold.-1746896709] = Blocks.field_150477_bB;
        array[Scaffold.-411372581] = Blocks.field_150351_n;
        array[Scaffold.896870368] = Blocks.field_150468_ap;
        array[Scaffold.1626298485] = Blocks.field_150395_bd;
        array[Scaffold.251239616] = (Block)Blocks.field_150461_bJ;
        array[Scaffold.1390413670] = Blocks.field_150421_aI;
        array[Scaffold.1575666695] = (Block)Blocks.field_180410_as;
        array[Scaffold.1646084800] = (Block)Blocks.field_180412_aq;
        array[Scaffold.190788461] = (Block)Blocks.field_180409_at;
        array[Scaffold.-1928547296] = (Block)Blocks.field_150454_av;
        array[Scaffold.-1133436447] = (Block)Blocks.field_180411_ar;
        array[Scaffold.-109746347] = (Block)Blocks.field_180413_ao;
        array[Scaffold.474332574] = (Block)Blocks.field_180414_ap;
        array[Scaffold.739161886] = Blocks.field_180400_cw;
        array[Scaffold.457586468] = Blocks.field_150415_aT;
        array[Scaffold.-1133280143] = Blocks.field_190975_dA;
        array[Scaffold.1940887124] = Blocks.field_190988_dw;
        array[Scaffold.-1215880908] = Blocks.field_190989_dx;
        array[Scaffold.-901255045] = Blocks.field_190986_du;
        array[Scaffold.594802002] = Blocks.field_190984_ds;
        array[Scaffold.-227024077] = Blocks.field_190990_dy;
        array[Scaffold.1610219731] = Blocks.field_190980_do;
        array[Scaffold.-944918307] = Blocks.field_190982_dq;
        array[Scaffold.375211841] = Blocks.field_190979_dn;
        array[Scaffold.1641556627] = Blocks.field_190978_dm;
        array[Scaffold.1978910525] = Blocks.field_190983_dr;
        array[Scaffold.904149025] = Blocks.field_190987_dv;
        array[Scaffold.1997071404] = Blocks.field_190991_dz;
        array[Scaffold.-1807559045] = Blocks.field_190985_dt;
        array[Scaffold.579985113] = Blocks.field_190977_dl;
        array[Scaffold.-1931569903] = Blocks.field_190981_dp;
        this.invalid = invokedynamic(602640497:([Ljava/lang/Object;)Ljava/util/List;, array);
        this.timerMotion = new TimerUtil();
        this.itemTimer = new TimerUtil();
        this.expand = new NumberSetting(invokedynamic(-747176174:(IJ)Ljava/lang/String;, Scaffold.813742189, Scaffold.-77136101), 1.0, 1.0, Scaffold.-2075218138);
        final String 761961419 = invokedynamic(1300582960:(IJ)Ljava/lang/String;, Scaffold.-2142976094, Scaffold.-863766392 ^ Scaffold.-1774122415);
        final String 761961420 = invokedynamic(1773786073:(IJ)Ljava/lang/String;, Scaffold.-1907867183, Scaffold.1239915542);
        final String[] -1854986420 = new String[Scaffold.2066504500];
        -1854986420[Scaffold.1590833282] = invokedynamic(1071309182:(IJ)Ljava/lang/String;, Scaffold.742490285 & Scaffold.617765572, Scaffold.425424758);
        -1854986420[Scaffold.332761283] = invokedynamic(570996476:(IJ)Ljava/lang/String;, Scaffold.-1681889420, Scaffold.2120066936 ^ Scaffold.807099167);
        this.espMode = new ModeSetting(761961419, 761961420, -1854986420);
        this.Switch = new BooleanSetting(invokedynamic(2049596991:(IJ)Ljava/lang/String;, Scaffold.-1509774615, Scaffold.-482926247 ^ Scaffold.37865063), (boolean)(Scaffold.-830974692 != 0));
        this.tower = new BooleanSetting(invokedynamic(1482500179:(IJ)Ljava/lang/String;, Scaffold.-714106616, Scaffold.1853150999 ^ Scaffold.-1484345922), (boolean)(Scaffold.-1218124734 != 0));
        this.center = new BooleanSetting(invokedynamic(741683010:(IJ)Ljava/lang/String;, Scaffold.702631571 & Scaffold.-944844310, Scaffold.-1754729998), (boolean)(Scaffold.-171308587 != 0));
        this.keepY = new BooleanSetting(invokedynamic(-156451255:(IJ)Ljava/lang/String;, Scaffold.-2112250412, Scaffold.1294366228), (boolean)(Scaffold.1107912271 != 0));
        this.sprint = new BooleanSetting(invokedynamic(1882000170:(IJ)Ljava/lang/String;, Scaffold.-1569225616, Scaffold.-591088039), (boolean)(Scaffold.-1824802144 != 0));
        this.esp = new BooleanSetting(invokedynamic(1780778379:(IJ)Ljava/lang/String;, Scaffold.-1204682394, Scaffold.-1754242383 ^ Scaffold.1217423743), (boolean)(Scaffold.-1082007302 != 0));
        this.keepRots = new BooleanSetting(invokedynamic(234721112:(IJ)Ljava/lang/String;, Scaffold.1553809675, Scaffold.-1837106085), (boolean)(Scaffold.-1112703929 != 0));
        this.replenishBlocks = new BooleanSetting(invokedynamic(655133021:(IJ)Ljava/lang/String;, Scaffold.-44097554, Scaffold.-2053615656), (boolean)(Scaffold.1167249698 != 0));
        this.down = new BooleanSetting(invokedynamic(-1775405245:(IJ)Ljava/lang/String;, Scaffold.-1787675632 & Scaffold.742877607, Scaffold.1589140951), (boolean)(Scaffold.-1942560193 != 0));
        this.swing = new BooleanSetting(invokedynamic(-1697094070:(IJ)Ljava/lang/String;, Scaffold.-401901947, Scaffold.655907153 ^ Scaffold.2142637207), (boolean)(Scaffold.1403577773 != 0));
        final Setting[] array2 = new Setting[Scaffold.165851456];
        array2[Scaffold.1222352927] = this.expand;
        array2[Scaffold.903890813] = this.espMode;
        array2[Scaffold.-1742755606] = this.Switch;
        array2[Scaffold.2144335196] = this.tower;
        array2[Scaffold.768739230] = this.center;
        array2[Scaffold.1660669649] = this.keepY;
        array2[Scaffold.815186617] = this.sprint;
        array2[Scaffold.1262753103] = this.esp;
        array2[Scaffold.-1341981211] = this.keepRots;
        array2[Scaffold.-1495942082] = this.replenishBlocks;
        array2[Scaffold.1053998506] = this.down;
        array2[Scaffold.2139554845] = this.swing;
    }
    // invokedynamic(-1168590986:(Ljava/lang/Object;[Lcom/sten_region_skidrrr/strafehack/module/settings/Setting;)V, this, array2)
    
    @SubscribeEvent
    public void onRender(final RenderHandEvent 815659769) throws Exception {
        if (invokedynamic(1639914066:(Ljava/lang/Object;)Z, this.esp) && this.blockData != null && this.blockData.position != null) {
            final BlockPos position = this.blockData.position;
            Field 815659770 = invokedynamic(-121264206:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/reflect/Field;, invokedynamic(-707592201:(Ljava/lang/Object;)Ljava/lang/Class;, invokedynamic(2093868317:(Ljava/lang/Object;)Lnet/minecraft/client/renderer/entity/RenderManager;, this.mc)), invokedynamic(2117730298:(IJ)Ljava/lang/String;, Scaffold.-1822345186, Scaffold.460870522 ^ Scaffold.546385214));
            // invokedynamic(1983634078:(Ljava/lang/Object;Z)V, 815659770, Scaffold.179614941)
            final int n = invokedynamic(-2022190742:(Ljava/lang/Object;)I, (Integer)invokedynamic(2038988820:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;, 815659770, invokedynamic(-1749582817:(Ljava/lang/Object;)Lnet/minecraft/client/renderer/entity/RenderManager;, this.mc)));
            815659770 = invokedynamic(346458498:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/reflect/Field;, invokedynamic(-1924551837:(Ljava/lang/Object;)Ljava/lang/Class;, invokedynamic(583677453:(Ljava/lang/Object;)Lnet/minecraft/client/renderer/entity/RenderManager;, this.mc)), invokedynamic(-899619781:(IJ)Ljava/lang/String;, Scaffold.798159631 & Scaffold.984250250, Scaffold.476866765));
            // invokedynamic(1751586466:(Ljava/lang/Object;Z)V, 815659770, Scaffold.1342262382)
            final int n2 = invokedynamic(1615039084:(Ljava/lang/Object;)I, (Integer)invokedynamic(-616998946:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;, 815659770, invokedynamic(-884684501:(Ljava/lang/Object;)Lnet/minecraft/client/renderer/entity/RenderManager;, this.mc)));
            815659770 = invokedynamic(-709523034:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/reflect/Field;, invokedynamic(-798993294:(Ljava/lang/Object;)Ljava/lang/Class;, invokedynamic(1188782176:(Ljava/lang/Object;)Lnet/minecraft/client/renderer/entity/RenderManager;, this.mc)), invokedynamic(1883374454:(IJ)Ljava/lang/String;, Scaffold.397830028, Scaffold.-382794649 ^ Scaffold.-2035828310));
            // invokedynamic(-1061323673:(Ljava/lang/Object;Z)V, 815659770, Scaffold.767225231)
            final int 815659771 = invokedynamic(-1140893670:(Ljava/lang/Object;)I, (Integer)invokedynamic(-1728309904:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;, 815659770, invokedynamic(447167996:(Ljava/lang/Object;)Lnet/minecraft/client/renderer/entity/RenderManager;, this.mc)));
            double n3 = (double)((invokedynamic(-374178947:(Ljava/lang/Object;Ljava/lang/Object;)Z, invokedynamic(-2039567309:(Ljava/lang/Object;)Ljava/lang/String;, this.espMode), invokedynamic(1473907844:(IJ)Ljava/lang/String;, Scaffold.100790970, Scaffold.1876602448)) ? invokedynamic(1369560041:(Ljava/lang/Object;)I, this.pos) : invokedynamic(-1163938766:(Ljava/lang/Object;)I, position)) - n);
            double n4 = (double)((invokedynamic(-1655751091:(Ljava/lang/Object;Ljava/lang/Object;)Z, invokedynamic(-1236388438:(Ljava/lang/Object;)Ljava/lang/String;, this.espMode), invokedynamic(-2089860388:(IJ)Ljava/lang/String;, Scaffold.118583577 & Scaffold.-1151286472, Scaffold.-1496318285)) ? invokedynamic(436305309:(Ljava/lang/Object;)I, this.pos) : invokedynamic(-1295096030:(Ljava/lang/Object;)I, position)) - n + Scaffold.-2041298644);
            double 815659772 = (double)((invokedynamic(-1414530572:(Ljava/lang/Object;Ljava/lang/Object;)Z, invokedynamic(-191536844:(Ljava/lang/Object;)Ljava/lang/String;, this.espMode), invokedynamic(-414088482:(IJ)Ljava/lang/String;, Scaffold.626738280, Scaffold.-1152071250 ^ Scaffold.1283731613)) ? invokedynamic(-1068164686:(Ljava/lang/Object;)I, this.pos) : invokedynamic(-985534452:(Ljava/lang/Object;)I, position)) - n2);
            final double n5 = (double)((invokedynamic(-1162323807:(Ljava/lang/Object;Ljava/lang/Object;)Z, invokedynamic(-1051397912:(Ljava/lang/Object;)Ljava/lang/String;, this.espMode), invokedynamic(283018037:(IJ)Ljava/lang/String;, Scaffold.1691572198, Scaffold.1461069685)) ? invokedynamic(465371097:(Ljava/lang/Object;)I, this.pos) : invokedynamic(-713482863:(Ljava/lang/Object;)I, position)) - n2 + Scaffold.-290268276);
            double 815659773 = (double)((invokedynamic(829259791:(Ljava/lang/Object;Ljava/lang/Object;)Z, invokedynamic(512855783:(Ljava/lang/Object;)Ljava/lang/String;, this.espMode), invokedynamic(2118607608:(IJ)Ljava/lang/String;, Scaffold.-180616842, Scaffold.-530774641 ^ Scaffold.-733642252)) ? invokedynamic(-523000487:(Ljava/lang/Object;)I, this.pos) : invokedynamic(1319165897:(Ljava/lang/Object;)I, position)) - 815659771);
            double 815659774 = (double)((invokedynamic(-1525177772:(Ljava/lang/Object;Ljava/lang/Object;)Z, invokedynamic(1371849216:(Ljava/lang/Object;)Ljava/lang/String;, this.espMode), invokedynamic(-1921008893:(IJ)Ljava/lang/String;, Scaffold.2005469004, Scaffold.766652876 ^ Scaffold.-2095733632)) ? invokedynamic(1852464475:(Ljava/lang/Object;)I, this.pos) : invokedynamic(379998210:(Ljava/lang/Object;)I, position)) - 815659771 + Scaffold.-1993110764);
            if (invokedynamic(50289571:(Ljava/lang/Object;Ljava/lang/Object;)Z, invokedynamic(-1626549136:(Ljava/lang/Object;)Ljava/lang/String;, this.espMode), invokedynamic(660172056:(IJ)Ljava/lang/String;, Scaffold.819753950, Scaffold.-584617372))) {
                final EnumFacing 815659775 = this.blockData.face;
                815659772 += (double)invokedynamic(1357515209:(Ljava/lang/Object;)I, 815659775);
                if (invokedynamic(2058143506:(Ljava/lang/Object;)I, 815659775) < 0) {
                    n4 += (double)invokedynamic(1551465346:(Ljava/lang/Object;)I, 815659775);
                }
                else {
                    n3 += (double)invokedynamic(379684920:(Ljava/lang/Object;)I, 815659775);
                }
                if (invokedynamic(-1031396664:(Ljava/lang/Object;)I, 815659775) < 0) {
                    815659774 += (double)invokedynamic(1991499334:(Ljava/lang/Object;)I, 815659775);
                }
                else {
                    815659773 += (double)invokedynamic(-1865166809:(Ljava/lang/Object;)I, 815659775);
                }
            }
            final Color 815659776 = new Color(Scaffold.-931102198, Scaffold.-1376860412, Scaffold.459565375, Scaffold.-110629301);
        }
        // invokedynamic(-66360023:(Ljava/lang/Object;FFFF)V, new AxisAlignedBB(n3, 815659772, 815659773, n4, n5, 815659774), (float)invokedynamic(-677984356:(Ljava/lang/Object;)I, 815659776), (float)invokedynamic(-1501093117:(Ljava/lang/Object;)I, 815659776), (float)invokedynamic(419791390:(Ljava/lang/Object;)I, 815659776), (float)invokedynamic(1692162200:(Ljava/lang/Object;)I, 815659776))
    }
    
    @SubscribeEvent
    public void onUpdate(final LivingEvent.LivingUpdateEvent -578917429) {
        if (invokedynamic(-1902555422:(Ljava/lang/Object;)Lnet/minecraft/entity/EntityLivingBase;, -578917429) instanceof EntityPlayer) {
            if (invokedynamic(2130703618:(Ljava/lang/Object;)Lnet/minecraftforge/fml/common/eventhandler/EventPriority;, -578917429) == EventPriority.LOWEST) {
                if (this.blockData != null) {
                    if (this.getBlockCountHotbar() <= 0 || (!invokedynamic(-189526029:(Ljava/lang/Object;)Z, this.Switch) && invokedynamic(334824051:(Ljava/lang/Object;)Lnet/minecraft/item/Item;, invokedynamic(263002973:(Ljava/lang/Object;)Lnet/minecraft/item/ItemStack;, this.mc.field_71439_g)) != null && !(invokedynamic(1765547912:(Ljava/lang/Object;)Lnet/minecraft/item/Item;, invokedynamic(-1790253170:(Ljava/lang/Object;)Lnet/minecraft/item/ItemStack;, this.mc.field_71439_g)) instanceof ItemBlock))) {
                        return;
                    }
                    final int 1562353314 = this.mc.field_71439_g.field_71071_by.field_70461_c;
                    if (invokedynamic(-837080171:(Ljava/lang/Object;)Z, this.Switch)) {
                        for (int i = Scaffold.788359805; i < Scaffold.1671449066; ++i) {
                            if (invokedynamic(1984363682:(Ljava/lang/Object;I)Lnet/minecraft/item/ItemStack;, this.mc.field_71439_g.field_71071_by, i) != null && invokedynamic(359019754:(Ljava/lang/Object;)I, invokedynamic(-2123467052:(Ljava/lang/Object;I)Lnet/minecraft/item/ItemStack;, this.mc.field_71439_g.field_71071_by, i)) != 0 && invokedynamic(-1541629064:(Ljava/lang/Object;)Lnet/minecraft/item/Item;, invokedynamic(-759363815:(Ljava/lang/Object;I)Lnet/minecraft/item/ItemStack;, this.mc.field_71439_g.field_71071_by, i)) instanceof ItemBlock && !invokedynamic(1638023927:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(1721306968:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, (ItemBlock)invokedynamic(-2001072233:(Ljava/lang/Object;)Lnet/minecraft/item/Item;, invokedynamic(185537894:(Ljava/lang/Object;I)Lnet/minecraft/item/ItemStack;, this.mc.field_71439_g.field_71071_by, i))))) {
                                this.mc.field_71439_g.field_71071_by.field_70461_c = i;
                                break;
                            }
                        }
                    }
                    if (invokedynamic(558439758:(Ljava/lang/Object;)Z, this.tower)) {
                        if (invokedynamic(-645325296:(Ljava/lang/Object;)Z, this.mc.field_71474_y.field_74314_A) && this.mc.field_71439_g.field_191988_bg == 0.0f && this.mc.field_71439_g.field_70702_br == 0.0f && invokedynamic(853538389:(Ljava/lang/Object;)Z, this.tower) && !invokedynamic(1358219860:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.mc.field_71439_g, MobEffects.field_76430_j)) {
                            if (!this.teleported && invokedynamic(170572606:(Ljava/lang/Object;)Z, this.center)) {
                                this.teleported = (Scaffold.1718145353 != 0);
                                final BlockPos blockPos = new BlockPos(this.mc.field_71439_g.field_70165_t, this.mc.field_71439_g.field_70163_u, this.mc.field_71439_g.field_70161_v);
                            }
                            // invokedynamic(167467938:(Ljava/lang/Object;DDD)V, this.mc.field_71439_g, (double)invokedynamic(-301862850:(Ljava/lang/Object;)I, blockPos) + Scaffold.116332616, (double)invokedynamic(84404530:(Ljava/lang/Object;)I, blockPos), (double)invokedynamic(-1831446937:(Ljava/lang/Object;)I, blockPos) + Scaffold.131655105)
                            if (invokedynamic(1787124164:(Ljava/lang/Object;)Z, this.center) && !this.teleported) {
                                return;
                            }
                            this.mc.field_71439_g.field_70181_x = Scaffold.-1207107436;
                            this.mc.field_71439_g.field_70179_y = 0.0;
                            this.mc.field_71439_g.field_70159_w = 0.0;
                            if (invokedynamic(-1454332177:(Ljava/lang/Object;J)Z, this.timerMotion, Scaffold.-1187723891)) {
                                this.mc.field_71439_g.field_70181_x = Scaffold.1428996240;
                            }
                        }
                        else if (this.teleported && invokedynamic(-150251561:(Ljava/lang/Object;)Z, this.center)) {
                            this.teleported = (Scaffold.-431904469 != 0);
                        }
                    }
                    if (invokedynamic(279714041:(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/util/EnumActionResult;, this.mc.field_71442_b, this.mc.field_71439_g, this.mc.field_71441_e, this.blockData.position, this.blockData.face, new Vec3d((double)invokedynamic(-1053055112:(Ljava/lang/Object;)I, this.blockData.position) + invokedynamic(1663295618:()D), (double)invokedynamic(-1939933989:(Ljava/lang/Object;)I, this.blockData.position) + invokedynamic(2114656607:()D), (double)invokedynamic(-1461928801:(Ljava/lang/Object;)I, this.blockData.position) + invokedynamic(-797430351:()D)), EnumHand.MAIN_HAND) != EnumActionResult.FAIL) {
                        if (invokedynamic(1807749827:(Ljava/lang/Object;)Z, this.swing)) {
                        }
                        // invokedynamic(-1144977971:(Ljava/lang/Object;Ljava/lang/Object;)V, this.mc.field_71439_g, EnumHand.MAIN_HAND)
                        else {
                        }
                        // invokedynamic(1089672112:(Ljava/lang/Object;Ljava/lang/Object;)V, this.mc.field_71439_g.field_71174_a, new CPacketAnimation(EnumHand.MAIN_HAND))
                    }
                    this.mc.field_71439_g.field_71071_by.field_70461_c = 1562353314;
                }
            }
            else if (invokedynamic(-1684398250:(Ljava/lang/Object;)Lnet/minecraftforge/fml/common/eventhandler/EventPriority;, -578917429) == EventPriority.HIGHEST) {
                double 1562353315 = this.mc.field_71439_g.field_70165_t;
                double n = this.mc.field_71439_g.field_70161_v;
                final double 1562353316 = invokedynamic(-1349941661:(Ljava/lang/Object;)Z, this.keepY) ? this.lastY : this.mc.field_71439_g.field_70163_u;
                final double n2 = this.mc.field_71439_g.field_71158_b.field_192832_b;
                final double 1562353317 = this.mc.field_71439_g.field_71158_b.field_78902_a;
                final float 1562353318 = this.mc.field_71439_g.field_70177_z;
                if (!this.mc.field_71439_g.field_70123_F) {
                    final double[] 1562353319 = (double[])invokedynamic(1579894952:(Ljava/lang/Object;DDDDF)[D, this, 1562353315, n, n2, 1562353317, 1562353318);
                    1562353315 = 1562353319[Scaffold.2075470134];
                    n = 1562353319[Scaffold.-108599672];
                }
                if (invokedynamic(-747106399:(Ljava/lang/Object;Ljava/lang/Object;)Z, this, invokedynamic(98334356:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1491021630:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, new BlockPos(this.mc.field_71439_g.field_70165_t, this.mc.field_71439_g.field_70163_u - ((invokedynamic(2003419866:(Ljava/lang/Object;)Z, this.mc.field_71474_y.field_74311_E) && invokedynamic(-966400307:(Ljava/lang/Object;)Z, this.down)) ? Scaffold.1649403363 : Scaffold.-1135381693), this.mc.field_71439_g.field_70161_v))))) {
                    1562353315 = this.mc.field_71439_g.field_70165_t;
                    n = this.mc.field_71439_g.field_70161_v;
                }
                BlockPos 1562353320 = new BlockPos(1562353315, 1562353316 - 1.0, n);
                if (invokedynamic(289569639:(Ljava/lang/Object;)Z, this.mc.field_71474_y.field_74311_E) && invokedynamic(-806038977:(Ljava/lang/Object;)Z, this.down)) {
                    1562353320 = new BlockPos(1562353315, 1562353316 - Scaffold.63914693, n);
                }
                this.pos = 1562353320;
                if (invokedynamic(1852479489:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(178844358:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, 1562353320)) == Blocks.field_150350_a) {
                    this.blockData = this.getBlockData2(1562353320);
                    if (this.blockData != null) {
                        final float n3 = this.aimAtLocation((double)invokedynamic(-1836649109:(Ljava/lang/Object;)I, this.blockData.position), (double)invokedynamic(-1088219278:(Ljava/lang/Object;)I, this.blockData.position), (double)invokedynamic(1941753640:(Ljava/lang/Object;)I, this.blockData.position), this.blockData.face)[Scaffold.1411299896];
                        final float n4 = this.aimAtLocation((double)invokedynamic(-383747487:(Ljava/lang/Object;)I, this.blockData.position), (double)invokedynamic(-607368909:(Ljava/lang/Object;)I, this.blockData.position), (double)invokedynamic(-397276868:(Ljava/lang/Object;)I, this.blockData.position), this.blockData.face)[Scaffold.-984510500];
                        if (invokedynamic(-1487821287:(Ljava/lang/Object;)Z, this.keepRots)) {
                            this.lastYaw = n3;
                            this.lastPitch = n4;
                        }
                        else {
                            this.mc.field_71439_g.field_70177_z = n3;
                            this.mc.field_71439_g.field_70125_A = n4;
                        }
                    }
                }
                if (invokedynamic(897383636:(Ljava/lang/Object;)Z, this.keepRots)) {
                    this.mc.field_71439_g.field_70177_z = this.lastYaw;
                    this.mc.field_71439_g.field_70125_A = this.lastPitch;
                }
            }
            if (!invokedynamic(-1119368267:(Ljava/lang/Object;)Z, invokedynamic(1013027987:(Ljava/lang/Object;)Lcom/sten_region_skidrrr/strafehack/module/Module;, invokedynamic(1154257393:(IJ)Ljava/lang/String;, Scaffold.298641779, Scaffold.500120964 ^ Scaffold.872922874))) && ((invokedynamic(-1594115619:(Ljava/lang/Object;)Z, this.down) && invokedynamic(-283082542:(Ljava/lang/Object;)Z, this.mc.field_71474_y.field_74311_E)) || !invokedynamic(1789829989:(Ljava/lang/Object;)Z, this.sprint))) {
            }
            // invokedynamic(414552626:(Ljava/lang/Object;Z)V, this.mc.field_71439_g, Scaffold.1725861965)
            if (invokedynamic(1544870737:(Ljava/lang/Object;)Z, this.replenishBlocks) && !(invokedynamic(1166556355:(Ljava/lang/Object;)Lnet/minecraft/item/Item;, invokedynamic(1942269427:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/item/ItemStack;, this.mc.field_71439_g, EnumHand.MAIN_HAND)) instanceof ItemBlock) && this.getBlockCountHotbar() <= 0 && invokedynamic(-316782775:(Ljava/lang/Object;J)Z, this.itemTimer, Scaffold.-1340831892)) {
                for (int 1562353321 = Scaffold.1398133380; 1562353321 < Scaffold.791028632; ++1562353321) {
                    if (invokedynamic(-1899248972:(Ljava/lang/Object;)Z, invokedynamic(-276290593:(Ljava/lang/Object;I)Lnet/minecraft/inventory/Slot;, this.mc.field_71439_g.field_71069_bz, 1562353321))) {
                        final ItemStack itemStack = invokedynamic(1241752130:(Ljava/lang/Object;)Lnet/minecraft/item/ItemStack;, invokedynamic(-1201203383:(Ljava/lang/Object;I)Lnet/minecraft/inventory/Slot;, this.mc.field_71439_g.field_71069_bz, 1562353321));
                        if (invokedynamic(809775063:(Ljava/lang/Object;)Lnet/minecraft/item/Item;, itemStack) instanceof ItemBlock && !invokedynamic(-507876162:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(402045836:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1954433363:(Ljava/lang/Object;)Lnet/minecraft/item/Item;, itemStack))) && 1562353321 < Scaffold.913673326) {
                        }
                        // invokedynamic(-1516726092:(II)V, invokedynamic(-1739862941:(Ljava/lang/Object;Ljava/lang/Object;)I, this.mc.field_71439_g.field_71069_bz, invokedynamic(-41121939:(Ljava/lang/Object;)Lnet/minecraft/item/Item;, itemStack)), Scaffold.-1560039845)
                    }
                }
            }
            if (invokedynamic(-879332596:(Ljava/lang/Object;)Z, this.keepY)) {
                if ((!invokedynamic(1011020817:(Ljava/lang/Object;)Z, this.mc.field_71439_g) && invokedynamic(-697014353:(Ljava/lang/Object;)Z, this.mc.field_71474_y.field_74314_A)) || this.mc.field_71439_g.field_70124_G || this.mc.field_71439_g.field_70122_E) {
                    this.lastY = invokedynamic(-1761378448:(D)I, this.mc.field_71439_g.field_70163_u);
                }
            }
            else {
                this.lastY = invokedynamic(-1916754767:(D)I, this.mc.field_71439_g.field_70163_u);
            }
        }
    }
    
    private int getBlockCount() {
        int 740667469 = Scaffold.740667469;
        for (int i = Scaffold.1089787589; i < Scaffold.497132895; ++i) {
            if (invokedynamic(-1275164368:(Ljava/lang/Object;)Z, invokedynamic(-1824717001:(Ljava/lang/Object;I)Lnet/minecraft/inventory/Slot;, this.mc.field_71439_g.field_71069_bz, i))) {
                final ItemStack itemStack = invokedynamic(1366573508:(Ljava/lang/Object;)Lnet/minecraft/item/ItemStack;, invokedynamic(874674235:(Ljava/lang/Object;I)Lnet/minecraft/inventory/Slot;, this.mc.field_71439_g.field_71069_bz, i));
                final Item item = invokedynamic(-1675595525:(Ljava/lang/Object;)Lnet/minecraft/item/Item;, itemStack);
                if (invokedynamic(855873715:(Ljava/lang/Object;)Lnet/minecraft/item/Item;, itemStack) instanceof ItemBlock && !invokedynamic(90018555:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(317387886:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, (ItemBlock)item))) {
                    740667469 += invokedynamic(-1353046517:(Ljava/lang/Object;)I, itemStack);
                }
            }
        }
        return 740667469;
    }
    
    public double[] getExpandCoords(final double 754074760, final double 1559117721, final double -1819541925, final double -1624964470, final float 1109306241) {
        BlockPos 1559117722 = new BlockPos(754074760, this.mc.field_71439_g.field_70163_u - ((invokedynamic(2027450281:(Ljava/lang/Object;)Z, this.mc.field_71474_y.field_74311_E) && invokedynamic(-1498248071:(Ljava/lang/Object;)Z, this.down)) ? Scaffold.974817115 : Scaffold.-997513601), 1559117721);
        Block block = invokedynamic(-1899691465:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1191694254:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, 1559117722));
        double 1559117723 = Scaffold.258225863;
        double -1819541926 = Scaffold.-1637571708;
        double 1559117724 = 0.0;
        final double n = invokedynamic(-1249270896:(Ljava/lang/Object;)D, this.expand) * Scaffold.1530361711;
        while (!invokedynamic(1971534193:(Ljava/lang/Object;Ljava/lang/Object;)Z, this, block)) {
            1559117723 = 754074760;
            -1819541926 = 1559117721;
            ++1559117724;
            if (1559117724 > n) {
                1559117724 = n;
            }
            1559117723 += (-1819541925 * Scaffold.373564555 * invokedynamic(889999650:(D)D, invokedynamic(-968803611:(D)D, (double)(1109306241 + Scaffold.19110609))) + -1624964470 * Scaffold.1391561503 * invokedynamic(-967387465:(D)D, invokedynamic(1534227120:(D)D, (double)(1109306241 + Scaffold.-1114026407)))) * 1559117724;
            -1819541926 += (-1819541925 * Scaffold.-645717918 * invokedynamic(-1386911356:(D)D, invokedynamic(-1328990267:(D)D, (double)(1109306241 + Scaffold.-975433472))) - -1624964470 * Scaffold.-560107224 * invokedynamic(1903214919:(D)D, invokedynamic(-1653890740:(D)D, (double)(1109306241 + Scaffold.-915577915)))) * 1559117724;
            if (1559117724 == n) {
                break;
            }
            1559117722 = new BlockPos(1559117723, this.mc.field_71439_g.field_70163_u - ((invokedynamic(-830674585:(Ljava/lang/Object;)Z, this.mc.field_71474_y.field_74311_E) && invokedynamic(-2028989776:(Ljava/lang/Object;)Z, this.down)) ? Scaffold.1311543494 : Scaffold.223289916), -1819541926);
            block = invokedynamic(-1082714493:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-138527326:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, 1559117722));
        }
        final double[] array = new double[Scaffold.-35482268];
        array[Scaffold.133732036] = 1559117723;
        array[Scaffold.-282491125] = -1819541926;
        return array;
    }
    
    public boolean canPlace(final Block 1579818371) {
        return (((1579818371 instanceof BlockAir || 1579818371 instanceof BlockLiquid) && this.mc.field_71441_e != null && this.mc.field_71439_g != null && this.pos != null && invokedynamic(-1444118949:(Ljava/lang/Object;)Z, invokedynamic(2026725160:(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/List;, this.mc.field_71441_e, null, new AxisAlignedBB(this.pos)))) ? Scaffold.65449854 : Scaffold.-1847718566) != 0;
    }
    
    private int getBlockCountHotbar() {
        int 1930960783 = Scaffold.-1656927652;
        for (int 1930960784 = Scaffold.1807313339; 1930960784 < Scaffold.1924659613; ++1930960784) {
            if (invokedynamic(-586173962:(Ljava/lang/Object;)Z, invokedynamic(-262525825:(Ljava/lang/Object;I)Lnet/minecraft/inventory/Slot;, this.mc.field_71439_g.field_71069_bz, 1930960784))) {
                final ItemStack itemStack = invokedynamic(992865551:(Ljava/lang/Object;)Lnet/minecraft/item/ItemStack;, invokedynamic(-312321828:(Ljava/lang/Object;I)Lnet/minecraft/inventory/Slot;, this.mc.field_71439_g.field_71069_bz, 1930960784));
                final Item item = invokedynamic(564661465:(Ljava/lang/Object;)Lnet/minecraft/item/Item;, itemStack);
                if (invokedynamic(613279646:(Ljava/lang/Object;)Lnet/minecraft/item/Item;, itemStack) instanceof ItemBlock && !invokedynamic(470404705:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-1274857558:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, (ItemBlock)item))) {
                    1930960783 += invokedynamic(-1284859746:(Ljava/lang/Object;)I, itemStack);
                }
            }
        }
        return 1930960783;
    }
    
    private BlockData getBlockData2(final BlockPos -1671576855) {
        if (!invokedynamic(-698318037:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(1070988416:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1014556520:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-487073781:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, -1671576855, Scaffold.1239207657, Scaffold.-343888879, Scaffold.-2080030083))))) {
            return new BlockData(invokedynamic(342110581:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, -1671576855, Scaffold.-2145534657, Scaffold.743643918, Scaffold.-1705025771), EnumFacing.UP);
        }
        if (!invokedynamic(-1216786293:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(862813165:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-854322409:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1334351088:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, -1671576855, Scaffold.592698647, Scaffold.-1261744748, Scaffold.661904155))))) {
            return new BlockData(invokedynamic(-1144362146:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, -1671576855, Scaffold.-901001903, Scaffold.-1565766939, Scaffold.-1701971277), EnumFacing.EAST);
        }
        if (!invokedynamic(-964994522:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-1733823485:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(84093761:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-368830594:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, -1671576855, Scaffold.-2032594706, Scaffold.-1951810933, Scaffold.-469503027))))) {
            return new BlockData(invokedynamic(-1063426523:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, -1671576855, Scaffold.-213561088, Scaffold.667959669, Scaffold.-956399102), EnumFacing.WEST);
        }
        if (!invokedynamic(-1282355411:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-56439112:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-287392535:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(1068597571:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, -1671576855, Scaffold.-95540063, Scaffold.1095736645, Scaffold.1385713505))))) {
            return new BlockData(invokedynamic(941788170:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, -1671576855, Scaffold.800155507, Scaffold.2031087318, Scaffold.269622672), EnumFacing.NORTH);
        }
        if (!invokedynamic(1064260145:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(917025951:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-421523723:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(949053570:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, -1671576855, Scaffold.-815576298, Scaffold.918343191, Scaffold.-112489442))))) {
            return new BlockData(invokedynamic(-1070609176:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, -1671576855, Scaffold.1778890455, Scaffold.1464055528, Scaffold.-811808187), EnumFacing.SOUTH);
        }
        if (!invokedynamic(2085202721:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-724423175:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(725006805:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(825540155:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, -1671576855, Scaffold.526974703, Scaffold.250866310, Scaffold.-1503268165))))) {
            return new BlockData(invokedynamic(1888411952:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, -1671576855, Scaffold.2046945995, Scaffold.1237310079, Scaffold.67157437), EnumFacing.DOWN);
        }
        final BlockPos blockPos = invokedynamic(-618442837:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, -1671576855, Scaffold.1457942371, Scaffold.953611515, Scaffold.-376383473);
        if (!invokedynamic(-2035281675:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(2098798822:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1034836605:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(1824342997:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos, Scaffold.1681887528, Scaffold.1827913340, Scaffold.-908104800))))) {
            return new BlockData(invokedynamic(741033915:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos, Scaffold.-511150024, Scaffold.-525439259, Scaffold.-718646863), EnumFacing.UP);
        }
        if (!invokedynamic(1685204083:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-373316919:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1536235614:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1784917061:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos, Scaffold.859058866, Scaffold.-954262608, Scaffold.1212153146))))) {
            return new BlockData(invokedynamic(512828983:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos, Scaffold.328746372, Scaffold.328109306, Scaffold.1545562860), EnumFacing.DOWN);
        }
        if (!invokedynamic(-1814496394:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-1299491320:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-1226425375:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1098387052:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos, Scaffold.1160314559, Scaffold.-64318028, Scaffold.-1304060938))))) {
            return new BlockData(invokedynamic(-1411451106:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos, Scaffold.-933643455, Scaffold.-1704059422, Scaffold.702434098), EnumFacing.EAST);
        }
        if (!invokedynamic(-973514511:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-1287985641:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-2117967159:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(1108928567:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos, Scaffold.1191188427, Scaffold.814261592, Scaffold.2862484))))) {
            return new BlockData(invokedynamic(1941720862:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos, Scaffold.2044644149, Scaffold.-406642439, Scaffold.-697608325), EnumFacing.WEST);
        }
        if (!invokedynamic(903947260:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-985665416:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1974143804:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-481687371:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos, Scaffold.-383309913, Scaffold.-2124499483, Scaffold.713352149))))) {
            return new BlockData(invokedynamic(1968694749:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos, Scaffold.-738850674, Scaffold.-636678352, Scaffold.1608264402), EnumFacing.NORTH);
        }
        if (!invokedynamic(-51626096:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-513850934:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-155775603:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(248471939:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos, Scaffold.-1052603658, Scaffold.1858421051, Scaffold.-410885468))))) {
            return new BlockData(invokedynamic(759680448:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos, Scaffold.1690859144, Scaffold.1227740583, Scaffold.1615513604), EnumFacing.SOUTH);
        }
        final BlockPos blockPos2 = invokedynamic(1673699002:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, -1671576855, Scaffold.1075538583, Scaffold.553172933, Scaffold.-1894193466);
        if (!invokedynamic(1640609168:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-1610227289:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(682180537:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(719778195:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos2, Scaffold.-1157649433, Scaffold.971483928, Scaffold.-646642048))))) {
            return new BlockData(invokedynamic(-1094236071:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos2, Scaffold.-1369991727, Scaffold.-1409737857, Scaffold.951765279), EnumFacing.UP);
        }
        if (!invokedynamic(1847078480:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(661952514:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1813785361:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1848770156:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos2, Scaffold.-1482239417, Scaffold.-1364724388, Scaffold.72404236))))) {
            return new BlockData(invokedynamic(539941273:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos2, Scaffold.1188522983, Scaffold.1914256543, Scaffold.2043970282), EnumFacing.DOWN);
        }
        if (!invokedynamic(1590011499:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(1451974294:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-775409765:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1201023170:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos2, Scaffold.-1238820845, Scaffold.1672350452, Scaffold.-679812638))))) {
            return new BlockData(invokedynamic(-26842841:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos2, Scaffold.-917949669, Scaffold.395372136, Scaffold.-539023846), EnumFacing.EAST);
        }
        if (!invokedynamic(662840591:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(93369191:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-2001130736:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1320273517:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos2, Scaffold.760583686, Scaffold.263725723, Scaffold.423857617))))) {
            return new BlockData(invokedynamic(1518739425:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos2, Scaffold.864961381, Scaffold.1122076485, Scaffold.-1322443954), EnumFacing.WEST);
        }
        if (!invokedynamic(-1906147505:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(517658735:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1655538631:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(1355635501:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos2, Scaffold.-460468485, Scaffold.-318661106, Scaffold.-758021711))))) {
            return new BlockData(invokedynamic(63762141:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos2, Scaffold.-1127813035, Scaffold.354818245, Scaffold.-49570033), EnumFacing.NORTH);
        }
        if (!invokedynamic(66705669:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-329736761:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1174334310:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1018172861:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos2, Scaffold.-77322661, Scaffold.1574513589, Scaffold.1478757043))))) {
            return new BlockData(invokedynamic(-793910617:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos2, Scaffold.328971719, Scaffold.-856940360, Scaffold.-1514889688), EnumFacing.SOUTH);
        }
        final BlockPos 1845411501 = invokedynamic(981047555:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, -1671576855, Scaffold.-1958719977, Scaffold.-897000645, Scaffold.-1286659608);
        if (!invokedynamic(1049008451:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-1097194475:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-370783937:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(746186447:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411501, Scaffold.-1265318711, Scaffold.133275407, Scaffold.1668755994))))) {
            return new BlockData(invokedynamic(-490234611:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411501, Scaffold.-1869837300, Scaffold.-1434626101, Scaffold.-1590723753), EnumFacing.UP);
        }
        if (!invokedynamic(-732297627:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(1047795851:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1240515686:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(1878152480:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411501, Scaffold.-881089765, Scaffold.-2106998331, Scaffold.-1787359107))))) {
            return new BlockData(invokedynamic(-1096371046:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411501, Scaffold.1527561135, Scaffold.-623210398, Scaffold.-308359886), EnumFacing.DOWN);
        }
        if (!invokedynamic(-653954161:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-312237556:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-1951605583:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-859289471:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411501, Scaffold.1607611660, Scaffold.-1004238349, Scaffold.-1864073970))))) {
            return new BlockData(invokedynamic(-1900096257:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411501, Scaffold.708433236, Scaffold.-667312884, Scaffold.-564296682), EnumFacing.EAST);
        }
        if (!invokedynamic(278749643:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-1439898898:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(355977552:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1750260614:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411501, Scaffold.-2063201070, Scaffold.584581548, Scaffold.1447678899))))) {
            return new BlockData(invokedynamic(284786800:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411501, Scaffold.-232672382, Scaffold.578334303, Scaffold.244124494), EnumFacing.WEST);
        }
        if (!invokedynamic(1870661252:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(1167245956:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-355377080:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1683396731:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411501, Scaffold.-753227775, Scaffold.-1008825547, Scaffold.-118187492))))) {
            return new BlockData(invokedynamic(-1164084639:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411501, Scaffold.-1123472217, Scaffold.625588216, Scaffold.-1458020241), EnumFacing.NORTH);
        }
        if (!invokedynamic(-1176161472:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-1399586710:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1432438881:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(1580146635:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411501, Scaffold.1167138627, Scaffold.-452372985, Scaffold.-1468104660))))) {
            return new BlockData(invokedynamic(-274589790:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411501, Scaffold.593107317, Scaffold.-173647363, Scaffold.1304468407), EnumFacing.SOUTH);
        }
        final BlockPos 1845411502 = invokedynamic(-2120039349:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, -1671576855, Scaffold.-937920963, Scaffold.1901871042, Scaffold.919939278);
        if (!invokedynamic(-1335778940:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-110282245:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1548889379:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(1959640257:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411502, Scaffold.-440940467, Scaffold.-1358012136, Scaffold.-551878264))))) {
            return new BlockData(invokedynamic(-1618413415:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411502, Scaffold.-1930442882, Scaffold.-140008609, Scaffold.1798394312), EnumFacing.UP);
        }
        if (!invokedynamic(741109339:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(1711644208:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1132460990:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(1741876676:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411502, Scaffold.-1809878993, Scaffold.-2028600758, Scaffold.1533275200))))) {
            return new BlockData(invokedynamic(-1602947309:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411502, Scaffold.-1449567609, Scaffold.174071966, Scaffold.1633145396), EnumFacing.DOWN);
        }
        if (!invokedynamic(-2103093559:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-83495573:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-1984300682:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1776608708:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411502, Scaffold.834394594, Scaffold.1677034447, Scaffold.-1940003002))))) {
            return new BlockData(invokedynamic(2054398407:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411502, Scaffold.-1421627471, Scaffold.-1191489112, Scaffold.1045347062), EnumFacing.EAST);
        }
        if (!invokedynamic(-1212265487:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-359802160:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1521796271:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1938843078:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411502, Scaffold.1212107428, Scaffold.-1861382242, Scaffold.-1306359797))))) {
            return new BlockData(invokedynamic(-1892661706:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411502, Scaffold.-333458183, Scaffold.1897947774, Scaffold.-703291284), EnumFacing.WEST);
        }
        if (!invokedynamic(-1565748080:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(2079830422:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-723952706:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-653996119:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411502, Scaffold.-1753961480, Scaffold.-1491202890, Scaffold.913040537))))) {
            return new BlockData(invokedynamic(-102195309:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411502, Scaffold.1135854158, Scaffold.-1056603771, Scaffold.1941285788), EnumFacing.NORTH);
        }
        if (!invokedynamic(1380954068:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-454983016:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1661765597:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1951479814:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411502, Scaffold.-836361159, Scaffold.-2133343849, Scaffold.374507953))))) {
            return new BlockData(invokedynamic(-846263364:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411502, Scaffold.1503845733, Scaffold.-1821834573, Scaffold.1407074542), EnumFacing.SOUTH);
        }
        final BlockPos blockPos3 = invokedynamic(-1867470079:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, -1671576855, Scaffold.-992685009, Scaffold.-84844362, Scaffold.-2037292337);
        if (!invokedynamic(-1483984469:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-382733856:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(719569566:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-205002567:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos, Scaffold.-1805277508, Scaffold.2032165445, Scaffold.-1081526491))))) {
            return new BlockData(invokedynamic(2035681112:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos, Scaffold.2084373415, Scaffold.-1433385874, Scaffold.-1285107974), EnumFacing.UP);
        }
        if (!invokedynamic(-990077320:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-423202369:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-581875112:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(1554883485:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos, Scaffold.379617126, Scaffold.-1918438750, Scaffold.676341938))))) {
            return new BlockData(invokedynamic(-140743509:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos, Scaffold.-1949746352, Scaffold.-1100457913, Scaffold.2064846248), EnumFacing.DOWN);
        }
        if (!invokedynamic(2094140576:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(424548196:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-695994691:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1519064261:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos, Scaffold.-414808013, Scaffold.146413447, Scaffold.-512622707))))) {
            return new BlockData(invokedynamic(207206561:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos, Scaffold.-2136955160, Scaffold.1871417772, Scaffold.842724534), EnumFacing.EAST);
        }
        if (!invokedynamic(1523058348:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(1940068060:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1277406239:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(290570059:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos, Scaffold.1835804804, Scaffold.-26875339, Scaffold.-797768157))))) {
            return new BlockData(invokedynamic(1658149375:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos, Scaffold.644897902, Scaffold.-529157917, Scaffold.384545488), EnumFacing.WEST);
        }
        if (!invokedynamic(-1940671374:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(315433544:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(2035063877:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(1550139471:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos, Scaffold.981055119, Scaffold.2091015257, Scaffold.-1526026250))))) {
            return new BlockData(invokedynamic(-1422316229:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos, Scaffold.-327245998, Scaffold.-1871605255, Scaffold.444271936), EnumFacing.NORTH);
        }
        if (!invokedynamic(388999932:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(1053454514:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-1521577685:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(1416280399:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos, Scaffold.-1330639173, Scaffold.1502787897, Scaffold.-662760536))))) {
            return new BlockData(invokedynamic(605380202:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos, Scaffold.1985157851, Scaffold.1094362227, Scaffold.-1084342953), EnumFacing.SOUTH);
        }
        final BlockPos 1845411503 = invokedynamic(-684024036:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, -1671576855, Scaffold.761983138, Scaffold.-403181796, Scaffold.-141361347);
        if (!invokedynamic(821336876:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(58669383:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1156710443:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1693085229:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos2, Scaffold.-1729658219, Scaffold.1657711293, Scaffold.-364699100))))) {
            return new BlockData(invokedynamic(2071704761:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos2, Scaffold.-1811808381, Scaffold.-229925817, Scaffold.1805637130), EnumFacing.UP);
        }
        if (!invokedynamic(1643769789:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(47023539:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1426650278:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(1523595957:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos2, Scaffold.1726466905, Scaffold.1801093854, Scaffold.1607888025))))) {
            return new BlockData(invokedynamic(2032846328:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos2, Scaffold.1283346163, Scaffold.-752364800, Scaffold.-1283942996), EnumFacing.DOWN);
        }
        if (!invokedynamic(1824375134:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(1091283864:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-546423591:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1115068952:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos2, Scaffold.-780213265, Scaffold.-1165667272, Scaffold.603114380))))) {
            return new BlockData(invokedynamic(981090162:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos2, Scaffold.1432631340, Scaffold.41887433, Scaffold.-40750410), EnumFacing.EAST);
        }
        if (!invokedynamic(-16509282:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(2143626503:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(768682979:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(32486372:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos2, Scaffold.1886411635, Scaffold.182999233, Scaffold.-1931967739))))) {
            return new BlockData(invokedynamic(960874657:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos2, Scaffold.1739596701, Scaffold.-190732205, Scaffold.-2098393896), EnumFacing.WEST);
        }
        if (!invokedynamic(-1039344838:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-1345649071:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-1663094166:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-419116499:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos2, Scaffold.995137568, Scaffold.668767894, Scaffold.-732955744))))) {
            return new BlockData(invokedynamic(-1382959793:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos2, Scaffold.49650709, Scaffold.755041987, Scaffold.2023278158), EnumFacing.NORTH);
        }
        if (!invokedynamic(1428132307:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(648810060:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-1706164866:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-65328727:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos2, Scaffold.29391832, Scaffold.-1060769107, Scaffold.-1214154342))))) {
            return new BlockData(invokedynamic(-318931983:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos2, Scaffold.1753741252, Scaffold.-1612589754, Scaffold.220568657), EnumFacing.SOUTH);
        }
        final BlockPos blockPos4 = invokedynamic(-529497986:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, -1671576855, Scaffold.-1369542515, Scaffold.2000161663, Scaffold.1456225880);
        if (!invokedynamic(718539999:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-348321316:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1837090274:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(1219290997:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411501, Scaffold.898311863, Scaffold.408333837, Scaffold.-956056609))))) {
            return new BlockData(invokedynamic(-240233242:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411501, Scaffold.-244906113, Scaffold.-1736965317, Scaffold.-240829710), EnumFacing.UP);
        }
        if (!invokedynamic(1203164357:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(1201984865:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1845621410:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-715048504:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411501, Scaffold.-1903681495, Scaffold.-783129586, Scaffold.-2003947397))))) {
            return new BlockData(invokedynamic(-259328446:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411501, Scaffold.-910142355, Scaffold.56078887, Scaffold.1834599076), EnumFacing.DOWN);
        }
        if (!invokedynamic(-1834514728:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-1664735273:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(436912490:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(1197090144:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411501, Scaffold.-713230295, Scaffold.948695496, Scaffold.-431999122))))) {
            return new BlockData(invokedynamic(951853494:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411501, Scaffold.1060738359, Scaffold.-282442024, Scaffold.137103710), EnumFacing.EAST);
        }
        if (!invokedynamic(104344848:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(2093184853:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1282170924:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(609502353:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411501, Scaffold.-1993217795, Scaffold.-1857033701, Scaffold.1536875952))))) {
            return new BlockData(invokedynamic(-207876997:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411501, Scaffold.343335421, Scaffold.-552333303, Scaffold.903149975), EnumFacing.WEST);
        }
        if (!invokedynamic(612511082:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(2139590140:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(70927007:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(2067071165:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411501, Scaffold.-667013257, Scaffold.329123242, Scaffold.397701923))))) {
            return new BlockData(invokedynamic(-1465264164:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411501, Scaffold.-2082543283, Scaffold.-796863477, Scaffold.279818309), EnumFacing.NORTH);
        }
        if (!invokedynamic(-964077513:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-1621764165:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-144690881:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1299464404:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411501, Scaffold.-1796741738, Scaffold.-2127306413, Scaffold.-1874142893))))) {
            return new BlockData(invokedynamic(-444563107:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411501, Scaffold.-132396127, Scaffold.554414290, Scaffold.-1851006964), EnumFacing.SOUTH);
        }
        final BlockPos 1845411504 = invokedynamic(420702677:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, -1671576855, Scaffold.-995540065, Scaffold.191462039, Scaffold.-343272805);
        if (!invokedynamic(1215368924:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-1012607383:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-1642012713:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1101978644:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411502, Scaffold.589139938, Scaffold.1026462315, Scaffold.1670825625))))) {
            return new BlockData(invokedynamic(156953658:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411502, Scaffold.1366852202, Scaffold.1551156299, Scaffold.116414034), EnumFacing.UP);
        }
        if (!invokedynamic(1788134561:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-8474354:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-394890982:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1720065877:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411502, Scaffold.-942586642, Scaffold.-732812138, Scaffold.-1035648944))))) {
            return new BlockData(invokedynamic(1845524070:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411502, Scaffold.-1194727317, Scaffold.857256288, Scaffold.-333322021), EnumFacing.DOWN);
        }
        if (!invokedynamic(905202131:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(1187959328:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(256615388:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(672109073:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411502, Scaffold.1239071497, Scaffold.-1931448261, Scaffold.-1406432673))))) {
            return new BlockData(invokedynamic(1450637101:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411502, Scaffold.-1947057165, Scaffold.-87756313, Scaffold.-1572800863), EnumFacing.EAST);
        }
        if (!invokedynamic(-56295153:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(746457827:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-1948693712:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(1519147167:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411502, Scaffold.-653221871, Scaffold.-1128168119, Scaffold.-1653014703))))) {
            return new BlockData(invokedynamic(704215982:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411502, Scaffold.1476319726, Scaffold.450171456, Scaffold.1911622971), EnumFacing.WEST);
        }
        if (!invokedynamic(-1656650085:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-826330310:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-553575831:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(1769647294:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411502, Scaffold.449468212, Scaffold.-1223626108, Scaffold.-2089190939))))) {
            return new BlockData(invokedynamic(-1401667452:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411502, Scaffold.66191962, Scaffold.-1246350814, Scaffold.862322866), EnumFacing.NORTH);
        }
        if (!invokedynamic(1433951029:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(1849180573:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-119852985:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1515853226:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411502, Scaffold.1191557094, Scaffold.-1188876322, Scaffold.336337097))))) {
            return new BlockData(invokedynamic(1116657756:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411502, Scaffold.1343014990, Scaffold.978969130, Scaffold.-158465404), EnumFacing.SOUTH);
        }
        final BlockPos blockPos5 = invokedynamic(-536408027:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, -1671576855, Scaffold.425405273, Scaffold.1365265248, Scaffold.213587739);
        if (!invokedynamic(1335105269:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(1944743321:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-1786731608:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(1255859437:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos5, Scaffold.2018171206, Scaffold.-365247928, Scaffold.-1517302185))))) {
            return new BlockData(invokedynamic(-1360283057:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos5, Scaffold.565116894, Scaffold.-1251517979, Scaffold.-1927175233), EnumFacing.UP);
        }
        if (!invokedynamic(1442672081:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(904244223:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-1923868078:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(908848660:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos5, Scaffold.-1590611448, Scaffold.683112321, Scaffold.1687291354))))) {
            return new BlockData(invokedynamic(978231930:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos5, Scaffold.-1417896005, Scaffold.8275926, Scaffold.-735017145), EnumFacing.DOWN);
        }
        if (!invokedynamic(725958228:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-609978127:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-1691813194:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-2135503596:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos5, Scaffold.-1149668469, Scaffold.1794667874, Scaffold.-1350431596))))) {
            return new BlockData(invokedynamic(-1408024647:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos5, Scaffold.-940403810, Scaffold.-1992542179, Scaffold.-167742274), EnumFacing.EAST);
        }
        if (!invokedynamic(-2109279554:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-1215825167:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-1843292907:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(1908509573:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos5, Scaffold.1756302990, Scaffold.1256320985, Scaffold.1619576416))))) {
            return new BlockData(invokedynamic(-810172241:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos5, Scaffold.-1581931672, Scaffold.-1328504982, Scaffold.-394624562), EnumFacing.WEST);
        }
        if (!invokedynamic(1106455539:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-1466001804:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-67629513:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-811955234:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos5, Scaffold.-788039763, Scaffold.-1905626891, Scaffold.1995929123))))) {
            return new BlockData(invokedynamic(1521740853:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos5, Scaffold.-1255103363, Scaffold.309327565, Scaffold.881445210), EnumFacing.NORTH);
        }
        if (!invokedynamic(-161392335:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-299701479:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-1546615815:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1951059054:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos5, Scaffold.-185794572, Scaffold.-864339298, Scaffold.22727020))))) {
            return new BlockData(invokedynamic(682994997:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos5, Scaffold.-1845867729, Scaffold.-917426683, Scaffold.408628799), EnumFacing.SOUTH);
        }
        final BlockPos blockPos6 = invokedynamic(-2123397493:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos5, Scaffold.-468744974, Scaffold.-1545898706, Scaffold.-1678729521);
        if (!invokedynamic(-1008514871:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(100363339:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(593745342:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1959959707:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos6, Scaffold.-1657243592, Scaffold.1034256254, Scaffold.1305804443))))) {
            return new BlockData(invokedynamic(-198146618:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos6, Scaffold.2037316429, Scaffold.-447614732, Scaffold.-37358612), EnumFacing.UP);
        }
        if (!invokedynamic(-996306513:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(717351972:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(789716739:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(154408368:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos6, Scaffold.469806844, Scaffold.-2113292560, Scaffold.132149995))))) {
            return new BlockData(invokedynamic(-1144957189:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos6, Scaffold.-38552936, Scaffold.1992302482, Scaffold.-1126673859), EnumFacing.DOWN);
        }
        if (!invokedynamic(1948130095:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(1134360589:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1998997138:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(856905105:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos6, Scaffold.2085576398, Scaffold.-1185423638, Scaffold.607314796))))) {
            return new BlockData(invokedynamic(1256744516:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos6, Scaffold.-1757754803, Scaffold.-2133800739, Scaffold.-563636279), EnumFacing.EAST);
        }
        if (!invokedynamic(-712183586:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-1196285435:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(146846306:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1064915563:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos6, Scaffold.1209008906, Scaffold.1683811009, Scaffold.-1506486798))))) {
            return new BlockData(invokedynamic(-286999900:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos6, Scaffold.-592887836, Scaffold.1458666383, Scaffold.1824928413), EnumFacing.WEST);
        }
        if (!invokedynamic(-1754532856:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-4252886:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1268649996:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-534172551:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos6, Scaffold.-900726651, Scaffold.-687756575, Scaffold.1606390229))))) {
            return new BlockData(invokedynamic(-937516985:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos6, Scaffold.1006708049, Scaffold.186719392, Scaffold.1293180608), EnumFacing.NORTH);
        }
        if (!invokedynamic(854029548:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-50608241:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-1977676077:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(605857728:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos6, Scaffold.-1647539192, Scaffold.1725425925, Scaffold.-343710105))))) {
            return new BlockData(invokedynamic(804071073:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos6, Scaffold.437295657, Scaffold.2108306416, Scaffold.-1555282005), EnumFacing.SOUTH);
        }
        final BlockPos blockPos7 = invokedynamic(1722155276:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos5, Scaffold.715535872, Scaffold.-704842020, Scaffold.-799250257);
        if (!invokedynamic(-224264858:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(1013192135:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-1791262028:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-840545279:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos7, Scaffold.-1038432817, Scaffold.-106233262, Scaffold.-903174583))))) {
            return new BlockData(invokedynamic(-1023458104:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos7, Scaffold.-1271368224, Scaffold.791412783, Scaffold.632134644), EnumFacing.UP);
        }
        if (!invokedynamic(-1929668944:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(1207074490:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1728674526:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1167220897:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos7, Scaffold.2108214294, Scaffold.-1990381331, Scaffold.816919105))))) {
            return new BlockData(invokedynamic(-239429096:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos7, Scaffold.-1977678738, Scaffold.600036548, Scaffold.1252567012), EnumFacing.DOWN);
        }
        if (!invokedynamic(-1658316168:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-1705487206:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(2127354903:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(1391130789:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos7, Scaffold.-2126815822, Scaffold.-1855439297, Scaffold.153782979))))) {
            return new BlockData(invokedynamic(2137078886:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos7, Scaffold.277088018, Scaffold.1926178217, Scaffold.887722830), EnumFacing.EAST);
        }
        if (!invokedynamic(1330641097:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(764332085:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-1181344353:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(780438086:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos7, Scaffold.-1138471376, Scaffold.-1483521536, Scaffold.1161146524))))) {
            return new BlockData(invokedynamic(-777163663:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos7, Scaffold.-300971711, Scaffold.-1976027684, Scaffold.-1922844515), EnumFacing.WEST);
        }
        if (!invokedynamic(171498462:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(1784285543:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1134276557:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1167952451:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos7, Scaffold.940085249, Scaffold.1863967554, Scaffold.-979431968))))) {
            return new BlockData(invokedynamic(1119566926:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos7, Scaffold.-2122022447, Scaffold.630189588, Scaffold.813491319), EnumFacing.NORTH);
        }
        if (!invokedynamic(-1423451287:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-1503536238:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-186841799:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(359623394:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos7, Scaffold.-65057435, Scaffold.774672983, Scaffold.1465255690))))) {
            return new BlockData(invokedynamic(-942433216:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos7, Scaffold.-1469811211, Scaffold.1988754392, Scaffold.-152754980), EnumFacing.SOUTH);
        }
        final BlockPos 1845411505 = invokedynamic(-1386060178:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos5, Scaffold.-224921705, Scaffold.-1379996120, Scaffold.1193645681);
        if (!invokedynamic(-981970811:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(1009210847:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-826115128:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-22491673:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411505, Scaffold.-1456484935, Scaffold.980656556, Scaffold.2115468170))))) {
            return new BlockData(invokedynamic(-259752145:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411505, Scaffold.1445376120, Scaffold.272289033, Scaffold.-714995732), EnumFacing.UP);
        }
        if (!invokedynamic(1006972696:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(2063068569:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1745606836:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1937149903:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411505, Scaffold.-2077508205, Scaffold.-1425681619, Scaffold.1913159316))))) {
            return new BlockData(invokedynamic(-290931676:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411505, Scaffold.-1058956607, Scaffold.-396751331, Scaffold.-1033058811), EnumFacing.EAST);
        }
        if (!invokedynamic(-1171223592:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-1660214935:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-2093915437:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(80452815:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411505, Scaffold.1600815497, Scaffold.790028706, Scaffold.-316927055))))) {
            return new BlockData(invokedynamic(501477822:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411505, Scaffold.1469420636, Scaffold.725765803, Scaffold.1901472883), EnumFacing.DOWN);
        }
        if (!invokedynamic(-1747637255:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-1658449030:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(420808447:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1977727907:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411505, Scaffold.-384170936, Scaffold.-934343442, Scaffold.-1573140297))))) {
            return new BlockData(invokedynamic(-1735321620:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411505, Scaffold.973944784, Scaffold.-248654021, Scaffold.977880991), EnumFacing.WEST);
        }
        if (!invokedynamic(-801518506:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(1369263461:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(131375670:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-782444911:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411505, Scaffold.1180751564, Scaffold.-1686088184, Scaffold.356736216))))) {
            return new BlockData(invokedynamic(-200869158:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411505, Scaffold.1041582978, Scaffold.457371154, Scaffold.1494653404), EnumFacing.NORTH);
        }
        if (!invokedynamic(-653954650:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(261958891:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-927648071:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-123656490:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411505, Scaffold.1142986045, Scaffold.-326419743, Scaffold.-1269886358))))) {
            return new BlockData(invokedynamic(-1368858016:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, 1845411505, Scaffold.1456658393, Scaffold.-934714452, Scaffold.1338487021), EnumFacing.SOUTH);
        }
        final BlockPos blockPos8 = invokedynamic(-2077611644:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos5, Scaffold.1184102419, Scaffold.-2107675619, Scaffold.822667728);
        if (!invokedynamic(-21876440:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-1944594426:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-234978987:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(415018860:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos8, Scaffold.890072330, Scaffold.-1485209785, Scaffold.-716807429))))) {
            return new BlockData(invokedynamic(-290377020:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos8, Scaffold.-1729764341, Scaffold.-1040451988, Scaffold.-537376229), EnumFacing.UP);
        }
        if (!invokedynamic(-871403696:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(1796881227:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(1303917178:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-935170242:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos8, Scaffold.1357677071, Scaffold.520659285, Scaffold.-819419873))))) {
            return new BlockData(invokedynamic(-1375887825:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos8, Scaffold.1023448724, Scaffold.953951292, Scaffold.-184466375), EnumFacing.DOWN);
        }
        if (!invokedynamic(863068428:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(407883095:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(564171580:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-740482448:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos8, Scaffold.814998549, Scaffold.-688382819, Scaffold.-286581046))))) {
            return new BlockData(invokedynamic(-1732313625:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos8, Scaffold.1844491714, Scaffold.1204485815, Scaffold.-233032194), EnumFacing.EAST);
        }
        if (!invokedynamic(-1504864196:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(2025975449:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-636356646:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(303110530:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos8, Scaffold.-1807681114, Scaffold.351999916, Scaffold.2125053485))))) {
            return new BlockData(invokedynamic(-750824898:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos8, Scaffold.-252435436, Scaffold.1295976539, Scaffold.-1166861977), EnumFacing.WEST);
        }
        if (!invokedynamic(-239363590:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(-9253135:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-267045348:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(-1305599426:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos8, Scaffold.-1854038362, Scaffold.2090619777, Scaffold.-157230286))))) {
            return new BlockData(invokedynamic(-376358702:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos8, Scaffold.531196010, Scaffold.1811608531, Scaffold.1688910858), EnumFacing.NORTH);
        }
        if (!invokedynamic(-612554339:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.invalid, invokedynamic(1449400577:(Ljava/lang/Object;)Lnet/minecraft/block/Block;, invokedynamic(-610090593:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/block/state/IBlockState;, this.mc.field_71441_e, invokedynamic(715161785:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos8, Scaffold.-802292767, Scaffold.2123483993, Scaffold.816488832))))) {
            return new BlockData(invokedynamic(-1596862611:(Ljava/lang/Object;III)Lnet/minecraft/util/math/BlockPos;, blockPos8, Scaffold.45801058, Scaffold.1915844304, Scaffold.-287304689), EnumFacing.SOUTH);
        }
        return null;
    }
    
    private float[] aimAtLocation(final double 192991487, final double 386740347, final double 120836702, final EnumFacing 1177999600) {
        final EntitySnowball entitySnowball = new EntitySnowball((World)this.mc.field_71441_e);
        entitySnowball.field_70165_t = 192991487 + Scaffold.-1209657323;
        entitySnowball.field_70163_u = 386740347 - Scaffold.484239379;
        entitySnowball.field_70161_v = 120836702 + Scaffold.-948211374;
        return this.aimAtLocation(entitySnowball.field_70165_t, entitySnowball.field_70163_u, entitySnowball.field_70161_v);
    }
    
    private float[] aimAtLocation(final double -1577566035, final double 796127424, final double -884683402) {
        final double 796127425 = -1577566035 - this.mc.field_71439_g.field_70165_t;
        final double 796127426 = 796127424 - this.mc.field_71439_g.field_70163_u;
        final double 796127427 = -884683402 - this.mc.field_71439_g.field_70161_v;
        final double n = (double)invokedynamic(-1143259740:(D)F, 796127425 * 796127425 + 796127427 * 796127427);
        final float[] array = new float[Scaffold.1529517446];
        array[Scaffold.-1395634031] = (float)(invokedynamic(-393568514:(DD)D, 796127427, 796127425) * Scaffold.-449671539 / Scaffold.-2053492680) - Scaffold.-181649210;
        array[Scaffold.997371932] = (float)(-(invokedynamic(1739998029:(DD)D, 796127426, n) * Scaffold.-1309540876 / Scaffold.54187530));
        return array;
    }
    
    static {
        Scaffold.-962003851 = -331703793;
        Scaffold.-671791991 = 184;
        Scaffold.-1757805408 = invokedynamic(1560938420:(I)I, false);
        Scaffold.-938873572 = (-1 >>> 81 | -1 << -81);
        Scaffold.-2017626160 = invokedynamic(-1819808582:(J)J, 9213554663955783563L);
        Scaffold.1080825236 = invokedynamic(-1056323513:(I)I, Integer.MIN_VALUE);
        Scaffold.-1931654621 = invokedynamic(-1103760781:(J)J, 9213554663955783563L);
        Scaffold.1645752374 = (0 >>> 215 | 0 << ~0xD7 + 1);
        Scaffold.1689147936 = invokedynamic(-307864380:(I)I, -1811939328);
        Scaffold.-1491463124 = (0 >>> 122 | 0 << -122);
        Scaffold.289267565 = invokedynamic(-1722404606:(I)I, Integer.MIN_VALUE);
        Scaffold.2046104560 = invokedynamic(1519490855:(I)I, 1073741824);
        Scaffold.201377824 = (3 >>> 224 | 3 << -224);
        Scaffold.-1375758128 = invokedynamic(232990166:(I)I, 536870912);
        Scaffold.-1814985787 = (10 >>> 129 | 10 << -129);
        Scaffold.1381086822 = (402653184 >>> 58 | 402653184 << -58);
        Scaffold.-1407523321 = ((448 >>> 166 | 448 << ~0xA6 + 1) & -1);
        Scaffold.-1437440113 = ((1073741824 >>> 59 | 1073741824 << ~0x3B + 1) & -1);
        Scaffold.-817770663 = invokedynamic(1009514902:(I)I, -1879048192);
        Scaffold.-1746896709 = invokedynamic(-1880337020:(I)I, 1342177280);
        Scaffold.-411372581 = invokedynamic(912901701:(I)I, -805306368);
        Scaffold.896870368 = (6291456 >>> 147 | 6291456 << ~0x93 + 1);
        Scaffold.1626298485 = (6656 >>> 9 | 6656 << -9);
        Scaffold.251239616 = invokedynamic(221536885:(I)I, 1879048192);
        Scaffold.1390413670 = ((251658240 >>> 24 | 251658240 << ~0x18 + 1) & -1);
        Scaffold.1575666695 = ((2097152 >>> 209 | 2097152 << -209) & -1);
        Scaffold.1646084800 = (2176 >>> 7 | 2176 << ~0x7 + 1);
        Scaffold.190788461 = invokedynamic(746072046:(I)I, 1207959552);
        Scaffold.-1928547296 = invokedynamic(-1509444183:(I)I, -939524096);
        Scaffold.-1133436447 = invokedynamic(-685008012:(I)I, 671088640);
        Scaffold.-109746347 = (672 >>> 5 | 672 << -5);
        Scaffold.474332574 = invokedynamic(-710409920:(I)I, 1744830464);
        Scaffold.739161886 = (-2147483637 >>> 191 | -2147483637 << -191);
        Scaffold.457586468 = (24 >>> 96 | 24 << -96);
        Scaffold.-1133280143 = (25600 >>> 202 | 25600 << ~0xCA + 1);
        Scaffold.1940887124 = invokedynamic(638203014:(I)I, 1476395008);
        Scaffold.-1215880908 = invokedynamic(-520431589:(I)I, -671088640);
        Scaffold.-901255045 = invokedynamic(1470920016:(I)I, 939524096);
        Scaffold.594802002 = invokedynamic(1915849870:(I)I, -1207959552);
        Scaffold.-227024077 = invokedynamic(666210483:(I)I, 2013265920);
        Scaffold.1610219731 = invokedynamic(381757322:(I)I, -134217728);
        Scaffold.-944918307 = ((536870912 >>> 88 | 536870912 << -88) & -1);
        Scaffold.375211841 = ((4224 >>> 39 | 4224 << -39) & -1);
        Scaffold.1641556627 = invokedynamic(1856498914:(I)I, 1140850688);
        Scaffold.1978910525 = (1610612740 >>> 93 | 1610612740 << ~0x5D + 1);
        Scaffold.904149025 = invokedynamic(2062890949:(I)I, 603979776);
        Scaffold.1997071404 = (1073741833 >>> 94 | 1073741833 << ~0x5E + 1);
        Scaffold.-1807559045 = ((9728 >>> 104 | 9728 << -104) & -1);
        Scaffold.579985113 = (-1677721600 >>> 26 | -1677721600 << ~0x1A + 1);
        Scaffold.-1931569903 = invokedynamic(1948726721:(I)I, 335544320);
        Scaffold.813742189 = ((268435456 >>> 27 | 268435456 << ~0x1B + 1) & -1);
        Scaffold.-77136101 = invokedynamic(143485644:(J)J, 9213554663955783563L);
        Scaffold.-2075218138 = invokedynamic(-1432803136:(J)D, invokedynamic(747679836:(J)J, 6146L));
        Scaffold.-2142976094 = invokedynamic(-1824586854:(I)I, -1073741824);
        Scaffold.-863766392 = invokedynamic(41460674:(J)J, -442162937126559861L);
        Scaffold.-1774122415 = invokedynamic(1708720063:(J)J, -8791026472627208192L);
        Scaffold.-1907867183 = invokedynamic(1514607471:(I)I, 536870912);
        Scaffold.1239915542 = invokedynamic(1244734630:(J)J, 9213554663955783563L);
        Scaffold.2066504500 = invokedynamic(-509347228:(I)I, 1073741824);
        Scaffold.1590833282 = invokedynamic(-1010094756:(I)I, false);
        Scaffold.742490285 = invokedynamic(-1711202556:(I)I, -1610612736);
        Scaffold.617765572 = invokedynamic(1002000229:(I)I, -1);
        Scaffold.425424758 = invokedynamic(-1458876756:(J)J, 9213554663955783563L);
        Scaffold.332761283 = invokedynamic(-64630178:(I)I, Integer.MIN_VALUE);
        Scaffold.-1681889420 = invokedynamic(849488944:(I)I, 1610612736);
        Scaffold.2120066936 = invokedynamic(-1811605645:(J)J, -442162937126559861L);
        Scaffold.807099167 = invokedynamic(-982670133:(J)J, -8791026472627208192L);
        Scaffold.-1509774615 = ((14680064 >>> 53 | 14680064 << ~0x35 + 1) & -1);
        Scaffold.-482926247 = invokedynamic(-904489140:(J)J, -442162937126559861L);
        Scaffold.37865063 = invokedynamic(2006151076:(J)J, -8791026472627208192L);
        Scaffold.-830974692 = invokedynamic(819665591:(I)I, Integer.MIN_VALUE);
        Scaffold.-714106616 = ((2 >>> 190 | 2 << -190) & -1);
        Scaffold.1853150999 = invokedynamic(890917255:(J)J, -442162937126559861L);
        Scaffold.-1484345922 = invokedynamic(222036473:(J)J, -8791026472627208192L);
        Scaffold.-1218124734 = (131072 >>> 241 | 131072 << ~0xF1 + 1);
        Scaffold.702631571 = (9 >>> 32 | 9 << -32);
        Scaffold.-944844310 = invokedynamic(-338467083:(I)I, -1);
        Scaffold.-1754729998 = invokedynamic(1658022849:(J)J, 9213554663955783563L);
        Scaffold.-171308587 = (8 >>> 195 | 8 << -195);
        Scaffold.-2112250412 = invokedynamic(-154965580:(I)I, 1342177280);
        Scaffold.1294366228 = invokedynamic(2006476717:(J)J, 9213554663955783563L);
        Scaffold.1107912271 = invokedynamic(-1041058819:(I)I, Integer.MIN_VALUE);
        Scaffold.-1569225616 = invokedynamic(2033305064:(I)I, -805306368);
        Scaffold.-591088039 = invokedynamic(-443334591:(J)J, 9213554663955783563L);
        Scaffold.-1824802144 = invokedynamic(-2004503275:(I)I, Integer.MIN_VALUE);
        Scaffold.-1204682394 = ((-2147483647 >>> 125 | -2147483647 << ~0x7D + 1) & -1);
        Scaffold.-1754242383 = invokedynamic(-349410094:(J)J, -442162937126559861L);
        Scaffold.1217423743 = invokedynamic(1942263760:(J)J, -8791026472627208192L);
        Scaffold.-1082007302 = invokedynamic(411011447:(I)I, Integer.MIN_VALUE);
        Scaffold.1553809675 = ((1744830464 >>> 219 | 1744830464 << -219) & -1);
        Scaffold.-1837106085 = invokedynamic(1963967947:(J)J, 9213554663955783563L);
        Scaffold.-1112703929 = (2048 >>> 107 | 2048 << ~0x6B + 1);
        Scaffold.-44097554 = (3584 >>> 8 | 3584 << ~0x8 + 1);
        Scaffold.-2053615656 = invokedynamic(980491498:(J)J, 9213554663955783563L);
        Scaffold.1167249698 = invokedynamic(-794742217:(I)I, Integer.MIN_VALUE);
        Scaffold.-1787675632 = ((60 >>> 34 | 60 << ~0x22 + 1) & -1);
        Scaffold.742877607 = ((-1 >>> 187 | -1 << ~0xBB + 1) & -1);
        Scaffold.1589140951 = invokedynamic(-925273753:(J)J, 9213554663955783563L);
        Scaffold.-1942560193 = ((2097152 >>> 21 | 2097152 << ~0x15 + 1) & -1);
        Scaffold.-401901947 = ((536870912 >>> 249 | 536870912 << ~0xF9 + 1) & -1);
        Scaffold.655907153 = invokedynamic(-998379914:(J)J, -442162937126559861L);
        Scaffold.2142637207 = invokedynamic(838236614:(J)J, -8791026472627208192L);
        Scaffold.1403577773 = invokedynamic(-1834857153:(I)I, false);
        Scaffold.165851456 = (192 >>> 196 | 192 << -196);
        Scaffold.1222352927 = ((0 >>> 199 | 0 << ~0xC7 + 1) & -1);
        Scaffold.903890813 = ((8 >>> 99 | 8 << ~0x63 + 1) & -1);
        Scaffold.-1742755606 = ((Integer.MIN_VALUE >>> 190 | Integer.MIN_VALUE << -190) & -1);
        Scaffold.2144335196 = invokedynamic(1759547452:(I)I, -1073741824);
        Scaffold.768739230 = ((8192 >>> 235 | 8192 << ~0xEB + 1) & -1);
        Scaffold.1660669649 = (2560 >>> 9 | 2560 << -9);
        Scaffold.815186617 = invokedynamic(1088518514:(I)I, 1610612736);
        Scaffold.1262753103 = (224 >>> 69 | 224 << ~0x45 + 1);
        Scaffold.-1341981211 = (1024 >>> 167 | 1024 << -167);
        Scaffold.-1495942082 = invokedynamic(-1233300460:(I)I, -1879048192);
        Scaffold.1053998506 = invokedynamic(1537049943:(I)I, 1342177280);
        Scaffold.2139554845 = (180224 >>> 238 | 180224 << -238);
        Scaffold.-1822345186 = invokedynamic(1385467600:(I)I, -2013265920);
        Scaffold.460870522 = invokedynamic(-811686827:(J)J, -442162937126559861L);
        Scaffold.546385214 = invokedynamic(603951473:(J)J, -8791026472627208192L);
        Scaffold.179614941 = ((512 >>> 137 | 512 << ~0x89 + 1) & -1);
        Scaffold.798159631 = invokedynamic(1579905428:(I)I, 1207959552);
        Scaffold.984250250 = invokedynamic(2008316365:(I)I, -1);
        Scaffold.476866765 = invokedynamic(1596270724:(J)J, 9213554663955783563L);
        Scaffold.1342262382 = ((32768 >>> 15 | 32768 << -15) & -1);
        Scaffold.397830028 = ((19456 >>> 10 | 19456 << ~0xA + 1) & -1);
        Scaffold.-382794649 = invokedynamic(328595119:(J)J, -442162937126559861L);
        Scaffold.-2035828310 = invokedynamic(1676707583:(J)J, -8791026472627208192L);
        Scaffold.767225231 = (Integer.MIN_VALUE >>> 223 | Integer.MIN_VALUE << -223);
        Scaffold.100790970 = invokedynamic(-582846399:(I)I, 671088640);
        Scaffold.1876602448 = invokedynamic(-987771595:(J)J, 9213554663955783563L);
        Scaffold.118583577 = invokedynamic(1093549965:(I)I, -1476395008);
        Scaffold.-1151286472 = (-1 >>> 119 | -1 << ~0x77 + 1);
        Scaffold.-1496318285 = invokedynamic(1399668085:(J)J, 9213554663955783563L);
        Scaffold.-2041298644 = invokedynamic(-1260647585:(I)I, Integer.MIN_VALUE);
        Scaffold.626738280 = invokedynamic(-418378136:(I)I, 1744830464);
        Scaffold.-1152071250 = invokedynamic(1318484013:(J)J, -442162937126559861L);
        Scaffold.1283731613 = invokedynamic(2096317458:(J)J, -8791026472627208192L);
        Scaffold.1691572198 = (736 >>> 37 | 736 << ~0x25 + 1);
        Scaffold.1461069685 = invokedynamic(-1435302062:(J)J, 9213554663955783563L);
        Scaffold.-290268276 = invokedynamic(1553697448:(I)I, Integer.MIN_VALUE);
        Scaffold.-180616842 = invokedynamic(41111812:(I)I, 402653184);
        Scaffold.-530774641 = invokedynamic(1907380980:(J)J, -442162937126559861L);
        Scaffold.-733642252 = invokedynamic(-453955581:(J)J, -8791026472627208192L);
        Scaffold.2005469004 = invokedynamic(441717119:(I)I, -1744830464);
        Scaffold.766652876 = invokedynamic(101283571:(J)J, -442162937126559861L);
        Scaffold.-2095733632 = invokedynamic(-325843659:(J)J, -8791026472627208192L);
        Scaffold.-1993110764 = invokedynamic(-1846565332:(I)I, Integer.MIN_VALUE);
        Scaffold.819753950 = invokedynamic(-298957501:(I)I, 1476395008);
        Scaffold.-584617372 = invokedynamic(2044755131:(J)J, 9213554663955783563L);
        Scaffold.-931102198 = invokedynamic(1585192039:(I)I, -1375731712);
        Scaffold.-1376860412 = invokedynamic(573432674:(I)I, -16777216);
        Scaffold.459565375 = invokedynamic(1460265044:(I)I, -1090519040);
        Scaffold.-110629301 = invokedynamic(625464118:(I)I, -1207959552);
        Scaffold.788359805 = invokedynamic(439092913:(I)I, false);
        Scaffold.1671449066 = (1179648 >>> 17 | 1179648 << ~0x11 + 1);
        Scaffold.1718145353 = ((16 >>> 196 | 16 << ~0xC4 + 1) & -1);
        Scaffold.116332616 = invokedynamic(429751329:(J)D, invokedynamic(-306708737:(J)J, 2044L));
        Scaffold.131655105 = invokedynamic(717759145:(J)D, invokedynamic(1698379348:(J)J, 2044L));
        Scaffold.-1207107436 = invokedynamic(747242399:(J)D, invokedynamic(-921584429:(J)J, 25275358204L));
        Scaffold.-1187723891 = invokedynamic(-2126491394:(J)J, 4296434044511453184L);
        Scaffold.1428996240 = invokedynamic(2146088293:(J)D, invokedynamic(-888430288:(J)J, 4002043622820645885L));
        Scaffold.-431904469 = (0 >>> 185 | 0 << ~0xB9 + 1);
        Scaffold.2075470134 = invokedynamic(572969282:(I)I, false);
        Scaffold.-108599672 = ((16 >>> 228 | 16 << -228) & -1);
        Scaffold.1649403363 = (65536 >>> 47 | 65536 << -47);
        Scaffold.-1135381693 = (1073741824 >>> 158 | 1073741824 << -158);
        Scaffold.63914693 = invokedynamic(286020204:(J)D, invokedynamic(2027869498:(J)J, 2L));
        Scaffold.1411299896 = invokedynamic(-1940763068:(I)I, false);
        Scaffold.-984510500 = invokedynamic(1661068913:(I)I, Integer.MIN_VALUE);
        Scaffold.298641779 = ((1769472 >>> 240 | 1769472 << -240) & -1);
        Scaffold.500120964 = invokedynamic(225453742:(J)J, -442162937126559861L);
        Scaffold.872922874 = invokedynamic(837902049:(J)J, -8791026472627208192L);
        Scaffold.1725861965 = ((0 >>> 131 | 0 << -131) & -1);
        Scaffold.-1340831892 = invokedynamic(274252568:(J)J, 2738188573441261568L);
        Scaffold.1398133380 = invokedynamic(441019811:(I)I, -1879048192);
        Scaffold.791028632 = (180 >>> 130 | 180 << -130);
        Scaffold.913673326 = invokedynamic(171220278:(I)I, 603979776);
        Scaffold.-1560039845 = ((184549376 >>> 54 | 184549376 << ~0x36 + 1) & -1);
        Scaffold.740667469 = invokedynamic(1308066695:(I)I, false);
        Scaffold.1089787589 = invokedynamic(-1080748657:(I)I, false);
        Scaffold.497132895 = (368640 >>> 141 | 368640 << -141);
        Scaffold.974817115 = (4 >>> 65 | 4 << -65);
        Scaffold.-997513601 = invokedynamic(-116191993:(I)I, Integer.MIN_VALUE);
        Scaffold.258225863 = invokedynamic(1157409158:(J)D, invokedynamic(-1038382341:(J)J, 1896707L));
        Scaffold.-1637571708 = invokedynamic(1196188241:(J)D, invokedynamic(-1615933449:(J)J, 1896707L));
        Scaffold.1530361711 = invokedynamic(1046231074:(J)D, invokedynamic(-340949668:(J)J, 2L));
        Scaffold.373564555 = invokedynamic(-806926663:(J)D, invokedynamic(-2029000944:(J)J, -5534023222112863236L));
        Scaffold.19110609 = invokedynamic(-1351221088:(I)F, 69943296 >>> 60 | 69943296 << -60);
        Scaffold.1391561503 = invokedynamic(1296578207:(J)D, invokedynamic(-91296777:(J)J, -5534023222112863236L));
        Scaffold.-1114026407 = invokedynamic(65692114:(I)F, 34971648 >>> 219 | 34971648 << ~0xDB + 1);
        Scaffold.-645717918 = invokedynamic(406612009:(J)D, invokedynamic(1927093212:(J)J, -5534023222112863236L));
        Scaffold.-975433472 = invokedynamic(1188309467:(I)F, 69943296 >>> 124 | 69943296 << ~0x7C + 1);
        Scaffold.-560107224 = invokedynamic(396638240:(J)D, invokedynamic(1675947700:(J)J, -5534023222112863236L));
        Scaffold.-915577915 = invokedynamic(-73275620:(I)F, -2056781824 >>> 97 | -2056781824 << -97);
        Scaffold.1311543494 = ((268435456 >>> 91 | 268435456 << ~0x5B + 1) & -1);
        Scaffold.223289916 = (134217728 >>> 219 | 134217728 << -219);
        Scaffold.-35482268 = ((65536 >>> 15 | 65536 << ~0xF + 1) & -1);
        Scaffold.133732036 = (0 >>> 120 | 0 << ~0x78 + 1);
        Scaffold.-282491125 = (128 >>> 7 | 128 << -7);
        Scaffold.65449854 = (2 >>> 161 | 2 << -161);
        Scaffold.-1847718566 = ((0 >>> 197 | 0 << ~0xC5 + 1) & -1);
        Scaffold.-1656927652 = invokedynamic(-840388571:(I)I, false);
        Scaffold.1807313339 = ((2359296 >>> 80 | 2359296 << ~0x50 + 1) & -1);
        Scaffold.1924659613 = (754974720 >>> 248 | 754974720 << ~0xF8 + 1);
        Scaffold.1239207657 = invokedynamic(-1764381679:(I)I, false);
        Scaffold.-343888879 = invokedynamic(-731151520:(I)I, -1);
        Scaffold.-2080030083 = (0 >>> 228 | 0 << ~0xE4 + 1);
        Scaffold.-2145534657 = invokedynamic(1243502067:(I)I, false);
        Scaffold.743643918 = invokedynamic(-1808921597:(I)I, -1);
        Scaffold.-1705025771 = ((0 >>> 108 | 0 << ~0x6C + 1) & -1);
        Scaffold.592698647 = ((-1 >>> 64 | -1 << ~0x40 + 1) & -1);
        Scaffold.-1261744748 = ((0 >>> 179 | 0 << -179) & -1);
        Scaffold.661904155 = ((0 >>> 109 | 0 << -109) & -1);
        Scaffold.-901001903 = (-1 >>> 216 | -1 << -216);
        Scaffold.-1565766939 = (0 >>> 84 | 0 << -84);
        Scaffold.-1701971277 = invokedynamic(-163958385:(I)I, false);
        Scaffold.-2032594706 = (536870912 >>> 253 | 536870912 << -253);
        Scaffold.-1951810933 = invokedynamic(-115884671:(I)I, false);
        Scaffold.-469503027 = invokedynamic(-1713373158:(I)I, false);
        Scaffold.-213561088 = invokedynamic(130159543:(I)I, Integer.MIN_VALUE);
        Scaffold.667959669 = invokedynamic(-1514418880:(I)I, false);
        Scaffold.-956399102 = (0 >>> 52 | 0 << -52);
        Scaffold.-95540063 = ((0 >>> 151 | 0 << -151) & -1);
        Scaffold.1095736645 = invokedynamic(-1555054749:(I)I, false);
        Scaffold.1385713505 = invokedynamic(-232290535:(I)I, Integer.MIN_VALUE);
        Scaffold.800155507 = invokedynamic(-964132781:(I)I, false);
        Scaffold.2031087318 = (0 >>> 73 | 0 << -73);
        Scaffold.269622672 = ((8192 >>> 141 | 8192 << -141) & -1);
        Scaffold.-815576298 = ((0 >>> 247 | 0 << -247) & -1);
        Scaffold.918343191 = invokedynamic(-1592477765:(I)I, false);
        Scaffold.-112489442 = invokedynamic(1514894973:(I)I, -1);
        Scaffold.1778890455 = (0 >>> 193 | 0 << ~0xC1 + 1);
        Scaffold.1464055528 = invokedynamic(-196171301:(I)I, false);
        Scaffold.-811808187 = invokedynamic(1963523152:(I)I, -1);
        Scaffold.526974703 = invokedynamic(486581851:(I)I, false);
        Scaffold.250866310 = invokedynamic(-1453958097:(I)I, Integer.MIN_VALUE);
        Scaffold.-1503268165 = (0 >>> 159 | 0 << ~0x9F + 1);
        Scaffold.2046945995 = ((0 >>> 59 | 0 << -59) & -1);
        Scaffold.1237310079 = invokedynamic(2037418184:(I)I, Integer.MIN_VALUE);
        Scaffold.67157437 = invokedynamic(323844711:(I)I, false);
        Scaffold.1457942371 = invokedynamic(-1506048126:(I)I, -1);
        Scaffold.953611515 = ((0 >>> 186 | 0 << ~0xBA + 1) & -1);
        Scaffold.-376383473 = invokedynamic(-2023399565:(I)I, false);
        Scaffold.1681887528 = ((0 >>> 10 | 0 << -10) & -1);
        Scaffold.1827913340 = invokedynamic(2054713368:(I)I, -1);
        Scaffold.-908104800 = invokedynamic(321237854:(I)I, false);
        Scaffold.-511150024 = (0 >>> 8 | 0 << -8);
        Scaffold.-525439259 = ((-1 >>> 43 | -1 << ~0x2B + 1) & -1);
        Scaffold.-718646863 = (0 >>> 96 | 0 << -96);
        Scaffold.859058866 = invokedynamic(-656459672:(I)I, false);
        Scaffold.-954262608 = ((2 >>> 97 | 2 << ~0x61 + 1) & -1);
        Scaffold.1212153146 = ((0 >>> 68 | 0 << ~0x44 + 1) & -1);
        Scaffold.328746372 = invokedynamic(18950141:(I)I, false);
        Scaffold.328109306 = invokedynamic(1543199246:(I)I, Integer.MIN_VALUE);
        Scaffold.1545562860 = (0 >>> 187 | 0 << -187);
        Scaffold.1160314559 = invokedynamic(1857173784:(I)I, -1);
        Scaffold.-64318028 = (0 >>> 29 | 0 << -29);
        Scaffold.-1304060938 = invokedynamic(-1889062782:(I)I, false);
        Scaffold.-933643455 = ((-1 >>> 61 | -1 << ~0x3D + 1) & -1);
        Scaffold.-1704059422 = (0 >>> 13 | 0 << -13);
        Scaffold.702434098 = invokedynamic(-965444533:(I)I, false);
        Scaffold.1191188427 = invokedynamic(1359013189:(I)I, Integer.MIN_VALUE);
        Scaffold.814261592 = invokedynamic(-645429015:(I)I, false);
        Scaffold.2862484 = invokedynamic(-882003476:(I)I, false);
        Scaffold.2044644149 = invokedynamic(845802894:(I)I, Integer.MIN_VALUE);
        Scaffold.-406642439 = invokedynamic(1751105650:(I)I, false);
        Scaffold.-697608325 = invokedynamic(-1234378551:(I)I, false);
        Scaffold.-383309913 = invokedynamic(-410290699:(I)I, false);
        Scaffold.-2124499483 = invokedynamic(-124719907:(I)I, false);
        Scaffold.713352149 = (1073741824 >>> 126 | 1073741824 << -126);
        Scaffold.-738850674 = invokedynamic(-2009317946:(I)I, false);
        Scaffold.-636678352 = invokedynamic(-2087517014:(I)I, false);
        Scaffold.1608264402 = ((536870912 >>> 189 | 536870912 << ~0xBD + 1) & -1);
        Scaffold.-1052603658 = ((0 >>> 213 | 0 << ~0xD5 + 1) & -1);
        Scaffold.1858421051 = (0 >>> 140 | 0 << ~0x8C + 1);
        Scaffold.-410885468 = invokedynamic(-542957735:(I)I, -1);
        Scaffold.1690859144 = invokedynamic(702658680:(I)I, false);
        Scaffold.1227740583 = invokedynamic(-966748869:(I)I, false);
        Scaffold.1615513604 = ((-1 >>> 103 | -1 << -103) & -1);
        Scaffold.1075538583 = invokedynamic(-458487366:(I)I, Integer.MIN_VALUE);
        Scaffold.553172933 = (0 >>> 67 | 0 << ~0x43 + 1);
        Scaffold.-1894193466 = invokedynamic(-860185249:(I)I, false);
        Scaffold.-1157649433 = ((0 >>> 70 | 0 << ~0x46 + 1) & -1);
        Scaffold.971483928 = (-1 >>> 104 | -1 << ~0x68 + 1);
        Scaffold.-646642048 = invokedynamic(-1156996567:(I)I, false);
        Scaffold.-1369991727 = ((0 >>> 17 | 0 << ~0x11 + 1) & -1);
        Scaffold.-1409737857 = ((-1 >>> 10 | -1 << -10) & -1);
        Scaffold.951765279 = invokedynamic(-449009774:(I)I, false);
        Scaffold.-1482239417 = invokedynamic(2108391419:(I)I, false);
        Scaffold.-1364724388 = invokedynamic(-942049601:(I)I, Integer.MIN_VALUE);
        Scaffold.72404236 = invokedynamic(-282221289:(I)I, false);
        Scaffold.1188522983 = ((0 >>> 227 | 0 << ~0xE3 + 1) & -1);
        Scaffold.1914256543 = (1048576 >>> 212 | 1048576 << -212);
        Scaffold.2043970282 = ((0 >>> 121 | 0 << ~0x79 + 1) & -1);
        Scaffold.-1238820845 = invokedynamic(-13922590:(I)I, -1);
        Scaffold.1672350452 = invokedynamic(-1121964050:(I)I, false);
        Scaffold.-679812638 = invokedynamic(471150891:(I)I, false);
        Scaffold.-917949669 = ((-1 >>> 45 | -1 << ~0x2D + 1) & -1);
        Scaffold.395372136 = (0 >>> 153 | 0 << -153);
        Scaffold.-539023846 = ((0 >>> 86 | 0 << ~0x56 + 1) & -1);
        Scaffold.760583686 = (268435456 >>> 188 | 268435456 << -188);
        Scaffold.263725723 = ((0 >>> 15 | 0 << ~0xF + 1) & -1);
        Scaffold.423857617 = invokedynamic(1918955604:(I)I, false);
        Scaffold.864961381 = invokedynamic(409333821:(I)I, Integer.MIN_VALUE);
        Scaffold.1122076485 = invokedynamic(-634188416:(I)I, false);
        Scaffold.-1322443954 = (0 >>> 91 | 0 << ~0x5B + 1);
        Scaffold.-460468485 = invokedynamic(-1742009734:(I)I, false);
        Scaffold.-318661106 = invokedynamic(-1345710201:(I)I, false);
        Scaffold.-758021711 = invokedynamic(-789191012:(I)I, Integer.MIN_VALUE);
        Scaffold.-1127813035 = invokedynamic(1171261948:(I)I, false);
        Scaffold.354818245 = invokedynamic(-332603283:(I)I, false);
        Scaffold.-49570033 = invokedynamic(1624449667:(I)I, Integer.MIN_VALUE);
        Scaffold.-77322661 = (0 >>> 190 | 0 << -190);
        Scaffold.1574513589 = ((0 >>> 63 | 0 << ~0x3F + 1) & -1);
        Scaffold.1478757043 = ((-1 >>> 183 | -1 << -183) & -1);
        Scaffold.328971719 = ((0 >>> 240 | 0 << ~0xF0 + 1) & -1);
        Scaffold.-856940360 = invokedynamic(-978091948:(I)I, false);
        Scaffold.-1514889688 = invokedynamic(1523875167:(I)I, -1);
        Scaffold.-1958719977 = ((0 >>> 222 | 0 << ~0xDE + 1) & -1);
        Scaffold.-897000645 = (0 >>> 139 | 0 << -139);
        Scaffold.-1286659608 = invokedynamic(-603574340:(I)I, Integer.MIN_VALUE);
        Scaffold.-1265318711 = invokedynamic(-541039433:(I)I, false);
        Scaffold.133275407 = (-1 >>> 248 | -1 << -248);
        Scaffold.1668755994 = invokedynamic(-369766012:(I)I, false);
        Scaffold.-1869837300 = invokedynamic(-1946010689:(I)I, false);
        Scaffold.-1434626101 = ((-1 >>> 157 | -1 << ~0x9D + 1) & -1);
        Scaffold.-1590723753 = ((0 >>> 234 | 0 << ~0xEA + 1) & -1);
        Scaffold.-881089765 = invokedynamic(-1785549768:(I)I, false);
        Scaffold.-2106998331 = invokedynamic(-475438068:(I)I, Integer.MIN_VALUE);
        Scaffold.-1787359107 = ((0 >>> 170 | 0 << -170) & -1);
        Scaffold.1527561135 = (0 >>> 18 | 0 << ~0x12 + 1);
        Scaffold.-623210398 = (1024 >>> 10 | 1024 << -10);
        Scaffold.-308359886 = invokedynamic(1299986267:(I)I, false);
        Scaffold.1607611660 = invokedynamic(-1346430295:(I)I, -1);
        Scaffold.-1004238349 = ((0 >>> 247 | 0 << ~0xF7 + 1) & -1);
        Scaffold.-1864073970 = (0 >>> 136 | 0 << ~0x88 + 1);
        Scaffold.708433236 = invokedynamic(-414970570:(I)I, -1);
        Scaffold.-667312884 = invokedynamic(1089481855:(I)I, false);
        Scaffold.-564296682 = (0 >>> 159 | 0 << -159);
        Scaffold.-2063201070 = ((1 >>> 224 | 1 << ~0xE0 + 1) & -1);
        Scaffold.584581548 = (0 >>> 24 | 0 << ~0x18 + 1);
        Scaffold.1447678899 = invokedynamic(-1345066498:(I)I, false);
        Scaffold.-232672382 = invokedynamic(-1213678535:(I)I, Integer.MIN_VALUE);
        Scaffold.578334303 = ((0 >>> 127 | 0 << -127) & -1);
        Scaffold.244124494 = invokedynamic(-320416902:(I)I, false);
        Scaffold.-753227775 = invokedynamic(-1194803223:(I)I, false);
        Scaffold.-1008825547 = (0 >>> 98 | 0 << ~0x62 + 1);
        Scaffold.-118187492 = (1024 >>> 202 | 1024 << -202);
        Scaffold.-1123472217 = invokedynamic(654592560:(I)I, false);
        Scaffold.625588216 = ((0 >>> 177 | 0 << ~0xB1 + 1) & -1);
        Scaffold.-1458020241 = invokedynamic(1414144906:(I)I, Integer.MIN_VALUE);
        Scaffold.1167138627 = invokedynamic(353764330:(I)I, false);
        Scaffold.-452372985 = (0 >>> 27 | 0 << -27);
        Scaffold.-1468104660 = invokedynamic(2001770812:(I)I, -1);
        Scaffold.593107317 = (0 >>> 90 | 0 << ~0x5A + 1);
        Scaffold.-173647363 = invokedynamic(2011442331:(I)I, false);
        Scaffold.1304468407 = ((-1 >>> 81 | -1 << -81) & -1);
        Scaffold.-937920963 = invokedynamic(-984764890:(I)I, false);
        Scaffold.1901871042 = (0 >>> 112 | 0 << -112);
        Scaffold.919939278 = ((-1 >>> 147 | -1 << ~0x93 + 1) & -1);
        Scaffold.-440940467 = ((0 >>> 64 | 0 << ~0x40 + 1) & -1);
        Scaffold.-1358012136 = invokedynamic(701394860:(I)I, -1);
        Scaffold.-551878264 = invokedynamic(1277833984:(I)I, false);
        Scaffold.-1930442882 = invokedynamic(-981452216:(I)I, false);
        Scaffold.-140008609 = invokedynamic(463123623:(I)I, -1);
        Scaffold.1798394312 = ((0 >>> 233 | 0 << ~0xE9 + 1) & -1);
        Scaffold.-1809878993 = invokedynamic(1885397025:(I)I, false);
        Scaffold.-2028600758 = invokedynamic(-1637173363:(I)I, Integer.MIN_VALUE);
        Scaffold.1533275200 = (0 >>> 119 | 0 << -119);
        Scaffold.-1449567609 = (0 >>> 192 | 0 << -192);
        Scaffold.174071966 = invokedynamic(113932401:(I)I, Integer.MIN_VALUE);
        Scaffold.1633145396 = (0 >>> 178 | 0 << ~0xB2 + 1);
        Scaffold.834394594 = (-1 >>> 218 | -1 << -218);
        Scaffold.1677034447 = (0 >>> 204 | 0 << ~0xCC + 1);
        Scaffold.-1940003002 = invokedynamic(-80789518:(I)I, false);
        Scaffold.-1421627471 = (-1 >>> 147 | -1 << ~0x93 + 1);
        Scaffold.-1191489112 = invokedynamic(1570849616:(I)I, false);
        Scaffold.1045347062 = (0 >>> 42 | 0 << ~0x2A + 1);
        Scaffold.1212107428 = invokedynamic(1868084277:(I)I, Integer.MIN_VALUE);
        Scaffold.-1861382242 = invokedynamic(-961489562:(I)I, false);
        Scaffold.-1306359797 = invokedynamic(-1259536513:(I)I, false);
        Scaffold.-333458183 = (131072 >>> 113 | 131072 << -113);
        Scaffold.1897947774 = invokedynamic(-396901059:(I)I, false);
        Scaffold.-703291284 = invokedynamic(-915038486:(I)I, false);
        Scaffold.-1753961480 = invokedynamic(1202049693:(I)I, false);
        Scaffold.-1491202890 = ((0 >>> 44 | 0 << -44) & -1);
        Scaffold.913040537 = invokedynamic(1582713989:(I)I, Integer.MIN_VALUE);
        Scaffold.1135854158 = ((0 >>> 186 | 0 << -186) & -1);
        Scaffold.-1056603771 = (0 >>> 129 | 0 << ~0x81 + 1);
        Scaffold.1941285788 = invokedynamic(1191208097:(I)I, Integer.MIN_VALUE);
        Scaffold.-836361159 = (0 >>> 44 | 0 << ~0x2C + 1);
        Scaffold.-2133343849 = ((0 >>> 181 | 0 << -181) & -1);
        Scaffold.374507953 = ((-1 >>> 122 | -1 << -122) & -1);
        Scaffold.1503845733 = (0 >>> 81 | 0 << -81);
        Scaffold.-1821834573 = invokedynamic(-1814602399:(I)I, false);
        Scaffold.1407074542 = ((-1 >>> 196 | -1 << -196) & -1);
        Scaffold.-992685009 = invokedynamic(194166141:(I)I, Integer.MAX_VALUE);
        Scaffold.-84844362 = invokedynamic(-1200956509:(I)I, false);
        Scaffold.-2037292337 = ((0 >>> 56 | 0 << ~0x38 + 1) & -1);
        Scaffold.-1805277508 = invokedynamic(1248026058:(I)I, false);
        Scaffold.2032165445 = ((-1 >>> 181 | -1 << ~0xB5 + 1) & -1);
        Scaffold.-1081526491 = (0 >>> 30 | 0 << ~0x1E + 1);
        Scaffold.2084373415 = (0 >>> 35 | 0 << ~0x23 + 1);
        Scaffold.-1433385874 = invokedynamic(650275763:(I)I, -1);
        Scaffold.-1285107974 = invokedynamic(180734926:(I)I, false);
        Scaffold.379617126 = (0 >>> 247 | 0 << -247);
        Scaffold.-1918438750 = invokedynamic(-1789022940:(I)I, Integer.MIN_VALUE);
        Scaffold.676341938 = invokedynamic(1779237950:(I)I, false);
        Scaffold.-1949746352 = invokedynamic(320219765:(I)I, false);
        Scaffold.-1100457913 = ((16384 >>> 142 | 16384 << ~0x8E + 1) & -1);
        Scaffold.2064846248 = invokedynamic(-103545120:(I)I, false);
        Scaffold.-414808013 = (-1 >>> 20 | -1 << -20);
        Scaffold.146413447 = invokedynamic(1236681862:(I)I, false);
        Scaffold.-512622707 = (0 >>> 143 | 0 << -143);
        Scaffold.-2136955160 = (-1 >>> 137 | -1 << ~0x89 + 1);
        Scaffold.1871417772 = ((0 >>> 60 | 0 << -60) & -1);
        Scaffold.842724534 = (0 >>> 178 | 0 << ~0xB2 + 1);
        Scaffold.1835804804 = (262144 >>> 82 | 262144 << ~0x52 + 1);
        Scaffold.-26875339 = ((0 >>> 143 | 0 << ~0x8F + 1) & -1);
        Scaffold.-797768157 = invokedynamic(1769284600:(I)I, false);
        Scaffold.644897902 = invokedynamic(82388400:(I)I, Integer.MIN_VALUE);
        Scaffold.-529157917 = invokedynamic(-834264261:(I)I, false);
        Scaffold.384545488 = ((0 >>> 104 | 0 << -104) & -1);
        Scaffold.981055119 = invokedynamic(1326751304:(I)I, false);
        Scaffold.2091015257 = invokedynamic(-34021921:(I)I, false);
        Scaffold.-1526026250 = invokedynamic(1791154426:(I)I, Integer.MIN_VALUE);
        Scaffold.-327245998 = invokedynamic(-1103015652:(I)I, false);
        Scaffold.-1871605255 = ((0 >>> 1 | 0 << ~0x1 + 1) & -1);
        Scaffold.444271936 = (65536 >>> 112 | 65536 << -112);
        Scaffold.-1330639173 = invokedynamic(-992415960:(I)I, false);
        Scaffold.1502787897 = ((0 >>> 34 | 0 << -34) & -1);
        Scaffold.-662760536 = invokedynamic(-1603066993:(I)I, -1);
        Scaffold.1985157851 = (0 >>> 21 | 0 << ~0x15 + 1);
        Scaffold.1094362227 = invokedynamic(-1932267855:(I)I, false);
        Scaffold.-1084342953 = (-1 >>> 54 | -1 << -54);
        Scaffold.761983138 = (33554432 >>> 184 | 33554432 << ~0xB8 + 1);
        Scaffold.-403181796 = invokedynamic(1508776410:(I)I, false);
        Scaffold.-141361347 = invokedynamic(1853424254:(I)I, false);
        Scaffold.-1729658219 = invokedynamic(-1894405075:(I)I, false);
        Scaffold.1657711293 = (-1 >>> 174 | -1 << -174);
        Scaffold.-364699100 = (0 >>> 122 | 0 << ~0x7A + 1);
        Scaffold.-1811808381 = (0 >>> 109 | 0 << -109);
        Scaffold.-229925817 = invokedynamic(-555621717:(I)I, -1);
        Scaffold.1805637130 = (0 >>> 209 | 0 << ~0xD1 + 1);
        Scaffold.1726466905 = invokedynamic(107904370:(I)I, false);
        Scaffold.1801093854 = (134217728 >>> 219 | 134217728 << ~0xDB + 1);
        Scaffold.1607888025 = (0 >>> 209 | 0 << ~0xD1 + 1);
        Scaffold.1283346163 = invokedynamic(-1797634267:(I)I, false);
        Scaffold.-752364800 = invokedynamic(-1830539225:(I)I, Integer.MIN_VALUE);
        Scaffold.-1283942996 = (0 >>> 120 | 0 << -120);
        Scaffold.-780213265 = (-1 >>> 75 | -1 << ~0x4B + 1);
        Scaffold.-1165667272 = ((0 >>> 36 | 0 << ~0x24 + 1) & -1);
        Scaffold.603114380 = (0 >>> 147 | 0 << ~0x93 + 1);
        Scaffold.1432631340 = invokedynamic(1517057933:(I)I, -1);
        Scaffold.41887433 = (0 >>> 189 | 0 << ~0xBD + 1);
        Scaffold.-40750410 = ((0 >>> 76 | 0 << -76) & -1);
        Scaffold.1886411635 = (268435456 >>> 188 | 268435456 << -188);
        Scaffold.182999233 = ((0 >>> 73 | 0 << ~0x49 + 1) & -1);
        Scaffold.-1931967739 = invokedynamic(1680857429:(I)I, false);
        Scaffold.1739596701 = ((4 >>> 34 | 4 << -34) & -1);
        Scaffold.-190732205 = ((0 >>> 169 | 0 << -169) & -1);
        Scaffold.-2098393896 = (0 >>> 35 | 0 << -35);
        Scaffold.995137568 = ((0 >>> 216 | 0 << ~0xD8 + 1) & -1);
        Scaffold.668767894 = (0 >>> 188 | 0 << ~0xBC + 1);
        Scaffold.-732955744 = invokedynamic(-609189249:(I)I, Integer.MIN_VALUE);
        Scaffold.49650709 = ((0 >>> 78 | 0 << -78) & -1);
        Scaffold.755041987 = invokedynamic(-2127049904:(I)I, false);
        Scaffold.2023278158 = (131072 >>> 81 | 131072 << -81);
        Scaffold.29391832 = ((0 >>> 229 | 0 << ~0xE5 + 1) & -1);
        Scaffold.-1060769107 = invokedynamic(271445534:(I)I, false);
        Scaffold.-1214154342 = ((-1 >>> 157 | -1 << ~0x9D + 1) & -1);
        Scaffold.1753741252 = invokedynamic(-314383804:(I)I, false);
        Scaffold.-1612589754 = (0 >>> 0 | 0 << ~0x0 + 1);
        Scaffold.220568657 = (-1 >>> 54 | -1 << -54);
        Scaffold.-1369542515 = invokedynamic(-363837343:(I)I, false);
        Scaffold.2000161663 = invokedynamic(1866374027:(I)I, false);
        Scaffold.1456225880 = invokedynamic(-2011965039:(I)I, 1073741824);
        Scaffold.898311863 = (0 >>> 57 | 0 << -57);
        Scaffold.408333837 = (-1 >>> 5 | -1 << -5);
        Scaffold.-956056609 = invokedynamic(539730907:(I)I, false);
        Scaffold.-244906113 = invokedynamic(2065619824:(I)I, false);
        Scaffold.-1736965317 = invokedynamic(2063430100:(I)I, -1);
        Scaffold.-240829710 = ((0 >>> 207 | 0 << -207) & -1);
        Scaffold.-1903681495 = invokedynamic(1044992191:(I)I, false);
        Scaffold.-783129586 = ((33554432 >>> 217 | 33554432 << ~0xD9 + 1) & -1);
        Scaffold.-2003947397 = invokedynamic(913857308:(I)I, false);
        Scaffold.-910142355 = invokedynamic(-2100291012:(I)I, false);
        Scaffold.56078887 = invokedynamic(-137152529:(I)I, Integer.MIN_VALUE);
        Scaffold.1834599076 = (0 >>> 220 | 0 << ~0xDC + 1);
        Scaffold.-713230295 = (-1 >>> 173 | -1 << -173);
        Scaffold.948695496 = invokedynamic(1232022673:(I)I, false);
        Scaffold.-431999122 = ((0 >>> 200 | 0 << -200) & -1);
        Scaffold.1060738359 = invokedynamic(-781384216:(I)I, -1);
        Scaffold.-282442024 = ((0 >>> 21 | 0 << -21) & -1);
        Scaffold.137103710 = ((0 >>> 157 | 0 << -157) & -1);
        Scaffold.-1993217795 = ((262144 >>> 146 | 262144 << ~0x92 + 1) & -1);
        Scaffold.-1857033701 = invokedynamic(1475723330:(I)I, false);
        Scaffold.1536875952 = invokedynamic(1860326120:(I)I, false);
        Scaffold.343335421 = invokedynamic(2088313585:(I)I, Integer.MIN_VALUE);
        Scaffold.-552333303 = invokedynamic(652520576:(I)I, false);
        Scaffold.903149975 = (0 >>> 172 | 0 << ~0xAC + 1);
        Scaffold.-667013257 = invokedynamic(644652181:(I)I, false);
        Scaffold.329123242 = invokedynamic(785834783:(I)I, false);
        Scaffold.397701923 = ((32768 >>> 207 | 32768 << -207) & -1);
        Scaffold.-2082543283 = (0 >>> 202 | 0 << ~0xCA + 1);
        Scaffold.-796863477 = invokedynamic(1132841890:(I)I, false);
        Scaffold.279818309 = (1048576 >>> 84 | 1048576 << -84);
        Scaffold.-1796741738 = ((0 >>> 162 | 0 << -162) & -1);
        Scaffold.-2127306413 = (0 >>> 91 | 0 << -91);
        Scaffold.-1874142893 = (-1 >>> 50 | -1 << ~0x32 + 1);
        Scaffold.-132396127 = invokedynamic(-1036071620:(I)I, false);
        Scaffold.554414290 = (0 >>> 145 | 0 << -145);
        Scaffold.-1851006964 = invokedynamic(495311675:(I)I, -1);
        Scaffold.-995540065 = ((0 >>> 29 | 0 << ~0x1D + 1) & -1);
        Scaffold.191462039 = invokedynamic(231519625:(I)I, false);
        Scaffold.-343272805 = ((-17 >>> 196 | -17 << -196) & -1);
        Scaffold.589139938 = (0 >>> 141 | 0 << -141);
        Scaffold.1026462315 = invokedynamic(-930692381:(I)I, -1);
        Scaffold.1670825625 = invokedynamic(-646417522:(I)I, false);
        Scaffold.1366852202 = (0 >>> 237 | 0 << ~0xED + 1);
        Scaffold.1551156299 = invokedynamic(1490180782:(I)I, -1);
        Scaffold.116414034 = invokedynamic(2110031780:(I)I, false);
        Scaffold.-942586642 = invokedynamic(-2068978231:(I)I, false);
        Scaffold.-732812138 = (16777216 >>> 216 | 16777216 << -216);
        Scaffold.-1035648944 = invokedynamic(695856946:(I)I, false);
        Scaffold.-1194727317 = invokedynamic(590934612:(I)I, false);
        Scaffold.857256288 = ((128 >>> 167 | 128 << ~0xA7 + 1) & -1);
        Scaffold.-333322021 = (0 >>> 154 | 0 << -154);
        Scaffold.1239071497 = invokedynamic(-993338350:(I)I, -1);
        Scaffold.-1931448261 = (0 >>> 144 | 0 << ~0x90 + 1);
        Scaffold.-1406432673 = invokedynamic(416572866:(I)I, false);
        Scaffold.-1947057165 = invokedynamic(-1650851524:(I)I, -1);
        Scaffold.-87756313 = (0 >>> 72 | 0 << -72);
        Scaffold.-1572800863 = invokedynamic(-176183408:(I)I, false);
        Scaffold.-653221871 = (65536 >>> 80 | 65536 << ~0x50 + 1);
        Scaffold.-1128168119 = ((0 >>> 85 | 0 << ~0x55 + 1) & -1);
        Scaffold.-1653014703 = invokedynamic(-382893991:(I)I, false);
        Scaffold.1476319726 = invokedynamic(-269096761:(I)I, Integer.MIN_VALUE);
        Scaffold.450171456 = ((0 >>> 195 | 0 << ~0xC3 + 1) & -1);
        Scaffold.1911622971 = ((0 >>> 54 | 0 << ~0x36 + 1) & -1);
        Scaffold.449468212 = invokedynamic(-493020648:(I)I, false);
        Scaffold.-1223626108 = invokedynamic(1822344864:(I)I, false);
        Scaffold.-2089190939 = ((16 >>> 196 | 16 << -196) & -1);
        Scaffold.66191962 = ((0 >>> 168 | 0 << -168) & -1);
        Scaffold.-1246350814 = invokedynamic(387339971:(I)I, false);
        Scaffold.862322866 = invokedynamic(-2112918668:(I)I, Integer.MIN_VALUE);
        Scaffold.1191557094 = invokedynamic(2146750530:(I)I, false);
        Scaffold.-1188876322 = invokedynamic(-2040410609:(I)I, false);
        Scaffold.336337097 = invokedynamic(1367472526:(I)I, -1);
        Scaffold.1343014990 = invokedynamic(1352192026:(I)I, false);
        Scaffold.978969130 = ((0 >>> 231 | 0 << ~0xE7 + 1) & -1);
        Scaffold.-158465404 = invokedynamic(-1195663854:(I)I, -1);
        Scaffold.425405273 = invokedynamic(382044965:(I)I, false);
        Scaffold.1365265248 = (-1 >>> 57 | -1 << ~0x39 + 1);
        Scaffold.213587739 = invokedynamic(-1167879369:(I)I, false);
        Scaffold.2018171206 = ((0 >>> 120 | 0 << ~0x78 + 1) & -1);
        Scaffold.-365247928 = ((-1 >>> 113 | -1 << -113) & -1);
        Scaffold.-1517302185 = invokedynamic(-2113453595:(I)I, false);
        Scaffold.565116894 = (0 >>> 217 | 0 << ~0xD9 + 1);
        Scaffold.-1251517979 = (-1 >>> 108 | -1 << ~0x6C + 1);
        Scaffold.-1927175233 = invokedynamic(1055266959:(I)I, false);
        Scaffold.-1590611448 = invokedynamic(-1714048096:(I)I, false);
        Scaffold.683112321 = invokedynamic(1122486411:(I)I, Integer.MIN_VALUE);
        Scaffold.1687291354 = ((0 >>> 57 | 0 << -57) & -1);
        Scaffold.-1417896005 = invokedynamic(-693339502:(I)I, false);
        Scaffold.8275926 = invokedynamic(-1225782066:(I)I, Integer.MIN_VALUE);
        Scaffold.-735017145 = ((0 >>> 62 | 0 << ~0x3E + 1) & -1);
        Scaffold.-1149668469 = ((-1 >>> 212 | -1 << ~0xD4 + 1) & -1);
        Scaffold.1794667874 = ((0 >>> 64 | 0 << -64) & -1);
        Scaffold.-1350431596 = invokedynamic(-1629960897:(I)I, false);
        Scaffold.-940403810 = ((-1 >>> 31 | -1 << -31) & -1);
        Scaffold.-1992542179 = ((0 >>> 18 | 0 << -18) & -1);
        Scaffold.-167742274 = ((0 >>> 151 | 0 << ~0x97 + 1) & -1);
        Scaffold.1756302990 = ((268435456 >>> 156 | 268435456 << ~0x9C + 1) & -1);
        Scaffold.1256320985 = invokedynamic(-60408633:(I)I, false);
        Scaffold.1619576416 = invokedynamic(-326945502:(I)I, false);
        Scaffold.-1581931672 = invokedynamic(-669837260:(I)I, Integer.MIN_VALUE);
        Scaffold.-1328504982 = ((0 >>> 31 | 0 << ~0x1F + 1) & -1);
        Scaffold.-394624562 = invokedynamic(-2068978560:(I)I, false);
        Scaffold.-788039763 = invokedynamic(-526357259:(I)I, false);
        Scaffold.-1905626891 = (0 >>> 199 | 0 << ~0xC7 + 1);
        Scaffold.1995929123 = invokedynamic(712408762:(I)I, Integer.MIN_VALUE);
        Scaffold.-1255103363 = invokedynamic(587244705:(I)I, false);
        Scaffold.309327565 = (0 >>> 159 | 0 << ~0x9F + 1);
        Scaffold.881445210 = invokedynamic(2007296852:(I)I, Integer.MIN_VALUE);
        Scaffold.-185794572 = invokedynamic(275651091:(I)I, false);
        Scaffold.-864339298 = invokedynamic(-1247844707:(I)I, false);
        Scaffold.22727020 = ((-1 >>> 80 | -1 << ~0x50 + 1) & -1);
        Scaffold.-1845867729 = (0 >>> 191 | 0 << ~0xBF + 1);
        Scaffold.-917426683 = invokedynamic(-1805913587:(I)I, false);
        Scaffold.408628799 = (-1 >>> 42 | -1 << -42);
        Scaffold.-468744974 = invokedynamic(904456215:(I)I, Integer.MIN_VALUE);
        Scaffold.-1545898706 = invokedynamic(-662962863:(I)I, false);
        Scaffold.-1678729521 = invokedynamic(-84741097:(I)I, false);
        Scaffold.-1657243592 = (0 >>> 155 | 0 << -155);
        Scaffold.1034256254 = invokedynamic(109225388:(I)I, -1);
        Scaffold.1305804443 = (0 >>> 113 | 0 << ~0x71 + 1);
        Scaffold.2037316429 = (0 >>> 201 | 0 << ~0xC9 + 1);
        Scaffold.-447614732 = (-1 >>> 24 | -1 << -24);
        Scaffold.-37358612 = invokedynamic(1911040021:(I)I, false);
        Scaffold.469806844 = ((0 >>> 49 | 0 << -49) & -1);
        Scaffold.-2113292560 = ((16 >>> 132 | 16 << -132) & -1);
        Scaffold.132149995 = (0 >>> 224 | 0 << ~0xE0 + 1);
        Scaffold.-38552936 = (0 >>> 225 | 0 << -225);
        Scaffold.1992302482 = ((256 >>> 232 | 256 << ~0xE8 + 1) & -1);
        Scaffold.-1126673859 = ((0 >>> 48 | 0 << ~0x30 + 1) & -1);
        Scaffold.2085576398 = invokedynamic(1741291419:(I)I, -1);
        Scaffold.-1185423638 = (0 >>> 159 | 0 << ~0x9F + 1);
        Scaffold.607314796 = (0 >>> 220 | 0 << ~0xDC + 1);
        Scaffold.-1757754803 = ((-1 >>> 103 | -1 << ~0x67 + 1) & -1);
        Scaffold.-2133800739 = invokedynamic(-853538196:(I)I, false);
        Scaffold.-563636279 = invokedynamic(463299179:(I)I, false);
        Scaffold.1209008906 = invokedynamic(875510228:(I)I, Integer.MIN_VALUE);
        Scaffold.1683811009 = ((0 >>> 77 | 0 << -77) & -1);
        Scaffold.-1506486798 = invokedynamic(1916123478:(I)I, false);
        Scaffold.-592887836 = (256 >>> 200 | 256 << ~0xC8 + 1);
        Scaffold.1458666383 = invokedynamic(1727930581:(I)I, false);
        Scaffold.1824928413 = (0 >>> 233 | 0 << ~0xE9 + 1);
        Scaffold.-900726651 = invokedynamic(2006039572:(I)I, false);
        Scaffold.-687756575 = invokedynamic(228362503:(I)I, false);
        Scaffold.1606390229 = (65536 >>> 144 | 65536 << -144);
        Scaffold.1006708049 = (0 >>> 158 | 0 << -158);
        Scaffold.186719392 = invokedynamic(786637689:(I)I, false);
        Scaffold.1293180608 = (2048 >>> 171 | 2048 << -171);
        Scaffold.-1647539192 = (0 >>> 196 | 0 << ~0xC4 + 1);
        Scaffold.1725425925 = (0 >>> 157 | 0 << ~0x9D + 1);
        Scaffold.-343710105 = ((-1 >>> 74 | -1 << -74) & -1);
        Scaffold.437295657 = (0 >>> 208 | 0 << ~0xD0 + 1);
        Scaffold.2108306416 = invokedynamic(-2008272296:(I)I, false);
        Scaffold.-1555282005 = (-1 >>> 239 | -1 << ~0xEF + 1);
        Scaffold.715535872 = invokedynamic(1021910525:(I)I, -1);
        Scaffold.-704842020 = (0 >>> 239 | 0 << ~0xEF + 1);
        Scaffold.-799250257 = invokedynamic(-479158015:(I)I, false);
        Scaffold.-1038432817 = ((0 >>> 27 | 0 << ~0x1B + 1) & -1);
        Scaffold.-106233262 = (-1 >>> 121 | -1 << -121);
        Scaffold.-903174583 = ((0 >>> 26 | 0 << ~0x1A + 1) & -1);
        Scaffold.-1271368224 = (0 >>> 139 | 0 << -139);
        Scaffold.791412783 = ((-1 >>> 2 | -1 << ~0x2 + 1) & -1);
        Scaffold.632134644 = ((0 >>> 247 | 0 << -247) & -1);
        Scaffold.2108214294 = ((0 >>> 91 | 0 << -91) & -1);
        Scaffold.-1990381331 = (2 >>> 129 | 2 << -129);
        Scaffold.816919105 = ((0 >>> 238 | 0 << ~0xEE + 1) & -1);
        Scaffold.-1977678738 = invokedynamic(-1813498312:(I)I, false);
        Scaffold.600036548 = ((Integer.MIN_VALUE >>> 31 | Integer.MIN_VALUE << ~0x1F + 1) & -1);
        Scaffold.1252567012 = ((0 >>> 103 | 0 << ~0x67 + 1) & -1);
        Scaffold.-2126815822 = invokedynamic(633726498:(I)I, -1);
        Scaffold.-1855439297 = (0 >>> 34 | 0 << ~0x22 + 1);
        Scaffold.153782979 = invokedynamic(591437397:(I)I, false);
        Scaffold.277088018 = ((-1 >>> 209 | -1 << ~0xD1 + 1) & -1);
        Scaffold.1926178217 = ((0 >>> 246 | 0 << -246) & -1);
        Scaffold.887722830 = ((0 >>> 172 | 0 << -172) & -1);
        Scaffold.-1138471376 = (67108864 >>> 26 | 67108864 << ~0x1A + 1);
        Scaffold.-1483521536 = invokedynamic(-920508201:(I)I, false);
        Scaffold.1161146524 = invokedynamic(-1989432171:(I)I, false);
        Scaffold.-300971711 = ((32768 >>> 47 | 32768 << -47) & -1);
        Scaffold.-1976027684 = (0 >>> 230 | 0 << -230);
        Scaffold.-1922844515 = ((0 >>> 42 | 0 << ~0x2A + 1) & -1);
        Scaffold.940085249 = ((0 >>> 6 | 0 << ~0x6 + 1) & -1);
        Scaffold.1863967554 = ((0 >>> 74 | 0 << -74) & -1);
        Scaffold.-979431968 = invokedynamic(-940066111:(I)I, Integer.MIN_VALUE);
        Scaffold.-2122022447 = ((0 >>> 86 | 0 << -86) & -1);
        Scaffold.630189588 = ((0 >>> 143 | 0 << -143) & -1);
        Scaffold.813491319 = invokedynamic(19390767:(I)I, Integer.MIN_VALUE);
        Scaffold.-65057435 = invokedynamic(1543540085:(I)I, false);
        Scaffold.774672983 = (0 >>> 183 | 0 << ~0xB7 + 1);
        Scaffold.1465255690 = invokedynamic(1096800331:(I)I, -1);
        Scaffold.-1469811211 = (0 >>> 216 | 0 << ~0xD8 + 1);
        Scaffold.1988754392 = (0 >>> 170 | 0 << ~0xAA + 1);
        Scaffold.-152754980 = invokedynamic(1790214316:(I)I, -1);
        Scaffold.-224921705 = ((0 >>> 220 | 0 << ~0xDC + 1) & -1);
        Scaffold.-1379996120 = ((0 >>> 34 | 0 << -34) & -1);
        Scaffold.1193645681 = (16 >>> 228 | 16 << -228);
        Scaffold.-1456484935 = (0 >>> 51 | 0 << -51);
        Scaffold.980656556 = invokedynamic(687538469:(I)I, -1);
        Scaffold.2115468170 = ((0 >>> 230 | 0 << ~0xE6 + 1) & -1);
        Scaffold.1445376120 = (0 >>> 23 | 0 << -23);
        Scaffold.272289033 = invokedynamic(1016995749:(I)I, -1);
        Scaffold.-714995732 = invokedynamic(1270575921:(I)I, false);
        Scaffold.-2077508205 = invokedynamic(1067834957:(I)I, -1);
        Scaffold.-1425681619 = invokedynamic(1278910051:(I)I, false);
        Scaffold.1913159316 = invokedynamic(1431686011:(I)I, false);
        Scaffold.-1058956607 = invokedynamic(-492123652:(I)I, -1);
        Scaffold.-396751331 = (0 >>> 94 | 0 << -94);
        Scaffold.-1033058811 = ((0 >>> 76 | 0 << -76) & -1);
        Scaffold.1600815497 = invokedynamic(1189417733:(I)I, false);
        Scaffold.790028706 = ((33554432 >>> 249 | 33554432 << -249) & -1);
        Scaffold.-316927055 = ((0 >>> 80 | 0 << -80) & -1);
        Scaffold.1469420636 = invokedynamic(1659596265:(I)I, false);
        Scaffold.725765803 = (65536 >>> 16 | 65536 << ~0x10 + 1);
        Scaffold.1901472883 = ((0 >>> 157 | 0 << ~0x9D + 1) & -1);
        Scaffold.-384170936 = (4096 >>> 108 | 4096 << -108);
        Scaffold.-934343442 = invokedynamic(820336051:(I)I, false);
        Scaffold.-1573140297 = invokedynamic(-660891268:(I)I, false);
        Scaffold.973944784 = (65536 >>> 240 | 65536 << -240);
        Scaffold.-248654021 = invokedynamic(347086002:(I)I, false);
        Scaffold.977880991 = invokedynamic(-2066222675:(I)I, false);
        Scaffold.1180751564 = ((0 >>> 31 | 0 << ~0x1F + 1) & -1);
        Scaffold.-1686088184 = (0 >>> 165 | 0 << ~0xA5 + 1);
        Scaffold.356736216 = invokedynamic(1961160944:(I)I, Integer.MIN_VALUE);
        Scaffold.1041582978 = invokedynamic(2142464221:(I)I, false);
        Scaffold.457371154 = invokedynamic(-1646934201:(I)I, false);
        Scaffold.1494653404 = ((4096 >>> 204 | 4096 << -204) & -1);
        Scaffold.1142986045 = ((0 >>> 73 | 0 << -73) & -1);
        Scaffold.-326419743 = (0 >>> 128 | 0 << ~0x80 + 1);
        Scaffold.-1269886358 = invokedynamic(-1160296924:(I)I, -1);
        Scaffold.1456658393 = ((0 >>> 140 | 0 << -140) & -1);
        Scaffold.-934714452 = invokedynamic(-1529643982:(I)I, false);
        Scaffold.1338487021 = (-1 >>> 232 | -1 << ~0xE8 + 1);
        Scaffold.1184102419 = ((0 >>> 226 | 0 << -226) & -1);
        Scaffold.-2107675619 = invokedynamic(749087965:(I)I, false);
        Scaffold.822667728 = (-1 >>> 10 | -1 << ~0xA + 1);
        Scaffold.890072330 = ((0 >>> 198 | 0 << ~0xC6 + 1) & -1);
        Scaffold.-1485209785 = (-1 >>> 188 | -1 << -188);
        Scaffold.-716807429 = (0 >>> 94 | 0 << -94);
        Scaffold.-1729764341 = (0 >>> 177 | 0 << -177);
        Scaffold.-1040451988 = (-1 >>> 83 | -1 << ~0x53 + 1);
        Scaffold.-537376229 = invokedynamic(608380144:(I)I, false);
        Scaffold.1357677071 = invokedynamic(1940606756:(I)I, false);
        Scaffold.520659285 = invokedynamic(995322451:(I)I, Integer.MIN_VALUE);
        Scaffold.-819419873 = invokedynamic(-1233726495:(I)I, false);
        Scaffold.1023448724 = invokedynamic(1424842415:(I)I, false);
        Scaffold.953951292 = ((4194304 >>> 54 | 4194304 << -54) & -1);
        Scaffold.-184466375 = invokedynamic(-690751960:(I)I, false);
        Scaffold.814998549 = (-1 >>> 153 | -1 << -153);
        Scaffold.-688382819 = (0 >>> 61 | 0 << ~0x3D + 1);
        Scaffold.-286581046 = ((0 >>> 103 | 0 << -103) & -1);
        Scaffold.1844491714 = invokedynamic(-1825367277:(I)I, -1);
        Scaffold.1204485815 = invokedynamic(1151899278:(I)I, false);
        Scaffold.-233032194 = (0 >>> 235 | 0 << ~0xEB + 1);
        Scaffold.-1807681114 = invokedynamic(1446811607:(I)I, Integer.MIN_VALUE);
        Scaffold.351999916 = invokedynamic(837955795:(I)I, false);
        Scaffold.2125053485 = (0 >>> 128 | 0 << ~0x80 + 1);
        Scaffold.-252435436 = ((16384 >>> 46 | 16384 << ~0x2E + 1) & -1);
        Scaffold.1295976539 = invokedynamic(-582461113:(I)I, false);
        Scaffold.-1166861977 = invokedynamic(-1368822085:(I)I, false);
        Scaffold.-1854038362 = (0 >>> 128 | 0 << ~0x80 + 1);
        Scaffold.2090619777 = invokedynamic(49764341:(I)I, false);
        Scaffold.-157230286 = invokedynamic(-90632104:(I)I, Integer.MIN_VALUE);
        Scaffold.531196010 = invokedynamic(1099885193:(I)I, false);
        Scaffold.1811608531 = ((0 >>> 48 | 0 << ~0x30 + 1) & -1);
        Scaffold.1688910858 = (1048576 >>> 212 | 1048576 << -212);
        Scaffold.-802292767 = invokedynamic(-842684871:(I)I, false);
        Scaffold.2123483993 = invokedynamic(-1598137935:(I)I, false);
        Scaffold.816488832 = ((-1 >>> 92 | -1 << -92) & -1);
        Scaffold.45801058 = invokedynamic(2108282519:(I)I, false);
        Scaffold.1915844304 = invokedynamic(574616506:(I)I, false);
        Scaffold.-287304689 = (-1 >>> 240 | -1 << -240);
        Scaffold.-1209657323 = invokedynamic(1330769979:(J)D, invokedynamic(-632690949:(J)J, 2044L));
        Scaffold.484239379 = invokedynamic(-51531002:(J)D, invokedynamic(1613849137:(J)J, 5299669597518405634L));
        Scaffold.-948211374 = invokedynamic(-1641758264:(J)D, invokedynamic(1512409174:(J)J, 2044L));
        Scaffold.1529517446 = (32768 >>> 110 | 32768 << -110);
        Scaffold.-1395634031 = ((0 >>> 174 | 0 << ~0xAE + 1) & -1);
        Scaffold.-449671539 = invokedynamic(-1596562934:(J)D, invokedynamic(-1499872834:(J)J, 91650L));
        Scaffold.-2053492680 = invokedynamic(-2066258157:(J)D, invokedynamic(1824598600:(J)J, 1780085320252166146L));
        Scaffold.-181649210 = invokedynamic(327275881:(I)F, (1451229192 >>> 133 | 1451229192 << ~0x85 + 1) & -1);
        Scaffold.997371932 = invokedynamic(258503599:(I)I, Integer.MIN_VALUE);
        Scaffold.-1309540876 = invokedynamic(-1469315783:(J)D, invokedynamic(149581702:(J)J, 91650L));
        Scaffold.54187530 = invokedynamic(-574603376:(J)D, invokedynamic(-1855378582:(J)J, 1780085320252166146L));
        Scaffold.-573356356 = invokedynamic(-2067067215:(I)I, 939524096);
        Scaffold.-1743503692 = (917504 >>> 239 | 917504 << -239);
        Scaffold.-1728576055 = new String[Scaffold.-573356356];
        Scaffold.1078569619 = new String[Scaffold.-1743503692];
    }
    // invokedynamic(1781107612:()V)
    
    private static Object -542020806(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(Scaffold.class, "1350538989", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", Scaffold.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/player/Scaffold:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String 1350538989(final int n, long n2) {
        n2 ^= 0x61L;
        n2 ^= 0x4B145971A25F9AC4L;
        if (Scaffold.-1728576055[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/player/Scaffold");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            Scaffold.-1728576055[n] = new String(instance.doFinal(Base64.getDecoder().decode(Scaffold.1078569619[n])));
        }
        return Scaffold.-1728576055[n];
    }
    
    private static void -1576921947() {
        Scaffold.-927584011 = -3316234832702817377L;
        final long n = Scaffold.-927584011 ^ 0x4B145971A25F9AC4L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    Scaffold.1078569619[0] = "roRLOsJDJ20Xvk4V0RdOzg==";
                    Scaffold.1078569619[1] = "INd7n83Aotq6W0ZdrFLpZd3BxL9edcA0";
                    Scaffold.1078569619[2] = "tcE94M0P+/c=";
                    Scaffold.1078569619[3] = "ym041be89/0=";
                    Scaffold.1078569619[4] = "JhubyFH+K7Q=";
                    Scaffold.1078569619[5] = "JhubyFH+K7Q=";
                    Scaffold.1078569619[6] = "qAk3y+uyVFk=";
                    Scaffold.1078569619[7] = "AB9ucLIQxX8=";
                    Scaffold.1078569619[8] = "26qWZAwY77Y=";
                    Scaffold.1078569619[9] = "QNMuB2bt3q0=";
                    Scaffold.1078569619[10] = "zrrmXKD8eEw=";
                    Scaffold.1078569619[11] = "SpM4DeRUJvA=";
                    Scaffold.1078569619[12] = "wRFKPykitOI=";
                    Scaffold.1078569619[13] = "oad5ASIOnEHM8TlJwtsiyw==";
                    Scaffold.1078569619[14] = "LIGGp7RomyN+7c+S4DQEbg==";
                    Scaffold.1078569619[15] = "LIGGp7RomyN+7c+S4DQEbg==";
                    Scaffold.1078569619[16] = "opPawhiLRhA=";
                    Scaffold.1078569619[17] = "+/93J1Es1zdWzYMKeVx5LQ==";
                    Scaffold.1078569619[18] = "+/93J1Es1zdFXCq8qj59JQ==";
                    Scaffold.1078569619[19] = "+/93J1Es1zcRdpUXwOaTLQ==";
                    Scaffold.1078569619[20] = "v178d1ZpWjA=";
                    Scaffold.1078569619[21] = "v178d1ZpWjA=";
                    Scaffold.1078569619[22] = "v178d1ZpWjA=";
                    Scaffold.1078569619[23] = "v178d1ZpWjA=";
                    Scaffold.1078569619[24] = "v178d1ZpWjA=";
                    Scaffold.1078569619[25] = "v178d1ZpWjA=";
                    Scaffold.1078569619[26] = "rZtojhLfWYw=";
                    Scaffold.1078569619[27] = "lR+ElZxEX1N1MXm6aMbYPQ==";
                    break;
                }
                case 1: {
                    Scaffold.1078569619[0] = "roRLOsJDJ21XBHRh86S0Kg==";
                    Scaffold.1078569619[1] = "INd7n83Aotq6W0ZdrFLpZUC+O11OE/gDc6eaNQdP7g0=";
                    Scaffold.1078569619[2] = "H3zszsZVtp0N/kTJQAfI+w==";
                    Scaffold.1078569619[3] = "HJWVTdssMjhEgtjYAcsUkg==";
                    Scaffold.1078569619[4] = "0qnSwrbz/CS1mCUIHeK4DA==";
                    Scaffold.1078569619[5] = "arLinivfHI8=";
                    Scaffold.1078569619[6] = "Z6iMIiU/Pb4vXobM0G/fIg==";
                    Scaffold.1078569619[7] = "z1YyuerlvtUPTX1GKuAr6g==";
                    Scaffold.1078569619[8] = "kZbJSgzp8g0hCKOS63n2Wg==";
                    Scaffold.1078569619[9] = "eQMn4KxKPykAsI1whaXvPw==";
                    Scaffold.1078569619[10] = "RP5KPJ8WPYDQBKpMe7DpmQ==";
                    Scaffold.1078569619[11] = "iO6XU9e4pbY68Nd76/HAVQ==";
                    Scaffold.1078569619[12] = "Gj1jXQjukPY=";
                    Scaffold.1078569619[13] = "oad5ASIOnEEYIGnTEjuzijp6NAD8ARj5";
                    Scaffold.1078569619[14] = "LIGGp7RomyOpmTYZ0m0uAQ==";
                    Scaffold.1078569619[15] = "LIGGp7RomyPExMv0u4e5kg==";
                    Scaffold.1078569619[16] = "KLPWKiNJ353n13Hwap0w+w==";
                    Scaffold.1078569619[17] = "+/93J1Es1zfXIkBQiOQ0mw==";
                    Scaffold.1078569619[18] = "+/93J1Es1zewuepoT5BK9w==";
                    Scaffold.1078569619[19] = "+/93J1Es1zdX7P1el22tIA==";
                    Scaffold.1078569619[20] = "qMowDhCCvUw=";
                    Scaffold.1078569619[21] = "heh2HRjfDY8=";
                    Scaffold.1078569619[22] = "2RLwFQGXDzo=";
                    Scaffold.1078569619[23] = "ulAYnX9qql4k3jtmfoQPmA==";
                    Scaffold.1078569619[24] = "N64VxtFczoe38052UPl+jw==";
                    Scaffold.1078569619[25] = "44KMPSCE6wolFPrxx9WNeg==";
                    Scaffold.1078569619[26] = "TD2URhgD2EaGIfVBEQZvIQ==";
                    Scaffold.1078569619[27] = "lR+ElZxEX1OTCx5X87TMFA==";
                    break;
                }
                case 2: {
                    Scaffold.1078569619[0] = "iXS6x9+fKD7z8JtQvGQgvQ==";
                    break;
                }
                case 4: {
                    Scaffold.1078569619[0] = "6J5ZZ7gxJA3QvxMJqowvtg==";
                    break;
                }
            }
        }
    }
    
    public static Object -603869125(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4) throws Exception {
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if ((int)o == 184) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
    
    private class BlockData
    {
        public BlockPos position;
        public EnumFacing face;
        
        public BlockData(final BlockPos -1087831808, final EnumFacing -2046007486) {
            this.position = -1087831808;
            this.face = -2046007486;
        }
    }
}

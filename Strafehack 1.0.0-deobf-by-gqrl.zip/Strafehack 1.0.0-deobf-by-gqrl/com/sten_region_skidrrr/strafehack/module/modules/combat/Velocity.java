// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module.modules.combat;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import com.sten_region_skidrrr.strafehack.module.Category;
import com.sten_region_skidrrr.strafehack.module.Module;

public class Velocity extends Module
{
    private static String[] -1093422248;
    private static String[] -371288621;
    private static long 895930724;
    private static int 618389252;
    private static long -145099789;
    private static long -785860234;
    private static int 1480413943;
    private static long -1840549090;
    private static int 568414781;
    private static int -338208304;
    private static int 1347048572;
    private static int -1078840545;
    private static int -1891008905;
    
    public Velocity() {
        super(invokedynamic(612917205:(IJ)Ljava/lang/String;, Velocity.618389252, Velocity.-145099789 ^ Velocity.-785860234), invokedynamic(-1352620438:(IJ)Ljava/lang/String;, Velocity.1480413943, Velocity.-1840549090), Category.Combat, Velocity.568414781);
    }
    
    @Override
    public void onEnable() {
    }
    
    static {
        Velocity.-1078840545 = 1818490332;
        Velocity.-1891008905 = 184;
        Velocity.618389252 = invokedynamic(1154268166:(I)I, false);
        Velocity.-145099789 = invokedynamic(-580415402:(J)J, 5168383274170456890L);
        Velocity.-785860234 = invokedynamic(-1142571802:(J)J, -1297036692682702848L);
        Velocity.1480413943 = ((262144 >>> 82 | 262144 << -82) & -1);
        Velocity.-1840549090 = invokedynamic(-1672631531:(J)J, -6216716583822156998L);
        Velocity.568414781 = (0 >>> 133 | 0 << ~0x85 + 1);
        Velocity.-338208304 = (64 >>> 197 | 64 << ~0xC5 + 1);
        Velocity.1347048572 = invokedynamic(1872913705:(I)I, 1073741824);
        Velocity.-1093422248 = new String[Velocity.-338208304];
        Velocity.-371288621 = new String[Velocity.1347048572];
    }
    // invokedynamic(-63358898:()V)
    
    private static Object 1353438813(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(Velocity.class, "-1264099600", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", Velocity.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/combat/Velocity:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String -1264099600(final int n, long n2) {
        n2 ^= 0x77L;
        n2 ^= 0x638C3BD6E29980FL;
        if (Velocity.-1093422248[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/combat/Velocity");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            Velocity.-1093422248[n] = new String(instance.doFinal(Base64.getDecoder().decode(Velocity.-371288621[n])));
        }
        return Velocity.-1093422248[n];
    }
    
    private static void 1554405598() {
        Velocity.895930724 = 6690097272976547298L;
        final long n = Velocity.895930724 ^ 0x638C3BD6E29980FL;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    Velocity.-371288621[0] = "wHLuxP0VEdwDdphMT0Af4w==";
                    Velocity.-371288621[1] = "4pYpjlforDe5TxP1aU9XboW/IfnEsKze";
                    break;
                }
                case 1: {
                    Velocity.-371288621[0] = "wHLuxP0VEdzj1ahGqg4ULQ==";
                    Velocity.-371288621[1] = "4pYpjlforDe5TxP1aU9XbvULxZh+myF2";
                    break;
                }
                case 2: {
                    Velocity.-371288621[0] = "vR54rUXETOEo9vMw+fz9zQ==";
                    break;
                }
                case 4: {
                    Velocity.-371288621[0] = "xHGtiDEU322HbFW4m7erdw==";
                    break;
                }
            }
        }
    }
    
    public static Object -1513464667(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7) throws Exception {
        final int n = ((int)o ^ Velocity.-1078840545) & 0xFF;
        final Integer value = Velocity.-1891008905;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

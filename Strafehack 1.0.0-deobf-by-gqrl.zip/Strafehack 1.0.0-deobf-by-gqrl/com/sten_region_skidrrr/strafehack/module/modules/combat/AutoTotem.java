// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module.modules.combat;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.item.Item;
import net.minecraft.init.Items;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import com.sten_region_skidrrr.strafehack.module.Category;
import com.sten_region_skidrrr.strafehack.module.Module;

public class AutoTotem extends Module
{
    private static String[] -528674806;
    private static String[] 209364018;
    private static long -705736112;
    private static int -397443377;
    private static long -159784984;
    private static int -626104080;
    private static int 1766320041;
    private static long 716038304;
    private static int 1552681942;
    private static int -1616260628;
    private static int -1687679638;
    private static int -2138678908;
    private static int 335239334;
    private static int 204387180;
    
    public AutoTotem() {
        super(invokedynamic(1925757493:(IJ)Ljava/lang/String;, AutoTotem.-397443377, AutoTotem.-159784984), invokedynamic(-1924976274:(IJ)Ljava/lang/String;, AutoTotem.-626104080 & AutoTotem.1766320041, AutoTotem.716038304), Category.Combat, AutoTotem.1552681942);
    }
    
    @SubscribeEvent
    public void onUpdate(final TickEvent.PlayerTickEvent 864628060) {
        if (this.mc.field_71462_r == null || this.mc.field_71462_r instanceof GuiInventory) {
            final Item 864628061 = invokedynamic(-128283497:(Ljava/lang/Object;)Lnet/minecraft/item/Item;, invokedynamic(1675840963:(Ljava/lang/Object;)Lnet/minecraft/item/ItemStack;, this.mc.field_71439_g));
            if (invokedynamic(1125944656:(Ljava/lang/Object;Ljava/lang/Object;)I, this.mc.field_71439_g.field_71069_bz, Items.field_190929_cY) > 0 && !invokedynamic(-1594956217:(Ljava/lang/Object;Ljava/lang/Object;)Z, 864628061, Items.field_190929_cY)) {
            }
            // invokedynamic(1036142340:(II)V, invokedynamic(1484504317:(Ljava/lang/Object;Ljava/lang/Object;)I, this.mc.field_71439_g.field_71069_bz, Items.field_190929_cY), AutoTotem.-1616260628)
        }
    }
    
    static {
        AutoTotem.335239334 = -592365170;
        AutoTotem.204387180 = 184;
        AutoTotem.-397443377 = invokedynamic(897531307:(I)I, false);
        AutoTotem.-159784984 = invokedynamic(1367102732:(J)J, -586825867131707494L);
        AutoTotem.-626104080 = invokedynamic(-1631344990:(I)I, Integer.MIN_VALUE);
        AutoTotem.1766320041 = (-1 >>> 22 | -1 << -22);
        AutoTotem.716038304 = invokedynamic(1147481803:(J)J, -586825867131707494L);
        AutoTotem.1552681942 = invokedynamic(-1482479601:(I)I, false);
        AutoTotem.-1616260628 = ((2949120 >>> 208 | 2949120 << -208) & -1);
        AutoTotem.-1687679638 = invokedynamic(520300197:(I)I, 1073741824);
        AutoTotem.-2138678908 = ((131072 >>> 112 | 131072 << ~0x70 + 1) & -1);
        AutoTotem.-528674806 = new String[AutoTotem.-1687679638];
        AutoTotem.209364018 = new String[AutoTotem.-2138678908];
    }
    // invokedynamic(2081229405:()V)
    
    private static Object -636610924(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(AutoTotem.class, "-652261026", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", AutoTotem.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/combat/AutoTotem:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String -652261026(final int n, long n2) {
        n2 ^= 0x48L;
        n2 ^= 0x6D3B209CC7DEB1C1L;
        if (AutoTotem.-528674806[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/combat/AutoTotem");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            AutoTotem.-528674806[n] = new String(instance.doFinal(Base64.getDecoder().decode(AutoTotem.209364018[n])));
        }
        return AutoTotem.-528674806[n];
    }
    
    private static void -1724954553() {
        AutoTotem.-705736112 = 6483311157769984935L;
        final long n = AutoTotem.-705736112 ^ 0x6D3B209CC7DEB1C1L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    AutoTotem.209364018[0] = "vmxwbf+YPBXSvB8qSaCnqg==";
                    AutoTotem.209364018[1] = "x4XFktGQFQ7vz5fNtQc615Wyz0I9nHIr1aZo/prfwEKG+i4Th+CutXau53SJS7XLsEud9erPCSH/rgYa6oSW2pY/P5RT+XJE4wT9oNatsII=";
                    break;
                }
                case 1: {
                    AutoTotem.209364018[0] = "vmxwbf+YPBUAA3OT8b0+MQ==";
                    AutoTotem.209364018[1] = "x4XFktGQFQ7vz5fNtQc615Wyz0I9nHIr1aZo/prfwEKG+i4Th+CutXau53SJS7XLsEud9erPCSH/rgYa6oSW2pY/P5RT+XJE2pjsp0UlU+k=";
                    break;
                }
                case 2: {
                    AutoTotem.209364018[0] = "C0A9jGLu2OikIHisD1lZig==";
                    break;
                }
                case 4: {
                    AutoTotem.209364018[0] = "jKK4EW3Rqko=";
                    break;
                }
            }
        }
    }
    
    public static Object 1536631269(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7, final Object o8, final Object o9) throws Exception {
        final int n = ((int)o ^ AutoTotem.335239334) & 0xFF;
        final Integer value = AutoTotem.204387180;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

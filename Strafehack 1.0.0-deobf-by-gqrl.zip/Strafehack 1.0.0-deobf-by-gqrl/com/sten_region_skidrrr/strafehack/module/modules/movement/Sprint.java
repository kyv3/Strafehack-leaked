// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module.modules.movement;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.living.LivingEvent;
import com.sten_region_skidrrr.strafehack.module.Category;
import com.sten_region_skidrrr.strafehack.module.Module;

public class Sprint extends Module
{
    private static String[] 1520887250;
    private static String[] -878581526;
    private static long 47353271;
    private static int -1209747376;
    private static int -86878206;
    private static long -1485082781;
    private static int 215012433;
    private static long -642672207;
    private static int -173577599;
    private static int 1060197318;
    private static int -70906971;
    private static int -1541754294;
    private static int -1440411515;
    private static int -1797076484;
    
    public Sprint() {
        super(invokedynamic(-1667922877:(IJ)Ljava/lang/String;, Sprint.-1209747376 & Sprint.-86878206, Sprint.-1485082781), invokedynamic(1617426944:(IJ)Ljava/lang/String;, Sprint.215012433, Sprint.-642672207), Category.Movement, Sprint.-173577599);
    }
    // invokedynamic(1197799875:(Ljava/lang/Object;Z)V, this, Sprint.1060197318)
    
    @SubscribeEvent
    public void onUpdate(final LivingEvent.LivingUpdateEvent 202209464) {
        if (invokedynamic(1255141918:(Ljava/lang/Object;)Lnet/minecraft/entity/EntityLivingBase;, 202209464) instanceof EntityPlayer) {}
    }
    
    static {
        Sprint.-1440411515 = 1515739313;
        Sprint.-1797076484 = 184;
        Sprint.-1209747376 = ((0 >>> 216 | 0 << ~0xD8 + 1) & -1);
        Sprint.-86878206 = ((-1 >>> 100 | -1 << -100) & -1);
        Sprint.-1485082781 = invokedynamic(-358159480:(J)J, 7715994471724683473L);
        Sprint.215012433 = invokedynamic(-1722247694:(I)I, Integer.MIN_VALUE);
        Sprint.-642672207 = invokedynamic(-253678085:(J)J, 7715994471724683473L);
        Sprint.-173577599 = ((0 >>> 186 | 0 << ~0xBA + 1) & -1);
        Sprint.1060197318 = (536870912 >>> 253 | 536870912 << ~0xFD + 1);
        Sprint.-70906971 = (8192 >>> 44 | 8192 << -44);
        Sprint.-1541754294 = invokedynamic(981149550:(I)I, 1073741824);
        Sprint.1520887250 = new String[Sprint.-70906971];
        Sprint.-878581526 = new String[Sprint.-1541754294];
    }
    // invokedynamic(-1876085995:()V)
    
    private static Object -875829106(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(Sprint.class, "1510536828", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", Sprint.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/movement/Sprint:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String 1510536828(final int n, long n2) {
        n2 ^= 0x31L;
        n2 ^= 0xF401C32E6749050EL;
        if (Sprint.1520887250[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/movement/Sprint");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            Sprint.1520887250[n] = new String(instance.doFinal(Base64.getDecoder().decode(Sprint.-878581526[n])));
        }
        return Sprint.1520887250[n];
    }
    
    private static void 1118899503() {
        Sprint.47353271 = -8428240330815624985L;
        final long n = Sprint.47353271 ^ 0xF401C32E6749050EL;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    Sprint.-878581526[0] = "gMQyjL1v9zeUNP/qaAbAJg==";
                    Sprint.-878581526[1] = "HBTxGh2Y8s+/CklqsemzHicA/MXlZem5jCIFRWhaP6vm6qE57eNJbw==";
                    break;
                }
                case 1: {
                    Sprint.-878581526[0] = "gMQyjL1v9zcXOdrRjnb+PA==";
                    Sprint.-878581526[1] = "HBTxGh2Y8s+/CklqsemzHicA/MXlZem5jCIFRWhaP6tOSVm5NDwHxw==";
                    break;
                }
                case 2: {
                    Sprint.-878581526[0] = "Y4zkvUOiSIZOUCuE0FA1AA==";
                    break;
                }
                case 4: {
                    Sprint.-878581526[0] = "2aEL1d1RBuqa4CDngzvbcdCrQMwWNbac";
                    break;
                }
            }
        }
    }
    
    public static Object -1054530681(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5) throws Exception {
        final int n = ((int)o ^ Sprint.-1440411515) & 0xFF;
        final Integer value = Sprint.-1797076484;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

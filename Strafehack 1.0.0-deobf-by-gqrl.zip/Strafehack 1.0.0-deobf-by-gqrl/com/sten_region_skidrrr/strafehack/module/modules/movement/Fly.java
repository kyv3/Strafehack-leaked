// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module.modules.movement;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.living.LivingEvent;
import com.sten_region_skidrrr.strafehack.module.settings.Setting;
import com.sten_region_skidrrr.strafehack.module.Category;
import com.sten_region_skidrrr.strafehack.module.settings.NumberSetting;
import com.sten_region_skidrrr.strafehack.module.Module;

public class Fly extends Module
{
    private boolean isFlying;
    private boolean allowFlying;
    public NumberSetting flySpeed;
    private static String[] 1774702554;
    private static String[] -1616577395;
    private static long 1835963299;
    private static int -1225131265;
    private static int -1496966595;
    private static long 26250218;
    private static int -1945887389;
    private static int 1263389099;
    private static long 849117700;
    private static int -1913251993;
    private static int 1313875107;
    private static long -455390033;
    private static long 690561621;
    private static double 1935657716;
    private static double 2008995662;
    private static int -1581062921;
    private static int -330466217;
    private static int 633665298;
    private static float 1781266237;
    private static int -1833479214;
    private static int 1589848125;
    private static int -597323887;
    private static int -65068877;
    private static int 1859354595;
    
    public Fly() {
        super(invokedynamic(418128794:(IJ)Ljava/lang/String;, Fly.-1225131265 & Fly.-1496966595, Fly.26250218), invokedynamic(-260301166:(IJ)Ljava/lang/String;, Fly.-1945887389 & Fly.1263389099, Fly.849117700), Category.Movement, Fly.-1913251993);
        this.flySpeed = new NumberSetting(invokedynamic(-2101506231:(IJ)Ljava/lang/String;, Fly.1313875107, Fly.-455390033 ^ Fly.690561621), Fly.1935657716, 1.0, Fly.2008995662);
        final Setting[] array = new Setting[Fly.-1581062921];
        array[Fly.-330466217] = this.flySpeed;
    }
    // invokedynamic(114981645:(Ljava/lang/Object;[Lcom/sten_region_skidrrr/strafehack/module/settings/Setting;)V, this, array)
    
    @SubscribeEvent
    public void onUpdate(final LivingEvent.LivingUpdateEvent -743197211) {
        if (invokedynamic(-1801645457:(Ljava/lang/Object;)Lnet/minecraft/entity/EntityLivingBase;, -743197211) instanceof EntityPlayer) {
            this.mc.field_71439_g.field_71075_bZ.field_75100_b = (Fly.633665298 != 0);
        }
        // invokedynamic(-1991881014:(Ljava/lang/Object;F)V, this.mc.field_71439_g.field_71075_bZ, (float)invokedynamic(334947933:(Ljava/lang/Object;)D, this.flySpeed) / Fly.1781266237)
    }
    
    @Override
    public void onEnable() {
        super.onEnable();
        this.isFlying = this.mc.field_71439_g.field_71075_bZ.field_75100_b;
        this.allowFlying = this.mc.field_71439_g.field_71075_bZ.field_75101_c;
        this.mc.field_71439_g.field_71075_bZ.field_75101_c = (Fly.-1833479214 != 0);
    }
    
    @Override
    public void onDisable() {
        super.onDisable();
        this.mc.field_71439_g.field_71075_bZ.field_75101_c = this.allowFlying;
        this.mc.field_71439_g.field_71075_bZ.field_75100_b = this.isFlying;
    }
    
    static {
        Fly.-65068877 = -737943889;
        Fly.1859354595 = 184;
        Fly.-1225131265 = invokedynamic(845784854:(I)I, false);
        Fly.-1496966595 = (-1 >>> 47 | -1 << ~0x2F + 1);
        Fly.26250218 = invokedynamic(-423061149:(J)J, -5732764240192877181L);
        Fly.-1945887389 = invokedynamic(-1164133062:(I)I, Integer.MIN_VALUE);
        Fly.1263389099 = (-1 >>> 38 | -1 << ~0x26 + 1);
        Fly.849117700 = invokedynamic(-2048278888:(J)J, -5732764240192877181L);
        Fly.-1913251993 = ((0 >>> 19 | 0 << -19) & -1);
        Fly.1313875107 = invokedynamic(-546058674:(I)I, 1073741824);
        Fly.-455390033 = invokedynamic(-1823587286:(J)J, 896534411296492931L);
        Fly.690561621 = invokedynamic(2031803907:(J)J, -4899916394579099648L);
        Fly.1935657716 = invokedynamic(1786350048:(J)D, invokedynamic(722390915:(J)J, 10242L));
        Fly.2008995662 = invokedynamic(988554382:(J)D, invokedynamic(-340408777:(J)J, 11266L));
        Fly.-1581062921 = ((4194304 >>> 150 | 4194304 << -150) & -1);
        Fly.-330466217 = invokedynamic(1715583982:(I)I, false);
        Fly.633665298 = invokedynamic(1964756756:(I)I, Integer.MIN_VALUE);
        Fly.1781266237 = invokedynamic(233178026:(I)F, (1073742354 >>> 43 | 1073742354 << ~0x2B + 1) & -1);
        Fly.-1833479214 = (64 >>> 166 | 64 << -166);
        Fly.1589848125 = (1572864 >>> 147 | 1572864 << -147);
        Fly.-597323887 = ((24576 >>> 237 | 24576 << ~0xED + 1) & -1);
        Fly.1774702554 = new String[Fly.1589848125];
        Fly.-1616577395 = new String[Fly.-597323887];
    }
    // invokedynamic(460903897:()V)
    
    private static Object -520973323(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(Fly.class, "1395391138", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", Fly.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/movement/Fly:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String 1395391138(final int n, long n2) {
        n2 ^= 0x3DL;
        n2 ^= 0x1177C709D3C5B4B9L;
        if (Fly.1774702554[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/movement/Fly");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            Fly.1774702554[n] = new String(instance.doFinal(Base64.getDecoder().decode(Fly.-1616577395[n])));
        }
        return Fly.1774702554[n];
    }
    
    private static void 1057954757() {
        Fly.1835963299 = -4489037350927299024L;
        final long n = Fly.1835963299 ^ 0x1177C709D3C5B4B9L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    Fly.-1616577395[0] = "xXbhLMueZyo=";
                    Fly.-1616577395[1] = "1ieCAfrN7tDRI3HhEWOQe3JgNuvFi3HB";
                    Fly.-1616577395[2] = "WbseCRqxzyf1TL39mtamDQ==";
                    break;
                }
                case 1: {
                    Fly.-1616577395[0] = "DfIqenliS88=";
                    Fly.-1616577395[1] = "1ieCAfrN7tDRI3HhEWOQe2JEsVV934rd";
                    Fly.-1616577395[2] = "WbseCRqxzyfk7KrZzZvu9w==";
                    break;
                }
                case 2: {
                    Fly.-1616577395[0] = "Se1nuMlnlRx2EFPezpWB+A==";
                    break;
                }
                case 4: {
                    Fly.-1616577395[0] = "IIsxZ9F8sgCuHE0zGbwjXg==";
                    break;
                }
            }
        }
    }
    
    public static Object 894008050(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6) throws Exception {
        final int n = ((int)o ^ Fly.-65068877) & 0xFF;
        final Integer value = Fly.1859354595;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

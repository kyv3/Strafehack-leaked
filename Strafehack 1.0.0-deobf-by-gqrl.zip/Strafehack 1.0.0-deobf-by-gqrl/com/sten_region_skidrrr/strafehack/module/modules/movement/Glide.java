// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module.modules.movement;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.block.material.Material;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.living.LivingEvent;
import com.sten_region_skidrrr.strafehack.module.Category;
import com.sten_region_skidrrr.strafehack.module.Module;

public class Glide extends Module
{
    private static String[] -1102249285;
    private static String[] 1391822946;
    private static long 1580245298;
    private static int 537853445;
    private static long -1387514885;
    private static int 1493791935;
    private static long 223175999;
    private static long 847346622;
    private static int 718041287;
    private static double -1070440223;
    private static float 1725963929;
    private static int -1082193013;
    private static int 1151683335;
    private static int -2016977127;
    private static int -1527298217;
    
    public Glide() {
        super(invokedynamic(1437004338:(IJ)Ljava/lang/String;, Glide.537853445, Glide.-1387514885), invokedynamic(-1862964409:(IJ)Ljava/lang/String;, Glide.1493791935, Glide.223175999 ^ Glide.847346622), Category.Movement, Glide.718041287);
    }
    
    @SubscribeEvent
    public void onUpdate(final LivingEvent.LivingUpdateEvent 835252105) {
        if (invokedynamic(-1021897339:(Ljava/lang/Object;)Lnet/minecraft/entity/EntityLivingBase;, 835252105) instanceof EntityPlayer && invokedynamic(-233402001:(Ljava/lang/Object;)Lnet/minecraftforge/fml/common/eventhandler/EventPriority;, 835252105) == EventPriority.LOWEST) {
            final double 835252106 = this.mc.field_71439_g.field_70181_x;
            final float field_70747_aH = this.mc.field_71439_g.field_70747_aH;
            if (invokedynamic(1036100265:(Ljava/lang/Object;)Z, this)) {
                if (this.mc.field_71439_g.field_70181_x < 0.0 && this.mc.field_71439_g.field_70160_al && !invokedynamic(-766528380:(Ljava/lang/Object;)Z, this.mc.field_71439_g) && !invokedynamic(375611611:(Ljava/lang/Object;)Z, this.mc.field_71439_g) && !invokedynamic(-1392499178:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.mc.field_71439_g, Material.field_151587_i)) {
                    this.mc.field_71439_g.field_70181_x = Glide.-1070440223;
                    final EntityPlayerSP field_71439_g = this.mc.field_71439_g;
                    field_71439_g.field_70747_aH *= Glide.1725963929;
                }
            }
            else {
                this.mc.field_71439_g.field_70181_x = 835252106;
                this.mc.field_71439_g.field_70747_aH = field_70747_aH;
            }
        }
    }
    
    static {
        Glide.-2016977127 = 181578054;
        Glide.-1527298217 = 184;
        Glide.537853445 = invokedynamic(-1914864077:(I)I, false);
        Glide.-1387514885 = invokedynamic(1338269702:(J)J, 4152474219662987146L);
        Glide.1493791935 = (2048 >>> 11 | 2048 << -11);
        Glide.223175999 = invokedynamic(-499599013:(J)J, 837824893918302090L);
        Glide.847346622 = invokedynamic(380800191:(J)J, 3602879701896396800L);
        Glide.718041287 = (0 >>> 21 | 0 << -21);
        Glide.-1070440223 = invokedynamic(2041266730:(J)D, invokedynamic(1538092266:(J)J, 1021L));
        Glide.1725963929 = invokedynamic(-325121870:(I)F, invokedynamic(-2088388761:(I)I, -380374532));
        Glide.-1082193013 = (1048576 >>> 179 | 1048576 << ~0xB3 + 1);
        Glide.1151683335 = (16384 >>> 109 | 16384 << -109);
        Glide.-1102249285 = new String[Glide.-1082193013];
        Glide.1391822946 = new String[Glide.1151683335];
    }
    // invokedynamic(1676347446:()V)
    
    private static Object -644009512(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(Glide.class, "-245686614", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", Glide.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/movement/Glide:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String -245686614(final int n, long n2) {
        n2 ^= 0x4CL;
        n2 ^= 0x562598FF3639672FL;
        if (Glide.-1102249285[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/movement/Glide");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            Glide.-1102249285[n] = new String(instance.doFinal(Base64.getDecoder().decode(Glide.1391822946[n])));
        }
        return Glide.-1102249285[n];
    }
    
    private static void -647611076() {
        Glide.1580245298 = 5905168585720923600L;
        final long n = Glide.1580245298 ^ 0x562598FF3639672FL;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    Glide.1391822946[0] = "JE5KSI5IlnM=";
                    Glide.1391822946[1] = "oJrnFDAPqe7Tiquo6Xrmnq6CbBZsT94whRFpCxcWrrCNszUytpjoyi2eFjpgdPk1";
                    break;
                }
                case 1: {
                    Glide.1391822946[0] = "4Mqfc7YF37oS9YYeUbRcgg==";
                    Glide.1391822946[1] = "oJrnFDAPqe7Tiquo6Xrmnq6CbBZsT94whRFpCxcWrrCNszUytpjoyhvGFTMVnQlChCzOiSIRXMQ=";
                    break;
                }
                case 2: {
                    Glide.1391822946[0] = "fMFGx6wjGfhSiWfTM5kY7TxK+2UUs6pq";
                    break;
                }
                case 4: {
                    Glide.1391822946[0] = "u9XZZOZtjdXVDZXUdwheXA==";
                    break;
                }
            }
        }
    }
    
    public static Object -575029394(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7, final Object o8) throws Exception {
        final int n = ((int)o ^ Glide.-2016977127) & 0xFF;
        final Integer value = Glide.-1527298217;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

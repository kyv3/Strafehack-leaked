// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module.settings;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import java.util.List;

public class ModeSetting extends Setting
{
    public List<String> modes;
    private static String[] -581137923;
    private static String[] -654525127;
    private static long 1797536836;
    private static int -800593596;
    private static long -30969029;
    private static int -450643256;
    private static long 2102656780;
    private static long -1809155769;
    private static int -2030898647;
    private static int 1309970422;
    private static int -479319410;
    private static int 1491590480;
    private static long 791012864;
    private static long 362437378;
    private static int -1427144072;
    private static int -1681604223;
    private static int -990285615;
    private static int -18676016;
    
    public ModeSetting(final String 761961419, final String 553619758, final String... -1854986420) {
        this.name = 761961419;
        this.modes = invokedynamic(393108876:([Ljava/lang/Object;)Ljava/util/List;, -1854986420);
        this.value = invokedynamic(244672445:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(1625951629:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-1337377301:(Ljava/lang/Object;I)Ljava/lang/StringBuilder;, new StringBuilder(), invokedynamic(1084481922:(Ljava/lang/Object;Ljava/lang/Object;)I, this.modes, 553619758)), invokedynamic(-1000562015:(IJ)Ljava/lang/String;, ModeSetting.-800593596, ModeSetting.-30969029)));
    }
    
    public String getMode() {
        return (String)invokedynamic(1651725037:(Ljava/lang/Object;I)Ljava/lang/Object;, this.modes, invokedynamic(54929434:(Ljava/lang/Object;)I, this.value));
    }
    
    public boolean is(final String 807663104) {
        return ((this.value == invokedynamic(413626355:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-1177441109:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-1627416241:(Ljava/lang/Object;I)Ljava/lang/StringBuilder;, new StringBuilder(), invokedynamic(-690613389:(Ljava/lang/Object;Ljava/lang/Object;)I, this.modes, 807663104)), invokedynamic(-1827099528:(IJ)Ljava/lang/String;, ModeSetting.-450643256, ModeSetting.2102656780 ^ ModeSetting.-1809155769)))) ? ModeSetting.-2030898647 : ModeSetting.1309970422) != 0;
    }
    
    public void cycle(final int 792337989) {
        if (invokedynamic(1882620425:(Ljava/lang/Object;)I, this.value) + 792337989 < invokedynamic(-1279766604:(Ljava/lang/Object;)I, this.modes) && invokedynamic(273928312:(Ljava/lang/Object;)I, this.value) + 792337989 > ModeSetting.-479319410) {
            this.value = invokedynamic(-581027974:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(629908853:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(1108156532:(Ljava/lang/Object;I)Ljava/lang/StringBuilder;, new StringBuilder(), invokedynamic(-823550291:(Ljava/lang/Object;)I, this.value) + 792337989), invokedynamic(736017208:(IJ)Ljava/lang/String;, ModeSetting.1491590480, ModeSetting.791012864 ^ ModeSetting.362437378)));
        }
    }
    
    static {
        ModeSetting.-990285615 = -457148012;
        ModeSetting.-18676016 = 184;
        ModeSetting.-800593596 = invokedynamic(-834294646:(I)I, false);
        ModeSetting.-30969029 = invokedynamic(1162264570:(J)J, 1527071317163290028L);
        ModeSetting.-450643256 = invokedynamic(1883662944:(I)I, Integer.MIN_VALUE);
        ModeSetting.2102656780 = invokedynamic(934321211:(J)J, -3228729889339953748L);
        ModeSetting.-1809155769 = invokedynamic(381955963:(J)J, -4179340454199820288L);
        ModeSetting.-2030898647 = invokedynamic(-1972624610:(I)I, Integer.MIN_VALUE);
        ModeSetting.1309970422 = invokedynamic(-11539683:(I)I, false);
        ModeSetting.-479319410 = ((-1 >>> 220 | -1 << ~0xDC + 1) & -1);
        ModeSetting.1491590480 = ((128 >>> 166 | 128 << ~0xA6 + 1) & -1);
        ModeSetting.791012864 = invokedynamic(1883644182:(J)J, -3228729889339953748L);
        ModeSetting.362437378 = invokedynamic(3514365:(J)J, -4179340454199820288L);
        ModeSetting.-1427144072 = invokedynamic(2102073913:(I)I, -1073741824);
        ModeSetting.-1681604223 = ((1536 >>> 137 | 1536 << -137) & -1);
        ModeSetting.-581137923 = new String[ModeSetting.-1427144072];
        ModeSetting.-654525127 = new String[ModeSetting.-1681604223];
    }
    // invokedynamic(1112033119:()V)
    
    private static Object -452490256(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(ModeSetting.class, "-244640176", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", ModeSetting.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/settings/ModeSetting:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String -244640176(final int n, long n2) {
        n2 ^= 0x63L;
        n2 ^= 0x9676BA994CC64CF6L;
        if (ModeSetting.-581137923[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/settings/ModeSetting");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            ModeSetting.-581137923[n] = new String(instance.doFinal(Base64.getDecoder().decode(ModeSetting.-654525127[n])));
        }
        return ModeSetting.-581137923[n];
    }
    
    private static void 1181243023() {
        ModeSetting.1797536836 = 3870048338552065227L;
        final long n = ModeSetting.1797536836 ^ 0x9676BA994CC64CF6L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    ModeSetting.-654525127[0] = "wJDufsYrT74=";
                    ModeSetting.-654525127[1] = "wJDufsYrT74=";
                    ModeSetting.-654525127[2] = "wJDufsYrT74=";
                    break;
                }
                case 1: {
                    ModeSetting.-654525127[0] = "iayijRwaUt4=";
                    ModeSetting.-654525127[1] = "gq6hctztqoQ=";
                    ModeSetting.-654525127[2] = "PY/TilkOXEE=";
                    break;
                }
                case 2: {
                    ModeSetting.-654525127[0] = "+iRqSAHKUBSeLNsfnPveYA==";
                    break;
                }
                case 4: {
                    ModeSetting.-654525127[0] = "8u/9lDnTVS81UuxO2b4zJA==";
                    break;
                }
            }
        }
    }
    
    public static Object -1116386112(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7, final Object o8, final Object o9) throws Exception {
        final int n = ((int)o ^ ModeSetting.-990285615) & 0xFF;
        final Integer value = ModeSetting.-18676016;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

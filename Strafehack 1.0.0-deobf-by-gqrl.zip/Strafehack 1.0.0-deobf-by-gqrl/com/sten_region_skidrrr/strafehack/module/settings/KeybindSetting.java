// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module.settings;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;

public class KeybindSetting extends Setting
{
    public int code;
    private static String[] 43874578;
    private static String[] 1850150046;
    private static long 622308935;
    private static int 2114501243;
    private static long 887761212;
    private static int -935046561;
    private static int -585140801;
    private static int 1688938413;
    private static int -842169098;
    
    public KeybindSetting(final int -2244507) {
        this.name = invokedynamic(2024775573:(IJ)Ljava/lang/String;, KeybindSetting.2114501243, KeybindSetting.887761212);
        this.code = -2244507;
    }
    
    static {
        KeybindSetting.1688938413 = 1672859620;
        KeybindSetting.-842169098 = 184;
        KeybindSetting.2114501243 = ((0 >>> 31 | 0 << -31) & -1);
        KeybindSetting.887761212 = invokedynamic(-125687082:(J)J, -2687560489405325942L);
        KeybindSetting.-935046561 = (1024 >>> 42 | 1024 << ~0x2A + 1);
        KeybindSetting.-585140801 = ((536870912 >>> 157 | 536870912 << -157) & -1);
        KeybindSetting.43874578 = new String[KeybindSetting.-935046561];
        KeybindSetting.1850150046 = new String[KeybindSetting.-585140801];
    }
    // invokedynamic(1610219222:()V)
    
    private static Object -1425052191(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(KeybindSetting.class, "877997162", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", KeybindSetting.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/settings/KeybindSetting:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String 877997162(final int n, long n2) {
        n2 ^= 0x42L;
        n2 ^= 0x137051B57898DF91L;
        if (KeybindSetting.43874578[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/settings/KeybindSetting");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            KeybindSetting.43874578[n] = new String(instance.doFinal(Base64.getDecoder().decode(KeybindSetting.1850150046[n])));
        }
        return KeybindSetting.43874578[n];
    }
    
    private static void 488055937() {
        KeybindSetting.622308935 = 5889434144512658713L;
        final long n = KeybindSetting.622308935 ^ 0x137051B57898DF91L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    KeybindSetting.1850150046[0] = "RSTsLb2lDLY=";
                    break;
                }
                case 1: {
                    KeybindSetting.1850150046[0] = "6I1LcGWmoyFpIxgS/1+4oQ==";
                    break;
                }
                case 2: {
                    KeybindSetting.1850150046[0] = "Jqe7BA3JpT4XfCzZ8j0UFPhDxbH8j5jK";
                    break;
                }
                case 4: {
                    KeybindSetting.1850150046[0] = "QwYvfuJHBUvSsXrCmEGUadvcu5HXCLAC";
                    break;
                }
            }
        }
    }
    
    public static Object -1465573830(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4) throws Exception {
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if ((int)o == 184) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

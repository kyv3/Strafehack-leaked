// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module;

import java.lang.invoke.MutableCallSite;
import javax.xml.bind.DatatypeConverter;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import java.util.List;
import java.util.Iterator;
import com.sten_region_skidrrr.strafehack.module.modules.player.Scaffold;
import com.sten_region_skidrrr.strafehack.module.modules.player.AntiHunger;
import com.sten_region_skidrrr.strafehack.module.modules.combat.AutoTotem;
import com.sten_region_skidrrr.strafehack.module.modules.movement.Glide;
import com.sten_region_skidrrr.strafehack.module.modules.movement.Step;
import com.sten_region_skidrrr.strafehack.module.modules.player.FastPlace;
import com.sten_region_skidrrr.strafehack.module.modules.render.FpsDisplay;
import com.sten_region_skidrrr.strafehack.module.modules.render.Fullbright;
import com.sten_region_skidrrr.strafehack.module.modules.render.KeyboardDisplay;
import com.sten_region_skidrrr.strafehack.module.modules.combat.Velocity;
import com.sten_region_skidrrr.strafehack.module.modules.combat.KillAura;
import com.sten_region_skidrrr.strafehack.module.modules.player.NoFall;
import com.sten_region_skidrrr.strafehack.module.modules.movement.Fly;
import com.sten_region_skidrrr.strafehack.module.modules.movement.Sprint;
import com.sten_region_skidrrr.strafehack.module.modules.render.Gui;
import com.sten_region_skidrrr.strafehack.module.modules.render.TabGui;
import java.util.ArrayList;

public class ModuleManager
{
    private static ArrayList<Module> modules;
    private static int -2005658242;
    private static int 1047600771;
    
    public static void saveModuleSettings() {
        final Iterator iterator = invokedynamic(1348802351:(Ljava/lang/Object;)Ljava/util/Iterator;, ModuleManager.modules);
        while (invokedynamic(824408842:(Ljava/lang/Object;)Z, iterator)) {
            final Module 1720639593 = (Module)invokedynamic(1238025230:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
        }
        // invokedynamic(860109848:(Ljava/lang/Object;)V, 1720639593)
    }
    
    public static List<Module> getModulesByCategory(final Category 1562326922) {
        final List<Module> list = new ArrayList<Module>();
        final Iterator iterator = invokedynamic(2051215627:(Ljava/lang/Object;)Ljava/util/Iterator;, ModuleManager.modules);
        while (invokedynamic(-533042360:(Ljava/lang/Object;)Z, iterator)) {
            final Module module = (Module)invokedynamic(-1164973643:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
            if (invokedynamic(622242190:(Ljava/lang/Object;)Lcom/sten_region_skidrrr/strafehack/module/Category;, module) == 1562326922) {
            }
            // invokedynamic(-691754622:(Ljava/lang/Object;Ljava/lang/Object;)Z, list, module)
        }
        return list;
    }
    
    public static ArrayList<Module> getModules() {
        return ModuleManager.modules;
    }
    
    public static Module getModule(final String 2093658282) {
        return (Module)invokedynamic(1096210619:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;, invokedynamic(-718788430:(Ljava/lang/Object;)Ljava/util/Optional;, invokedynamic(460334632:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/stream/Stream;, invokedynamic(-8725438:(Ljava/lang/Object;)Ljava/util/stream/Stream;, ModuleManager.modules), -763233372 -> invokedynamic(226526955:(Ljava/lang/Object;Ljava/lang/Object;)Z, invokedynamic(-755507017:(Ljava/lang/Object;)Ljava/lang/String;, -763233372), 2093658282))), null);
    }
    
    public static ArrayList<Module> getEnabledModules() {
        final ArrayList<Module> list = new ArrayList<Module>();
        final Iterator iterator = invokedynamic(-770906878:(Ljava/lang/Object;)Ljava/util/Iterator;, ModuleManager.modules);
        while (invokedynamic(736946285:(Ljava/lang/Object;)Z, iterator)) {
            final Module 1132186903 = (Module)invokedynamic(-1042308991:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
            if (invokedynamic(-1111951903:(Ljava/lang/Object;)Z, 1132186903)) {
            }
            // invokedynamic(-1073292446:(Ljava/lang/Object;Ljava/lang/Object;)Z, list, 1132186903)
        }
        return list;
    }
    
    static {
        ModuleManager.-2005658242 = 1481831958;
        ModuleManager.1047600771 = 184;
        ModuleManager.modules = new ArrayList<Module>();
    }
    
    public static Object -1546126333(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7, final Object o8) throws Exception {
        final int n = ((int)o ^ ModuleManager.-2005658242) & 0xFF;
        final Integer value = ModuleManager.1047600771;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

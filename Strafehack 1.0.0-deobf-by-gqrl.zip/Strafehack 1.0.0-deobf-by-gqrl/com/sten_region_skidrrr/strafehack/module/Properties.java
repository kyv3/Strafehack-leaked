// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module;

import java.lang.invoke.MutableCallSite;
import javax.xml.bind.DatatypeConverter;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import com.sten_region_skidrrr.strafehack.ui.hud.ScreenPosition;
import java.util.ArrayList;

public class Properties
{
    public ArrayList<String> settings;
    public ScreenPosition pos;
    public boolean enabled;
    public int keycode;
    private static double -917977062;
    private static double -1549858724;
    private static int -171789970;
    private static int -1474689249;
    private static int 1691650975;
    private static int 338641799;
    
    public Properties() {
        this.settings = new ArrayList<String>();
        this.pos = new ScreenPosition(Properties.-917977062, Properties.-1549858724);
        this.enabled = (Properties.-171789970 != 0);
        this.keycode = Properties.-1474689249;
    }
    
    static {
        Properties.1691650975 = 1201190935;
        Properties.338641799 = 184;
        Properties.-917977062 = invokedynamic(-1357827647:(J)D, invokedynamic(1109446968:(J)J, 2044L));
        Properties.-1549858724 = invokedynamic(1201954100:(J)D, invokedynamic(-1878192316:(J)J, 2044L));
        Properties.-171789970 = invokedynamic(-526403619:(I)I, false);
        Properties.-1474689249 = (0 >>> 170 | 0 << ~0xAA + 1);
    }
    
    public static Object -1744956282(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4) throws Exception {
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if ((int)o == 184) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

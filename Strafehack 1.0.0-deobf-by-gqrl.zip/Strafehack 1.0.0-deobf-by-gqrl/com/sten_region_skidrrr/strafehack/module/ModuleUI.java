// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module;

import java.lang.invoke.MutableCallSite;
import javax.xml.bind.DatatypeConverter;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import com.sten_region_skidrrr.strafehack.ui.hud.ScreenPosition;
import com.sten_region_skidrrr.strafehack.ui.hud.HUDManager;
import com.sten_region_skidrrr.strafehack.StrafeHack;
import com.sten_region_skidrrr.strafehack.ui.hud.IRenderer;

public abstract class ModuleUI extends Module implements IRenderer
{
    private static int 1698921611;
    private static int -444639839;
    private static int -1260924284;
    private static int 1319398214;
    private static int -963162676;
    
    public ModuleUI(final String 1460363747, final String 1259762780, final int -1921796668) {
        super(1460363747, 1259762780, Category.Render, -1921796668);
        final HUDManager hudManager = StrafeHack.hudManager;
        final IRenderer[] array = new IRenderer[ModuleUI.1698921611];
        array[ModuleUI.-444639839] = this;
    }
    // invokedynamic(232751103:(Ljava/lang/Object;[Lcom/sten_region_skidrrr/strafehack/ui/hud/IRenderer;)V, hudManager, array)
    
    public final int getLineOffset(final ScreenPosition -1983303791, final int -1269733264) {
        return invokedynamic(315756844:(Ljava/lang/Object;)I, -1983303791) + this.getLineOffset(-1269733264);
    }
    
    private int getLineOffset(final int 244467546) {
        return (invokedynamic(302807744:()Lnet/minecraft/client/Minecraft;).field_71466_p.field_78288_b + ModuleUI.-1260924284) * 244467546;
    }
    
    static {
        ModuleUI.1319398214 = 1481840527;
        ModuleUI.-963162676 = 184;
        ModuleUI.1698921611 = invokedynamic(2085227769:(I)I, Integer.MIN_VALUE);
        ModuleUI.-444639839 = ((0 >>> 70 | 0 << ~0x46 + 1) & -1);
        ModuleUI.-1260924284 = (100663296 >>> 185 | 100663296 << ~0xB9 + 1);
    }
    
    public static Object -918134356(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7) throws Exception {
        final int n = ((int)o ^ ModuleUI.1319398214) & 0xFF;
        final Integer value = ModuleUI.-963162676;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.utils;

import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.Transferable;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import java.awt.Component;
import javax.swing.JFrame;
import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;

public class FrameUtil
{
    private static String[] 1247015003;
    private static String[] 1811209739;
    private static long -930732582;
    private static int -1494209743;
    private static int -480785001;
    private static long 979447375;
    private static long 632072040;
    private static int 251644197;
    private static int -1130534918;
    private static int -873730379;
    private static int -868493176;
    
    public static void Display() {
        final Frame frame = new Frame();
        // invokedynamic(1491093826:(Ljava/lang/Object;Z)V, frame, FrameUtil.-1494209743)
        throw new NoStackTraceThrowable(invokedynamic(173029583:(IJ)Ljava/lang/String;, FrameUtil.-480785001, FrameUtil.979447375 ^ FrameUtil.632072040));
    }
    
    static {
        FrameUtil.-873730379 = 2022994706;
        FrameUtil.-868493176 = 184;
        FrameUtil.-1494209743 = (0 >>> 217 | 0 << -217);
        FrameUtil.-480785001 = (0 >>> 145 | 0 << -145);
        FrameUtil.979447375 = invokedynamic(781006152:(J)J, 8309821025363505086L);
        FrameUtil.632072040 = invokedynamic(814012092:(J)J, 8791026472627208192L);
        FrameUtil.251644197 = invokedynamic(499438991:(I)I, Integer.MIN_VALUE);
        FrameUtil.-1130534918 = (32 >>> 133 | 32 << ~0x85 + 1);
        FrameUtil.1247015003 = new String[FrameUtil.251644197];
        FrameUtil.1811209739 = new String[FrameUtil.-1130534918];
    }
    // invokedynamic(1396103480:()V)
    
    private static Object -1959977190(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(FrameUtil.class, "-2087270177", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", FrameUtil.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/utils/FrameUtil:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String -2087270177(final int n, long n2) {
        n2 ^= 0x5EL;
        n2 ^= 0x91AF3A2488C3EF92L;
        if (FrameUtil.1247015003[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/utils/FrameUtil");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            FrameUtil.1247015003[n] = new String(instance.doFinal(Base64.getDecoder().decode(FrameUtil.1811209739[n])));
        }
        return FrameUtil.1247015003[n];
    }
    
    private static void 1298729051() {
        FrameUtil.-930732582 = 9076085717864958670L;
        final long n = FrameUtil.-930732582 ^ 0x91AF3A2488C3EF92L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    FrameUtil.1811209739[0] = "57jyrLRaRIEurXnoEToPn52PrkSAYcTN";
                    break;
                }
                case 1: {
                    FrameUtil.1811209739[0] = "57jyrLRaRIEurXnoEToPn9aWhrYCYgt+";
                    break;
                }
                case 2: {
                    FrameUtil.1811209739[0] = "NcMEYTjBsa266fI3vgT7yg==";
                    break;
                }
                case 4: {
                    FrameUtil.1811209739[0] = "5Q8lgaf45SE+ZwuSz0j+EQ==";
                    break;
                }
            }
        }
    }
    
    public static Object 920211614(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7) throws Exception {
        final int n = ((int)o ^ FrameUtil.-873730379) & 0xFF;
        final Integer value = FrameUtil.-868493176;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
    
    public static class Frame extends JFrame
    {
        private static String[] -536516126;
        private static String[] -1657910112;
        private static long -1271727899;
        private static int 376486086;
        private static long 2095641064;
        private static long -238865525;
        private static int 1363542553;
        private static int 155325360;
        private static int 564505151;
        private static long -1458930433;
        private static int -1825391414;
        private static long -2009509823;
        private static int -1994688050;
        private static long 573650069;
        private static int 1064125581;
        private static int -1584168128;
        private static long -1251968908;
        private static int -896664812;
        private static long 1719470677;
        private static long -2000422974;
        private static int 1703209249;
        private static int 108103533;
        private static long 601233793;
        private static long -2145006311;
        private static int 1486510545;
        private static int -774842725;
        
        public Frame() {
            this.setTitle(invokedynamic(-1637012217:(IJ)Ljava/lang/String;, Frame.376486086, Frame.2095641064 ^ Frame.-238865525));
            this.setDefaultCloseOperation(Frame.1363542553);
            this.setLocationRelativeTo(null);
            copyToClipboard(HWIDUtil.getEncryptedHWID(invokedynamic(167342475:(IJ)Ljava/lang/String;, Frame.155325360 & Frame.564505151, Frame.-1458930433)));
            final String 1424544738 = invokedynamic(695767213:(IJ)Ljava/lang/String;, Frame.-1825391414, Frame.-2009509823) + HWIDUtil.getEncryptedHWID(invokedynamic(27501555:(IJ)Ljava/lang/String;, Frame.-1994688050, Frame.573650069)) + invokedynamic(539820719:(IJ)Ljava/lang/String;, Frame.1064125581 & Frame.-1584168128, Frame.-1251968908);
            JOptionPane.showMessageDialog((Component)this, (Object)1424544738, invokedynamic(-276636533:(IJ)Ljava/lang/String;, Frame.-896664812, Frame.1719470677 ^ Frame.-2000422974), Frame.1703209249, UIManager.getIcon(invokedynamic(-999894418:(IJ)Ljava/lang/String;, Frame.108103533, Frame.601233793 ^ Frame.-2145006311)));
        }
        
        public static void copyToClipboard(final String -1908920369) {
            final StringSelection stringSelection = new StringSelection(-1908920369);
            final Clipboard 1395548569 = Toolkit.getDefaultToolkit().getSystemClipboard();
            1395548569.setContents(stringSelection, stringSelection);
        }
        
        static {
            Frame.376486086 = (0 >>> 40 | 0 << ~0x28 + 1);
            Frame.2095641064 = Long.reverse(-8428904867885954565L);
            Frame.-238865525 = Long.reverse(1729382256910270464L);
            Frame.1363542553 = (67108864 >>> 217 | 67108864 << -217);
            Frame.155325360 = (16384 >>> 142 | 16384 << -142);
            Frame.564505151 = (-1 >>> 70 | -1 << -70);
            Frame.-1458930433 = Long.reverse(-7852444115582531077L);
            Frame.-1825391414 = ((128 >>> 230 | 128 << ~0xE6 + 1) & -1);
            Frame.-2009509823 = Long.reverse(-7852444115582531077L);
            Frame.-1994688050 = (768 >>> 104 | 768 << -104);
            Frame.573650069 = Long.reverse(-7852444115582531077L);
            Frame.1064125581 = Integer.reverse(536870912);
            Frame.-1584168128 = (-1 >>> 12 | -1 << ~0xC + 1);
            Frame.-1251968908 = Long.reverse(-7852444115582531077L);
            Frame.-896664812 = ((320 >>> 198 | 320 << ~0xC6 + 1) & -1);
            Frame.1719470677 = Long.reverse(-8428904867885954565L);
            Frame.-2000422974 = Long.reverse(1729382256910270464L);
            Frame.1703209249 = ((-1 >>> 30 | -1 << ~0x1E + 1) & -1);
            Frame.108103533 = Integer.reverse(1610612736);
            Frame.601233793 = Long.reverse(-8428904867885954565L);
            Frame.-2145006311 = Long.reverse(1729382256910270464L);
            Frame.1486510545 = ((229376 >>> 79 | 229376 << ~0x4F + 1) & -1);
            Frame.-774842725 = ((114688 >>> 206 | 114688 << ~0xCE + 1) & -1);
            Frame.-536516126 = new String[Frame.1486510545];
            Frame.-1657910112 = new String[Frame.-774842725];
            -1757124215();
        }
        
        private static Object 1869843440(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
            try {
                return new MutableCallSite(lookup.findStatic(Frame.class, "601929774", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", Frame.class.getClassLoader())).asType(newType));
            }
            catch (Exception cause) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/utils/FrameUtil$Frame:" + str + ":" + newType.toString(), cause);
            }
        }
        
        private static String 601929774(final int n, long n2) {
            n2 ^= 0x18L;
            n2 ^= 0x87275F0C33F63B35L;
            if (Frame.-536516126[n] == null) {
                Cipher instance;
                SecretKeyFactory instance2;
                try {
                    instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                    instance2 = SecretKeyFactory.getInstance("DES");
                }
                catch (Exception ex) {
                    throw new RuntimeException("com/sten_region_skidrrr/strafehack/utils/FrameUtil$Frame");
                }
                final byte[] key = new byte[8];
                key[0] = (byte)(n2 >>> 56);
                for (int i = 1; i < 8; ++i) {
                    key[i] = (byte)(n2 << i * 8 >>> 56);
                }
                instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
                Frame.-536516126[n] = new String(instance.doFinal(Base64.getDecoder().decode(Frame.-1657910112[n])));
            }
            return Frame.-536516126[n];
        }
        
        private static void -1757124215() {
            Frame.-1271727899 = -2336497348470808367L;
            final long n = Frame.-1271727899 ^ 0x87275F0C33F63B35L;
            final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
            final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
            final byte[] key = new byte[8];
            key[0] = (byte)(n >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            for (int n2 = 1, j = 0; j < n2; ++j) {
                switch (j) {
                    case 0: {
                        Frame.-1657910112[0] = "mmpLgMKg+mN9etnUrGGO5w==";
                        Frame.-1657910112[1] = "wuAKa7M8C9o=";
                        Frame.-1657910112[2] = "Wdg26JsQgMVqOpZFSJYZgOdeDsfqN4cEfq0PRPo3b8BuuaTd/9TFaQ==";
                        Frame.-1657910112[3] = "wuAKa7M8C9o=";
                        Frame.-1657910112[4] = "gifMTP5EndwowdUdR2lXmYWSJpdEnyGf";
                        Frame.-1657910112[5] = "mmpLgMKg+mN9etnUrGGO5w==";
                        Frame.-1657910112[6] = "Ua2wthdYN7kxq2yAplCYwQRIR4S21QWO";
                        break;
                    }
                    case 1: {
                        Frame.-1657910112[0] = "mmpLgMKg+mNgwiylc3xf/HM87R8AeWTZ";
                        Frame.-1657910112[1] = "ERn9dSJAduedUt4EXB+Nng==";
                        Frame.-1657910112[2] = "Wdg26JsQgMVqOpZFSJYZgOdeDsfqN4cEfq0PRPo3b8D2jR4IP2u77dqtyU4GnD4o";
                        Frame.-1657910112[3] = "fx07kn+P7xzWaQEm5YhkcA==";
                        Frame.-1657910112[4] = "gifMTP5EndwowdUdR2lXmTlLtelTy6M88hEjcxdqnsw=";
                        Frame.-1657910112[5] = "mmpLgMKg+mOrfcd0dP/3hw==";
                        Frame.-1657910112[6] = "Ua2wthdYN7kxq2yAplCYwU2VxX89gyJWQtJMYyNhJIU=";
                        break;
                    }
                    case 2: {
                        Frame.-1657910112[0] = "o1DWC0S6qXM=";
                        break;
                    }
                    case 4: {
                        Frame.-1657910112[0] = "JT4M54yBHhjTB7IH/KI/uA==";
                        break;
                    }
                }
            }
        }
    }
}

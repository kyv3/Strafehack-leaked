// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.utils;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.Cipher;
import java.security.NoSuchAlgorithmException;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;

public class HWIDUtil
{
    private static String[] -1049304105;
    private static String[] 812399061;
    private static long -1024297311;
    private static int -1555970402;
    private static int -1354934767;
    private static long 63768386;
    private static int 1241901165;
    private static long -2022604668;
    private static long 1812539959;
    private static int 177318749;
    private static long 1845672257;
    private static long 1256849143;
    private static int -302542;
    private static long -938523459;
    private static int -1694083818;
    private static int 759271782;
    private static long -1075751245;
    private static int 1143339749;
    private static long -1882283627;
    private static long -2069301806;
    private static int -1501840740;
    private static long 1025147624;
    private static int 112842261;
    private static long 1834089183;
    private static long 1819136836;
    private static int 1314429907;
    private static long -299384261;
    private static int 1202816110;
    private static int -378755681;
    private static long 1463468341;
    private static long 1137237433;
    private static int 1174914028;
    private static long -819567578;
    private static int -1916680379;
    private static int 1764679512;
    private static int -732220825;
    private static long 213911208;
    private static int 1763944547;
    private static int 1957721459;
    private static long -1634911275;
    private static int 323866383;
    private static int 144181344;
    private static long 1262681439;
    private static int 1841902688;
    private static int -1848805411;
    private static int -1768783487;
    private static int -773502186;
    
    public static byte[] rawHWID() throws NoSuchAlgorithmException {
        final String 464573207 = invokedynamic(-175305941:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(1139857296:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-1564012704:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(1838989004:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(578796848:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-485367042:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-1893879892:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(1069614901:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), invokedynamic(-54778419:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-1501536765:(IJ)Ljava/lang/String;, HWIDUtil.-1555970402 & HWIDUtil.-1354934767, HWIDUtil.63768386))), invokedynamic(1818773364:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-1247179576:(IJ)Ljava/lang/String;, HWIDUtil.1241901165, HWIDUtil.-2022604668 ^ HWIDUtil.1812539959))), invokedynamic(1190314502:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(416622141:(IJ)Ljava/lang/String;, HWIDUtil.177318749, HWIDUtil.1845672257 ^ HWIDUtil.1256849143))), invokedynamic(2034441785:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(1986162873:(IJ)Ljava/lang/String;, HWIDUtil.-302542, HWIDUtil.-938523459))), invokedynamic(1520413039:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-1308161602:(IJ)Ljava/lang/String;, HWIDUtil.-1694083818 & HWIDUtil.759271782, HWIDUtil.-1075751245))), invokedynamic(97034087:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-1467935939:(IJ)Ljava/lang/String;, HWIDUtil.1143339749, HWIDUtil.-1882283627 ^ HWIDUtil.-2069301806))), invokedynamic(406308809:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(256587236:(IJ)Ljava/lang/String;, HWIDUtil.-1501840740, HWIDUtil.1025147624))));
        final byte[] array = (byte[])invokedynamic(-775669824:(Ljava/lang/Object;Ljava/lang/Object;)[B, 464573207, StandardCharsets.UTF_8);
        final MessageDigest 464573208 = invokedynamic(1613124605:(Ljava/lang/Object;)Ljava/security/MessageDigest;, invokedynamic(-518579658:(IJ)Ljava/lang/String;, HWIDUtil.112842261, HWIDUtil.1834089183 ^ HWIDUtil.1819136836));
        return (byte[])invokedynamic(659907296:(Ljava/lang/Object;[B)[B, 464573208, array);
    }
    
    public static String Encrypt(final String -1913813492, final String -1410320143) {
        try {
            final Cipher cipher = invokedynamic(-1610245011:(Ljava/lang/Object;)Ljavax/crypto/Cipher;, invokedynamic(-91090617:(IJ)Ljava/lang/String;, HWIDUtil.1314429907, HWIDUtil.-299384261));
            // invokedynamic(-1348023454:(Ljava/lang/Object;ILjava/lang/Object;)V, cipher, HWIDUtil.1202816110, invokedynamic(346402331:(Ljava/lang/Object;)Ljavax/crypto/spec/SecretKeySpec;, -1410320143))
            return invokedynamic(-1745090205:(Ljava/lang/Object;[B)Ljava/lang/String;, invokedynamic(2100057563:()Ljava/util/Base64$Encoder;), (byte[])invokedynamic(1375225233:(Ljava/lang/Object;[B)[B, cipher, (byte[])invokedynamic(409300098:(Ljava/lang/Object;Ljava/lang/Object;)[B, -1913813492, StandardCharsets.UTF_8)));
        }
        catch (Exception 1701285517) {
            // invokedynamic(-748934803:(Ljava/lang/Object;Ljava/lang/Object;)V, System.out, invokedynamic(-739197047:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(1806372887:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(1076842364:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), invokedynamic(2136826223:(IJ)Ljava/lang/String;, HWIDUtil.-378755681, HWIDUtil.1463468341 ^ HWIDUtil.1137237433)), invokedynamic(-1734055923:(Ljava/lang/Object;)Ljava/lang/String;, 1701285517))))
            return null;
        }
    }
    
    public static SecretKeySpec getKey(final String -1919506847) {
        try {
            byte[] key = (byte[])invokedynamic(-1464879703:(Ljava/lang/Object;Ljava/lang/Object;)[B, -1919506847, StandardCharsets.UTF_8);
            final MessageDigest 2082320498 = invokedynamic(2007877928:(Ljava/lang/Object;)Ljava/security/MessageDigest;, invokedynamic(85551752:(IJ)Ljava/lang/String;, HWIDUtil.1174914028, HWIDUtil.-819567578));
            key = (byte[])invokedynamic(-1778331005:(Ljava/lang/Object;[B)[B, 2082320498, key);
            key = (byte[])invokedynamic(843388585:([BI)[B, key, HWIDUtil.-1916680379);
            return new SecretKeySpec(key, invokedynamic(-1860368835:(IJ)Ljava/lang/String;, HWIDUtil.1764679512 & HWIDUtil.-732220825, HWIDUtil.213911208));
        }
        catch (NoSuchAlgorithmException ex) {
            // invokedynamic(77137959:(Ljava/lang/Object;)V, ex)
            return null;
        }
    }
    
    public static String getEncryptedHWID(final String 744356945) {
        try {
            final String 744356946 = invokedynamic(1295718189:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-201737858:(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/hash/HashCode;, invokedynamic(-584972534:()Lcom/google/common/hash/HashFunction;), new String((byte[])invokedynamic(-570415484:()[B), StandardCharsets.UTF_8), StandardCharsets.UTF_8));
            final String 744356947 = invokedynamic(-1936564213:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(1191533777:(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/hash/HashCode;, invokedynamic(-855626550:()Lcom/google/common/hash/HashFunction;), 744356946, StandardCharsets.UTF_8));
            final String s = invokedynamic(1120783595:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-1726706218:(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/hash/HashCode;, invokedynamic(1277889337:()Lcom/google/common/hash/HashFunction;), 744356947, StandardCharsets.UTF_8));
            final String 744356948 = invokedynamic(-737565764:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-1325718271:(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/hash/HashCode;, invokedynamic(-1752961573:()Lcom/google/common/hash/HashFunction;), s, StandardCharsets.UTF_8));
            return invokedynamic(-1304685195:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/String;, 744356948, invokedynamic(-2095143695:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(1888897310:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-1899833171:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), invokedynamic(849087701:(IJ)Ljava/lang/String;, HWIDUtil.1763944547 & HWIDUtil.1957721459, HWIDUtil.-1634911275)), 744356945)));
        }
        catch (Exception ex) {
            // invokedynamic(-1464091451:(Ljava/lang/Object;)V, ex)
            return invokedynamic(-303579915:(IJ)Ljava/lang/String;, HWIDUtil.323866383 & HWIDUtil.144181344, HWIDUtil.1262681439);
        }
    }
    
    static {
        HWIDUtil.-1768783487 = 1761440349;
        HWIDUtil.-773502186 = 184;
        HWIDUtil.-1555970402 = ((0 >>> 225 | 0 << ~0xE1 + 1) & -1);
        HWIDUtil.-1354934767 = (-1 >>> 233 | -1 << ~0xE9 + 1);
        HWIDUtil.63768386 = invokedynamic(354598071:(J)J, -2047730156748685907L);
        HWIDUtil.1241901165 = ((2048 >>> 235 | 2048 << -235) & -1);
        HWIDUtil.-2022604668 = invokedynamic(1738888431:(J)J, -4353573165962379859L);
        HWIDUtil.1812539959 = invokedynamic(507083778:(J)J, 2305843009213693952L);
        HWIDUtil.177318749 = ((2048 >>> 202 | 2048 << -202) & -1);
        HWIDUtil.1845672257 = invokedynamic(-200636563:(J)J, -4353573165962379859L);
        HWIDUtil.1256849143 = invokedynamic(-1451861937:(J)J, 2305843009213693952L);
        HWIDUtil.-302542 = (98304 >>> 111 | 98304 << -111);
        HWIDUtil.-938523459 = invokedynamic(-100376708:(J)J, -2047730156748685907L);
        HWIDUtil.-1694083818 = invokedynamic(903982500:(I)I, 536870912);
        HWIDUtil.759271782 = (-1 >>> 107 | -1 << ~0x6B + 1);
        HWIDUtil.-1075751245 = invokedynamic(2124757784:(J)J, -2047730156748685907L);
        HWIDUtil.1143339749 = invokedynamic(648653300:(I)I, -1610612736);
        HWIDUtil.-1882283627 = invokedynamic(-755389436:(J)J, -4353573165962379859L);
        HWIDUtil.-2069301806 = invokedynamic(264746453:(J)J, 2305843009213693952L);
        HWIDUtil.-1501840740 = (100663296 >>> 88 | 100663296 << -88);
        HWIDUtil.1025147624 = invokedynamic(993734838:(J)J, -2047730156748685907L);
        HWIDUtil.112842261 = ((224 >>> 229 | 224 << ~0xE5 + 1) & -1);
        HWIDUtil.1834089183 = invokedynamic(1262808420:(J)J, -4353573165962379859L);
        HWIDUtil.1819136836 = invokedynamic(507134330:(J)J, 2305843009213693952L);
        HWIDUtil.1314429907 = (2 >>> 254 | 2 << ~0xFE + 1);
        HWIDUtil.-299384261 = invokedynamic(1967770779:(J)J, -2047730156748685907L);
        HWIDUtil.1202816110 = (1 >>> 96 | 1 << -96);
        HWIDUtil.-378755681 = invokedynamic(-936785247:(I)I, -1879048192);
        HWIDUtil.1463468341 = invokedynamic(-1561244081:(J)J, -4353573165962379859L);
        HWIDUtil.1137237433 = invokedynamic(2007524606:(J)J, 2305843009213693952L);
        HWIDUtil.1174914028 = invokedynamic(1411337783:(I)I, 1342177280);
        HWIDUtil.-819567578 = invokedynamic(-410422162:(J)J, -2047730156748685907L);
        HWIDUtil.-1916680379 = invokedynamic(-807109106:(I)I, 134217728);
        HWIDUtil.1764679512 = invokedynamic(-1004083096:(I)I, -805306368);
        HWIDUtil.-732220825 = ((-1 >>> 188 | -1 << ~0xBC + 1) & -1);
        HWIDUtil.213911208 = invokedynamic(-743339773:(J)J, -2047730156748685907L);
        HWIDUtil.1763944547 = invokedynamic(-96928210:(I)I, 805306368);
        HWIDUtil.1957721459 = ((-1 >>> 213 | -1 << ~0xD5 + 1) & -1);
        HWIDUtil.-1634911275 = invokedynamic(1882357318:(J)J, -2047730156748685907L);
        HWIDUtil.323866383 = ((218103808 >>> 184 | 218103808 << -184) & -1);
        HWIDUtil.144181344 = invokedynamic(2014259515:(I)I, -1);
        HWIDUtil.1262681439 = invokedynamic(46664318:(J)J, -2047730156748685907L);
        HWIDUtil.1841902688 = ((-536870912 >>> 252 | -536870912 << ~0xFC + 1) & -1);
        HWIDUtil.-1848805411 = invokedynamic(842229390:(I)I, 1879048192);
        HWIDUtil.-1049304105 = new String[HWIDUtil.1841902688];
        HWIDUtil.812399061 = new String[HWIDUtil.-1848805411];
    }
    // invokedynamic(1774674076:()V)
    
    private static Object 923501749(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(HWIDUtil.class, "-129196041", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", HWIDUtil.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/utils/HWIDUtil:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String -129196041(final int n, long n2) {
        n2 ^= 0x4L;
        n2 ^= 0xD0083A70C8FEDD21L;
        if (HWIDUtil.-1049304105[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/utils/HWIDUtil");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            HWIDUtil.-1049304105[n] = new String(instance.doFinal(Base64.getDecoder().decode(HWIDUtil.812399061[n])));
        }
        return HWIDUtil.-1049304105[n];
    }
    
    private static void 811998701() {
        HWIDUtil.-1024297311 = -5350904411960858173L;
        final long n = HWIDUtil.-1024297311 ^ 0xD0083A70C8FEDD21L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    HWIDUtil.812399061[0] = "LceBbSVoWMxu3yI6aH5rI8AWtdEW9t1T";
                    HWIDUtil.812399061[1] = "dAJw0oTjGseTBVVaE7yXlg==";
                    HWIDUtil.812399061[2] = "dAJw0oTjGscK6F/j9+Is9crEbvytyYQ+";
                    HWIDUtil.812399061[3] = "dAJw0oTjGsf4egaLCRZwaHsGd0+wR6Tp";
                    HWIDUtil.812399061[4] = "dAJw0oTjGsf4egaLCRZwaNjS/HGjyBOh";
                    HWIDUtil.812399061[5] = "ZjDhtJb0hLjI8enMZjryLaYi5MUUkRPg";
                    HWIDUtil.812399061[6] = "PcaPb9wtPV5Zc8gQl50fUQ==";
                    HWIDUtil.812399061[7] = "NUF2uHlQBSY=";
                    HWIDUtil.812399061[8] = "TJ+u3D5oKvDcu3Z0cr6C++qbBeuXJz3I";
                    HWIDUtil.812399061[9] = "1dAgQ7eQZZ0gp2JW+byJDRLkIXL36J2F2FDeTmneJdk=";
                    HWIDUtil.812399061[10] = "pg5TGkt0e6Y=";
                    HWIDUtil.812399061[11] = "QYqlHKCzIcc=";
                    HWIDUtil.812399061[12] = "izqOI+ARGNRvqYe3LRP+nw==";
                    HWIDUtil.812399061[13] = "hQzAUD0JOZ0=";
                    break;
                }
                case 1: {
                    HWIDUtil.812399061[0] = "LceBbSVoWMxu3yI6aH5rI4giOxW8uACQ";
                    HWIDUtil.812399061[1] = "dAJw0oTjGsfRzzHYdFdLtQb6fmJrZ0RZ";
                    HWIDUtil.812399061[2] = "dAJw0oTjGscK6F/j9+Is9bvePyFf1/tN";
                    HWIDUtil.812399061[3] = "dAJw0oTjGsf4egaLCRZwaM/2E4z/8B4ikdEtD7T/T/Y=";
                    HWIDUtil.812399061[4] = "dAJw0oTjGsf4egaLCRZwaEdgXpYilAHCryE3P3XtWEI=";
                    HWIDUtil.812399061[5] = "ZjDhtJb0hLjI8enMZjryLb9xrwKGyQcV";
                    HWIDUtil.812399061[6] = "PcaPb9wtPV59fKUgtmbPjZurJxFzPc0a";
                    HWIDUtil.812399061[7] = "NdvV7zy/oi8=";
                    HWIDUtil.812399061[8] = "TJ+u3D5oKvDcu3Z0cr6C+wpzoyLMe8ZJ";
                    HWIDUtil.812399061[9] = "1dAgQ7eQZZ0gp2JW+byJDRLkIXL36J2FgU6sa2lqKq8=";
                    HWIDUtil.812399061[10] = "K4YlE3AAF3kGRrznFSkZDg==";
                    HWIDUtil.812399061[11] = "6YX6CLm72ro=";
                    HWIDUtil.812399061[12] = "izqOI+ARGNSVpQ9oPdImXg==";
                    HWIDUtil.812399061[13] = "qAqjzDq0SMPLqmtHhizX+w==";
                    break;
                }
                case 2: {
                    HWIDUtil.812399061[0] = "0QxhwEzhEh4=";
                    break;
                }
                case 4: {
                    HWIDUtil.812399061[0] = "Db7IO+nsX4KpaPsHFc7waQ==";
                    break;
                }
            }
        }
    }
    
    public static Object -278798594(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7, final Object o8, final Object o9) throws Exception {
        final int n = ((int)o ^ HWIDUtil.-1768783487) & 0xFF;
        final Integer value = HWIDUtil.-773502186;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.utils;

import java.lang.invoke.MutableCallSite;
import javax.xml.bind.DatatypeConverter;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.inventory.Container;
import net.minecraft.client.Minecraft;

public class InventoryUtil
{
    private static Minecraft mc;
    private static int 1426182400;
    private static int -1019499622;
    private static int 1620895165;
    private static int 1023343512;
    private static int -1749338711;
    private static int -671368327;
    private static int -883205142;
    private static int 2025017014;
    private static int 1128475107;
    private static int 1688643204;
    private static int -1338762387;
    private static int 707065513;
    private static int 1193484853;
    private static int -509495323;
    
    public static int getItemCount(final Container -2128427148, final Item 1576630031) {
        int 1576630032 = InventoryUtil.1426182400;
        for (int 1576630033 = InventoryUtil.-1019499622; 1576630033 < InventoryUtil.1620895165; ++1576630033) {
            if (invokedynamic(526091725:(Ljava/lang/Object;)Z, invokedynamic(1881220016:(Ljava/lang/Object;I)Lnet/minecraft/inventory/Slot;, -2128427148, 1576630033))) {
                final ItemStack 1576630034 = invokedynamic(-471391729:(Ljava/lang/Object;)Lnet/minecraft/item/ItemStack;, invokedynamic(495122990:(Ljava/lang/Object;I)Lnet/minecraft/inventory/Slot;, -2128427148, 1576630033));
                if (invokedynamic(201334541:(Ljava/lang/Object;)Lnet/minecraft/item/Item;, 1576630034) == 1576630031) {
                    1576630032 += invokedynamic(-969674020:(Ljava/lang/Object;)I, 1576630034);
                }
            }
        }
        return 1576630032;
    }
    
    public static int getItemSlot(final Container -985735965, final Item -1674263230) {
        int 1986211683 = InventoryUtil.1023343512;
        for (int i = InventoryUtil.-1749338711; i < InventoryUtil.-671368327; ++i) {
            if (invokedynamic(1141485521:(Ljava/lang/Object;)Z, invokedynamic(-254548458:(Ljava/lang/Object;I)Lnet/minecraft/inventory/Slot;, -985735965, i))) {
                final ItemStack 1986211684 = invokedynamic(231118139:(Ljava/lang/Object;)Lnet/minecraft/item/ItemStack;, invokedynamic(-1527989707:(Ljava/lang/Object;I)Lnet/minecraft/inventory/Slot;, -985735965, i));
                if (invokedynamic(517712139:(Ljava/lang/Object;)Lnet/minecraft/item/Item;, 1986211684) == -1674263230) {
                    1986211683 = i;
                }
            }
        }
        return 1986211683;
    }
    
    public static int getItemSlotInHotbar(final Item 1486009665) {
        int 1486009666 = InventoryUtil.-883205142;
        for (int 1486009667 = InventoryUtil.2025017014; 1486009667 < InventoryUtil.1128475107; ++1486009667) {
            final ItemStack 1486009668 = invokedynamic(-1405872918:(Ljava/lang/Object;I)Lnet/minecraft/item/ItemStack;, InventoryUtil.mc.field_71439_g.field_71071_by, 1486009667);
            if (invokedynamic(952133993:(Ljava/lang/Object;)Lnet/minecraft/item/Item;, 1486009668) == 1486009665) {
                1486009666 = 1486009667;
                break;
            }
        }
        return 1486009666;
    }
    
    public static void swap(final int -1670346819, final int 889873906) {
    }
    // invokedynamic(-1705240224:(Ljava/lang/Object;IIILjava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/item/ItemStack;, InventoryUtil.mc.field_71442_b, InventoryUtil.mc.field_71439_g.field_71069_bz.field_75152_c, -1670346819, InventoryUtil.1688643204, ClickType.PICKUP, InventoryUtil.mc.field_71439_g)
    // invokedynamic(989487433:(Ljava/lang/Object;IIILjava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/item/ItemStack;, InventoryUtil.mc.field_71442_b, InventoryUtil.mc.field_71439_g.field_71069_bz.field_75152_c, 889873906, InventoryUtil.-1338762387, ClickType.PICKUP, InventoryUtil.mc.field_71439_g)
    // invokedynamic(-687824053:(Ljava/lang/Object;IIILjava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/item/ItemStack;, InventoryUtil.mc.field_71442_b, InventoryUtil.mc.field_71439_g.field_71069_bz.field_75152_c, -1670346819, InventoryUtil.707065513, ClickType.PICKUP, InventoryUtil.mc.field_71439_g)
    // invokedynamic(1789721299:(Ljava/lang/Object;)V, InventoryUtil.mc.field_71442_b)
    
    static {
        InventoryUtil.1193484853 = 358597244;
        InventoryUtil.-509495323 = 184;
        InventoryUtil.1426182400 = invokedynamic(474578359:(I)I, false);
        InventoryUtil.-1019499622 = invokedynamic(411507913:(I)I, false);
        InventoryUtil.1620895165 = ((754974720 >>> 248 | 754974720 << -248) & -1);
        InventoryUtil.1023343512 = invokedynamic(1518912439:(I)I, false);
        InventoryUtil.-1749338711 = (18432 >>> 75 | 18432 << ~0x4B + 1);
        InventoryUtil.-671368327 = invokedynamic(-2036792561:(I)I, -1275068416);
        InventoryUtil.-883205142 = (0 >>> 132 | 0 << ~0x84 + 1);
        InventoryUtil.2025017014 = invokedynamic(1137528123:(I)I, false);
        InventoryUtil.1128475107 = ((603979776 >>> 218 | 603979776 << ~0xDA + 1) & -1);
        InventoryUtil.1688643204 = (0 >>> 159 | 0 << -159);
        InventoryUtil.-1338762387 = (0 >>> 230 | 0 << ~0xE6 + 1);
        InventoryUtil.707065513 = invokedynamic(-1508565978:(I)I, false);
        InventoryUtil.mc = invokedynamic(-1836606877:()Lnet/minecraft/client/Minecraft;);
    }
    
    public static Object -1288517854(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6) throws Exception {
        final int n = ((int)o ^ InventoryUtil.1193484853) & 0xFF;
        final Integer value = InventoryUtil.-509495323;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

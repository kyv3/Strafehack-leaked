// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.utils;

import java.lang.invoke.MutableCallSite;
import javax.xml.bind.DatatypeConverter;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;

public class TimerUtil
{
    private long current;
    private static int -307703072;
    private static int -1755989474;
    private static int -1743435134;
    private static int -1091851774;
    private static int 375590189;
    private static int -2084058817;
    private static int 746738234;
    private static int 1838699108;
    
    public TimerUtil() {
        this.current = invokedynamic(-980905342:()J);
    }
    
    public boolean hasReached(final long -1418814) {
        return ((invokedynamic(-2071593175:()J) - this.current >= -1418814) ? TimerUtil.-307703072 : TimerUtil.-1755989474) != 0;
    }
    
    public boolean hasReached(final long -535256854, final boolean 388855971) {
        if (388855971) {
        }
        // invokedynamic(-910307588:(Ljava/lang/Object;)V, this)
        return ((invokedynamic(834236811:()J) - this.current >= -535256854) ? TimerUtil.-1743435134 : TimerUtil.-1091851774) != 0;
    }
    
    public void reset() {
        this.current = invokedynamic(-1100479432:()J);
    }
    
    public long getTimePassed() {
        return invokedynamic(1145210088:()J) - this.current;
    }
    
    public boolean sleep(final long -1395814845) {
        if (invokedynamic(-524414315:(Ljava/lang/Object;)J, this) >= -1395814845) {
            // invokedynamic(-1468522264:(Ljava/lang/Object;)V, this)
            return TimerUtil.375590189 != 0;
        }
        return TimerUtil.-2084058817 != 0;
    }
    
    public long time() {
        return invokedynamic(-1042770943:()J) - this.current;
    }
    
    static {
        TimerUtil.746738234 = -1371615686;
        TimerUtil.1838699108 = 184;
        TimerUtil.-307703072 = (8192 >>> 205 | 8192 << ~0xCD + 1);
        TimerUtil.-1755989474 = invokedynamic(-1756637231:(I)I, false);
        TimerUtil.-1743435134 = invokedynamic(1293473561:(I)I, Integer.MIN_VALUE);
        TimerUtil.-1091851774 = (0 >>> 125 | 0 << -125);
        TimerUtil.375590189 = invokedynamic(1457593995:(I)I, Integer.MIN_VALUE);
        TimerUtil.-2084058817 = invokedynamic(-210043152:(I)I, false);
    }
    
    public static Object 807411321(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7) throws Exception {
        final int n = ((int)o ^ TimerUtil.746738234) & 0xFF;
        final Integer value = TimerUtil.1838699108;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.utils;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import net.minecraftforge.fml.common.FMLLog;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class NetworkUtil
{
    private static String[] -722491820;
    private static String[] 1965941103;
    private static long -135786649;
    private static int -1378812335;
    private static long 333256006;
    private static int -1167316926;
    private static long -910246429;
    private static long -1424459035;
    private static int 2040891244;
    private static int -536409841;
    private static int -2081711305;
    private static int 1940896194;
    
    public static List<String> getHWIDList() {
        final List<String> 154202878 = new ArrayList<String>();
        try {
            final URL url = new URL(invokedynamic(499854515:(IJ)Ljava/lang/String;, NetworkUtil.-1378812335, NetworkUtil.333256006));
            final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(invokedynamic(1357716971:(Ljava/lang/Object;)Ljava/io/InputStream;, url)));
            String 154202879;
            while ((154202879 = invokedynamic(90245964:(Ljava/lang/Object;)Ljava/lang/String;, bufferedReader)) != null) {
            }
            // invokedynamic(-1296523846:(Ljava/lang/Object;Ljava/lang/Object;)Z, 154202878, 154202879)
        }
        catch (Exception ex) {
        }
        // invokedynamic(-1128809288:(Ljava/lang/Object;Ljava/lang/Object;)V, FMLLog.log, invokedynamic(-1806084410:(IJ)Ljava/lang/String;, NetworkUtil.-1167316926, NetworkUtil.-910246429 ^ NetworkUtil.-1424459035))
        return 154202878;
    }
    
    static {
        NetworkUtil.-2081711305 = 1383731558;
        NetworkUtil.1940896194 = 184;
        NetworkUtil.-1378812335 = invokedynamic(-554587617:(I)I, false);
        NetworkUtil.333256006 = invokedynamic(-1935713461:(J)J, 6282334820608788184L);
        NetworkUtil.-1167316926 = ((4 >>> 162 | 4 << ~0xA2 + 1) & -1);
        NetworkUtil.-910246429 = invokedynamic(1795825703:(J)J, 4264722187546805976L);
        NetworkUtil.-1424459035 = invokedynamic(1930730482:(J)J, 7782220156096217088L);
        NetworkUtil.2040891244 = invokedynamic(-1544017140:(I)I, 1073741824);
        NetworkUtil.-536409841 = (8 >>> 226 | 8 << -226);
        NetworkUtil.-722491820 = new String[NetworkUtil.2040891244];
        NetworkUtil.1965941103 = new String[NetworkUtil.-536409841];
    }
    // invokedynamic(1724038551:()V)
    
    private static Object 1335323409(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(NetworkUtil.class, "-1238429092", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", NetworkUtil.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/utils/NetworkUtil:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String -1238429092(final int n, long n2) {
        n2 ^= 0x36L;
        n2 ^= 0xC3B0B0311B0AF956L;
        if (NetworkUtil.-722491820[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/utils/NetworkUtil");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            NetworkUtil.-722491820[n] = new String(instance.doFinal(Base64.getDecoder().decode(NetworkUtil.1965941103[n])));
        }
        return NetworkUtil.-722491820[n];
    }
    
    private static void 1212831328() {
        NetworkUtil.-135786649 = 1973190679075681500L;
        final long n = NetworkUtil.-135786649 ^ 0xC3B0B0311B0AF956L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    NetworkUtil.1965941103[0] = "ceckHQbv1rRX9MzfopubXeLc588NlwyI2F+kJtUqGwPhvItW2ApPhTplxXDiAr9ISnZjXEjbY82MUk7zfna+RDDuQNoz1bz+8TJAtC3B/oo=";
                    NetworkUtil.1965941103[1] = "8Aot82blaezbUjizbUetOAxszh8bNe91";
                    break;
                }
                case 1: {
                    NetworkUtil.1965941103[0] = "ceckHQbv1rRX9MzfopubXeLc588NlwyI2F+kJtUqGwPhvItW2ApPhTplxXDiAr9ISnZjXEjbY82MUk7zfna+RDDuQNoz1bz+EEgHq0QMpy4Qgg582VOEtA==";
                    NetworkUtil.1965941103[1] = "8Aot82blaezbUjizbUetONf7IaTfFKOR";
                    break;
                }
                case 2: {
                    NetworkUtil.1965941103[0] = "fKEiURT9lPZckh9w/UX7J8dpwTtDF0kO";
                    break;
                }
                case 4: {
                    NetworkUtil.1965941103[0] = "cQ0zqqyIaXqkqcbyPkJCJQ==";
                    break;
                }
            }
        }
    }
    
    public static Object -1259441596(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5) throws Exception {
        final int n = ((int)o ^ NetworkUtil.-2081711305) & 0xFF;
        final Integer value = NetworkUtil.1940896194;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

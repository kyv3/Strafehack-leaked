// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.utils;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;

public class NoStackTraceThrowable extends RuntimeException
{
    private static String[] 1580835093;
    private static String[] -1621453154;
    private static long -1554090218;
    private static int -372923945;
    private static int 505537845;
    private static long 173285223;
    private static long 1948958402;
    private static int 1630527798;
    private static int -957440113;
    private static int -2043734765;
    private static int 1905216434;
    
    public NoStackTraceThrowable(final String -1479974928) {
        super(-1479974928);
    }
    // invokedynamic(-561579592:(Ljava/lang/Object;[Ljava/lang/StackTraceElement;)V, this, new StackTraceElement[NoStackTraceThrowable.-372923945])
    
    @Override
    public String toString() {
        return invokedynamic(-305852783:(IJ)Ljava/lang/String;, NoStackTraceThrowable.505537845, NoStackTraceThrowable.173285223 ^ NoStackTraceThrowable.1948958402);
    }
    
    @Override
    public synchronized Throwable fillInStackTrace() {
        return this;
    }
    
    static {
        NoStackTraceThrowable.-2043734765 = 1760000983;
        NoStackTraceThrowable.1905216434 = 184;
        NoStackTraceThrowable.-372923945 = invokedynamic(-2057458896:(I)I, false);
        NoStackTraceThrowable.505537845 = invokedynamic(-451637042:(I)I, false);
        NoStackTraceThrowable.173285223 = invokedynamic(-357190229:(J)J, -2554213938784269780L);
        NoStackTraceThrowable.1948958402 = invokedynamic(-116972541:(J)J, 7349874591868649472L);
        NoStackTraceThrowable.1630527798 = ((2 >>> 129 | 2 << ~0x81 + 1) & -1);
        NoStackTraceThrowable.-957440113 = (131072 >>> 177 | 131072 << ~0xB1 + 1);
        NoStackTraceThrowable.1580835093 = new String[NoStackTraceThrowable.1630527798];
        NoStackTraceThrowable.-1621453154 = new String[NoStackTraceThrowable.-957440113];
    }
    // invokedynamic(268093264:()V)
    
    private static Object 277166075(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(NoStackTraceThrowable.class, "518019814", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", NoStackTraceThrowable.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/utils/NoStackTraceThrowable:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String 518019814(final int n, long n2) {
        n2 ^= 0x66L;
        n2 ^= 0x6970CF7808F0D150L;
        if (NoStackTraceThrowable.1580835093[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/utils/NoStackTraceThrowable");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            NoStackTraceThrowable.1580835093[n] = new String(instance.doFinal(Base64.getDecoder().decode(NoStackTraceThrowable.-1621453154[n])));
        }
        return NoStackTraceThrowable.1580835093[n];
    }
    
    private static void 1177643946() {
        NoStackTraceThrowable.-1554090218 = 3769959672884867387L;
        final long n = NoStackTraceThrowable.-1554090218 ^ 0x6970CF7808F0D150L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    NoStackTraceThrowable.-1621453154[0] = "x7FG1yqE3fHuddXjpxzQxw==";
                    break;
                }
                case 1: {
                    NoStackTraceThrowable.-1621453154[0] = "x7FG1yqE3fG81FX3+jTjiH2rGFCS5cnS";
                    break;
                }
                case 2: {
                    NoStackTraceThrowable.-1621453154[0] = "g8dcXIerj/1VleRdmpd2RQ==";
                    break;
                }
                case 4: {
                    NoStackTraceThrowable.-1621453154[0] = "hnp+K+D+dlM=";
                    break;
                }
            }
        }
    }
    
    public static Object -1072702488(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7, final Object o8, final Object o9) throws Exception {
        final int n = ((int)o ^ NoStackTraceThrowable.-2043734765) & 0xFF;
        final Integer value = NoStackTraceThrowable.1905216434;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

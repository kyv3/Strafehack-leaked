// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.utils;

import java.lang.invoke.MutableCallSite;
import javax.xml.bind.DatatypeConverter;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.client.Minecraft;

public class MotionUtil
{
    private static Minecraft mc;
    private static int -658456291;
    private static int 1692985183;
    private static int 1325020758;
    private static int -2026235257;
    private static double -1323924308;
    private static int -391489517;
    private static int 1125051933;
    private static double -966755037;
    private static int 1540517084;
    private static int -1561496947;
    private static int 1803409007;
    private static int -1412400767;
    private static int 148569794;
    private static float -1695082008;
    private static float -804811625;
    private static float 419398419;
    private static int -1715870925;
    private static int -196278787;
    private static int -143216448;
    private static int -302138328;
    private static int -1705907912;
    
    public static boolean isMoving(final EntityLivingBase -1418948766) {
        return ((-1418948766.field_191988_bg != 0.0f || -1418948766.field_70702_br != 0.0f) ? MotionUtil.-658456291 : MotionUtil.1692985183) != 0;
    }
    
    public static void setSpeed(final EntityLivingBase 531761668, final double 310156834) {
        final double[] array = (double[])invokedynamic(308021283:(D)[D, 310156834);
        531761668.field_70159_w = array[MotionUtil.1325020758];
        531761668.field_70179_y = array[MotionUtil.-2026235257];
    }
    
    public static double getBaseMoveSpeed() {
        double 313859010 = MotionUtil.-1323924308;
        if (MotionUtil.mc.field_71439_g != null && invokedynamic(-175421096:(Ljava/lang/Object;Ljava/lang/Object;)Z, MotionUtil.mc.field_71439_g, invokedynamic(2894577:(I)Lnet/minecraft/potion/Potion;, MotionUtil.-391489517))) {
            final int n = invokedynamic(1981740210:(Ljava/lang/Object;)I, invokedynamic(-418503380:(Ljava/lang/Object;Ljava/lang/Object;)Lnet/minecraft/potion/PotionEffect;, MotionUtil.mc.field_71439_g, invokedynamic(-1606958849:(I)Lnet/minecraft/potion/Potion;, MotionUtil.1125051933)));
            313859010 *= 1.0 + MotionUtil.-966755037 * (n + MotionUtil.1540517084);
        }
        return 313859010;
    }
    
    public static double getSpeed(final EntityLivingBase 1419794382) {
        return invokedynamic(173735291:(D)D, 1419794382.field_70159_w * 1419794382.field_70159_w + 1419794382.field_70179_y * 1419794382.field_70179_y);
    }
    
    public static double[] forward(final double -1537908861) {
        float 1529431698 = MotionUtil.mc.field_71439_g.field_71158_b.field_192832_b;
        float field_78902_a = MotionUtil.mc.field_71439_g.field_71158_b.field_78902_a;
        float n = MotionUtil.mc.field_71439_g.field_70126_B + (MotionUtil.mc.field_71439_g.field_70177_z - MotionUtil.mc.field_71439_g.field_70126_B) * invokedynamic(208100467:(Ljava/lang/Object;)F, MotionUtil.mc);
        if (1529431698 != 0.0f) {
            if (field_78902_a > 0.0f) {
                n += ((1529431698 > 0.0f) ? MotionUtil.-1561496947 : MotionUtil.1803409007);
            }
            else if (field_78902_a < 0.0f) {
                n += ((1529431698 > 0.0f) ? MotionUtil.-1412400767 : MotionUtil.148569794);
            }
            field_78902_a = 0.0f;
            if (1529431698 > 0.0f) {
                1529431698 = 1.0f;
            }
            else if (1529431698 < 0.0f) {
                1529431698 = MotionUtil.-1695082008;
            }
        }
        final double n2 = invokedynamic(-807183141:(D)D, invokedynamic(-431967130:(D)D, (double)(n + MotionUtil.-804811625)));
        final double n3 = invokedynamic(-2146756860:(D)D, invokedynamic(1937989600:(D)D, (double)(n + MotionUtil.419398419)));
        final double n4 = 1529431698 * -1537908861 * n3 + field_78902_a * -1537908861 * n2;
        final double 1529431699 = 1529431698 * -1537908861 * n2 - field_78902_a * -1537908861 * n3;
        final double[] array = new double[MotionUtil.-1715870925];
        array[MotionUtil.-196278787] = n4;
        array[MotionUtil.-143216448] = 1529431699;
        return array;
    }
    
    static {
        MotionUtil.-302138328 = -1798510088;
        MotionUtil.-1705907912 = 184;
        MotionUtil.-658456291 = invokedynamic(1119659466:(I)I, Integer.MIN_VALUE);
        MotionUtil.1692985183 = invokedynamic(786017284:(I)I, false);
        MotionUtil.1325020758 = invokedynamic(-1393750628:(I)I, false);
        MotionUtil.-2026235257 = ((268435456 >>> 60 | 268435456 << ~0x3C + 1) & -1);
        MotionUtil.-1323924308 = invokedynamic(-1731504493:(J)D, invokedynamic(-572168460:(J)J, 8881257146915113980L));
        MotionUtil.-391489517 = invokedynamic(-1286741994:(I)I, Integer.MIN_VALUE);
        MotionUtil.1125051933 = ((512 >>> 9 | 512 << -9) & -1);
        MotionUtil.-966755037 = invokedynamic(-754153819:(J)D, invokedynamic(593423494:(J)J, 6456360425798341628L));
        MotionUtil.1540517084 = ((1 >>> 0 | 1 << ~0x0 + 1) & -1);
        MotionUtil.-1561496947 = invokedynamic(1481336498:(I)I, -872415233);
        MotionUtil.1803409007 = (23592960 >>> 51 | 23592960 << ~0x33 + 1);
        MotionUtil.-1412400767 = invokedynamic(132413999:(I)I, -1275068416);
        MotionUtil.148569794 = invokedynamic(-882015904:(I)I, -872415233);
        MotionUtil.-1695082008 = invokedynamic(1537083863:(I)F, invokedynamic(-222390004:(I)I, 509));
        MotionUtil.-804811625 = invokedynamic(2057536757:(I)F, invokedynamic(-1441783479:(I)I, 11586));
        MotionUtil.419398419 = invokedynamic(1292690168:(I)F, invokedynamic(-1717391535:(I)I, 11586));
        MotionUtil.-1715870925 = (16777216 >>> 55 | 16777216 << -55);
        MotionUtil.-196278787 = invokedynamic(2001539653:(I)I, false);
        MotionUtil.-143216448 = invokedynamic(1712910316:(I)I, Integer.MIN_VALUE);
        MotionUtil.mc = invokedynamic(2146892591:()Lnet/minecraft/client/Minecraft;);
    }
    
    public static Object -534535489(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4) throws Exception {
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if ((int)o == 184) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

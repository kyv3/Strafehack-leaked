// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import net.minecraftforge.common.MinecraftForge;
import java.util.List;
import java.util.Iterator;
import com.sten_region_skidrrr.strafehack.module.settings.BooleanSetting;
import java.io.File;
import net.minecraft.client.Minecraft;
import com.sten_region_skidrrr.strafehack.module.settings.Setting;
import java.util.ArrayList;
import com.sten_region_skidrrr.strafehack.module.settings.KeybindSetting;

public class Module
{
    private String name;
    private String description;
    private Category category;
    private boolean expanded;
    public int index;
    public KeybindSetting keybind;
    private ArrayList<Setting> settings;
    public Properties properties;
    protected Minecraft mc;
    private boolean isInit;
    private static String[] -627672166;
    private static String[] -551789883;
    private static long -681900335;
    private static int -455295732;
    private static int 982505071;
    private static long 1450643598;
    private static int -79360939;
    private static long -181629188;
    private static long -1794433238;
    private static int -2092049208;
    private static int -1279626933;
    private static int 599844826;
    private static int 477134229;
    private static int 609191547;
    private static int 932062106;
    private static long -712188709;
    private static long 596115063;
    private static int -23875231;
    private static int -579390430;
    private static int 2131177754;
    private static int -409779968;
    private static int 630579510;
    private static int 668981344;
    private static long -1013796336;
    private static int -981089115;
    private static int 1776776060;
    private static long 761622203;
    private static long 1576763669;
    private static int 2057144565;
    private static long -1302979665;
    private static int -616678377;
    private static int -2042166815;
    private static int -968461418;
    private static int -400501244;
    private static int -437154204;
    private static int 1449422254;
    
    public Properties load() {
        return this.properties;
    }
    
    public void save() {
        this.savePropertiesToFile();
    }
    
    private File getFolder() {
        final File 878716773 = new File(invokedynamic(106257810:()Ljava/io/File;), invokedynamic(-1356925314:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(830571178:(Ljava/lang/Object;)Ljava/lang/Class;, this)));
        // invokedynamic(1627150908:(Ljava/lang/Object;)Z, 878716773)
        return 878716773;
    }
    
    private void savePropertiesToFile() {
    }
    // invokedynamic(-1380127326:(Ljava/lang/Object;Ljava/lang/Object;)Z, new File(this.getFolder(), invokedynamic(640982957:(IJ)Ljava/lang/String;, Module.-455295732 & Module.982505071, Module.1450643598)), this.properties)
    
    private Properties loadPropertiesFromFile() {
        Properties properties = (Properties)invokedynamic(328054561:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;, new File(this.getFolder(), invokedynamic(1381766943:(IJ)Ljava/lang/String;, Module.-79360939, Module.-181629188 ^ Module.-1794433238)), Properties.class);
        if (properties == null) {
            properties = new Properties();
            this.properties = properties;
            this.savePropertiesToFile();
        }
        return properties;
    }
    
    public Module(final String -33851209, final String 542236723, final Category 1384324133, final int -206820863) {
        this.expanded = (Module.-2092049208 != 0);
        this.index = Module.-1279626933;
        this.keybind = new KeybindSetting(Module.599844826);
        this.settings = new ArrayList<Setting>();
        this.properties = new Properties();
        this.mc = invokedynamic(-1917262314:()Lnet/minecraft/client/Minecraft;);
        this.isInit = (Module.477134229 != 0);
        this.isInit = (Module.609191547 != 0);
        if (invokedynamic(-435209167:(Ljava/lang/Object;)Z, new File(this.getFolder(), invokedynamic(-439959256:(IJ)Ljava/lang/String;, Module.932062106, Module.-712188709 ^ Module.596115063)))) {
            this.properties = this.loadPropertiesFromFile();
        }
        else {
            this.isInit = (Module.-23875231 != 0);
        }
        if (this.properties.keycode != 0) {
            this.keybind.code = this.properties.keycode;
        }
        else {
            this.keybind.code = -206820863;
            this.properties.keycode = -206820863;
        }
        // invokedynamic(-1430693697:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.settings, this.keybind)
        if (this.isInit) {
        }
        // invokedynamic(-1376308078:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.properties.settings, null)
        this.name = -33851209;
        this.description = 542236723;
        this.category = 1384324133;
        this.expanded = (Module.-579390430 != 0);
        this.index = Module.2131177754;
    }
    
    public void addSettings(final Setting... 2135748946) {
        // invokedynamic(227386884:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.settings, invokedynamic(-266324202:([Ljava/lang/Object;)Ljava/util/List;, 2135748946))
        if (this.isInit) {
            for (int length = 2135748946.length, i = Module.-409779968; i < length; ++i) {
                final Setting setting = 2135748946[i];
            }
            // invokedynamic(2058109616:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.properties.settings, setting.value)
        }
        else {
            // invokedynamic(-1663681523:(Ljava/lang/Object;Ljava/lang/Object;)V, System.out, invokedynamic(-2127189395:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-1647910921:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(1215876002:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), invokedynamic(2087572920:(IJ)Ljava/lang/String;, Module.630579510 & Module.668981344, Module.-1013796336)), this.name)))
            int 2135748947 = Module.-981089115;
            final Iterator iterator = invokedynamic(-1455516425:(Ljava/lang/Object;)Ljava/util/Iterator;, this.settings);
            while (invokedynamic(-2010379011:(Ljava/lang/Object;)Z, iterator)) {
                final Setting setting2 = (Setting)invokedynamic(-1505997804:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
                if (!(setting2 instanceof KeybindSetting)) {
                    setting2.value = (String)invokedynamic(1316947686:(Ljava/lang/Object;I)Ljava/lang/Object;, this.properties.settings, 2135748947);
                    if (setting2 instanceof BooleanSetting) {
                    }
                    // invokedynamic(-1116944526:(Ljava/lang/Object;Ljava/lang/Object;)V, System.out, invokedynamic(-759406601:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(2016650890:(Ljava/lang/Object;Z)Ljava/lang/StringBuilder;, invokedynamic(74574204:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(987037278:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), setting2.name), invokedynamic(1126082422:(IJ)Ljava/lang/String;, Module.1776776060, Module.761622203 ^ Module.1576763669)), invokedynamic(-2128438894:(Ljava/lang/Object;)Z, (BooleanSetting)setting2))))
                    else {
                    }
                    // invokedynamic(-1406390768:(Ljava/lang/Object;Ljava/lang/Object;)V, System.out, invokedynamic(-633794497:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-1270446731:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-1514252512:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-1425783955:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), setting2.name), invokedynamic(1304817685:(IJ)Ljava/lang/String;, Module.2057144565, Module.-1302979665)), setting2.value)))
                }
                ++2135748947;
            }
        }
    }
    // invokedynamic(-777054395:(Ljava/lang/Object;)V, this)
    
    public void setKeycode(final int 722853183) {
        this.keybind.code = 722853183;
        this.properties.keycode = 722853183;
    }
    // invokedynamic(808593585:(Ljava/lang/Object;)V, this)
    
    public String getName() {
        return this.name;
    }
    
    public List<Setting> getSettings() {
        return this.settings;
    }
    
    public Category getCategory() {
        return this.category;
    }
    
    public String getDescription() {
        return this.description;
    }
    
    public boolean isExpanded() {
        return this.expanded;
    }
    
    public void setExpanded(final boolean 707309695) {
        this.expanded = 707309695;
    }
    
    public boolean isEnabled() {
        return this.properties.enabled;
    }
    
    public void setEnabled(final boolean 851681684) {
        this.properties.enabled = 851681684;
        // invokedynamic(728156513:(Ljava/lang/Object;)V, this)
        if (851681684) {
        }
        // invokedynamic(-984493733:(Ljava/lang/Object;)V, this)
        else {
        }
        // invokedynamic(113814218:(Ljava/lang/Object;)V, this)
    }
    
    public int getKey() {
        return this.keybind.code;
    }
    
    public void onEnable() {
    }
    // invokedynamic(1390061385:(Ljava/lang/Object;Ljava/lang/Object;)V, MinecraftForge.EVENT_BUS, this)
    
    public void onDisable() {
    }
    // invokedynamic(1308320453:(Ljava/lang/Object;Ljava/lang/Object;)V, MinecraftForge.EVENT_BUS, this)
    
    public void onToggle() {
    }
    
    public void Toggle() {
    }
    // invokedynamic(-2128657877:(Ljava/lang/Object;Z)V, this, invokedynamic(962875593:(Ljava/lang/Object;)Z, this) ? Module.-2042166815 : Module.-616678377)
    
    static {
        Module.-437154204 = -149954978;
        Module.1449422254 = 184;
        Module.-455295732 = (0 >>> 150 | 0 << ~0x96 + 1);
        Module.982505071 = invokedynamic(1905559238:(I)I, -1);
        Module.1450643598 = invokedynamic(-367435766:(J)J, 7051371572034719210L);
        Module.-79360939 = invokedynamic(149886758:(I)I, Integer.MIN_VALUE);
        Module.-181629188 = invokedynamic(-1901494149:(J)J, 8204293076641566186L);
        Module.-1794433238 = invokedynamic(734227805:(J)J, 1152921504606846976L);
        Module.-2092049208 = invokedynamic(-561070300:(I)I, false);
        Module.-1279626933 = (0 >>> 20 | 0 << ~0x14 + 1);
        Module.599844826 = invokedynamic(-1006315885:(I)I, false);
        Module.477134229 = invokedynamic(-2089666079:(I)I, false);
        Module.609191547 = (0 >>> 29 | 0 << ~0x1D + 1);
        Module.932062106 = ((16777216 >>> 183 | 16777216 << ~0xB7 + 1) & -1);
        Module.-712188709 = invokedynamic(624025345:(J)J, 8204293076641566186L);
        Module.596115063 = invokedynamic(-1996063959:(J)J, 1152921504606846976L);
        Module.-23875231 = invokedynamic(1310838857:(I)I, Integer.MIN_VALUE);
        Module.-579390430 = ((0 >>> 216 | 0 << ~0xD8 + 1) & -1);
        Module.2131177754 = invokedynamic(-1973747804:(I)I, false);
        Module.-409779968 = ((0 >>> 227 | 0 << ~0xE3 + 1) & -1);
        Module.630579510 = invokedynamic(-165671464:(I)I, -1073741824);
        Module.668981344 = ((-1 >>> 209 | -1 << -209) & -1);
        Module.-1013796336 = invokedynamic(1583192856:(J)J, 7051371572034719210L);
        Module.-981089115 = ((0 >>> 172 | 0 << -172) & -1);
        Module.1776776060 = ((4096 >>> 138 | 4096 << -138) & -1);
        Module.761622203 = invokedynamic(-1865895585:(J)J, 8204293076641566186L);
        Module.1576763669 = invokedynamic(751670413:(J)J, 1152921504606846976L);
        Module.2057144565 = (2560 >>> 201 | 2560 << -201);
        Module.-1302979665 = invokedynamic(208003955:(J)J, 7051371572034719210L);
        Module.-616678377 = invokedynamic(935429764:(I)I, Integer.MIN_VALUE);
        Module.-2042166815 = invokedynamic(-2100090950:(I)I, false);
        Module.-968461418 = invokedynamic(-587410196:(I)I, 1610612736);
        Module.-400501244 = invokedynamic(617866873:(I)I, 1610612736);
        Module.-627672166 = new String[Module.-968461418];
        Module.-551789883 = new String[Module.-400501244];
    }
    // invokedynamic(-2101483809:()V)
    
    private static Object 816525823(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(Module.class, "234851126", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", Module.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/Module:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String 234851126(final int n, long n2) {
        n2 ^= 0x8L;
        n2 ^= 0x6395F2E48E45E3B9L;
        if (Module.-627672166[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/Module");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            Module.-627672166[n] = new String(instance.doFinal(Base64.getDecoder().decode(Module.-551789883[n])));
        }
        return Module.-627672166[n];
    }
    
    private static void 659984384() {
        Module.-681900335 = 6319489550720818062L;
        final long n = Module.-681900335 ^ 0x6395F2E48E45E3B9L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    Module.-551789883[0] = "iVCV6pdjBVjx4WWwpgd/aw==";
                    Module.-551789883[1] = "iVCV6pdjBVjx4WWwpgd/aw==";
                    Module.-551789883[2] = "iVCV6pdjBVjx4WWwpgd/aw==";
                    Module.-551789883[3] = "Cef6zeoKwSA=";
                    Module.-551789883[4] = "P6bIZpqBdqo=";
                    Module.-551789883[5] = "P6bIZpqBdqo=";
                    break;
                }
                case 1: {
                    Module.-551789883[0] = "iVCV6pdjBVjrfQ2pBo2FkTCAE30dhhK4";
                    Module.-551789883[1] = "iVCV6pdjBVizzmuoj9afxrgwJfkGM3XT";
                    Module.-551789883[2] = "iVCV6pdjBVgC5WeHMmD66Ik+LFgGsUj5";
                    Module.-551789883[3] = "FPnChAIrQgM=";
                    Module.-551789883[4] = "3XVey3xX5Xo=";
                    Module.-551789883[5] = "dY7NPoScLDU=";
                    break;
                }
                case 2: {
                    Module.-551789883[0] = "DTF/c/Ne0sfRZqn9BFtbUqp1HKpQaDZh";
                    break;
                }
                case 4: {
                    Module.-551789883[0] = "FllKo9SpYxnNLz5QtLONYQ==";
                    break;
                }
            }
        }
    }
    
    public static Object -754749117(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6) throws Exception {
        final int n = ((int)o ^ Module.-437154204) & 0xFF;
        final Integer value = Module.1449422254;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

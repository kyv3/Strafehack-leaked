// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module.settings;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;

public class BooleanSetting extends Setting
{
    private static String[] 103628828;
    private static String[] -1570720560;
    private static long -1578706727;
    private static int 645080643;
    private static long 2109259964;
    private static int -1626936502;
    private static long -1416734888;
    private static long 1813824249;
    private static int -815410750;
    private static long 1149727827;
    private static long 1322659233;
    private static int 732704979;
    private static long 415220812;
    private static long -773988682;
    private static int 1058666920;
    private static int 1063282204;
    private static int 949004997;
    private static int 773085934;
    
    public BooleanSetting(final String 999324703, final boolean 298009591) {
        this.name = 999324703;
    }
    // invokedynamic(-1900008256:(Ljava/lang/Object;Z)V, this, 298009591)
    
    public boolean isEnabled() {
        return invokedynamic(1289227242:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.value, invokedynamic(221927552:(IJ)Ljava/lang/String;, BooleanSetting.645080643, BooleanSetting.2109259964));
    }
    
    public void setEnabled(final boolean 940660715) {
        this.value = invokedynamic(-954557400:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(31501439:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(1196863655:(Ljava/lang/Object;Z)Ljava/lang/StringBuilder;, new StringBuilder(), 940660715), invokedynamic(-149133624:(IJ)Ljava/lang/String;, BooleanSetting.-1626936502, BooleanSetting.-1416734888 ^ BooleanSetting.1813824249)));
    }
    
    public void Toggle() {
        if (invokedynamic(382793049:(Ljava/lang/Object;)Z, this)) {
            this.value = invokedynamic(47353545:(IJ)Ljava/lang/String;, BooleanSetting.-815410750, BooleanSetting.1149727827 ^ BooleanSetting.1322659233);
        }
        else {
            this.value = invokedynamic(446957815:(IJ)Ljava/lang/String;, BooleanSetting.732704979, BooleanSetting.415220812 ^ BooleanSetting.-773988682);
        }
    }
    
    static {
        BooleanSetting.949004997 = -2093779093;
        BooleanSetting.773085934 = 184;
        BooleanSetting.645080643 = (0 >>> 99 | 0 << ~0x63 + 1);
        BooleanSetting.2109259964 = invokedynamic(2057750836:(J)J, -3785754644594274917L);
        BooleanSetting.-1626936502 = (131072 >>> 49 | 131072 << -49);
        BooleanSetting.-1416734888 = invokedynamic(-55763339:(J)J, -2776948328063283813L);
        BooleanSetting.1813824249 = invokedynamic(-1351207387:(J)J, 1297036692682702848L);
        BooleanSetting.-815410750 = invokedynamic(-750804079:(I)I, 1073741824);
        BooleanSetting.1149727827 = invokedynamic(-1902813308:(J)J, -2776948328063283813L);
        BooleanSetting.1322659233 = invokedynamic(1635997566:(J)J, 1297036692682702848L);
        BooleanSetting.732704979 = invokedynamic(-453456831:(I)I, -1073741824);
        BooleanSetting.415220812 = invokedynamic(544522734:(J)J, -2776948328063283813L);
        BooleanSetting.-773988682 = invokedynamic(897608144:(J)J, 1297036692682702848L);
        BooleanSetting.1058666920 = (1073741824 >>> 252 | 1073741824 << -252);
        BooleanSetting.1063282204 = ((8192 >>> 75 | 8192 << -75) & -1);
        BooleanSetting.103628828 = new String[BooleanSetting.1058666920];
        BooleanSetting.-1570720560 = new String[BooleanSetting.1063282204];
    }
    // invokedynamic(-207905138:()V)
    
    private static Object 1183292911(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(BooleanSetting.class, "-1413764097", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", BooleanSetting.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/settings/BooleanSetting:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String -1413764097(final int n, long n2) {
        n2 ^= 0x48L;
        n2 ^= 0xBC5EFD5F338B8325L;
        if (BooleanSetting.103628828[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/settings/BooleanSetting");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            BooleanSetting.103628828[n] = new String(instance.doFinal(Base64.getDecoder().decode(BooleanSetting.-1570720560[n])));
        }
        return BooleanSetting.103628828[n];
    }
    
    private static void -1924127843() {
        BooleanSetting.-1578706727 = -2760086143483351397L;
        final long n = BooleanSetting.-1578706727 ^ 0xBC5EFD5F338B8325L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    BooleanSetting.-1570720560[0] = "zqeVeF94LMc=";
                    BooleanSetting.-1570720560[1] = "7/kYK5N609U=";
                    BooleanSetting.-1570720560[2] = "53VPYh9Q3oA=";
                    BooleanSetting.-1570720560[3] = "zqeVeF94LMc=";
                    break;
                }
                case 1: {
                    BooleanSetting.-1570720560[0] = "fA5epSXW/eQ=";
                    BooleanSetting.-1570720560[1] = "gFgM1Mxds4Q=";
                    BooleanSetting.-1570720560[2] = "wKXkX0VKh/s=";
                    BooleanSetting.-1570720560[3] = "3MYiiY16EI7SixMNfMuAcA==";
                    break;
                }
                case 2: {
                    BooleanSetting.-1570720560[0] = "BcRPiNYY49umbffQTbr2wA==";
                    break;
                }
                case 4: {
                    BooleanSetting.-1570720560[0] = "+luHGD/6J0lYAigCZ+d0KA==";
                    break;
                }
            }
        }
    }
    
    public static Object 429089596(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7, final Object o8, final Object o9) throws Exception {
        final int n = ((int)o ^ BooleanSetting.949004997) & 0xFF;
        final Integer value = BooleanSetting.773085934;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

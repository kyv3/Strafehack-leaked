// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module.settings;

public class Setting
{
    public String name;
    public boolean focussed;
    public String value;
}

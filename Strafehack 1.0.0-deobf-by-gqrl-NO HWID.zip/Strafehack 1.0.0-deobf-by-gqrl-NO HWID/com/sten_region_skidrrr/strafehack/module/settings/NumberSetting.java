// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module.settings;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;

public class NumberSetting extends Setting
{
    private double minimum;
    private double maximum;
    private static String[] 1245999097;
    private static String[] -1746391377;
    private static long -1313031852;
    private static int 1656405671;
    private static long -935497614;
    private static long 73461517;
    private static int -1359481806;
    private static long -1777670303;
    private static int -360376921;
    private static int 1999423802;
    private static int 18345151;
    private static int 1984803587;
    private static int -1426363270;
    private static int 970218185;
    
    public NumberSetting(final String 92904557, final double 678540102, final double 1375833867, final double 33253275) {
        this.name = 92904557;
        this.value = invokedynamic(532066958:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-511453856:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(1599797887:(Ljava/lang/Object;D)Ljava/lang/StringBuilder;, new StringBuilder(), 678540102), invokedynamic(-368461346:(IJ)Ljava/lang/String;, NumberSetting.1656405671, NumberSetting.-935497614 ^ NumberSetting.73461517)));
        this.minimum = 1375833867;
        this.maximum = 33253275;
    }
    
    public double getValue() {
        return invokedynamic(-846797173:(Ljava/lang/Object;)D, this.value);
    }
    
    public void setValue(final double 1016784967) {
        this.value = invokedynamic(-1771627839:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(1394988666:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-1897214592:(Ljava/lang/Object;J)Ljava/lang/StringBuilder;, new StringBuilder(), invokedynamic(-1546646795:(D)J, invokedynamic(30416904:(DD)D, this.minimum, invokedynamic(1396667751:(DD)D, this.maximum, 1016784967)))), invokedynamic(-490804981:(IJ)Ljava/lang/String;, NumberSetting.-1359481806, NumberSetting.-1777670303)));
    }
    
    public void increment(final boolean 2090217919) {
    }
    // invokedynamic(1147255057:(Ljava/lang/Object;D)V, this, invokedynamic(1954260935:(Ljava/lang/Object;)D, this) + (double)2090217919 ? NumberSetting.-360376921 : NumberSetting.1999423802)
    
    public double getMinimum() {
        return this.minimum;
    }
    
    public void setMinimum(final double -1449038094) {
        this.minimum = -1449038094;
    }
    
    public double getMaximum() {
        return this.maximum;
    }
    
    public void setMaximum(final double 2111062297) {
        this.maximum = 2111062297;
    }
    
    static {
        NumberSetting.-1426363270 = -131051416;
        NumberSetting.970218185 = 184;
        NumberSetting.1656405671 = (0 >>> 130 | 0 << -130);
        NumberSetting.-935497614 = invokedynamic(-2120701782:(J)J, -6585496904497317137L);
        NumberSetting.73461517 = invokedynamic(-844773395:(J)J, -8646911284551352320L);
        NumberSetting.-1359481806 = invokedynamic(472857400:(I)I, Integer.MIN_VALUE);
        NumberSetting.-1777670303 = invokedynamic(1545764606:(J)J, 3214335884660882159L);
        NumberSetting.-360376921 = (131072 >>> 49 | 131072 << -49);
        NumberSetting.1999423802 = (-1 >>> 131 | -1 << -131);
        NumberSetting.18345151 = invokedynamic(814831949:(I)I, 1073741824);
        NumberSetting.1984803587 = invokedynamic(531714872:(I)I, 1073741824);
        NumberSetting.1245999097 = new String[NumberSetting.18345151];
        NumberSetting.-1746391377 = new String[NumberSetting.1984803587];
    }
    // invokedynamic(1006166578:()V)
    
    private static Object 1845949386(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(NumberSetting.class, "-424799646", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", NumberSetting.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/settings/NumberSetting:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String -424799646(final int n, long n2) {
        n2 ^= 0x11L;
        n2 ^= 0x6A4390E219CF3243L;
        if (NumberSetting.1245999097[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/settings/NumberSetting");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            NumberSetting.1245999097[n] = new String(instance.doFinal(Base64.getDecoder().decode(NumberSetting.-1746391377[n])));
        }
        return NumberSetting.1245999097[n];
    }
    
    private static void 1004376890() {
        NumberSetting.-1313031852 = -622340833420912347L;
        final long n = NumberSetting.-1313031852 ^ 0x6A4390E219CF3243L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    NumberSetting.-1746391377[0] = "ToA7aLRw1IQ=";
                    NumberSetting.-1746391377[1] = "ToA7aLRw1IQ=";
                    break;
                }
                case 1: {
                    NumberSetting.-1746391377[0] = "lcerk0Ud6W0=";
                    NumberSetting.-1746391377[1] = "sDVpHtScKgQ=";
                    break;
                }
                case 2: {
                    NumberSetting.-1746391377[0] = "+qPOg/J0t/+7b9kwcbCBBQ==";
                    break;
                }
                case 4: {
                    NumberSetting.-1746391377[0] = "GJVT5p0rEqqPWEsP2f7NA86y69gr5h8p";
                    break;
                }
            }
        }
    }
    
    public static Object -1790669272(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6) throws Exception {
        final int n = ((int)o ^ NumberSetting.-1426363270) & 0xFF;
        final Integer value = NumberSetting.970218185;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

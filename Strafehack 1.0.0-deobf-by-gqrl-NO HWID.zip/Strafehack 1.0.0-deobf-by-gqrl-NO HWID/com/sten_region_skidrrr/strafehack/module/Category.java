// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import java.util.Iterator;

public enum Category
{
    Combat(invokedynamic(1389645957:(IJ)Ljava/lang/String;, Category.1423843926, Category.779439316 ^ Category.628186661)), 
    Movement(invokedynamic(-440995585:(IJ)Ljava/lang/String;, Category.564129550 & Category.1159897011, Category.401687127)), 
    Player(invokedynamic(-753325615:(IJ)Ljava/lang/String;, Category.-1652540732 & Category.71818036, Category.-1682622700)), 
    Render(invokedynamic(-729401210:(IJ)Ljava/lang/String;, Category.543630138, Category.-670753551 ^ Category.-1495646024)), 
    Other(invokedynamic(-184599119:(IJ)Ljava/lang/String;, Category.-802247457 & Category.1748659219, Category.-845763156));
    
    public String name;
    public int moduleIndex;
    private static String[] 610354709;
    private static String[] -1981316460;
    private static long -1587581331;
    private static int 975386465;
    private static int -64432571;
    private static int -142741843;
    private static int -1179331604;
    private static long -1035879925;
    private static int -431760824;
    private static int 235732643;
    private static int -1236014416;
    private static long 631788583;
    private static long -150990172;
    private static int 1145869812;
    private static int 1423843926;
    private static long 779439316;
    private static long 628186661;
    private static int -1912585805;
    private static long 496994711;
    private static long -211587956;
    private static int -899280950;
    private static int 564129550;
    private static int 1159897011;
    private static long 401687127;
    private static int 1909325944;
    private static int -1044142046;
    private static long -1656837941;
    private static int -273712247;
    private static int -1652540732;
    private static int 71818036;
    private static long -1682622700;
    private static int 374544749;
    private static long -557109915;
    private static long 145614450;
    private static int 494276569;
    private static int 543630138;
    private static long -670753551;
    private static long -1495646024;
    private static int -378413765;
    private static long 395163762;
    private static long -138086209;
    private static int -1107649512;
    private static int -802247457;
    private static int 1748659219;
    private static long -845763156;
    private static int -1022566260;
    private static int -1722871790;
    private static int -969331353;
    private static int 19664113;
    private static int 1374780842;
    private static int -351333913;
    private static int -2040928465;
    private static int -1169097811;
    
    private Category(final String 2107517584) {
        this.name = 2107517584;
    }
    
    public static int size(final Category 120764832) {
        int 120764834 = Category.975386465;
        final Iterator iterator = invokedynamic(-250877781:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(1428579924:()Ljava/util/ArrayList;));
        while (invokedynamic(2124201515:(Ljava/lang/Object;)Z, iterator)) {
            final Module 120764833 = (Module)invokedynamic(540179734:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
            if (invokedynamic(56364931:(Ljava/lang/Object;)Lcom/sten_region_skidrrr/strafehack/module/Category;, 120764833) == 120764832) {
                ++120764834;
            }
        }
        return 120764834;
    }
    
    public static int placeInList(final Module -473679092, final Category -885829757) {
        int -885829758 = Category.-64432571;
        final Iterator iterator = invokedynamic(-972726789:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(1360119112:()Ljava/util/ArrayList;));
        while (invokedynamic(1109120498:(Ljava/lang/Object;)Z, iterator)) {
            final Module module = (Module)invokedynamic(985115532:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
            if (invokedynamic(-2126304203:(Ljava/lang/Object;)Ljava/lang/String;, module) != invokedynamic(844111878:(IJ)Ljava/lang/String;, Category.-142741843 & Category.-1179331604, Category.-1035879925)) {
                if (invokedynamic(-1329963542:(Ljava/lang/Object;)Lcom/sten_region_skidrrr/strafehack/module/Category;, module) == -885829757 && module != -473679092) {
                    ++-885829758;
                }
                else {
                    if (invokedynamic(537739663:(Ljava/lang/Object;)Lcom/sten_region_skidrrr/strafehack/module/Category;, module) == -885829757 && module == -473679092) {
                        return -885829758;
                    }
                    continue;
                }
            }
        }
        return -885829758;
    }
    
    static {
        Category.-2040928465 = 1218619659;
        Category.-1169097811 = 184;
        Category.975386465 = (0 >>> 45 | 0 << -45);
        Category.-64432571 = (0 >>> 162 | 0 << ~0xA2 + 1);
        Category.-142741843 = ((0 >>> 29 | 0 << ~0x1D + 1) & -1);
        Category.-1179331604 = invokedynamic(-470570628:(I)I, -1);
        Category.-1035879925 = invokedynamic(-928327805:(J)J, 5245251670806023619L);
        Category.-431760824 = invokedynamic(483854952:(I)I, -805306368);
        Category.235732643 = invokedynamic(-1181221015:(I)I, -805306368);
        Category.-1236014416 = ((16777216 >>> 24 | 16777216 << -24) & -1);
        Category.631788583 = invokedynamic(1768757394:(J)J, -6572193751414157885L);
        Category.-150990172 = invokedynamic(-1268507416:(J)J, -1441151880758558720L);
        Category.1145869812 = (0 >>> 85 | 0 << -85);
        Category.1423843926 = ((2 >>> 96 | 2 << ~0x60 + 1) & -1);
        Category.779439316 = invokedynamic(1100280979:(J)J, -6572193751414157885L);
        Category.628186661 = invokedynamic(-53838331:(J)J, -1441151880758558720L);
        Category.-1912585805 = (3072 >>> 106 | 3072 << -106);
        Category.496994711 = invokedynamic(1261114466:(J)J, -6572193751414157885L);
        Category.-211587956 = invokedynamic(-319028404:(J)J, -1441151880758558720L);
        Category.-899280950 = (524288 >>> 115 | 524288 << -115);
        Category.564129550 = ((2 >>> 255 | 2 << -255) & -1);
        Category.1159897011 = ((-1 >>> 250 | -1 << -250) & -1);
        Category.401687127 = invokedynamic(99452220:(J)J, 5245251670806023619L);
        Category.1909325944 = ((83886080 >>> 184 | 83886080 << -184) & -1);
        Category.-1044142046 = invokedynamic(-171993152:(I)I, -1);
        Category.-1656837941 = invokedynamic(1090099273:(J)J, 5245251670806023619L);
        Category.-273712247 = (512 >>> 72 | 512 << -72);
        Category.-1652540732 = ((1572864 >>> 146 | 1572864 << -146) & -1);
        Category.71818036 = invokedynamic(-1346926307:(I)I, -1);
        Category.-1682622700 = invokedynamic(111759793:(J)J, 5245251670806023619L);
        Category.374544749 = invokedynamic(1051529629:(I)I, -536870912);
        Category.-557109915 = invokedynamic(-929468664:(J)J, -6572193751414157885L);
        Category.145614450 = invokedynamic(2104046872:(J)J, -1441151880758558720L);
        Category.494276569 = (402653184 >>> 187 | 402653184 << -187);
        Category.543630138 = invokedynamic(2059123213:(I)I, 268435456);
        Category.-670753551 = invokedynamic(224561873:(J)J, -6572193751414157885L);
        Category.-1495646024 = invokedynamic(1875147878:(J)J, -1441151880758558720L);
        Category.-378413765 = (288 >>> 197 | 288 << -197);
        Category.395163762 = invokedynamic(-1234585262:(J)J, -6572193751414157885L);
        Category.-138086209 = invokedynamic(1520748418:(J)J, -1441151880758558720L);
        Category.-1107649512 = invokedynamic(-941673683:(I)I, 536870912);
        Category.-802247457 = ((160 >>> 132 | 160 << -132) & -1);
        Category.1748659219 = ((-1 >>> 114 | -1 << ~0x72 + 1) & -1);
        Category.-845763156 = invokedynamic(-1674371338:(J)J, 5245251670806023619L);
        Category.-1022566260 = (163840 >>> 111 | 163840 << ~0x6F + 1);
        Category.-1722871790 = invokedynamic(-1035691995:(I)I, false);
        Category.-969331353 = invokedynamic(831105851:(I)I, Integer.MIN_VALUE);
        Category.19664113 = (128 >>> 166 | 128 << -166);
        Category.1374780842 = ((50331648 >>> 216 | 50331648 << -216) & -1);
        Category.-351333913 = invokedynamic(556291104:(I)I, 536870912);
        Category.610354709 = new String[Category.-431760824];
        Category.-1981316460 = new String[Category.235732643];
        // invokedynamic(1502048598:()V)
        final Category[] $values = new Category[Category.-1022566260];
        $values[Category.-1722871790] = Category.Combat;
        $values[Category.-969331353] = Category.Movement;
        $values[Category.19664113] = Category.Player;
        $values[Category.1374780842] = Category.Render;
        $values[Category.-351333913] = Category.Other;
        $VALUES = $values;
    }
    
    private static Object 602318340(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(Category.class, "-1373571774", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", Category.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/Category:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String -1373571774(final int n, long n2) {
        n2 ^= 0x37L;
        n2 ^= 0x53F201325909ECDBL;
        if (Category.610354709[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/Category");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            Category.610354709[n] = new String(instance.doFinal(Base64.getDecoder().decode(Category.-1981316460[n])));
        }
        return Category.610354709[n];
    }
    
    private static void 954537333() {
        Category.-1587581331 = -4345032710368570587L;
        final long n = Category.-1587581331 ^ 0x53F201325909ECDBL;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    Category.-1981316460[0] = "OVPdspHvOGA=";
                    Category.-1981316460[1] = "lducRSExo2Q=";
                    Category.-1981316460[2] = "lducRSExo2Q=";
                    Category.-1981316460[3] = "qQ+d7q4su3Ty1CahoR8qAA==";
                    Category.-1981316460[4] = "qQ+d7q4su3Ty1CahoR8qAA==";
                    Category.-1981316460[5] = "X6/irh3gE3g=";
                    Category.-1981316460[6] = "X6/irh3gE3g=";
                    Category.-1981316460[7] = "AF2XkwBzKVI=";
                    Category.-1981316460[8] = "AF2XkwBzKVI=";
                    Category.-1981316460[9] = "C8cZmK2yngM=";
                    Category.-1981316460[10] = "C8cZmK2yngM=";
                    break;
                }
                case 1: {
                    Category.-1981316460[0] = "lVFhjxwE4xg=";
                    Category.-1981316460[1] = "fnS6zGhsHxbPM29QQkHX4A==";
                    Category.-1981316460[2] = "eAXc0/aWdQIzhZx9iIUvAA==";
                    Category.-1981316460[3] = "qQ+d7q4su3SLYkhN9aQOiQ==";
                    Category.-1981316460[4] = "qQ+d7q4su3SFqtKV2wblmg==";
                    Category.-1981316460[5] = "QOClnEMAXqzOm5k6a2CVCQ==";
                    Category.-1981316460[6] = "HZkG4NhnR2xK5QWr05AtBw==";
                    Category.-1981316460[7] = "+69QyCU72j6Xrum6z1+xPg==";
                    Category.-1981316460[8] = "qfH6P8KNKznD9MdqDth5tA==";
                    Category.-1981316460[9] = "Jru3tSFu/JRGwkAiLvShoQ==";
                    Category.-1981316460[10] = "274IL15XKzVw/ydkrsu7xA==";
                    break;
                }
                case 2: {
                    Category.-1981316460[0] = "64Il+Z9+QfI=";
                    break;
                }
                case 4: {
                    Category.-1981316460[0] = "tK9m5ae3R35siDiUFSgkmQ==";
                    break;
                }
            }
        }
    }
    
    public static Object 203617110(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7) throws Exception {
        final int n = ((int)o ^ Category.-2040928465) & 0xFF;
        final Integer value = Category.-1169097811;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

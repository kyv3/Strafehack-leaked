// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module.modules.player;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.living.LivingEvent;
import com.sten_region_skidrrr.strafehack.module.Category;
import com.sten_region_skidrrr.strafehack.module.Module;

public class NoFall extends Module
{
    private static String[] 1118645201;
    private static String[] 595457646;
    private static long -584280133;
    private static int -1491874383;
    private static long 1555757122;
    private static long 1408328538;
    private static int 905387972;
    private static long -1632717708;
    private static long -889074023;
    private static int -70625300;
    private static int -1113237890;
    private static int 456586187;
    private static int 1210448029;
    private static int -977619307;
    private static int -1851202684;
    
    public NoFall() {
        super(invokedynamic(1034103851:(IJ)Ljava/lang/String;, NoFall.-1491874383, NoFall.1555757122 ^ NoFall.1408328538), invokedynamic(777435871:(IJ)Ljava/lang/String;, NoFall.905387972, NoFall.-1632717708 ^ NoFall.-889074023), Category.Player, NoFall.-70625300);
    }
    
    @SubscribeEvent
    public void onUpdate(final LivingEvent.LivingUpdateEvent -861248579) {
        if (invokedynamic(-2096614820:(Ljava/lang/Object;)Lnet/minecraft/entity/EntityLivingBase;, -861248579) instanceof EntityPlayer) {
        }
        // invokedynamic(517111449:(Ljava/lang/Object;Ljava/lang/Object;)V, invokedynamic(-1385877156:(Ljava/lang/Object;)Lnet/minecraft/client/network/NetHandlerPlayClient;, this.mc), new CPacketPlayer((boolean)NoFall.-1113237890))
    }
    
    static {
        NoFall.-977619307 = 1814870540;
        NoFall.-1851202684 = 184;
        NoFall.-1491874383 = invokedynamic(1773698379:(I)I, false);
        NoFall.1555757122 = invokedynamic(624118177:(J)J, -1082526781823976945L);
        NoFall.1408328538 = invokedynamic(-831115139:(J)J, -5908722711110090752L);
        NoFall.905387972 = (2 >>> 193 | 2 << ~0xC1 + 1);
        NoFall.-1632717708 = invokedynamic(129288816:(J)J, -1082526781823976945L);
        NoFall.-889074023 = invokedynamic(1512315898:(J)J, -5908722711110090752L);
        NoFall.-70625300 = invokedynamic(-96079250:(I)I, false);
        NoFall.-1113237890 = (32 >>> 229 | 32 << -229);
        NoFall.456586187 = (16384 >>> 109 | 16384 << -109);
        NoFall.1210448029 = invokedynamic(-758239230:(I)I, 1073741824);
        NoFall.1118645201 = new String[NoFall.456586187];
        NoFall.595457646 = new String[NoFall.1210448029];
    }
    // invokedynamic(-2142950075:()V)
    
    private static Object 411526423(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(NoFall.class, "-239891880", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", NoFall.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/player/NoFall:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String -239891880(final int n, long n2) {
        n2 ^= 0x75L;
        n2 ^= 0x6B566D83D47A95AAL;
        if (NoFall.1118645201[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/player/NoFall");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            NoFall.1118645201[n] = new String(instance.doFinal(Base64.getDecoder().decode(NoFall.595457646[n])));
        }
        return NoFall.1118645201[n];
    }
    
    private static void -1897147849() {
        NoFall.-584280133 = -1126161895453597937L;
        final long n = NoFall.-584280133 ^ 0x6B566D83D47A95AAL;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    NoFall.595457646[0] = "a0HSz51ye/c=";
                    NoFall.595457646[1] = "ON15XI36QttWhGDqR3SHcNx6krKHnIe7";
                    break;
                }
                case 1: {
                    NoFall.595457646[0] = "U+3XGLCLHWk1oj6SQVZLiQ==";
                    NoFall.595457646[1] = "ON15XI36QttWhGDqR3SHcCbQfAHALn4a";
                    break;
                }
                case 2: {
                    NoFall.595457646[0] = "Nvb/0Hh99L4ZsUPb5elE6A==";
                    break;
                }
                case 4: {
                    NoFall.595457646[0] = "De4ebMsSCrpNOHNl1MkE8Q==";
                    break;
                }
            }
        }
    }
    
    public static Object -1324229408(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6) throws Exception {
        final int n = ((int)o ^ NoFall.-977619307) & 0xFF;
        final Integer value = NoFall.-1851202684;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

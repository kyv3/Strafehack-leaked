// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module.modules.player;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import com.sten_region_skidrrr.strafehack.module.Category;
import com.sten_region_skidrrr.strafehack.module.Module;

public class AntiHunger extends Module
{
    private static String[] -1453752994;
    private static String[] -1303035145;
    private static long -723977655;
    private static int 437223156;
    private static long -1239208381;
    private static long -866984857;
    private static int -1754350360;
    private static int -1072213421;
    private static long 193809442;
    private static int -1879235004;
    private static int -2124915650;
    private static int 923105484;
    private static int -2047508930;
    private static int 1437782402;
    
    public AntiHunger() {
        super(invokedynamic(-531174337:(IJ)Ljava/lang/String;, AntiHunger.437223156, AntiHunger.-1239208381 ^ AntiHunger.-866984857), invokedynamic(1956721964:(IJ)Ljava/lang/String;, AntiHunger.-1754350360 & AntiHunger.-1072213421, AntiHunger.193809442), Category.Player, AntiHunger.-1879235004);
    }
    
    static {
        AntiHunger.-2047508930 = -1147708621;
        AntiHunger.1437782402 = 184;
        AntiHunger.437223156 = invokedynamic(-1431437808:(I)I, false);
        AntiHunger.-1239208381 = invokedynamic(1009653133:(J)J, -4021822887437493258L);
        AntiHunger.-866984857 = invokedynamic(-1561327211:(J)J, 1008806316530991104L);
        AntiHunger.-1754350360 = ((268435456 >>> 124 | 268435456 << ~0x7C + 1) & -1);
        AntiHunger.-1072213421 = (-1 >>> 38 | -1 << ~0x26 + 1);
        AntiHunger.193809442 = invokedynamic(-1405226276:(J)J, -4165938075513349130L);
        AntiHunger.-1879235004 = (0 >>> 13 | 0 << -13);
        AntiHunger.-2124915650 = ((8192 >>> 140 | 8192 << -140) & -1);
        AntiHunger.923105484 = (268435456 >>> 91 | 268435456 << -91);
        AntiHunger.-1453752994 = new String[AntiHunger.-2124915650];
        AntiHunger.-1303035145 = new String[AntiHunger.923105484];
    }
    // invokedynamic(741375482:()V)
    
    private static Object 1780660474(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(AntiHunger.class, "-1013560643", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", AntiHunger.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/player/AntiHunger:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String -1013560643(final int n, long n2) {
        n2 ^= 0x70L;
        n2 ^= 0xF3934776EDF40511L;
        if (AntiHunger.-1453752994[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/player/AntiHunger");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            AntiHunger.-1453752994[n] = new String(instance.doFinal(Base64.getDecoder().decode(AntiHunger.-1303035145[n])));
        }
        return AntiHunger.-1453752994[n];
    }
    
    private static void -2097359776() {
        AntiHunger.-723977655 = 8059476504909313043L;
        final long n = AntiHunger.-723977655 ^ 0xF3934776EDF40511L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    AntiHunger.-1303035145[0] = "nTNiVQvsVGag0PphFOf4Cw==";
                    AntiHunger.-1303035145[1] = "MKBS5mEKh05lqsJfwcfmhR3gxaET00yfOoyuNb2K7xzUvOYczsv7kw==";
                    break;
                }
                case 1: {
                    AntiHunger.-1303035145[0] = "nTNiVQvsVGZ0np6kB8gJjQ==";
                    AntiHunger.-1303035145[1] = "MKBS5mEKh05lqsJfwcfmhR3gxaET00yfOoyuNb2K7xxW4VkqHi9CnA==";
                    break;
                }
                case 2: {
                    AntiHunger.-1303035145[0] = "GqFSzJA6rrgoXS1KfvxYZoHjKrakF1GC";
                    break;
                }
                case 4: {
                    AntiHunger.-1303035145[0] = "RdMR/etswDzgvMeRqk8Esw==";
                    break;
                }
            }
        }
    }
    
    public static Object 1323309650(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7, final Object o8) throws Exception {
        final int n = ((int)o ^ AntiHunger.-2047508930) & 0xFF;
        final Integer value = AntiHunger.1437782402;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module.modules.player;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import java.lang.reflect.Field;
import net.minecraftforge.event.entity.living.LivingEvent;
import com.sten_region_skidrrr.strafehack.module.Category;
import com.sten_region_skidrrr.strafehack.module.Module;

public class FastPlace extends Module
{
    private static String[] 331085635;
    private static String[] -612700821;
    private static long 1671117961;
    private static int -710139553;
    private static long -1907432151;
    private static long -1344110838;
    private static int -1279007629;
    private static long -2061901229;
    private static long 621406639;
    private static int -812345803;
    private static int 1939852160;
    private static long 1234678289;
    private static long 12343653;
    private static int 611978076;
    private static int -1751384751;
    private static int -210590414;
    private static int 214914813;
    private static int -552691772;
    private static int -63934548;
    
    public FastPlace() {
        super(invokedynamic(-2129223045:(IJ)Ljava/lang/String;, FastPlace.-710139553, FastPlace.-1907432151 ^ FastPlace.-1344110838), invokedynamic(-670739206:(IJ)Ljava/lang/String;, FastPlace.-1279007629, FastPlace.-2061901229 ^ FastPlace.621406639), Category.Player, FastPlace.-812345803);
    }
    
    @SubscribeEvent
    public void onUpdate(final LivingEvent.LivingUpdateEvent 252790810) throws Exception {
        final Field field = invokedynamic(1911176895:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/reflect/Field;, invokedynamic(271749098:(Ljava/lang/Object;)Ljava/lang/Class;, invokedynamic(371897209:(Ljava/lang/Object;)Lnet/minecraft/client/renderer/entity/RenderManager;, this.mc)), invokedynamic(-1486821017:(IJ)Ljava/lang/String;, FastPlace.1939852160, FastPlace.1234678289 ^ FastPlace.12343653));
        // invokedynamic(-167085235:(Ljava/lang/Object;Z)V, field, FastPlace.611978076)
        int 252790811 = invokedynamic(-461760957:(Ljava/lang/Object;)I, (Integer)invokedynamic(1942906026:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;, field, invokedynamic(-633844214:(Ljava/lang/Object;)Lnet/minecraft/client/renderer/entity/RenderManager;, this.mc)));
        252790811 = FastPlace.-1751384751;
    }
    
    static {
        FastPlace.-552691772 = 1477412095;
        FastPlace.-63934548 = 184;
        FastPlace.-710139553 = (0 >>> 236 | 0 << ~0xEC + 1);
        FastPlace.-1907432151 = invokedynamic(-1168747630:(J)J, 1718240155678974680L);
        FastPlace.-1344110838 = invokedynamic(-1857431584:(J)J, -3602879701896396800L);
        FastPlace.-1279007629 = (2 >>> 193 | 2 << -193);
        FastPlace.-2061901229 = invokedynamic(1581650220:(J)J, 1718240155678974680L);
        FastPlace.621406639 = invokedynamic(1810406820:(J)J, -3602879701896396800L);
        FastPlace.-812345803 = invokedynamic(791643587:(I)I, false);
        FastPlace.1939852160 = invokedynamic(844440312:(I)I, 1073741824);
        FastPlace.1234678289 = invokedynamic(-2076253117:(J)J, 1718240155678974680L);
        FastPlace.12343653 = invokedynamic(1591736706:(J)J, -3602879701896396800L);
        FastPlace.611978076 = invokedynamic(-890447884:(I)I, Integer.MIN_VALUE);
        FastPlace.-1751384751 = invokedynamic(-1706198400:(I)I, false);
        FastPlace.-210590414 = invokedynamic(1524635843:(I)I, -1073741824);
        FastPlace.214914813 = ((786432 >>> 178 | 786432 << ~0xB2 + 1) & -1);
        FastPlace.331085635 = new String[FastPlace.-210590414];
        FastPlace.-612700821 = new String[FastPlace.214914813];
    }
    // invokedynamic(-1993412830:()V)
    
    private static Object -725316850(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(FastPlace.class, "864853757", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", FastPlace.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/player/FastPlace:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String 864853757(final int n, long n2) {
        n2 ^= 0x73L;
        n2 ^= 0xB81E07A92A92D692L;
        if (FastPlace.331085635[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/player/FastPlace");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            FastPlace.331085635[n] = new String(instance.doFinal(Base64.getDecoder().decode(FastPlace.-612700821[n])));
        }
        return FastPlace.331085635[n];
    }
    
    private static void 138647431() {
        FastPlace.1671117961 = 1965100398126963688L;
        final long n = FastPlace.1671117961 ^ 0xB81E07A92A92D692L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    FastPlace.-612700821[0] = "Y9cnvL64Ay74UiiCS4z8jg==";
                    FastPlace.-612700821[1] = "TWRpDAhepOhy5roaKQSkv/rx1yCsNi+T6makFgZmJ/muX7XBG/onuw==";
                    FastPlace.-612700821[2] = "RX3xHtxRDrnEy5WgLunpVkw8UL34acDU";
                    break;
                }
                case 1: {
                    FastPlace.-612700821[0] = "Y9cnvL64Ay47XSoInGVlww==";
                    FastPlace.-612700821[1] = "TWRpDAhepOhy5roaKQSkv/rx1yCsNi+T6makFgZmJ/mFFBbowrvQtLuYXXCm0v1r";
                    FastPlace.-612700821[2] = "RX3xHtxRDrnEy5WgLunpVl5fY8DdICyQ";
                    break;
                }
                case 2: {
                    FastPlace.-612700821[0] = "50sFSJgDo3E=";
                    break;
                }
                case 4: {
                    FastPlace.-612700821[0] = "OEujTBXS4CpfgqeqCKLOyw==";
                    break;
                }
            }
        }
    }
    
    public static Object -1359793876(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7, final Object o8) throws Exception {
        final int n = ((int)o ^ FastPlace.-552691772) & 0xFF;
        final Integer value = FastPlace.-63934548;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

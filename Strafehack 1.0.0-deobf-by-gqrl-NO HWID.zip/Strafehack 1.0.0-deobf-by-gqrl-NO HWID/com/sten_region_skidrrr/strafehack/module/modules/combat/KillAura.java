// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module.modules.combat;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import java.util.Iterator;
import net.minecraft.util.EnumHand;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.entity.Entity;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.living.LivingEvent;
import com.sten_region_skidrrr.strafehack.module.Category;
import net.minecraft.entity.EntityLivingBase;
import com.sten_region_skidrrr.strafehack.module.Module;

public class KillAura extends Module
{
    private EntityLivingBase target;
    private long current;
    private long last;
    private int delay;
    private float yaw;
    private float pitch;
    private boolean others;
    private static String[] 1600954437;
    private static String[] 1279785722;
    private static long 1205012502;
    private static int 132311951;
    private static int -523484021;
    private static long 1555702252;
    private static int -1024075181;
    private static int -448359013;
    private static long 1077422105;
    private static int 294138714;
    private static int -1922611385;
    private static int -696480391;
    private static long -1042549775;
    private static long -531953035;
    private static int -256924525;
    private static int 364816182;
    private static int 2006899168;
    private static int -1460903325;
    private static int 797834381;
    private static int -177057325;
    private static int -467758892;
    
    public KillAura() {
        super(invokedynamic(443193277:(IJ)Ljava/lang/String;, KillAura.132311951 & KillAura.-523484021, KillAura.1555702252), invokedynamic(-237937454:(IJ)Ljava/lang/String;, KillAura.-1024075181 & KillAura.-448359013, KillAura.1077422105), Category.Combat, KillAura.294138714);
        this.delay = KillAura.-1922611385;
    }
    
    @SubscribeEvent
    public void onPre(final LivingEvent.LivingUpdateEvent -955819222) {
        if (invokedynamic(-752008791:(Ljava/lang/Object;)Lnet/minecraft/entity/EntityLivingBase;, -955819222) != null && invokedynamic(-225736090:(Ljava/lang/Object;)Lnet/minecraft/entity/EntityLivingBase;, -955819222) instanceof EntityPlayer) {
            if (invokedynamic(-2052231894:(Ljava/lang/Object;)Lnet/minecraftforge/fml/common/eventhandler/EventPriority;, -955819222) == EventPriority.LOWEST) {
                this.target = this.getClosest((double)invokedynamic(-2140212049:(Ljava/lang/Object;)F, this.mc.field_71442_b));
                if (this.target == null) {
                    return;
                }
                this.updateTime();
                this.yaw = this.mc.field_71439_g.field_70177_z;
                this.pitch = this.mc.field_71439_g.field_70125_A;
                if (this.current - this.last > KillAura.-696480391 / this.delay) {
                    this.attack((Entity)this.target);
                    this.resetTime();
                }
            }
            else if (invokedynamic(491390902:(Ljava/lang/Object;)Lnet/minecraftforge/fml/common/eventhandler/EventPriority;, -955819222) == EventPriority.HIGHEST) {
                if (this.target == null) {
                    return;
                }
                this.mc.field_71439_g.field_70177_z = this.yaw;
                this.mc.field_71439_g.field_70125_A = this.pitch;
            }
        }
    }
    
    private void attack(final Entity 922087310) {
    }
    // invokedynamic(-826771256:(Ljava/lang/Object;Ljava/lang/Object;)V, this.mc.field_71439_g, EnumHand.MAIN_HAND)
    // invokedynamic(-98395208:(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V, this.mc.field_71442_b, this.mc.field_71439_g, 922087310)
    
    private void updateTime() {
        this.current = invokedynamic(1037758292:()J) / KillAura.-1042549775;
    }
    
    private void resetTime() {
        this.last = invokedynamic(89310607:()J) / KillAura.-531953035;
    }
    
    private EntityLivingBase getClosest(final double 1014738216) {
        double n = 1014738216;
        EntityLivingBase entityLivingBase = null;
        final Iterator iterator = invokedynamic(369135933:(Ljava/lang/Object;)Ljava/util/Iterator;, this.mc.field_71441_e.field_72996_f);
        while (invokedynamic(1552247461:(Ljava/lang/Object;)Z, iterator)) {
            final Object o = invokedynamic(1438497918:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
            final Entity 1014738217 = (Entity)o;
            if (1014738217 instanceof EntityLivingBase) {
                final EntityLivingBase 1014738218 = (EntityLivingBase)1014738217;
                if (!this.canAttack(1014738218)) {
                    continue;
                }
                final double 1014738219 = (double)invokedynamic(-2139722665:(Ljava/lang/Object;Ljava/lang/Object;)F, this.mc.field_71439_g, 1014738218);
                if (1014738219 > n) {
                    continue;
                }
                n = 1014738219;
                entityLivingBase = 1014738218;
            }
        }
        return entityLivingBase;
    }
    
    private boolean canAttack(final EntityLivingBase -931945345) {
        return ((-931945345 != this.mc.field_71439_g && invokedynamic(251696111:(Ljava/lang/Object;)Z, -931945345) && invokedynamic(1659891237:(Ljava/lang/Object;Ljava/lang/Object;)F, this.mc.field_71439_g, -931945345) <= invokedynamic(-877918655:(Ljava/lang/Object;)F, this.mc.field_71442_b) && -931945345.field_70173_aa > KillAura.-256924525 && invokedynamic(1553942193:(Ljava/lang/Object;F)F, this.mc.field_71439_g, 0.0f) >= 1.0f) ? KillAura.364816182 : KillAura.2006899168) != 0;
    }
    
    static {
        KillAura.-177057325 = 1559191838;
        KillAura.-467758892 = 184;
        KillAura.132311951 = invokedynamic(1961625671:(I)I, false);
        KillAura.-523484021 = invokedynamic(985531027:(I)I, -1);
        KillAura.1555702252 = invokedynamic(-1044734125:(J)J, 9036988912464671416L);
        KillAura.-1024075181 = (536870912 >>> 125 | 536870912 << ~0x7D + 1);
        KillAura.-448359013 = invokedynamic(-1391890239:(I)I, -1);
        KillAura.1077422105 = invokedynamic(1392893479:(J)J, 9036988912464671416L);
        KillAura.294138714 = ((0 >>> 164 | 0 << ~0xA4 + 1) & -1);
        KillAura.-1922611385 = invokedynamic(-1286537919:(I)I, 268435456);
        KillAura.-696480391 = ((8000 >>> 99 | 8000 << ~0x63 + 1) & -1);
        KillAura.-1042549775 = invokedynamic(-816156093:(J)J, 162956419329425408L);
        KillAura.-531953035 = invokedynamic(-908881734:(J)J, 162956419329425408L);
        KillAura.-256924525 = ((122880 >>> 204 | 122880 << -204) & -1);
        KillAura.364816182 = ((4 >>> 194 | 4 << ~0xC2 + 1) & -1);
        KillAura.2006899168 = invokedynamic(1178267613:(I)I, false);
        KillAura.-1460903325 = ((4096 >>> 235 | 4096 << -235) & -1);
        KillAura.797834381 = invokedynamic(1682178015:(I)I, 1073741824);
        KillAura.1600954437 = new String[KillAura.-1460903325];
        KillAura.1279785722 = new String[KillAura.797834381];
    }
    // invokedynamic(-2083318848:()V)
    
    private static Object -1925513632(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(KillAura.class, "733288093", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", KillAura.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/combat/KillAura:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String 733288093(final int n, long n2) {
        n2 ^= 0x72L;
        n2 ^= 0x33E728E1FBFA4B39L;
        if (KillAura.1600954437[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/combat/KillAura");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            KillAura.1600954437[n] = new String(instance.doFinal(Base64.getDecoder().decode(KillAura.1279785722[n])));
        }
        return KillAura.1600954437[n];
    }
    
    private static void 1463252138() {
        KillAura.1205012502 = 2111512526245828300L;
        final long n = KillAura.1205012502 ^ 0x33E728E1FBFA4B39L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    KillAura.1279785722[0] = "O1rynsridOUpjkydiPEymA==";
                    KillAura.1279785722[1] = "6KkvfhNfjd3ww4aL6Qrh8lJsqeZ9NMgRs7+bEVDcxLErYHeXmz7Jqw==";
                    break;
                }
                case 1: {
                    KillAura.1279785722[0] = "O1rynsridOVTU+IPKVeoXw==";
                    KillAura.1279785722[1] = "6KkvfhNfjd3ww4aL6Qrh8lJsqeZ9NMgRs7+bEVDcxLHqTnLti2rT+5AGL4/nLXHm";
                    break;
                }
                case 2: {
                    KillAura.1279785722[0] = "QsNu30tS1DHQ/M5i/5fSpw==";
                    break;
                }
                case 4: {
                    KillAura.1279785722[0] = "M1MdyuF8yus=";
                    break;
                }
            }
        }
    }
    
    public static Object -10811703(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4) throws Exception {
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if ((int)o == 184) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

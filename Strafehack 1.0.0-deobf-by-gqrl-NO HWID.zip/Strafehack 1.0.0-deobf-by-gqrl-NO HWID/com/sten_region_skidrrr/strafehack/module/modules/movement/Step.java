// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module.modules.movement;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.living.LivingEvent;
import com.sten_region_skidrrr.strafehack.module.settings.Setting;
import com.sten_region_skidrrr.strafehack.module.Category;
import com.sten_region_skidrrr.strafehack.module.settings.NumberSetting;
import com.sten_region_skidrrr.strafehack.module.Module;

public class Step extends Module
{
    private NumberSetting stepheight;
    private static String[] 740527822;
    private static String[] -592569118;
    private static long -1249617792;
    private static int -158011133;
    private static long 861382168;
    private static int 1879425930;
    private static long 542655763;
    private static int -904332787;
    private static int -942471558;
    private static int 915256793;
    private static long 1240054283;
    private static double 1279566557;
    private static double -1540520608;
    private static int -1362040228;
    private static int -678526457;
    private static float -33377241;
    private static int -1897017161;
    private static int 1958371278;
    private static int -247713828;
    private static int -600116199;
    
    public Step() {
        super(invokedynamic(-1183198997:(IJ)Ljava/lang/String;, Step.-158011133, Step.861382168), invokedynamic(-223823025:(IJ)Ljava/lang/String;, Step.1879425930, Step.542655763), Category.Movement, Step.-904332787);
        this.stepheight = new NumberSetting(invokedynamic(-771420497:(IJ)Ljava/lang/String;, Step.-942471558 & Step.915256793, Step.1240054283), 1.0, Step.1279566557, Step.-1540520608);
        final Setting[] array = new Setting[Step.-1362040228];
        array[Step.-678526457] = this.stepheight;
    }
    // invokedynamic(150901319:(Ljava/lang/Object;[Lcom/sten_region_skidrrr/strafehack/module/settings/Setting;)V, this, array)
    
    @SubscribeEvent
    public void onUpdate(final LivingEvent.LivingUpdateEvent 1113968249) {
        if (invokedynamic(-1120903591:(Ljava/lang/Object;)Z, this) && invokedynamic(1821180253:(Ljava/lang/Object;)Lnet/minecraft/entity/EntityLivingBase;, 1113968249) instanceof EntityPlayer && invokedynamic(1411392508:(Ljava/lang/Object;)Lnet/minecraftforge/fml/common/eventhandler/EventPriority;, 1113968249) == EventPriority.LOWEST) {
            this.mc.field_71439_g.field_70138_W = (float)invokedynamic(-459163909:(Ljava/lang/Object;)D, this.stepheight);
        }
    }
    
    @Override
    public void onDisable() {
        this.mc.field_71439_g.field_70138_W = Step.-33377241;
    }
    
    static {
        Step.-247713828 = 397043431;
        Step.-600116199 = 184;
        Step.-158011133 = ((0 >>> 188 | 0 << -188) & -1);
        Step.861382168 = invokedynamic(568870384:(J)J, 8770956917386537935L);
        Step.1879425930 = invokedynamic(2020232682:(I)I, Integer.MIN_VALUE);
        Step.542655763 = invokedynamic(388141944:(J)J, 8770956917386537935L);
        Step.-904332787 = ((0 >>> 170 | 0 << ~0xAA + 1) & -1);
        Step.-942471558 = invokedynamic(-685086947:(I)I, 1073741824);
        Step.915256793 = ((-1 >>> 202 | -1 << ~0xCA + 1) & -1);
        Step.1240054283 = invokedynamic(916389784:(J)J, 8770956917386537935L);
        Step.1279566557 = invokedynamic(1097505000:(J)D, invokedynamic(605454966:(J)J, 2044L));
        Step.-1540520608 = invokedynamic(-1879212780:(J)D, invokedynamic(-266820222:(J)J, 4098L));
        Step.-1362040228 = ((524288 >>> 179 | 524288 << ~0xB3 + 1) & -1);
        Step.-678526457 = invokedynamic(1050515388:(I)I, false);
        Step.-33377241 = invokedynamic(621071922:(I)F, invokedynamic(732921999:(I)I, 252));
        Step.-1897017161 = (3072 >>> 10 | 3072 << -10);
        Step.1958371278 = ((196608 >>> 240 | 196608 << -240) & -1);
        Step.740527822 = new String[Step.-1897017161];
        Step.-592569118 = new String[Step.1958371278];
    }
    // invokedynamic(1968910450:()V)
    
    private static Object 1000047496(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(Step.class, "196952980", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", Step.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/movement/Step:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String 196952980(final int n, long n2) {
        n2 ^= 0x67L;
        n2 ^= 0xFBC9AB52E873B4AL;
        if (Step.740527822[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/movement/Step");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            Step.740527822[n] = new String(instance.doFinal(Base64.getDecoder().decode(Step.-592569118[n])));
        }
        return Step.740527822[n];
    }
    
    private static void 1507071460() {
        Step.-1249617792 = -876468473783575047L;
        final long n = Step.-1249617792 ^ 0xFBC9AB52E873B4AL;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    Step.-592569118[0] = "oRs/LYPs+nw=";
                    Step.-592569118[1] = "TMVPfayTCjyP0r7mkSzEGrP2pBfGh8EAoAXiVncjYvj89n7kll9xN8n1gGcAjDT9";
                    Step.-592569118[2] = "Af/qzd/Ygrz17zCMVb0azQ==";
                    break;
                }
                case 1: {
                    Step.-592569118[0] = "JdgELCa9JLis+u+8tcdasw==";
                    Step.-592569118[1] = "TMVPfayTCjyP0r7mkSzEGrP2pBfGh8EAoAXiVncjYvj89n7kll9xN2EBGqmk3iVNJBCVwj25Y+U=";
                    Step.-592569118[2] = "Af/qzd/YgrxE6l5zscHV6A==";
                    break;
                }
                case 2: {
                    Step.-592569118[0] = "1mNrh/4KtVf3TQ9xN27DIszzH8w/LUkv";
                    break;
                }
                case 4: {
                    Step.-592569118[0] = "VpZXgjsUEMUwegigwW5MOA==";
                    break;
                }
            }
        }
    }
    
    public static Object 1789770094(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7) throws Exception {
        final int n = ((int)o ^ Step.-247713828) & 0xFF;
        final Integer value = Step.-600116199;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

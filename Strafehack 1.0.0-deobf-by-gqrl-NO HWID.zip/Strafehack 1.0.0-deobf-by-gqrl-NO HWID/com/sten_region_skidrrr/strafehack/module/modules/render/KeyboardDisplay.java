// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module.modules.render;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import java.util.Iterator;
import com.sten_region_skidrrr.strafehack.ui.hud.ScreenPosition;
import java.util.ArrayList;
import java.util.List;
import com.sten_region_skidrrr.strafehack.module.ModuleUI;

public class KeyboardDisplay extends ModuleUI
{
    private List<Long> clicksl;
    private List<Long> clicksr;
    private boolean wasPressedl;
    private long lastPressedl;
    private boolean wasPressedr;
    private long lastPressedr;
    private static String[] -248257079;
    private static String[] 149880059;
    private static long -1023915436;
    private static int -26796830;
    private static long 1286010295;
    private static long -321077985;
    private static int -1250793961;
    private static int 1247565393;
    private static long -1598998424;
    private static int -279271310;
    private static int 1196413776;
    private static int -368377797;
    private static int -1771355278;
    private static int -1468124837;
    private static int 415056153;
    private static int 2119836812;
    private static int 1011637502;
    private static int 750984198;
    private static int 2011034002;
    private static long -1551269088;
    private static int 253656721;
    private static int 1664023273;
    private static long 1178345652;
    private static int -1161037408;
    private static int 1145915330;
    private static int -2004284704;
    private static int -1589974382;
    private static int -295206562;
    private static long -2124072663;
    private static long 659973853;
    private static int -1833738690;
    private static long -201502426;
    private static long -2004114733;
    private static int -1527998493;
    private static int -146342733;
    private static int 290674201;
    private static int -281403207;
    private static int -1138098109;
    private static int -386623326;
    private static int 1878074248;
    private static int 1474575455;
    private static int -77874105;
    private static int 1892236309;
    private static long 733061465;
    private static int 100471310;
    private static int 1175795900;
    private static int -718203972;
    private static int -264981980;
    private static int 1747091063;
    private static int 1458860574;
    private static int -9790089;
    private static int 676766186;
    private static int -426588927;
    private static int 568686661;
    private static int 1981383639;
    private static long 575669690;
    private static long 1119849510;
    private static int -63413078;
    private static int -1569830990;
    private static long -1575998275;
    private static int 691574702;
    private static int -1506204802;
    private static int 87101864;
    private static int -315545053;
    private static int -1108357850;
    private static long 1090619625;
    private static int 309641620;
    private static int 1359689402;
    private static int -1372197518;
    private static int 877570585;
    private static int 785160481;
    private static int -416866099;
    private static int 96605739;
    private static int -1410327022;
    private static int -1091601972;
    private static long 653807343;
    private static long 602896553;
    private static int -879383250;
    private static int -970202870;
    private static int 1737186954;
    private static int 77353755;
    private static int 645168388;
    private static int 910347566;
    private static int -224330149;
    private static long -1155021456;
    private static int 1872276167;
    private static int -1248423572;
    private static long -1605873115;
    private static int 991193605;
    private static int 1812114679;
    private static int 224737713;
    private static int 1496873710;
    private static int -1074095801;
    private static int 2026823118;
    
    public KeyboardDisplay() {
        super(invokedynamic(171832030:(IJ)Ljava/lang/String;, KeyboardDisplay.-26796830, KeyboardDisplay.1286010295 ^ KeyboardDisplay.-321077985), invokedynamic(-813177740:(IJ)Ljava/lang/String;, KeyboardDisplay.-1250793961 & KeyboardDisplay.1247565393, KeyboardDisplay.-1598998424), KeyboardDisplay.-279271310);
        this.clicksl = new ArrayList<Long>();
        this.clicksr = new ArrayList<Long>();
    }
    
    @Override
    public int getWidth() {
        return KeyboardDisplay.1196413776;
    }
    
    @Override
    public int getHeight() {
        return KeyboardDisplay.-368377797;
    }
    
    @Override
    public void render(final ScreenPosition -1846811097) {
        // invokedynamic(710282695:()V)
        final boolean wasPressedl = invokedynamic(-285921302:(I)Z, KeyboardDisplay.-1771355278);
        if (wasPressedl != this.wasPressedl) {
            this.lastPressedl = invokedynamic(534957988:()J);
            if (this.wasPressedl = wasPressedl) {
            }
            // invokedynamic(-71494479:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.clicksl, invokedynamic(667321073:(J)Ljava/lang/Long;, this.lastPressedl))
        }
        final boolean 568772793 = invokedynamic(1911042004:(I)Z, KeyboardDisplay.-1468124837);
        if (568772793 != this.wasPressedr) {
            this.lastPressedr = invokedynamic(-1879795710:()J);
            if (this.wasPressedr = 568772793) {
            }
            // invokedynamic(206824482:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.clicksr, invokedynamic(246373486:(J)Ljava/lang/Long;, this.lastPressedr))
        }
        final Iterator iterator = invokedynamic(-630665090:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(1300945571:()Ljava/util/ArrayList;));
        while (invokedynamic(1001234178:(Ljava/lang/Object;)Z, iterator)) {
            final Key 568772794 = (Key)invokedynamic(-295642439:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
            // invokedynamic(2017950641:(IIIIII)V, invokedynamic(-244858494:(Ljava/lang/Object;)I, -1846811097) + invokedynamic(-248936182:(Ljava/lang/Object;)I, 568772794), invokedynamic(195275390:(Ljava/lang/Object;)I, -1846811097) + invokedynamic(-974078910:(Ljava/lang/Object;)I, 568772794), invokedynamic(1664930189:(Ljava/lang/Object;)I, 568772794), invokedynamic(1209457904:(Ljava/lang/Object;)I, 568772794), invokedynamic(-967170474:(Ljava/lang/Object;)Z, 568772794) ? KeyboardDisplay.415056153 : KeyboardDisplay.2119836812, KeyboardDisplay.1011637502)
            if (invokedynamic(2000856213:(Ljava/lang/Object;)Ljava/lang/String;, 568772794) == invokedynamic(-739271303:(IJ)Ljava/lang/String;, KeyboardDisplay.750984198 & KeyboardDisplay.2011034002, KeyboardDisplay.-1551269088) || invokedynamic(356716412:(Ljava/lang/Object;)Ljava/lang/String;, 568772794) == invokedynamic(573608107:(IJ)Ljava/lang/String;, KeyboardDisplay.253656721 & KeyboardDisplay.1664023273, KeyboardDisplay.1178345652)) {
            }
            // invokedynamic(-946644326:(Ljava/lang/Object;III)V, invokedynamic(1469152449:(Ljava/lang/Object;)Ljava/lang/String;, 568772794), invokedynamic(862367890:(Ljava/lang/Object;)I, -1846811097) + invokedynamic(537471932:(Ljava/lang/Object;)I, 568772794) + KeyboardDisplay.-1161037408, invokedynamic(832071294:(Ljava/lang/Object;)I, -1846811097) + invokedynamic(-1223304628:(Ljava/lang/Object;)I, 568772794) - KeyboardDisplay.1145915330, invokedynamic(-639475020:(Ljava/lang/Object;)Z, 568772794) ? KeyboardDisplay.-2004284704 : KeyboardDisplay.-1589974382)
            // invokedynamic(-122687329:(Ljava/lang/Object;III)V, invokedynamic(1948849081:(Ljava/lang/Object;)L...
            else {
            }
            // invokedynamic(-845240359:(Ljava/lang/Object;III)V, invokedynamic(-1451163016:(Ljava/lang/Object;)Ljava/lang/String;, 568772794), invokedynamic(1579598380:(Ljava/lang/Object;)I, -1846811097) + invokedynamic(2064681377:(Ljava/lang/Object;)I, 568772794) + KeyboardDisplay.-1138098109, invokedynamic(-131610527:(Ljava/lang/Object;)I, -1846811097) + invokedynamic(358615933:(Ljava/lang/Object;)I, 568772794) + KeyboardDisplay.-386623326, invokedynamic(-103717842:(Ljava/lang/Object;)Z, 568772794) ? KeyboardDisplay.1878074248 : KeyboardDisplay.1474575455)
            if (invokedynamic(-1726303770:(Ljava/lang/Object;)Ljava/lang/String;, 568772794) == invokedynamic(-916812461:(IJ)Ljava/lang/String;, KeyboardDisplay.-77874105 & KeyboardDisplay.1892236309, KeyboardDisplay.733061465)) {
            }
            // invokedynamic(-443032649:(IIIIII)V, invokedynamic(-785086414:(Ljava/lang/Object;)I, -1846811097) + invokedynamic(2047358456:(Ljava/lang/Object;)I, 568772794) + KeyboardDisplay.100471310, invokedynamic(118349423:(Ljava/lang/Object;)I, -1846811097) + invokedynamic(729661388:(Ljava/lang/Object;)I, 568772794) + KeyboardDisplay.1175795900, invokedynamic(750596913:(Ljava/lang/Object;)I, 568772794) - KeyboardDisplay.-718203972, KeyboardDisplay.-264981980, invokedynamic(307953860:(Ljava/lang/Object;)Z, 568772794) ? KeyboardDisplay.1747091063 : KeyboardDisplay.1458860574, KeyboardDisplay.-9790089)
        }
    }
    // invokedynamic(118272062:()V)
    
    @Override
    public void renderDummy(final ScreenPosition -1955998070) {
        // invokedynamic(838447916:()V)
        final Iterator iterator = invokedynamic(1940178365:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(-1670324981:()Ljava/util/ArrayList;));
        while (invokedynamic(-128726864:(Ljava/lang/Object;)Z, iterator)) {
            final Key key = (Key)invokedynamic(2065880381:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
            // invokedynamic(872120002:(IIIIII)V, invokedynamic(-27502670:(Ljava/lang/Object;)I, -1955998070) + invokedynamic(-1202243565:(Ljava/lang/Object;)I, key), invokedynamic(1549258746:(Ljava/lang/Object;)I, -1955998070) + invokedynamic(-1118420327:(Ljava/lang/Object;)I, key), invokedynamic(86163083:(Ljava/lang/Object;)I, key), invokedynamic(-469027550:(Ljava/lang/Object;)I, key), invokedynamic(-1059999912:(Ljava/lang/Object;)Z, key) ? KeyboardDisplay.676766186 : KeyboardDisplay.-426588927, KeyboardDisplay.568686661)
            if (invokedynamic(-336532641:(Ljava/lang/Object;)Ljava/lang/String;, key) == invokedynamic(-942000138:(IJ)Ljava/lang/String;, KeyboardDisplay.1981383639, KeyboardDisplay.575669690 ^ KeyboardDisplay.1119849510) || invokedynamic(-1043567431:(Ljava/lang/Object;)Ljava/lang/String;, key) == invokedynamic(-1144533770:(IJ)Ljava/lang/String;, KeyboardDisplay.-63413078 & KeyboardDisplay.-1569830990, KeyboardDisplay.-1575998275)) {
            }
            // invokedynamic(-709351707:(Ljava/lang/Object;III)V, invokedynamic(-767938290:(Ljava/lang/Object;)Ljava/lang/String;, key), invokedynamic(1439242257:(Ljava/lang/Object;)I, -1955998070) + invokedynamic(97538887:(Ljava/lang/Object;)I, key) + KeyboardDisplay.691574702, invokedynamic(-820037225:(Ljava/lang/Object;)I, -1955998070) + invokedynamic(-607988556:(Ljava/lang/Object;)I, key) - KeyboardDisplay.-1506204802, invokedynamic(784904831:(Ljava/lang/Object;)Z, key) ? KeyboardDisplay.87101864 : KeyboardDisplay.-315545053)
            // invokedynamic(-30819967:(Ljava/lang/Object;III)V, invokedynamic(-400340173:(IJ)Ljava/lang/String;, KeyboardDisplay.-1108357850, KeyboardDisplay.1090619625), invokedynamic(587837347:(Ljava/lang/Object;)I, -1955998070) + invokedynamic(907100185:(Ljava/lang/Object;)I, key) + KeyboardDisplay.309641620, invokedynamic(2038740606:(Ljava/lang/Object;)I, -1955998070) + invokedynamic(-1668334330:(Ljava/lang/Object;)I, key) + KeyboardDisplay.1359689402, invokedynamic(703890295:(Ljava/lang/Object;)Z, key) ? KeyboardDisplay.-1372197518 : KeyboardDisplay.877570585)
            else {
            }
            // invokedynamic(2086372135:(Ljava/lang/Object;III)V, invokedynamic(-451525301:(Ljava/lang/Object;)Ljava/lang/String;, key), invokedynamic(-1595516510:(Ljava/lang/Object;)I, -1955998070) + invokedynamic(1849099526:(Ljava/lang/Object;)I, key) + KeyboardDisplay.785160481, invokedynamic(-927023711:(Ljava/lang/Object;)I, -1955998070) + invokedynamic(-446051931:(Ljava/lang/Object;)I, key) + KeyboardDisplay.-416866099, invokedynamic(-639486086:(Ljava/lang/Object;)Z, key) ? KeyboardDisplay.96605739 : KeyboardDisplay.-1410327022)
            if (invokedynamic(-542742217:(Ljava/lang/Object;)Ljava/lang/String;, key) == invokedynamic(1786598870:(IJ)Ljava/lang/String;, KeyboardDisplay.-1091601972, KeyboardDisplay.653807343 ^ KeyboardDisplay.602896553)) {
            }
            // invokedynamic(1574503587:(IIIIII)V, invokedynamic(236030714:(Ljava/lang/Object;)I, -1955998070) + invokedynamic(-34565707:(Ljava/lang/Object;)I, key) + KeyboardDisplay.-879383250, invokedynamic(1670597164:(Ljava/lang/Object;)I, -1955998070) + invokedynamic(-995872611:(Ljava/lang/Object;)I, key) + KeyboardDisplay.-970202870, invokedynamic(1276751706:(Ljava/lang/Object;)I, key) - KeyboardDisplay.1737186954, KeyboardDisplay.77353755, invokedynamic(433803795:(Ljava/lang/Object;)Z, key) ? KeyboardDisplay.645168388 : KeyboardDisplay.910347566, KeyboardDisplay.-224330149)
        }
    }
    // invokedynamic(-1610760943:()V)
    
    private int getCpsr() {
        final long 116285018 = invokedynamic(1070166135:()J);
        // invokedynamic(1723320781:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.clicksr, -291615324 -> invokedynamic(-154389567:(Ljava/lang/Object;)J, -291615324) + KeyboardDisplay.-1605873115 < 116285018 ? KeyboardDisplay.991193605 : KeyboardDisplay.1812114679)
        return invokedynamic(-1309532004:(Ljava/lang/Object;)I, this.clicksr);
    }
    
    private int getCpsl() {
        final long n = invokedynamic(963714491:()J);
        // invokedynamic(-1507144310:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.clicksl, -543478904 -> invokedynamic(203294308:(Ljava/lang/Object;)J, -543478904) + KeyboardDisplay.-1155021456 < n ? KeyboardDisplay.1872276167 : KeyboardDisplay.-1248423572)
        return invokedynamic(1295886604:(Ljava/lang/Object;)I, this.clicksl);
    }
    
    static {
        KeyboardDisplay.-1074095801 = -1946778652;
        KeyboardDisplay.2026823118 = 184;
        KeyboardDisplay.-26796830 = ((0 >>> 230 | 0 << ~0xE6 + 1) & -1);
        KeyboardDisplay.1286010295 = invokedynamic(-1550156893:(J)J, 1995858976579912105L);
        KeyboardDisplay.-321077985 = invokedynamic(-1587762901:(J)J, -720575940379279360L);
        KeyboardDisplay.-1250793961 = ((8 >>> 163 | 8 << ~0xA3 + 1) & -1);
        KeyboardDisplay.1247565393 = invokedynamic(-1078945766:(I)I, -1);
        KeyboardDisplay.-1598998424 = invokedynamic(-991083474:(J)J, -1318790349164772951L);
        KeyboardDisplay.-279271310 = invokedynamic(-572539120:(I)I, false);
        KeyboardDisplay.1196413776 = (15360 >>> 168 | 15360 << -168);
        KeyboardDisplay.-368377797 = (2208 >>> 133 | 2208 << -133);
        KeyboardDisplay.-1771355278 = invokedynamic(1640920524:(I)I, false);
        KeyboardDisplay.-1468124837 = invokedynamic(1326790854:(I)I, Integer.MIN_VALUE);
        KeyboardDisplay.415056153 = (-128 >>> 136 | -128 << ~0x88 + 1);
        KeyboardDisplay.2119836812 = invokedynamic(1399404292:(I)I, 10);
        KeyboardDisplay.1011637502 = invokedynamic(1556021545:(I)I, -256);
        KeyboardDisplay.750984198 = ((512 >>> 136 | 512 << ~0x88 + 1) & -1);
        KeyboardDisplay.2011034002 = ((-1 >>> 101 | -1 << -101) & -1);
        KeyboardDisplay.-1551269088 = invokedynamic(-797284080:(J)J, -1318790349164772951L);
        KeyboardDisplay.253656721 = invokedynamic(-147338546:(I)I, -1073741824);
        KeyboardDisplay.1664023273 = (-1 >>> 204 | -1 << ~0xCC + 1);
        KeyboardDisplay.1178345652 = invokedynamic(1060101374:(J)J, -1318790349164772951L);
        KeyboardDisplay.-1161037408 = invokedynamic(955570826:(I)I, 1879048192);
        KeyboardDisplay.1145915330 = invokedynamic(-2086633056:(I)I, 1073741824);
        KeyboardDisplay.-2004284704 = ((0 >>> 94 | 0 << -94) & -1);
        KeyboardDisplay.-1589974382 = invokedynamic(199087348:(I)I, -1);
        KeyboardDisplay.-295206562 = invokedynamic(-564667608:(I)I, 536870912);
        KeyboardDisplay.-2124072663 = invokedynamic(1778147454:(J)J, 1995858976579912105L);
        KeyboardDisplay.659973853 = invokedynamic(-840895:(J)J, -720575940379279360L);
        KeyboardDisplay.-1833738690 = ((-1610612736 >>> 125 | -1610612736 << ~0x7D + 1) & -1);
        KeyboardDisplay.-201502426 = invokedynamic(-1674012299:(J)J, 1995858976579912105L);
        KeyboardDisplay.-2004114733 = invokedynamic(-958919558:(J)J, -720575940379279360L);
        KeyboardDisplay.-1527998493 = invokedynamic(186324250:(I)I, 1879048192);
        KeyboardDisplay.-146342733 = (917504 >>> 49 | 917504 << ~0x31 + 1);
        KeyboardDisplay.290674201 = invokedynamic(-2042761290:(I)I, false);
        KeyboardDisplay.-281403207 = ((-1 >>> 7 | -1 << ~0x7 + 1) & -1);
        KeyboardDisplay.-1138098109 = invokedynamic(-470745034:(I)I, 1342177280);
        KeyboardDisplay.-386623326 = ((3145728 >>> 20 | 3145728 << ~0x14 + 1) & -1);
        KeyboardDisplay.1878074248 = (0 >>> 77 | 0 << ~0x4D + 1);
        KeyboardDisplay.1474575455 = (-1 >>> 189 | -1 << -189);
        KeyboardDisplay.-77874105 = invokedynamic(407906127:(I)I, 1610612736);
        KeyboardDisplay.1892236309 = invokedynamic(725308352:(I)I, -1);
        KeyboardDisplay.733061465 = invokedynamic(2121590948:(J)J, -1318790349164772951L);
        KeyboardDisplay.100471310 = ((983040 >>> 112 | 983040 << ~0x70 + 1) & -1);
        KeyboardDisplay.1175795900 = (320 >>> 70 | 320 << -70);
        KeyboardDisplay.-718203972 = (1920 >>> 134 | 1920 << -134);
        KeyboardDisplay.-264981980 = (1024 >>> 234 | 1024 << -234);
        KeyboardDisplay.1747091063 = (1044480 >>> 52 | 1044480 << -52);
        KeyboardDisplay.1458860574 = invokedynamic(-2074400847:(I)I, -1);
        KeyboardDisplay.-9790089 = invokedynamic(1511159032:(I)I, -256);
        KeyboardDisplay.676766186 = invokedynamic(1533740702:(I)I, -255);
        KeyboardDisplay.-426588927 = invokedynamic(-1655905919:(I)I, 10);
        KeyboardDisplay.568686661 = invokedynamic(1240980041:(I)I, -256);
        KeyboardDisplay.1981383639 = (1835008 >>> 146 | 1835008 << -146);
        KeyboardDisplay.575669690 = invokedynamic(1215108245:(J)J, 1995858976579912105L);
        KeyboardDisplay.1119849510 = invokedynamic(-934481467:(J)J, -720575940379279360L);
        KeyboardDisplay.-63413078 = ((32768 >>> 108 | 32768 << -108) & -1);
        KeyboardDisplay.-1569830990 = (-1 >>> 81 | -1 << ~0x51 + 1);
        KeyboardDisplay.-1575998275 = invokedynamic(-1156753689:(J)J, -1318790349164772951L);
        KeyboardDisplay.691574702 = invokedynamic(940537368:(I)I, 1879048192);
        KeyboardDisplay.-1506204802 = (1048576 >>> 51 | 1048576 << -51);
        KeyboardDisplay.87101864 = invokedynamic(-1403852118:(I)I, false);
        KeyboardDisplay.-315545053 = invokedynamic(1038098771:(I)I, -1);
        KeyboardDisplay.-1108357850 = ((18874368 >>> 85 | 18874368 << -85) & -1);
        KeyboardDisplay.1090619625 = invokedynamic(-1826116410:(J)J, -1318790349164772951L);
        KeyboardDisplay.309641620 = (448 >>> 5 | 448 << ~0x5 + 1);
        KeyboardDisplay.1359689402 = (7 >>> 160 | 7 << -160);
        KeyboardDisplay.-1372197518 = (0 >>> 73 | 0 << ~0x49 + 1);
        KeyboardDisplay.877570585 = ((-1 >>> 191 | -1 << -191) & -1);
        KeyboardDisplay.785160481 = (20 >>> 97 | 20 << -97);
        KeyboardDisplay.-416866099 = (393216 >>> 177 | 393216 << -177);
        KeyboardDisplay.96605739 = invokedynamic(-1008875124:(I)I, false);
        KeyboardDisplay.-1410327022 = invokedynamic(502457980:(I)I, -1);
        KeyboardDisplay.-1091601972 = invokedynamic(-1618613647:(I)I, 1342177280);
        KeyboardDisplay.653807343 = invokedynamic(-1880245756:(J)J, 1995858976579912105L);
        KeyboardDisplay.602896553 = invokedynamic(-939164574:(J)J, -720575940379279360L);
        KeyboardDisplay.-879383250 = ((15360 >>> 74 | 15360 << -74) & -1);
        KeyboardDisplay.-970202870 = invokedynamic(-2040794325:(I)I, -1610612736);
        KeyboardDisplay.1737186954 = (125829120 >>> 214 | 125829120 << ~0xD6 + 1);
        KeyboardDisplay.77353755 = ((32 >>> 165 | 32 << -165) & -1);
        KeyboardDisplay.645168388 = invokedynamic(1210052180:(I)I, 255);
        KeyboardDisplay.910347566 = ((-1 >>> 4 | -1 << ~0x4 + 1) & -1);
        KeyboardDisplay.-224330149 = ((-1069547521 >>> 158 | -1069547521 << ~0x9E + 1) & -1);
        KeyboardDisplay.-1155021456 = invokedynamic(595378715:(J)J, 1711367858400788480L);
        KeyboardDisplay.1872276167 = invokedynamic(870481965:(I)I, Integer.MIN_VALUE);
        KeyboardDisplay.-1248423572 = invokedynamic(1347028582:(I)I, false);
        KeyboardDisplay.-1605873115 = invokedynamic(-362640986:(J)J, 1711367858400788480L);
        KeyboardDisplay.991193605 = (65536 >>> 176 | 65536 << -176);
        KeyboardDisplay.1812114679 = ((0 >>> 141 | 0 << ~0x8D + 1) & -1);
        KeyboardDisplay.224737713 = invokedynamic(-1166612662:(I)I, -805306368);
        KeyboardDisplay.1496873710 = invokedynamic(177066698:(I)I, -805306368);
        KeyboardDisplay.-248257079 = new String[KeyboardDisplay.224737713];
        KeyboardDisplay.149880059 = new String[KeyboardDisplay.1496873710];
    }
    // invokedynamic(-296901086:()V)
    
    private static Object -1990285576(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(KeyboardDisplay.class, "-1603208884", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", KeyboardDisplay.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/render/KeyboardDisplay:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String -1603208884(final int n, long n2) {
        n2 ^= 0x6FL;
        n2 ^= 0x362B35FA3636D792L;
        if (KeyboardDisplay.-248257079[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/render/KeyboardDisplay");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            KeyboardDisplay.-248257079[n] = new String(instance.doFinal(Base64.getDecoder().decode(KeyboardDisplay.149880059[n])));
        }
        return KeyboardDisplay.-248257079[n];
    }
    
    private static void -348441443() {
        KeyboardDisplay.-1023915436 = -7674051214343057960L;
        final long n = KeyboardDisplay.-1023915436 ^ 0x362B35FA3636D792L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    KeyboardDisplay.149880059[0] = "8WG40N78E/LZCS0MGdk5Ug==";
                    KeyboardDisplay.149880059[1] = "Aee2Cma/n02ZXNzDZ+UPZt4P/bigm64pPAbGHzHglSDeRDpAFyP4DA==";
                    KeyboardDisplay.149880059[2] = "Qj0NeE+3E/c=";
                    KeyboardDisplay.149880059[3] = "IrBKkveze54=";
                    KeyboardDisplay.149880059[4] = "Qj0NeE+3E/c=";
                    KeyboardDisplay.149880059[5] = "JQlG8ULYcVo=";
                    KeyboardDisplay.149880059[6] = "JQlG8ULYcVo=";
                    KeyboardDisplay.149880059[7] = "Qj0NeE+3E/c=";
                    KeyboardDisplay.149880059[8] = "IrBKkveze54=";
                    KeyboardDisplay.149880059[9] = "MiV0WILNkuo=";
                    KeyboardDisplay.149880059[10] = "JQlG8ULYcVo=";
                    break;
                }
                case 1: {
                    KeyboardDisplay.149880059[0] = "8WG40N78E/INXKiSC/3KRA==";
                    KeyboardDisplay.149880059[1] = "Aee2Cma/n02ZXNzDZ+UPZt4P/bigm64pPAbGHzHglSAf3SNdV9kebWzsMOhKJBDe";
                    KeyboardDisplay.149880059[2] = "v8WZ9LXO9TE=";
                    KeyboardDisplay.149880059[3] = "7Jc4BqdsIag=";
                    KeyboardDisplay.149880059[4] = "Xt2FEuPz5w4=";
                    KeyboardDisplay.149880059[5] = "I2MJrshRBBs=";
                    KeyboardDisplay.149880059[6] = "adi6T7jRzt8=";
                    KeyboardDisplay.149880059[7] = "sBfZmrdG46M=";
                    KeyboardDisplay.149880059[8] = "gLbe3AzpjTw=";
                    KeyboardDisplay.149880059[9] = "1Wd4sjzR7VU=";
                    KeyboardDisplay.149880059[10] = "MZdqOgLCV/s=";
                    break;
                }
                case 2: {
                    KeyboardDisplay.149880059[0] = "TmWw0StrNQEbsOKzuWq4iA==";
                    break;
                }
                case 4: {
                    KeyboardDisplay.149880059[0] = "XvbQf/2fU9fFxz1Exc/dpA==";
                    break;
                }
            }
        }
    }
    
    public static Object -1256618536(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6) throws Exception {
        final int n = ((int)o ^ KeyboardDisplay.-1074095801) & 0xFF;
        final Integer value = KeyboardDisplay.2026823118;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
    
    private static class Key
    {
        private static final Key W;
        private static final Key A;
        private static final Key S;
        private static final Key D;
        private static final Key Space;
        private static final Key LMB;
        private static final Key RMB;
        private ArrayList<Key> keys;
        private final String name;
        private final KeyBinding keybind;
        private final int x;
        private final int y;
        private final int width;
        private final int height;
        private static String[] 436840982;
        private static String[] -2111290748;
        private static long 851951533;
        private static int -1112155077;
        private static int 2075927055;
        private static int 811887795;
        private static long -175492333;
        private static int 1791003993;
        private static int 402685246;
        private static int 897927111;
        private static int -953182265;
        private static int 699038229;
        private static int -1217227936;
        private static long -1980727541;
        private static int -350637403;
        private static int 93283777;
        private static int 562368641;
        private static int -1770907814;
        private static int 192749098;
        private static long -1224570689;
        private static long -1153618826;
        private static int -1317330481;
        private static int 856435669;
        private static int -490489003;
        private static int 760172172;
        private static int -72294561;
        private static long -679572025;
        private static long 2101413247;
        private static int -1175114053;
        private static int 1109009967;
        private static int -1710402162;
        private static int 1153127897;
        private static int -1000309298;
        private static long -614339662;
        private static int 1548190666;
        private static int 1648678833;
        private static int 74344580;
        private static int 177594965;
        private static int 1020050714;
        private static int -1349935574;
        private static long 805898105;
        private static int -1685945162;
        private static int -1800599980;
        private static int -439901233;
        private static int 1928664704;
        private static int 408257065;
        private static long -1890199357;
        private static int 636235583;
        private static int -970705681;
        private static int -1789981987;
        private static int 1331203721;
        
        public static ArrayList<Key> getKeys() {
            final ArrayList<Key> 1419042501 = new ArrayList<Key>();
            1419042501.add(Key.W);
            1419042501.add(Key.A);
            1419042501.add(Key.S);
            1419042501.add(Key.D);
            1419042501.add(Key.Space);
            1419042501.add(Key.LMB);
            1419042501.add(Key.RMB);
            return 1419042501;
        }
        
        public Key(final String -439870640, final KeyBinding -2022264428, final int -41664036, final int -161710452, final int -907438990, final int 462958406) {
            this.keys = new ArrayList<Key>();
            this.name = -439870640;
            this.keybind = -2022264428;
            this.x = -41664036;
            this.y = -161710452;
            this.width = -907438990;
            this.height = 462958406;
        }
        
        public boolean isDown() {
            return this.keybind.func_151470_d();
        }
        
        public int getHeight() {
            return this.height;
        }
        
        public int getWidth() {
            return this.width;
        }
        
        public int getX() {
            return this.x;
        }
        
        public int getY() {
            return this.y;
        }
        
        static {
            Key.-1112155077 = (117440512 >>> 248 | 117440512 << -248);
            Key.2075927055 = ((458752 >>> 16 | 458752 << ~0x10 + 1) & -1);
            Key.811887795 = ((0 >>> 43 | 0 << ~0x2B + 1) & -1);
            Key.-175492333 = Long.reverse(8607226539629658492L);
            Key.1791003993 = ((84 >>> 130 | 84 << ~0x82 + 1) & -1);
            Key.402685246 = Integer.reverse(Integer.MIN_VALUE);
            Key.897927111 = (536870913 >>> 92 | 536870913 << ~0x5C + 1);
            Key.-953182265 = Integer.reverse(1207959552);
            Key.699038229 = (2097152 >>> 117 | 2097152 << -117);
            Key.-1217227936 = Integer.reverse(-1);
            Key.-1980727541 = Long.reverse(8607226539629658492L);
            Key.-350637403 = ((1048576 >>> 116 | 1048576 << ~0x74 + 1) & -1);
            Key.93283777 = Integer.reverse(-1476395008);
            Key.562368641 = Integer.reverse(1207959552);
            Key.-1770907814 = Integer.reverse(1207959552);
            Key.192749098 = (131072 >>> 208 | 131072 << ~0xD0 + 1);
            Key.-1224570689 = Long.reverse(5869037966188396924L);
            Key.-1153618826 = Long.reverse(2738188573441261568L);
            Key.-1317330481 = Integer.reverse(-1476395008);
            Key.856435669 = (1344 >>> 70 | 1344 << -70);
            Key.-490489003 = Integer.reverse(1207959552);
            Key.760172172 = ((72 >>> 162 | 72 << ~0xA2 + 1) & -1);
            Key.-72294561 = Integer.reverse(-1073741824);
            Key.-679572025 = Long.reverse(5869037966188396924L);
            Key.2101413247 = Long.reverse(2738188573441261568L);
            Key.-1175114053 = Integer.reverse(-1811939328);
            Key.1109009967 = ((176160768 >>> 183 | 176160768 << -183) & -1);
            Key.-1710402162 = ((18432 >>> 42 | 18432 << -42) & -1);
            Key.1153127897 = (18 >>> 192 | 18 << -192);
            Key.-1000309298 = Integer.reverse(536870912);
            Key.-614339662 = Long.reverse(8607226539629658492L);
            Key.1548190666 = ((512 >>> 9 | 512 << ~0x9 + 1) & -1);
            Key.1648678833 = (-1610612729 >>> 157 | -1610612729 << ~0x9D + 1);
            Key.74344580 = ((-1610612733 >>> 188 | -1610612733 << -188) & -1);
            Key.177594965 = (1 >>> 157 | 1 << -157);
            Key.1020050714 = ((81920 >>> 46 | 81920 << -46) & -1);
            Key.-1349935574 = (-1 >>> 62 | -1 << -62);
            Key.805898105 = Long.reverse(8607226539629658492L);
            Key.-1685945162 = (268435456 >>> 156 | 268435456 << ~0x9C + 1);
            Key.-1800599980 = Integer.reverse(-1811939328);
            Key.-439901233 = ((7 >>> 62 | 7 << -62) & -1);
            Key.1928664704 = Integer.reverse(1207959552);
            Key.408257065 = Integer.reverse(1610612736);
            Key.-1890199357 = Long.reverse(8607226539629658492L);
            Key.636235583 = Integer.reverse(-134217728);
            Key.-970705681 = ((1375731712 >>> 89 | 1375731712 << -89) & -1);
            Key.-1789981987 = (14680064 >>> 83 | 14680064 << -83);
            Key.1331203721 = (73728 >>> 108 | 73728 << ~0x6C + 1);
            Key.436840982 = new String[Key.-1112155077];
            Key.-2111290748 = new String[Key.2075927055];
            1440265042();
            W = new Key(invokedynamic(-493864795:(IJ)Ljava/lang/String;, Key.811887795, Key.-175492333), Minecraft.func_71410_x().field_71474_y.field_74351_w, Key.1791003993, Key.402685246, Key.897927111, Key.-953182265);
            A = new Key(invokedynamic(-44531502:(IJ)Ljava/lang/String;, Key.699038229 & Key.-1217227936, Key.-1980727541), Minecraft.func_71410_x().field_71474_y.field_74370_x, Key.-350637403, Key.93283777, Key.562368641, Key.-1770907814);
            S = new Key(invokedynamic(-741454612:(IJ)Ljava/lang/String;, Key.192749098, Key.-1224570689 ^ Key.-1153618826), Minecraft.func_71410_x().field_71474_y.field_74368_y, Key.-1317330481, Key.856435669, Key.-490489003, Key.760172172);
            D = new Key(invokedynamic(1466235077:(IJ)Ljava/lang/String;, Key.-72294561, Key.-679572025 ^ Key.2101413247), Minecraft.func_71410_x().field_71474_y.field_74366_z, Key.-1175114053, Key.1109009967, Key.-1710402162, Key.1153127897);
            Space = new Key(invokedynamic(1434758441:(IJ)Ljava/lang/String;, Key.-1000309298, Key.-614339662), Minecraft.func_71410_x().field_71474_y.field_74314_A, Key.1548190666, Key.1648678833, Key.74344580, Key.177594965);
            LMB = new Key(invokedynamic(-1804521008:(IJ)Ljava/lang/String;, Key.1020050714 & Key.-1349935574, Key.805898105), Minecraft.func_71410_x().field_71474_y.field_74312_F, Key.-1685945162, Key.-1800599980, Key.-439901233, Key.1928664704);
            RMB = new Key(invokedynamic(-164717201:(IJ)Ljava/lang/String;, Key.408257065, Key.-1890199357), Minecraft.func_71410_x().field_71474_y.field_74313_G, Key.636235583, Key.-970705681, Key.-1789981987, Key.1331203721);
        }
        
        private static Object 1180514377(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
            try {
                return new MutableCallSite(lookup.findStatic(Key.class, "-211801454", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", Key.class.getClassLoader())).asType(newType));
            }
            catch (Exception cause) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/render/KeyboardDisplay$Key:" + str + ":" + newType.toString(), cause);
            }
        }
        
        private static String -211801454(final int n, long n2) {
            n2 ^= 0x64L;
            n2 ^= 0xE135934E2006DD8DL;
            if (Key.436840982[n] == null) {
                Cipher instance;
                SecretKeyFactory instance2;
                try {
                    instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                    instance2 = SecretKeyFactory.getInstance("DES");
                }
                catch (Exception ex) {
                    throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/render/KeyboardDisplay$Key");
                }
                final byte[] key = new byte[8];
                key[0] = (byte)(n2 >>> 56);
                for (int i = 1; i < 8; ++i) {
                    key[i] = (byte)(n2 << i * 8 >>> 56);
                }
                instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
                Key.436840982[n] = new String(instance.doFinal(Base64.getDecoder().decode(Key.-2111290748[n])));
            }
            return Key.436840982[n];
        }
        
        private static void 1440265042() {
            Key.851951533 = 4504461451066396298L;
            final long n = Key.851951533 ^ 0xE135934E2006DD8DL;
            final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
            final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
            final byte[] key = new byte[8];
            key[0] = (byte)(n >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            for (int n2 = 1, j = 0; j < n2; ++j) {
                switch (j) {
                    case 0: {
                        Key.-2111290748[0] = "tvDY2roJD7c=";
                        Key.-2111290748[1] = "a6KbDEXqPRI=";
                        Key.-2111290748[2] = "Yde3yjJtrE4=";
                        Key.-2111290748[3] = "RdX041prY20=";
                        Key.-2111290748[4] = "U8L/Lmv+Zeo=";
                        Key.-2111290748[5] = "YOoee6YZtRE=";
                        Key.-2111290748[6] = "o+qIEkvMnnA=";
                        break;
                    }
                    case 1: {
                        Key.-2111290748[0] = "S+WOjLnTQXw=";
                        Key.-2111290748[1] = "lZ8DYpNoSnQ=";
                        Key.-2111290748[2] = "T5O+ayAgLuU=";
                        Key.-2111290748[3] = "m/aKlA9UIxI=";
                        Key.-2111290748[4] = "mfLbkbtwRl4=";
                        Key.-2111290748[5] = "L2K9LV7lsJI=";
                        Key.-2111290748[6] = "Zs9GFQjyc6E=";
                        break;
                    }
                    case 2: {
                        Key.-2111290748[0] = "rahIqSNBnrnkIGOHJsgx5w==";
                        break;
                    }
                    case 4: {
                        Key.-2111290748[0] = "W2IgXH21GHWRSL4uC9q4dtGfZLtGwitS";
                        break;
                    }
                }
            }
        }
    }
}

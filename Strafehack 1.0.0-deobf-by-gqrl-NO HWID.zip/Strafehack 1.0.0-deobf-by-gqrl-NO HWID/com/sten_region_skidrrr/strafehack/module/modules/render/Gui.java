// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module.modules.render;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import com.sten_region_skidrrr.strafehack.ui.ClickGui;
import java.util.Iterator;
import com.sten_region_skidrrr.strafehack.module.settings.Setting;
import com.sten_region_skidrrr.strafehack.module.Category;
import com.sten_region_skidrrr.strafehack.module.settings.BooleanSetting;
import com.sten_region_skidrrr.strafehack.module.Module;

public class Gui extends Module
{
    public BooleanSetting customfont;
    public BooleanSetting useshadow;
    private static String[] 59481298;
    private static String[] -1133365211;
    private static long 791689722;
    private static int 477284144;
    private static long 1933810449;
    private static int 1291101619;
    private static int 773116236;
    private static long -1810215176;
    private static int -1204126338;
    private static int 1914168806;
    private static long -129610667;
    private static int -531202531;
    private static int -870401997;
    private static long -79072695;
    private static long 890800509;
    private static int -1775057000;
    private static int -2092435937;
    private static int -1134220459;
    private static int 566161979;
    private static int 1270254081;
    private static int -770220473;
    private static int -1526759981;
    private static int 1635886192;
    private static int 231670761;
    private static int 2049430093;
    private static int -258354539;
    
    public Gui() {
        super(invokedynamic(-835569038:(IJ)Ljava/lang/String;, Gui.477284144, Gui.1933810449), invokedynamic(-811104417:(IJ)Ljava/lang/String;, Gui.1291101619 & Gui.773116236, Gui.-1810215176), Category.Render, Gui.-1204126338);
        this.customfont = new BooleanSetting(invokedynamic(-1831755865:(IJ)Ljava/lang/String;, Gui.1914168806, Gui.-129610667), (boolean)(Gui.-531202531 != 0));
        this.useshadow = new BooleanSetting(invokedynamic(-1840961935:(IJ)Ljava/lang/String;, Gui.-870401997, Gui.-79072695 ^ Gui.890800509), (boolean)(Gui.-1775057000 != 0));
        final Setting[] array = new Setting[Gui.-2092435937];
        array[Gui.-1134220459] = this.customfont;
        array[Gui.566161979] = this.useshadow;
    }
    // invokedynamic(-1681571423:(Ljava/lang/Object;[Lcom/sten_region_skidrrr/strafehack/module/settings/Setting;)V, this, array)
    
    public void ResetModules() {
        final Iterator iterator = invokedynamic(-1045075620:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(-1191862115:()Ljava/util/ArrayList;));
        while (invokedynamic(51336812:(Ljava/lang/Object;)Z, iterator)) {
            final Module 301620897 = (Module)invokedynamic(-1762474761:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
            final Iterator iterator2 = invokedynamic(1258064781:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(443571727:(Ljava/lang/Object;)Ljava/util/List;, 301620897));
            while (invokedynamic(-1988190573:(Ljava/lang/Object;)Z, iterator2)) {
                final Setting setting = (Setting)invokedynamic(-194635835:(Ljava/lang/Object;)Ljava/lang/Object;, iterator2);
                setting.focussed = (Gui.1270254081 != 0);
            }
        }
        // invokedynamic(-1937422354:(Ljava/lang/Object;Z)V, 301620897, Gui.-770220473)
    }
    
    @Override
    public void onToggle() {
        // invokedynamic(-1074400238:(Ljava/lang/Object;)V, this)
        final ClickGui 1937769186 = new ClickGui();
        1937769186.field_146291_p = (Gui.-1526759981 != 0);
    }
    // invokedynamic(1790191112:(Ljava/lang/Object;Ljava/lang/Object;)V, this.mc, 1937769186)
    
    static {
        Gui.2049430093 = -1453323799;
        Gui.-258354539 = 184;
        Gui.477284144 = ((0 >>> 66 | 0 << ~0x42 + 1) & -1);
        Gui.1933810449 = invokedynamic(141387901:(J)J, 611017228832064356L);
        Gui.1291101619 = ((131072 >>> 113 | 131072 << -113) & -1);
        Gui.773116236 = (-1 >>> 126 | -1 << ~0x7E + 1);
        Gui.-1810215176 = invokedynamic(-168482517:(J)J, 611017228832064356L);
        Gui.-1204126338 = invokedynamic(1751461:(I)I, 1811939328);
        Gui.1914168806 = invokedynamic(216339180:(I)I, 1073741824);
        Gui.-129610667 = invokedynamic(-399374169:(J)J, 611017228832064356L);
        Gui.-531202531 = invokedynamic(-1072059614:(I)I, Integer.MIN_VALUE);
        Gui.-870401997 = (201326592 >>> 186 | 201326592 << ~0xBA + 1);
        Gui.-79072695 = invokedynamic(-1431641279:(J)J, 466902040756208484L);
        Gui.890800509 = invokedynamic(-1643465579:(J)J, 1008806316530991104L);
        Gui.-1775057000 = ((0 >>> 94 | 0 << -94) & -1);
        Gui.-2092435937 = ((1 >>> 191 | 1 << ~0xBF + 1) & -1);
        Gui.-1134220459 = ((0 >>> 169 | 0 << ~0xA9 + 1) & -1);
        Gui.566161979 = ((16777216 >>> 152 | 16777216 << -152) & -1);
        Gui.1270254081 = invokedynamic(-876020801:(I)I, false);
        Gui.-770220473 = ((0 >>> 172 | 0 << ~0xAC + 1) & -1);
        Gui.-1526759981 = ((131072 >>> 113 | 131072 << ~0x71 + 1) & -1);
        Gui.1635886192 = ((256 >>> 230 | 256 << -230) & -1);
        Gui.231670761 = ((256 >>> 70 | 256 << ~0x46 + 1) & -1);
        Gui.59481298 = new String[Gui.1635886192];
        Gui.-1133365211 = new String[Gui.231670761];
    }
    // invokedynamic(-873725137:()V)
    
    private static Object -709833576(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(Gui.class, "-54733650", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", Gui.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/render/Gui:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String -54733650(final int n, long n2) {
        n2 ^= 0x70L;
        n2 ^= 0x78055C48E6F40857L;
        if (Gui.59481298[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/render/Gui");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            Gui.59481298[n] = new String(instance.doFinal(Base64.getDecoder().decode(Gui.-1133365211[n])));
        }
        return Gui.59481298[n];
    }
    
    private static void 194995975() {
        Gui.791689722 = 2793274335624912480L;
        final long n = Gui.791689722 ^ 0x78055C48E6F40857L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    Gui.-1133365211[0] = "DxVu2q6+arg=";
                    Gui.-1133365211[1] = "m5E/YX25JqWR6MFuBddlrEweqD9R4WnY";
                    Gui.-1133365211[2] = "5nn3WO1YDvG8hC26RHg71w==";
                    Gui.-1133365211[3] = "lguLHO0esLyoXMFgkPj9UA==";
                    break;
                }
                case 1: {
                    Gui.-1133365211[0] = "HAaGNiVL+Ws=";
                    Gui.-1133365211[1] = "m5E/YX25JqWR6MFuBddlrN12GCwPtQyH";
                    Gui.-1133365211[2] = "5nn3WO1YDvEcbpMrmkCh8w==";
                    Gui.-1133365211[3] = "lguLHO0esLwCsbOG4Kt2iA==";
                    break;
                }
                case 2: {
                    Gui.-1133365211[0] = "3aAwoEMyc16BEw2blu2FEg==";
                    break;
                }
                case 4: {
                    Gui.-1133365211[0] = "Z+Mz79YVueeVO1lTMZJOmzuJpCU3GRaJ";
                    break;
                }
            }
        }
    }
    
    public static Object 980601331(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4) throws Exception {
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if ((int)o == 184) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

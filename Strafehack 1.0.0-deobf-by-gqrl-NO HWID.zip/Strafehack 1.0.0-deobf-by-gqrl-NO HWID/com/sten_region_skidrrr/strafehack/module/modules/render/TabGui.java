// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.module.modules.render;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import java.util.Iterator;
import com.sten_region_skidrrr.strafehack.module.settings.BooleanSetting;
import com.sten_region_skidrrr.strafehack.module.settings.ModeSetting;
import com.sten_region_skidrrr.strafehack.module.settings.NumberSetting;
import com.sten_region_skidrrr.strafehack.module.settings.KeybindSetting;
import com.sten_region_skidrrr.strafehack.module.settings.Setting;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import com.sten_region_skidrrr.strafehack.module.Category;
import com.sten_region_skidrrr.strafehack.module.Module;

public class TabGui extends Module
{
    public boolean expanded;
    public int index;
    public static int selectedIndex;
    private static String[] -54334315;
    private static String[] -239649606;
    private static long 1807790708;
    private static int 1302577614;
    private static long 2133889613;
    private static long -1504685643;
    private static int 161246421;
    private static long -422828358;
    private static long -88995830;
    private static int 978969020;
    private static int -903048563;
    private static int 872114285;
    private static int 752974258;
    private static int 834276787;
    private static int -1616403449;
    private static int 699155485;
    private static int 1883457645;
    private static int 1930358216;
    private static int 202190701;
    private static int 171554520;
    private static int -1866488598;
    private static int 1915673075;
    private static int -1381329106;
    private static int -2046040949;
    private static int 377840749;
    private static int 1054796549;
    private static int -1674610297;
    private static int -883070580;
    private static int -2143648658;
    private static int -1782773760;
    private static int -1796701282;
    private static int -1317192547;
    private static int -1947728009;
    private static int -117932025;
    private static int 1134889636;
    private static int -177798981;
    private static int 94074686;
    private static int -1013673875;
    private static int 1043703007;
    private static int 836865042;
    private static int 1531119966;
    private static int 1380760605;
    private static int 1967072870;
    private static int -1072807487;
    private static int 1988008171;
    private static int -1212444428;
    private static int 358374895;
    private static int 938076209;
    private static int -1203687253;
    private static int 831125622;
    private static int 1102135984;
    private static int -99764987;
    private static int -1018275873;
    private static int 787323848;
    private static int 1596566246;
    private static int 546632306;
    private static int 1583131800;
    private static int 1141605070;
    private static int 1005142052;
    private static int -1566824168;
    private static int 1519392057;
    private static int 55067198;
    private static int -1421510366;
    private static int 604906045;
    private static int 1755251433;
    private static int -196277746;
    private static int -638212423;
    private static int 2146783448;
    private static int 870872492;
    private static int -1543383068;
    private static int 160012752;
    private static int 205201022;
    private static int -1894389151;
    private static int -1996383237;
    private static int 146716656;
    private static int -242336315;
    private static int 684975793;
    private static int 552572883;
    private static int -1010266805;
    private static int -1579676238;
    private static int 203772557;
    private static int -1652576628;
    private static int 1832842296;
    private static int 1019391969;
    private static int 2021868122;
    private static long 2053163979;
    private static long 598587465;
    private static int 1563425171;
    private static int 452374002;
    private static int 1083417677;
    private static int 1817930306;
    private static int 725405994;
    private static long -1235244091;
    private static int -1894474909;
    private static int 1207490475;
    private static int 1595883142;
    private static int -1523384441;
    private static long 69955696;
    private static int -452120851;
    private static int 901362320;
    private static int 1874768283;
    private static int -1253340629;
    private static long -762665548;
    private static long -1975749571;
    private static int 1054137929;
    private static int 404564304;
    private static int -1537589295;
    private static int 854165955;
    private static int -1569261793;
    private static int -595265487;
    private static int 298221185;
    private static int 1573622883;
    private static int 1700366157;
    private static int -1843346228;
    private static int -1413849094;
    private static int -272557102;
    private static int -1413059064;
    private static int 1859263028;
    private static int 1573220875;
    private static int 1945726466;
    private static int -888200732;
    private static int -913099331;
    private static int 671785778;
    private static int -2037384928;
    private static int 465685624;
    private static int 1241046725;
    private static int -519565367;
    private static int -549712630;
    private static int -1009835551;
    private static int 985520777;
    private static int 1894198664;
    private static int -529922996;
    private static int 1048330131;
    private static int -1605802076;
    private static int 460045408;
    private static int -479429018;
    private static int -1211747479;
    private static int -72022918;
    private static int -273071156;
    private static int -31687322;
    private static int -2031070400;
    private static int -647964512;
    private static int 687498030;
    private static int 1918947992;
    private static int 1481804846;
    private static int 502085563;
    private static int 148649763;
    private static int -1132133088;
    private static int 774298965;
    private static int 661579664;
    private static int 166723577;
    private static int 359155973;
    private static int -531995514;
    private static int 1145769184;
    
    public TabGui() {
        super(invokedynamic(-1002212171:(IJ)Ljava/lang/String;, TabGui.1302577614, TabGui.2133889613 ^ TabGui.-1504685643), invokedynamic(-1444853818:(IJ)Ljava/lang/String;, TabGui.161246421, TabGui.-422828358 ^ TabGui.-88995830), Category.Render, TabGui.978969020);
        this.expanded = (TabGui.-903048563 != 0);
        this.index = TabGui.872114285;
    }
    // invokedynamic(808137903:(Ljava/lang/Object;Z)V, this, TabGui.752974258)
    
    @SubscribeEvent
    public void onRender(final RenderGameOverlayEvent 1276040842) {
        final ScaledResolution scaledResolution = new ScaledResolution(this.mc);
        int 1276040843 = TabGui.834276787;
        final Category[] array = (Category[])invokedynamic(1942185609:()[Lcom/sten_region_skidrrr/strafehack/module/Category;);
        for (int length = array.length, i = TabGui.-1616403449; i < length; ++i) {
            final Category 1276040844 = array[i];
            final double n = 1276040843 * (this.mc.field_71466_p.field_78288_b + TabGui.699155485);
            // invokedynamic(-83844291:(IIIII)V, TabGui.1883457645, (int)n + TabGui.1930358216, TabGui.202190701, (int)n + this.mc.field_71466_p.field_78288_b + TabGui.171554520, TabGui.-1866488598)
            // invokedynamic(1048818407:(Ljava/lang/Object;III)V, invokedynamic(47110704:(Ljava/lang/Object;)Ljava/lang/String;, 1276040844), TabGui.1915673075, (int)n + TabGui.-1381329106, TabGui.-2046040949)
            ++1276040843;
        }
        double n2 = TabGui.selectedIndex * (this.mc.field_71466_p.field_78288_b + TabGui.377840749);
        if (!this.expanded) {
        }
        // invokedynamic(20461164:(IIIII)V, TabGui.1054796549, (int)n2 + TabGui.-1674610297, TabGui.-883070580, (int)n2 + this.mc.field_71466_p.field_78288_b + TabGui.-2143648658, TabGui.-1782773760)
        if (this.expanded) {
            1276040843 = TabGui.-1796701282;
            final Iterator iterator = invokedynamic(-630547355:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(1631713736:(Ljava/lang/Object;)Ljava/util/List;, ((Category[])invokedynamic(-619017768:()[Lcom/sten_region_skidrrr/strafehack/module/Category;))[TabGui.selectedIndex]));
            while (invokedynamic(-165317818:(Ljava/lang/Object;)Z, iterator)) {
                final Module 1276040845 = (Module)invokedynamic(-271304137:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
                n2 = TabGui.selectedIndex * (this.mc.field_71466_p.field_78288_b + TabGui.-1317192547) + 1276040843 * TabGui.-1947728009;
                // invokedynamic(-1908514552:(IIIII)V, TabGui.-117932025, (int)n2 + TabGui.1134889636, TabGui.-177798981, (int)n2 + this.mc.field_71466_p.field_78288_b + TabGui.94074686, TabGui.-1013673875)
                // invokedynamic(-362333144:(Ljava/lang/Object;III)V, invokedynamic(-1379668505:(Ljava/lang/Object;)Ljava/lang/String;, 1276040845), TabGui.1043703007, (int)n2 + TabGui.836865042, TabGui.1531119966)
                ++1276040843;
            }
            final Category 1276040846 = ((Category[])invokedynamic(-1811414776:()[Lcom/sten_region_skidrrr/strafehack/module/Category;))[TabGui.selectedIndex];
            final Module 1276040847 = (Module)invokedynamic(1304444894:(Ljava/lang/Object;I)Ljava/lang/Object;, invokedynamic(2102378842:(Ljava/lang/Object;)Ljava/util/List;, 1276040846), 1276040846.moduleIndex);
            if (!invokedynamic(-1144393978:(Ljava/lang/Object;)Z, 1276040847)) {
                n2 = 1276040846.moduleIndex * (this.mc.field_71466_p.field_78288_b + TabGui.1380760605) + TabGui.selectedIndex * TabGui.1967072870;
            }
            // invokedynamic(578082100:(IIIII)V, TabGui.-1072807487, (int)n2 + TabGui.1988008171, TabGui.-1212444428, (int)n2 + this.mc.field_71466_p.field_78288_b + TabGui.358374895, TabGui.938076209)
            else {
                1276040843 = TabGui.-1203687253;
                final Iterator iterator2 = invokedynamic(-860076459:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(1233906985:(Ljava/lang/Object;)Ljava/util/List;, 1276040847));
                while (invokedynamic(-1228044817:(Ljava/lang/Object;)Z, iterator2)) {
                    final Setting 1276040848 = (Setting)invokedynamic(1939397303:(Ljava/lang/Object;)Ljava/lang/Object;, iterator2);
                    n2 = TabGui.selectedIndex * (this.mc.field_71466_p.field_78288_b + TabGui.831125622) + 1276040843 * TabGui.1102135984 + 1276040846.moduleIndex * TabGui.-99764987;
                    // invokedynamic(-551839726:(IIIII)V, TabGui.-1018275873, (int)n2 + TabGui.787323848, TabGui.1596566246, (int)n2 + this.mc.field_71466_p.field_78288_b + TabGui.546632306, TabGui.1583131800)
                    n2 = 1276040847.index * (this.mc.field_71466_p.field_78288_b + TabGui.1141605070) + TabGui.selectedIndex * TabGui.1005142052 + 1276040846.moduleIndex * TabGui.-1566824168;
                    // invokedynamic(1923379842:(IIIII)V, TabGui.1519392057, (int)n2 + TabGui.55067198, TabGui.-1421510366, (int)n2 + this.mc.field_71466_p.field_78288_b + TabGui.604906045, TabGui.1755251433)
                    n2 = TabGui.selectedIndex * (this.mc.field_71466_p.field_78288_b + TabGui.-196277746) + 1276040843 * TabGui.-638212423 + 1276040846.moduleIndex * TabGui.2146783448;
                    if (1276040848.focussed) {
                    }
                    // invokedynamic(283030036:(Ljava/lang/Object;IIII)V, this, TabGui.870872492, TabGui.-1543383068, (int)n2 + TabGui.160012752, TabGui.205201022)
                    // invokedynamic(1365576820:(Ljava/lang/Object;IIII)V, this, TabGui.-1894389151, TabGui.-1996383237, (int)n2 + this.mc.field_71466_p.field_78288_b + TabGui.146716656, TabGui.-242336315)
                    // invokedynamic(-449139140:(Ljava/lang/Object;IIII)V, this, TabGui.684975793, (int)n2 + TabGui.552572883, (int)n2 + this.mc.field_71466_p.field_78288_b + TabGui.-1010266805, TabGui.-1579676238)
                    // invokedynamic(1707373385:(Ljava/lang/Object;IIII)V, this, TabGui.203772557, (int)n2 + TabGui.-1652576628, (int)n2 + this.mc.field_71466_p.field_78288_b + TabGui.1832842296, TabGui.1019391969)
                    if (1276040848 instanceof KeybindSetting) {
                        final KeybindSetting 1276040849 = (KeybindSetting)1276040848;
                    }
                    // invokedynamic(1012895017:(Ljava/lang/Object;III)V, invokedynamic(-1395836614:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-796528212:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-158507871:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(1986603110:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), 1276040849.name), invokedynamic(1474356954:(IJ)Ljava/lang/String;, TabGui.2021868122, TabGui.2053163979 ^ TabGui.598587465)), invokedynamic(517584935:(I)Ljava/lang/String;, 1276040849.code))), TabGui.1563425171, (int)n2 + TabGui.452374002, TabGui.1083417677)
                    if (1276040848 instanceof NumberSetting) {
                        final NumberSetting numberSetting = (NumberSetting)1276040848;
                    }
                    // invokedynamic(1583038110:(Ljava/lang/Object;III)V, invokedynamic(-1029240678:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(1492360070:(Ljava/lang/Object;D)Ljava/lang/StringBuilder;, invokedynamic(-833665359:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-1670889158:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), numberSetting.name), invokedynamic(1945046578:(IJ)Ljava/lang/String;, TabGui.1817930306 & TabGui.725405994, TabGui.-1235244091)), invokedynamic(-140112514:(Ljava/lang/Object;)D, numberSetting))), TabGui.-1894474909, (int)n2 + TabGui.1207490475, TabGui.1595883142)
                    if (1276040848 instanceof ModeSetting) {
                        final ModeSetting modeSetting = (ModeSetting)1276040848;
                    }
                    // invokedynamic(-229212033:(Ljava/lang/Object;III)V, invokedynamic(581064440:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(454449488:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(1394193062:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-1386269912:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), modeSetting.name), invokedynamic(-1471578134:(IJ)Ljava/lang/String;, TabGui.-1523384441, TabGui.69955696)), invokedynamic(1876461585:(Ljava/lang/Object;)Ljava/lang/String;, modeSetting))), TabGui.-452120851, (int)n2 + TabGui.901362320, TabGui.1874768283)
                    if (1276040848 instanceof BooleanSetting) {
                        final BooleanSetting 1276040850 = (BooleanSetting)1276040848;
                    }
                    // invokedynamic(388819683:(Ljava/lang/Object;III)V, invokedynamic(1888454984:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-319690098:(Ljava/lang/Object;Z)Ljava/lang/StringBuilder;, invokedynamic(-1917627156:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(1818595467:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), 1276040850.name), invokedynamic(-2072744551:(IJ)Ljava/lang/String;, TabGui.-1253340629, TabGui.-762665548 ^ TabGui.-1975749571)), invokedynamic(-958280650:(Ljava/lang/Object;)Z, 1276040850))), TabGui.1054137929, (int)n2 + TabGui.404564304, TabGui.-1537589295)
                    ++1276040843;
                }
            }
        }
    }
    // invokedynamic(-430096862:()V)
    
    protected void drawHorizontalLine(int 1912238934, int 6931153, final int -811067099, final int 2024441877) {
        if (6931153 < 1912238934) {
            final int 2024441878 = 1912238934;
            1912238934 = 6931153;
            6931153 = 2024441878;
        }
    }
    // invokedynamic(-1243460728:(IIIII)V, 1912238934, -811067099, 6931153 + TabGui.854165955, -811067099 + TabGui.-1569261793, 2024441877)
    
    protected void drawVerticalLine(final int 111443700, int -556003823, int 34241174, final int 750148578) {
        if (34241174 < -556003823) {
            final int 750148579 = -556003823;
            -556003823 = 34241174;
            34241174 = 750148579;
        }
    }
    // invokedynamic(1762241096:(IIIII)V, 111443700, -556003823 + TabGui.-595265487, 111443700 + TabGui.298221185, 34241174, 750148578)
    
    public void ResetFocussed() {
        final Iterator iterator = invokedynamic(1165827118:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(-1810723904:()Ljava/util/ArrayList;));
        while (invokedynamic(-1299002983:(Ljava/lang/Object;)Z, iterator)) {
            final Module 1622852395 = (Module)invokedynamic(627400084:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
            final Iterator iterator2 = invokedynamic(1858979384:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(-57844527:(Ljava/lang/Object;)Ljava/util/List;, 1622852395));
            while (invokedynamic(-1033697695:(Ljava/lang/Object;)Z, iterator2)) {
                final Setting 1622852396 = (Setting)invokedynamic(357059560:(Ljava/lang/Object;)Ljava/lang/Object;, iterator2);
                1622852396.focussed = (TabGui.1573622883 != 0);
            }
        }
    }
    
    @SubscribeEvent
    public void onKey(final InputEvent.KeyInputEvent -1776150899) {
        final Category category = ((Category[])invokedynamic(-1021853440:()[Lcom/sten_region_skidrrr/strafehack/module/Category;))[TabGui.selectedIndex];
        final Module module = (Module)invokedynamic(1346166937:(Ljava/lang/Object;I)Ljava/lang/Object;, invokedynamic(424515568:(Ljava/lang/Object;)Ljava/util/List;, category), category.moduleIndex);
        final Setting 1364366201 = (Setting)invokedynamic(-530246177:(Ljava/lang/Object;I)Ljava/lang/Object;, invokedynamic(2131409545:(Ljava/lang/Object;)Ljava/util/List;, module), module.index);
        if (!this.expanded) {
            if (invokedynamic(123003946:(I)Z, TabGui.1700366157) && TabGui.selectedIndex > 0) {
                TabGui.selectedIndex -= TabGui.-1843346228;
            }
            if (invokedynamic(-1788539390:(I)Z, TabGui.-1413849094) && TabGui.selectedIndex < ((Category[])invokedynamic(1126959039:()[Lcom/sten_region_skidrrr/strafehack/module/Category;)).length - TabGui.-272557102) {
                TabGui.selectedIndex += TabGui.-1413059064;
            }
        }
        else {
            if (invokedynamic(-1151128651:(I)Z, TabGui.1859263028) && category.moduleIndex > 0 && !invokedynamic(-1569426221:(Ljava/lang/Object;)Z, module)) {
                final Category category2 = category;
                category2.moduleIndex -= TabGui.1573220875;
            }
            if (invokedynamic(-1855307441:(I)Z, TabGui.1945726466) && category.moduleIndex < invokedynamic(-1903605204:(Ljava/lang/Object;)I, invokedynamic(-1081875077:(Ljava/lang/Object;)Ljava/util/List;, ((Category[])invokedynamic(-808375465:()[Lcom/sten_region_skidrrr/strafehack/module/Category;))[TabGui.selectedIndex])) - TabGui.-888200732 && !invokedynamic(1553406568:(Ljava/lang/Object;)Z, module)) {
                final Category category3 = category;
                category3.moduleIndex += TabGui.-913099331;
            }
            if (invokedynamic(-1937254150:(I)Z, TabGui.671785778) && !invokedynamic(-1155221875:(Ljava/lang/Object;)Z, module)) {
            }
            // invokedynamic(2105827546:(Ljava/lang/Object;)V, module)
            // invokedynamic(1073302902:(Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;, module.properties.settings, invokedynamic(-2011049848:(Ljava/lang/Object;Ljava/lang/Object;)I, invokedynamic(1596476676:(Ljava/lang/Object;)Ljava/util/List;, module), 1364366201), 1364366201.value)
            // invokedynamic(572499791:()V)
            if (invokedynamic(-1473974876:(Ljava/lang/Object;)Z, module)) {
                if (invokedynamic(-1555835309:(I)Z, TabGui.-2037384928) && this.expanded && module.index > 0) {
                    final Module module2 = module;
                    module2.index -= TabGui.465685624;
                }
                if (invokedynamic(-1480066192:(I)Z, TabGui.1241046725) && this.expanded && module.index < invokedynamic(-943710602:(Ljava/lang/Object;)I, invokedynamic(-1923318765:(Ljava/lang/Object;)Ljava/util/List;, module)) - TabGui.-519565367) {
                    final Module module3 = module;
                    module3.index += TabGui.-549712630;
                }
                if (invokedynamic(-1984255134:(I)Z, TabGui.-1009835551)) {
                    if (!(1364366201 instanceof BooleanSetting)) {
                        final boolean 1364366202 = 1364366201.focussed;
                        // invokedynamic(-1231455607:(Ljava/lang/Object;)V, this)
                        1364366201.focussed = ((1364366202 ? TabGui.1894198664 : TabGui.985520777) != 0);
                    }
                    else if (1364366201 instanceof BooleanSetting) {
                    }
                    // invokedynamic(-234304387:(Ljava/lang/Object;)V, (BooleanSetting)1364366201)
                    // invokedynamic(-1775283023:(Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;, module.properties.settings, invokedynamic(422081751:(Ljava/lang/Object;Ljava/lang/Object;)I, invokedynamic(-1500602070:(Ljava/lang/Object;)Ljava/util/List;, module), 1364366201), 1364366201.value)
                    // invokedynamic(385929234:()V)
                }
                if (1364366201 instanceof NumberSetting && 1364366201.focussed) {
                    final NumberSetting numberSetting = (NumberSetting)1364366201;
                    if (invokedynamic(-1183724451:(I)Z, TabGui.-529922996)) {
                    }
                    // invokedynamic(340088370:(Ljava/lang/Object;D)V, numberSetting, invokedynamic(1306450558:(Ljava/lang/Object;)D, numberSetting) - 1.0)
                    // invokedynamic(-897088964:(Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;, module.properties.settings, invokedynamic(92472793:(Ljava/lang/Object;Ljava/lang/Object;)I, invokedynamic(9876864:(Ljava/lang/Object;)Ljava/util/List;, module), 1364366201), 1364366201.value)
                    // invokedynamic(681004511:()V)
                    if (invokedynamic(-1508568247:(I)Z, TabGui.1048330131)) {
                    }
                    // invokedynamic(493628204:(Ljava/lang/Object;D)V, numberSetting, invokedynamic(1320121748:(Ljava/lang/Object;)D, numberSetting) + 1.0)
                    // invokedynamic(-97001869:(Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;, module.properties.settings, invokedynamic(-51341039:(Ljava/lang/Object;Ljava/lang/Object;)I, invokedynamic(1597624556:(Ljava/lang/Object;)Ljava/util/List;, module), 1364366201), 1364366201.value)
                    // invokedynamic(1259646841:()V)
                }
                if (1364366201.focussed) {
                    if (1364366201 instanceof KeybindSetting && !invokedynamic(60642595:(I)Z, TabGui.-1605802076)) {
                        if (invokedynamic(841262346:(I)Z, TabGui.460045408)) {
                            ((KeybindSetting)1364366201).code = TabGui.-479429018;
                            1364366201.focussed = (TabGui.-1211747479 != 0);
                        }
                        else {
                            1364366201.focussed = (TabGui.-72022918 != 0);
                        }
                    }
                    if (1364366201 instanceof ModeSetting) {
                        if (!invokedynamic(594969362:(I)Z, TabGui.-273071156)) {
                            if (invokedynamic(322999202:(I)Z, TabGui.-2031070400)) {
                            }
                            // invokedynamic(-1303909140:(Ljava/lang/Object;I)V, (ModeSetting)1364366201, TabGui.-647964512)
                            // invokedynamic(-803690967:(Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;, module.properties.settings, invokedynamic(329893484:(Ljava/lang/Object;Ljava/lang/Object;)I, invokedynamic(-236714426:(Ljava/lang/Object;)Ljava/util/List;, module), 1364366201), 1364366201.value)
                            // invokedynamic(1923633781:()V)
                        }
                    }
                }
            }
        }
        if (invokedynamic(1834907788:(I)Z, TabGui.687498030)) {
            if (!this.expanded) {
                this.expanded = (TabGui.1481804846 != 0);
            }
        }
        if (invokedynamic(687722855:(I)Z, TabGui.502085563) && !1364366201.focussed) {
            if (!invokedynamic(551072151:(Ljava/lang/Object;)Z, module) || !this.expanded) {
                this.expanded = (TabGui.-1132133088 != 0);
            }
            // invokedynamic(1450955129:(Ljava/lang/Object;Z)V, module, TabGui.774298965)
        }
    }
    
    static {
        TabGui.-531995514 = -1200047840;
        TabGui.1145769184 = 184;
        TabGui.1302577614 = invokedynamic(-508783073:(I)I, false);
        TabGui.2133889613 = invokedynamic(946429458:(J)J, -3598926016989653942L);
        TabGui.-1504685643 = invokedynamic(-451154320:(J)J, 1008806316530991104L);
        TabGui.161246421 = invokedynamic(-1658694807:(I)I, Integer.MIN_VALUE);
        TabGui.-422828358 = invokedynamic(84626702:(J)J, -3598926016989653942L);
        TabGui.-88995830 = invokedynamic(-869484462:(J)J, 1008806316530991104L);
        TabGui.978969020 = ((0 >>> 47 | 0 << -47) & -1);
        TabGui.-903048563 = invokedynamic(-1066443724:(I)I, false);
        TabGui.872114285 = invokedynamic(-657438457:(I)I, false);
        TabGui.752974258 = ((16777216 >>> 56 | 16777216 << ~0x38 + 1) & -1);
        TabGui.834276787 = invokedynamic(75785055:(I)I, false);
        TabGui.-1616403449 = ((0 >>> 29 | 0 << -29) & -1);
        TabGui.699155485 = invokedynamic(-1905542824:(I)I, -1610612736);
        TabGui.1883457645 = invokedynamic(-1812090783:(I)I, -1342177280);
        TabGui.1930358216 = (394264576 >>> 55 | 394264576 << ~0x37 + 1);
        TabGui.202190701 = invokedynamic(732106865:(I)I, 167772160);
        TabGui.171554520 = (54525952 >>> 180 | 54525952 << ~0xB4 + 1);
        TabGui.-1866488598 = invokedynamic(2018232343:(I)I, 192);
        TabGui.1915673075 = invokedynamic(-148634424:(I)I, 1207959552);
        TabGui.-1381329106 = (24064 >>> 41 | 24064 << -41);
        TabGui.-2046040949 = (268435440 >>> 36 | 268435440 << ~0x24 + 1);
        TabGui.377840749 = invokedynamic(-31443656:(I)I, -1610612736);
        TabGui.1054796549 = ((872415232 >>> 58 | 872415232 << ~0x3A + 1) & -1);
        TabGui.-1674610297 = invokedynamic(-191037535:(I)I, -201326592);
        TabGui.-883070580 = (112 >>> 67 | 112 << -67);
        TabGui.-2143648658 = invokedynamic(1585551433:(I)I, 738197504);
        TabGui.-1782773760 = invokedynamic(-1364688041:(I)I, -16187137);
        TabGui.-1796701282 = ((0 >>> 83 | 0 << -83) & -1);
        TabGui.-1317192547 = (10 >>> 193 | 10 << ~0xC1 + 1);
        TabGui.-1947728009 = invokedynamic(-81257977:(I)I, 1879048192);
        TabGui.-117932025 = invokedynamic(624512431:(I)I, 167772160);
        TabGui.1134889636 = (2013265921 >>> 27 | 2013265921 << ~0x1B + 1);
        TabGui.-177798981 = invokedynamic(1090403564:(I)I, -922746880);
        TabGui.94074686 = (1744830464 >>> 249 | 1744830464 << ~0xF9 + 1);
        TabGui.-1013673875 = invokedynamic(-271049264:(I)I, 192);
        TabGui.1043703007 = (348160 >>> 108 | 348160 << -108);
        TabGui.836865042 = (24641536 >>> 83 | 24641536 << ~0x53 + 1);
        TabGui.1531119966 = ((67108860 >>> 194 | 67108860 << -194) & -1);
        TabGui.1380760605 = invokedynamic(-995960090:(I)I, -1610612736);
        TabGui.1967072870 = ((-1073741823 >>> 125 | -1073741823 << ~0x7D + 1) & -1);
        TabGui.-1072807487 = (10240 >>> 135 | 10240 << ~0x87 + 1);
        TabGui.1988008171 = invokedynamic(984701680:(I)I, -201326592);
        TabGui.-1212444428 = invokedynamic(-190974295:(I)I, -1979711488);
        TabGui.358374895 = (27262976 >>> 115 | 27262976 << ~0x73 + 1);
        TabGui.938076209 = invokedynamic(815262610:(I)I, -16187137);
        TabGui.-1203687253 = invokedynamic(1506825249:(I)I, false);
        TabGui.831125622 = invokedynamic(-937430807:(I)I, -1610612736);
        TabGui.1102135984 = invokedynamic(-647196145:(I)I, 1879048192);
        TabGui.-99764987 = ((56 >>> 98 | 56 << ~0x62 + 1) & -1);
        TabGui.-1018275873 = invokedynamic(-1666674190:(I)I, -922746880);
        TabGui.787323848 = invokedynamic(-1452228087:(I)I, -201326592);
        TabGui.1596566246 = invokedynamic(304775533:(I)I, 1593835520);
        TabGui.546632306 = invokedynamic(-869830558:(I)I, 738197504);
        TabGui.1583131800 = (12288 >>> 212 | 12288 << ~0xD4 + 1);
        TabGui.1141605070 = (1310720 >>> 146 | 1310720 << -146);
        TabGui.1005142052 = (917504 >>> 112 | 917504 << ~0x70 + 1);
        TabGui.-1566824168 = invokedynamic(-764377088:(I)I, 1879048192);
        TabGui.1519392057 = ((4704 >>> 5 | 4704 << ~0x5 + 1) & -1);
        TabGui.55067198 = (385024 >>> 45 | 385024 << ~0x2D + 1);
        TabGui.-1421510366 = (-2147483630 >>> 189 | -2147483630 << -189);
        TabGui.604906045 = ((26 >>> 223 | 26 << ~0xDF + 1) & -1);
        TabGui.1755251433 = invokedynamic(-224122764:(I)I, -16187137);
        TabGui.-196277746 = ((20480 >>> 236 | 20480 << ~0xEC + 1) & -1);
        TabGui.-638212423 = invokedynamic(-455577932:(I)I, 1879048192);
        TabGui.2146783448 = ((57344 >>> 44 | 57344 << ~0x2C + 1) & -1);
        TabGui.870872492 = ((-1828716544 >>> 120 | -1828716544 << ~0x78 + 1) & -1);
        TabGui.-1543383068 = ((1044381696 >>> 86 | 1044381696 << ~0x56 + 1) & -1);
        TabGui.160012752 = (94 >>> 33 | 94 << ~0x21 + 1);
        TabGui.205201022 = invokedynamic(-1089534997:(I)I, -16187137);
        TabGui.-1894389151 = invokedynamic(112628767:(I)I, -922746880);
        TabGui.-1996383237 = ((15936 >>> 230 | 15936 << -230) & -1);
        TabGui.146716656 = (1744830464 >>> 89 | 1744830464 << -89);
        TabGui.-242336315 = (-8370049 >>> 63 | -8370049 << ~0x3F + 1);
        TabGui.684975793 = invokedynamic(1300366676:(I)I, -1627389952);
        TabGui.552572883 = ((376 >>> 195 | 376 << ~0xC3 + 1) & -1);
        TabGui.-1010266805 = (-1610612735 >>> 123 | -1610612735 << ~0x7B + 1);
        TabGui.-1579676238 = (-523129 >>> 155 | -523129 << -155);
        TabGui.203772557 = invokedynamic(235239212:(I)I, -922746880);
        TabGui.-1652576628 = ((94 >>> 97 | 94 << -97) & -1);
        TabGui.1832842296 = ((872415232 >>> 216 | 872415232 << ~0xD8 + 1) & -1);
        TabGui.1019391969 = (-8370049 >>> 223 | -8370049 << ~0xDF + 1);
        TabGui.2021868122 = invokedynamic(1958327086:(I)I, 1073741824);
        TabGui.2053163979 = invokedynamic(1505280786:(J)J, -3598926016989653942L);
        TabGui.598587465 = invokedynamic(1567619305:(J)J, 1008806316530991104L);
        TabGui.1563425171 = (633339904 >>> 150 | 633339904 << -150);
        TabGui.452374002 = invokedynamic(-1799086863:(I)I, 201326592);
        TabGui.1083417677 = invokedynamic(1069188459:(I)I, -256);
        TabGui.1817930306 = invokedynamic(1683322602:(I)I, -1073741824);
        TabGui.725405994 = ((-1 >>> 205 | -1 << -205) & -1);
        TabGui.-1235244091 = invokedynamic(1092290240:(J)J, -4607732333520645046L);
        TabGui.-1894474909 = (-1207959548 >>> 27 | -1207959548 << -27);
        TabGui.1207490475 = invokedynamic(1554814549:(I)I, 201326592);
        TabGui.1595883142 = (-522241 >>> 211 | -522241 << -211);
        TabGui.-1523384441 = ((4194304 >>> 116 | 4194304 << -116) & -1);
        TabGui.69955696 = invokedynamic(773044698:(J)J, -4607732333520645046L);
        TabGui.-452120851 = invokedynamic(754885041:(I)I, -385875968);
        TabGui.901362320 = (48 >>> 64 | 48 << -64);
        TabGui.1874768283 = invokedynamic(2120793521:(I)I, -256);
        TabGui.-1253340629 = invokedynamic(1712943987:(I)I, -1610612736);
        TabGui.-762665548 = invokedynamic(118280638:(J)J, -3598926016989653942L);
        TabGui.-1975749571 = invokedynamic(-660793274:(J)J, 1008806316530991104L);
        TabGui.1054137929 = invokedynamic(1192565299:(I)I, -385875968);
        TabGui.404564304 = (24576 >>> 73 | 24576 << ~0x49 + 1);
        TabGui.-1537589295 = ((-256 >>> 136 | -256 << -136) & -1);
        TabGui.854165955 = invokedynamic(269749081:(I)I, Integer.MIN_VALUE);
        TabGui.-1569261793 = (4194304 >>> 214 | 4194304 << ~0xD6 + 1);
        TabGui.-595265487 = invokedynamic(1035465308:(I)I, Integer.MIN_VALUE);
        TabGui.298221185 = invokedynamic(1042566354:(I)I, Integer.MIN_VALUE);
        TabGui.1573622883 = invokedynamic(639926058:(I)I, false);
        TabGui.1700366157 = (3276800 >>> 78 | 3276800 << ~0x4E + 1);
        TabGui.-1843346228 = invokedynamic(-1512748538:(I)I, Integer.MIN_VALUE);
        TabGui.-1413849094 = invokedynamic(-131635643:(I)I, 184549376);
        TabGui.-272557102 = (16 >>> 228 | 16 << ~0xE4 + 1);
        TabGui.-1413059064 = invokedynamic(-1532857945:(I)I, Integer.MIN_VALUE);
        TabGui.1859263028 = invokedynamic(1274150821:(I)I, 318767104);
        TabGui.1573220875 = (64 >>> 102 | 64 << ~0x66 + 1);
        TabGui.1945726466 = invokedynamic(-580872275:(I)I, 184549376);
        TabGui.-888200732 = (16777216 >>> 24 | 16777216 << ~0x18 + 1);
        TabGui.-913099331 = ((8192 >>> 141 | 8192 << -141) & -1);
        TabGui.671785778 = invokedynamic(1562770986:(I)I, 939524096);
        TabGui.-2037384928 = (-939524096 >>> 184 | -939524096 << -184);
        TabGui.465685624 = (4 >>> 226 | 4 << -226);
        TabGui.1241046725 = invokedynamic(1206845287:(I)I, 184549376);
        TabGui.-519565367 = ((2 >>> 225 | 2 << -225) & -1);
        TabGui.-549712630 = (4194304 >>> 150 | 4194304 << ~0x96 + 1);
        TabGui.-1009835551 = (114688 >>> 236 | 114688 << ~0xEC + 1);
        TabGui.985520777 = invokedynamic(2133374726:(I)I, Integer.MIN_VALUE);
        TabGui.1894198664 = (0 >>> 61 | 0 << ~0x3D + 1);
        TabGui.-529922996 = ((738197507 >>> 154 | 738197507 << -154) & -1);
        TabGui.1048330131 = invokedynamic(-726623778:(I)I, -1291845632);
        TabGui.-1605802076 = invokedynamic(1893031509:(I)I, 939524096);
        TabGui.460045408 = (917504 >>> 240 | 917504 << ~0xF0 + 1);
        TabGui.-479429018 = invokedynamic(-566085907:(I)I, false);
        TabGui.-1211747479 = ((0 >>> 93 | 0 << ~0x5D + 1) & -1);
        TabGui.-72022918 = ((0 >>> 28 | 0 << ~0x1C + 1) & -1);
        TabGui.-273071156 = (106430464 >>> 147 | 106430464 << ~0x93 + 1);
        TabGui.-31687322 = invokedynamic(1819940462:(I)I, -1);
        TabGui.-2031070400 = ((13120 >>> 166 | 13120 << ~0xA6 + 1) & -1);
        TabGui.-647964512 = invokedynamic(1544952259:(I)I, Integer.MIN_VALUE);
        TabGui.687498030 = invokedynamic(1364062471:(I)I, -1291845632);
        TabGui.1918947992 = ((16384 >>> 110 | 16384 << -110) & -1);
        TabGui.1481804846 = ((8 >>> 227 | 8 << ~0xE3 + 1) & -1);
        TabGui.502085563 = ((6651904 >>> 207 | 6651904 << -207) & -1);
        TabGui.148649763 = (0 >>> 26 | 0 << -26);
        TabGui.-1132133088 = invokedynamic(-1589262464:(I)I, false);
        TabGui.774298965 = invokedynamic(-497339020:(I)I, false);
        TabGui.661579664 = ((196608 >>> 15 | 196608 << ~0xF + 1) & -1);
        TabGui.166723577 = invokedynamic(740210758:(I)I, 1610612736);
        TabGui.359155973 = invokedynamic(-972618339:(I)I, false);
        TabGui.-54334315 = new String[TabGui.661579664];
        TabGui.-239649606 = new String[TabGui.166723577];
        // invokedynamic(1876773240:()V)
        TabGui.selectedIndex = TabGui.359155973;
    }
    
    private static Object 297432980(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(TabGui.class, "-879996564", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", TabGui.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/render/TabGui:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String -879996564(final int n, long n2) {
        n2 ^= 0x70L;
        n2 ^= 0xB54234120BD848C2L;
        if (TabGui.-54334315[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/module/modules/render/TabGui");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            TabGui.-54334315[n] = new String(instance.doFinal(Base64.getDecoder().decode(TabGui.-239649606[n])));
        }
        return TabGui.-54334315[n];
    }
    
    private static void -1869026154() {
        TabGui.1807790708 = 5920498484331442291L;
        final long n = TabGui.1807790708 ^ 0xB54234120BD848C2L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    TabGui.-239649606[0] = "pZOGbSOBs00=";
                    TabGui.-239649606[1] = "mr5rMk0Mxj7q33H6LKJtGgLSelWCQjYd0W34eAZONs/R0oxRTNTI+fi+itZf5fYCu26gNCoHDC+E5UOQ/TnRdh8sOPp6NGfQ+eWO9zgd2R8=";
                    TabGui.-239649606[2] = "euToj3CwdeM=";
                    TabGui.-239649606[3] = "euToj3CwdeM=";
                    TabGui.-239649606[4] = "euToj3CwdeM=";
                    TabGui.-239649606[5] = "euToj3CwdeM=";
                    break;
                }
                case 1: {
                    TabGui.-239649606[0] = "B4PVeVvGBEhGyHaZTyq3gg==";
                    TabGui.-239649606[1] = "mr5rMk0Mxj7q33H6LKJtGgLSelWCQjYd0W34eAZONs/R0oxRTNTI+fi+itZf5fYCu26gNCoHDC+E5UOQ/TnRdh8sOPp6NGfQtgzg+KtK7x0=";
                    TabGui.-239649606[2] = "P4RsbtLPVUE=";
                    TabGui.-239649606[3] = "1TJwQ8VJ+c8=";
                    TabGui.-239649606[4] = "7PjKvH8d8Oo=";
                    TabGui.-239649606[5] = "k54w/tQFTOA=";
                    break;
                }
                case 2: {
                    TabGui.-239649606[0] = "r9gT27qIbDY3+VlvaSehtqVJwev0ylwD";
                    break;
                }
                case 4: {
                    TabGui.-239649606[0] = "dadGLnwhOeEWgEubB26RD9THIkOXIKxg";
                    break;
                }
            }
        }
    }
    
    public static Object -1047874694(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7) throws Exception {
        final int n = ((int)o ^ TabGui.-531995514) & 0xFF;
        final Integer value = TabGui.1145769184;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

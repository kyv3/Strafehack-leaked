// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.utils;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import net.minecraft.client.resources.IResourceManager;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.ResourceLocation;
import java.awt.Font;
import com.sten_region_skidrrr.strafehack.ui.CustomFont;
import java.awt.Color;
import java.util.Random;
import net.minecraft.client.gui.FontRenderer;

public class TextRenderer extends FontRenderer
{
    public final Random field_78289_c;
    private final Color[] customColorCodes;
    private final int[] colorCode;
    private CustomFont font;
    private CustomFont boldFont;
    private CustomFont italicFont;
    private CustomFont boldItalicFont;
    private String colorcodeIdentifiers;
    private boolean bidi;
    private static String[] -1514998616;
    private static String[] -1385459114;
    private static long 811770822;
    private static int 1205570811;
    private static long 591400605;
    private static long 1386259016;
    private static int -1041617931;
    private static int -1369366506;
    private static int 201882089;
    private static int 503646832;
    private static long -743861171;
    private static long 2125254279;
    private static int -865314576;
    private static int -1479304347;
    private static int 739720435;
    private static int 43837774;
    private static int -903775476;
    private static int -1536221337;
    private static int 1435784082;
    private static int -225316734;
    private static int -1209746971;
    private static int -1403628503;
    private static int -476214552;
    private static int 2011898059;
    private static int -1868667367;
    private static long 1975458452;
    private static int -2057351931;
    private static int 1352320227;
    private static double 1562634920;
    private static double -1374696347;
    private static int 366795344;
    private static int 191795280;
    private static int -767571854;
    private static int -63262953;
    private static int 461977679;
    private static int 2044993375;
    private static int 1596593005;
    private static int 2083657632;
    private static int -1737304876;
    private static int 1698150970;
    private static int 2097184616;
    private static int -1029409504;
    private static float -1407704151;
    private static int 568881206;
    private static int -188022729;
    private static float 668506476;
    private static int 1866684162;
    private static float 205122789;
    private static int -387743090;
    private static int 1596440965;
    private static float 85154669;
    private static int 1967926438;
    private static long -1138114571;
    private static int 1484283241;
    private static long -1680931627;
    private static long -970863457;
    private static int -1654493581;
    private static int 1143000355;
    private static int -1285183868;
    private static int -892420004;
    private static int -620035338;
    private static int -1697946882;
    private static int 1633394987;
    private static int -782821162;
    private static int 1089442789;
    private static int 1140792044;
    private static int -275655162;
    private static int 855298866;
    private static int 345945934;
    private static int 291148946;
    private static int 1858682380;
    private static int -1223988382;
    private static int 1797660803;
    private static int 1892003498;
    private static int -1025963001;
    private static int 2006181473;
    private static int 1180032116;
    private static int 1713415775;
    private static int -800515210;
    private static int 800371133;
    private static int -1557118310;
    private static int -351748070;
    private static int 580152762;
    private static int 634792260;
    private static int 257856234;
    private static int -121624570;
    private static int 1409373178;
    private static int 847285085;
    private static int -1208356195;
    private static float -134832007;
    private static float -688349825;
    private static float 1534924353;
    private static float 1112505734;
    private static double 1323859217;
    private static int 279292722;
    private static double 1048097905;
    private static int -736018880;
    private static double 600114688;
    private static int -886211835;
    private static double -340444438;
    private static int -272650087;
    private static int 1273995437;
    private static int 1283200411;
    private static long 2003660710;
    private static long 1071336356;
    private static int 621225094;
    private static int 539579897;
    private static long -430094675;
    private static int 1262246656;
    private static int -1403325930;
    private static int -1470895736;
    private static long 969334599;
    private static int -2126706212;
    private static long 25262731;
    private static long -1654477283;
    private static int -1282569876;
    private static int 960816026;
    private static int 1669463769;
    private static int -24615174;
    private static int -2068189607;
    private static long 622444640;
    private static int -2115613905;
    private static int -1008772484;
    private static int -220270196;
    private static int -1444362027;
    private static int 526833044;
    private static int -819241858;
    private static int -1093407262;
    private static long -571505505;
    private static long -462034986;
    private static int -1145035048;
    private static long 1501600034;
    private static int -1471905301;
    private static int -1965430370;
    private static int 165544397;
    private static int 1731230478;
    private static int -1075610938;
    private static int 956004388;
    private static int -504843774;
    private static int -161356744;
    private static int -1554763883;
    private static int 247018453;
    private static long -1327776929;
    private static int 959721934;
    private static int -1453498832;
    private static int -1201068070;
    private static int -298994627;
    private static int 298306419;
    private static int 393230440;
    private static int 947573388;
    private static int 867072764;
    private static int -1104464188;
    private static int 1895894940;
    private static int 898854063;
    private static int 188109048;
    private static int 1156446089;
    private static int 28551019;
    private static int 2077667954;
    private static int 349259128;
    private static int 1175095018;
    private static int -1459562744;
    private static int -1542142093;
    private static int -214635668;
    private static int -407230057;
    private static int -483402464;
    private static int -201241341;
    private static long 998031541;
    private static int 1722647463;
    private static int 1448781755;
    private static long 1419963442;
    private static int 1470837079;
    private static int -1296219430;
    private static int 1021690385;
    private static int 468588310;
    private static int -2096988226;
    private static int 1534401244;
    private static int 1739741210;
    private static int 433415929;
    private static int -1897999605;
    private static int 1143716891;
    private static int 1678605331;
    private static int 1205437945;
    private static int -2117968845;
    private static int 562444384;
    private static int -1735791789;
    private static int -1024865711;
    private static int 1285986482;
    private static int -1552167533;
    private static int 240906699;
    private static int 1107588653;
    private static int -2133966555;
    private static int -1632922972;
    private static int -177996765;
    private static int 616497467;
    private static int 629265458;
    private static int 929629397;
    private static long -2009842092;
    private static int -1977451877;
    private static long 619105736;
    private static long 1715088025;
    private static int 467447897;
    private static int 731660032;
    private static int -396537524;
    private static int 1863857876;
    private static int -1729217847;
    private static int 1756949701;
    private static int 293633219;
    private static long 1043472191;
    private static long -1058239760;
    private static int 1452220936;
    private static long 1379282016;
    private static int -776840639;
    private static int -428923347;
    private static long 261785338;
    private static long 1171412605;
    private static int -1892815939;
    private static int -1246714602;
    private static long 1086345729;
    private static int 1575123375;
    private static int -1150836016;
    private static long -1349155928;
    private static int -422650121;
    private static long 77510482;
    private static int 634529583;
    private static int 1571746717;
    private static long 1320878182;
    private static int -1204774033;
    private static long -960184905;
    private static int 1117272510;
    private static long 250234333;
    private static int 1679832179;
    private static int 560954202;
    private static long -12808746;
    private static int 1172830945;
    private static int -1030214737;
    private static long 731737085;
    private static int 454434941;
    private static int 2045970474;
    private static int 575910128;
    private static int -1065212208;
    private static int 840212455;
    private static int 1351428617;
    private static int -576252015;
    private static long -638011120;
    private static long 220657828;
    private static int -1957932883;
    private static long -1711015879;
    private static long 1412429503;
    private static int -604646007;
    private static int -906485233;
    private static int -1108023608;
    private static int 384284647;
    private static int -1227044741;
    private static int -216393909;
    private static int -1852796323;
    private static int -329495761;
    private static int -1900454571;
    private static int -1588565646;
    private static int 555696911;
    private static int 23355942;
    private static int -329403804;
    private static int -2022385562;
    private static int 1268923485;
    private static int -599995124;
    private static int -1479837102;
    private static int -1291683283;
    private static int -1402776840;
    private static int 1528190577;
    private static int -307465700;
    private static int -42688655;
    private static int 1676616534;
    private static int -919469536;
    private static int -211178500;
    private static int -2134199659;
    private static int -517061051;
    private static int 973333820;
    private static int -841216745;
    private static int 1006897808;
    private static int -670575659;
    private static int -1238475304;
    private static int -160950069;
    private static int -1316787022;
    private static int -1495464135;
    private static int -1923643639;
    private static int -1616082956;
    private static int -44566610;
    private static int 390973373;
    private static int 1624207117;
    private static int -70435844;
    private static int -1948100598;
    private static int -442284508;
    private static int 166471570;
    private static int -1088943980;
    private static int -1595780306;
    private static int 714349745;
    private static float -1192621739;
    private static int -420646673;
    private static int 1469388561;
    private static float 1444844923;
    private static int 1023710160;
    private static float 1163686187;
    private static int -594520407;
    private static long 2119417128;
    private static int 1045240028;
    private static int 1848236100;
    private static int 1189419463;
    private static int 1566797085;
    private static int 1765958926;
    
    public TextRenderer(final Font -1438075855, final boolean -1805140184, final int 1003666100) {
        super(invokedynamic(1933583593:()Lnet/minecraft/client/Minecraft;).field_71474_y, new ResourceLocation(invokedynamic(-904593093:(IJ)Ljava/lang/String;, TextRenderer.1205570811, TextRenderer.591400605 ^ TextRenderer.1386259016)), invokedynamic(1354422457:(Ljava/lang/Object;)Lnet/minecraft/client/renderer/texture/TextureManager;, invokedynamic(196888054:()Lnet/minecraft/client/Minecraft;)), (boolean)(TextRenderer.-1041617931 != 0));
        this.field_78289_c = new Random();
        this.customColorCodes = new Color[TextRenderer.-1369366506];
        this.colorCode = new int[TextRenderer.201882089];
        this.colorcodeIdentifiers = invokedynamic(1329237065:(IJ)Ljava/lang/String;, TextRenderer.503646832, TextRenderer.-743861171 ^ TextRenderer.2125254279);
        // invokedynamic(2074897583:(Ljava/lang/Object;Ljava/lang/Object;ZI)V, this, -1438075855, -1805140184, 1003666100)
        this.customColorCodes[TextRenderer.-865314576] = new Color(TextRenderer.-1479304347, TextRenderer.739720435, TextRenderer.43837774);
        this.colorcodeIdentifiers = this.setupColorcodeIdentifier();
        this.setupMinecraftColorcodes();
        this.field_78288_b = invokedynamic(1590916211:(Ljava/lang/Object;)I, this);
    }
    
    public int drawString(final String -1542419771, final float 512918078, final float -1267424829, final int 1047425385) {
        return invokedynamic(-1658922525:(Ljava/lang/Object;Ljava/lang/Object;FFIZ)I, this, -1542419771, 512918078, -1267424829, 1047425385, TextRenderer.-903775476);
    }
    
    public int func_175063_a(final String -1575609487, final float 1767246939, final float -876573288, final int 636012342) {
        return invokedynamic(-507648468:(Ljava/lang/Object;Ljava/lang/Object;FFIZ)I, this, -1575609487, 1767246939, -876573288, 636012342, TextRenderer.-1536221337);
    }
    
    public void drawCenteredString(final String -490999483, final int -859443018, final int -1448880221, final int -1450644102, final boolean -238583821) {
        if (-238583821) {
        }
        // invokedynamic(-388239951:(Ljava/lang/Object;Ljava/lang/Object;FFI)I, this, -490999483, (float)-859443018 - invokedynamic(1702063892:(Ljava/lang/Object;Ljava/lang/Object;)I, this, -490999483) / TextRenderer.1435784082, (float)-1448880221, -1450644102)
        else {
        }
        // invokedynamic(809879147:(Ljava/lang/Object;Ljava/lang/Object;III)I, this, -490999483, -859443018 - invokedynamic(468106500:(Ljava/lang/Object;Ljava/lang/Object;)I, this, -490999483) / TextRenderer.-225316734, -1448880221, -1450644102)
    }
    
    public void drawCenteredStringXY(final String -1456717624, final int -1454809881, final int -1592493936, final int -1063638746, final boolean 1713647024) {
    }
    // invokedynamic(1527164341:(Ljava/lang/Object;Ljava/lang/Object;IIIZ)V, this, -1456717624, -1454809881, -1592493936 - invokedynamic(842214608:(Ljava/lang/Object;)I, this) / TextRenderer.-1209746971, -1063638746, 1713647024)
    
    public void drawCenteredStringWithShadow(final String 1370746447, final int -1725535369, final int 394216776, final int 902881300) {
    }
    // invokedynamic(-638224010:(Ljava/lang/Object;Ljava/lang/Object;FFI)I, this, 1370746447, (float)-1725535369 - invokedynamic(1453380263:(Ljava/lang/Object;Ljava/lang/Object;)I, this, 1370746447) / TextRenderer.-1403628503, (float)394216776, 902881300)
    
    public void drawCenteredString(final String 1081283961, final int 1253691684, final int 581220086, final int 886772394) {
    }
    // invokedynamic(12063194:(Ljava/lang/Object;Ljava/lang/Object;III)I, this, 1081283961, 1253691684 - invokedynamic(1167826924:(Ljava/lang/Object;Ljava/lang/Object;)I, this, 1081283961) / TextRenderer.-476214552, 581220086, 886772394)
    
    public int func_175065_a(final String 526558891, final float -424893445, final float 766538332, final int -875615960, final boolean 2142942144) {
        int n = TextRenderer.2011898059;
        final String[] 2142942145 = (String[])invokedynamic(-260877611:(Ljava/lang/Object;Ljava/lang/Object;)[Ljava/lang/String;, 526558891, invokedynamic(27695731:(IJ)Ljava/lang/String;, TextRenderer.-1868667367, TextRenderer.1975458452));
        for (int i = TextRenderer.-2057351931; i < 2142942145.length; ++i) {
            n = this.drawLine(2142942145[i], -424893445, 766538332 + (float)(i * invokedynamic(-2034181838:(Ljava/lang/Object;)I, this)), -875615960, 2142942144);
        }
        return n;
    }
    
    private int drawLine(final String 1124321878, final float -1188634643, final float -140003226, int -133434354, final boolean -519966170) {
        if (1124321878 == null) {
            return TextRenderer.1352320227;
        }
        // invokedynamic(-193290335:()V)
        // invokedynamic(475721060:(DDD)V, (double)-1188634643 - TextRenderer.1562634920, (double)-140003226 + TextRenderer.-1374696347, 0.0)
        final boolean b = invokedynamic(845457290:(I)Z, TextRenderer.366795344);
        // invokedynamic(1231218189:()V)
        // invokedynamic(-582201186:(I)V, TextRenderer.191795280)
        // invokedynamic(-738150125:(II)V, TextRenderer.-767571854, TextRenderer.-63262953)
        // invokedynamic(1972105851:(I)V, TextRenderer.461977679)
        if ((-133434354 & TextRenderer.2044993375) == 0x0) {
            -133434354 |= TextRenderer.1596593005;
        }
        if (-519966170) {
            -133434354 = ((-133434354 & TextRenderer.2083657632) >> TextRenderer.-1737304876 | (-133434354 & TextRenderer.1698150970));
        }
        final float r = (-133434354 >> TextRenderer.2097184616 & TextRenderer.-1029409504) / TextRenderer.-1407704151;
        final float 1124321879 = (-133434354 >> TextRenderer.568881206 & TextRenderer.-188022729) / TextRenderer.668506476;
        final float 1124321880 = (-133434354 & TextRenderer.1866684162) / TextRenderer.205122789;
        final float n = (-133434354 >> TextRenderer.-387743090 & TextRenderer.1596440965) / TextRenderer.85154669;
        final Color 1124321881 = new Color(r, 1124321879, 1124321880, n);
        if (invokedynamic(-1091103215:(Ljava/lang/Object;Ljava/lang/Object;)Z, 1124321878, invokedynamic(1375264179:(IJ)Ljava/lang/String;, TextRenderer.1967926438, TextRenderer.-1138114571))) {
            final String[] 1124321882 = (String[])invokedynamic(623059080:(Ljava/lang/Object;Ljava/lang/Object;)[Ljava/lang/String;, 1124321878, invokedynamic(-1196798678:(IJ)Ljava/lang/String;, TextRenderer.1484283241, TextRenderer.-1680931627 ^ TextRenderer.-970863457));
            Color color = 1124321881;
            CustomFont customFont = this.font;
            int 1124321883 = TextRenderer.-1654493581;
            boolean 1124321884 = TextRenderer.1143000355 != 0;
            boolean 1124321885 = TextRenderer.-1285183868 != 0;
            boolean 1124321886 = TextRenderer.-892420004 != 0;
            boolean b2 = TextRenderer.-620035338 != 0;
            boolean 1124321887 = TextRenderer.-1697946882 != 0;
            for (int 1124321888 = TextRenderer.1633394987; 1124321888 < 1124321882.length; ++1124321888) {
                if (invokedynamic(-361898730:(Ljava/lang/Object;)I, 1124321882[1124321888]) > 0) {
                    if (1124321888 == 0) {
                        // invokedynamic(-599061082:(Ljava/lang/Object;Ljava/lang/Object;DDLjava/lang/Object;Z)V, customFont, 1124321882[1124321888], (double)1124321883, 0.0, color, -519966170)
                        1124321883 += invokedynamic(-1351471871:(Ljava/lang/Object;Ljava/lang/Object;)I, customFont, 1124321882[1124321888]);
                    }
                    else {
                        final String s = invokedynamic(-727160933:(Ljava/lang/Object;I)Ljava/lang/String;, 1124321882[1124321888], TextRenderer.-782821162);
                        final char c = invokedynamic(868718652:(Ljava/lang/Object;I)C, 1124321882[1124321888], TextRenderer.1089442789);
                        final int 1124321889 = invokedynamic(-847172801:(Ljava/lang/Object;I)I, this.colorcodeIdentifiers, c);
                        if (1124321889 != TextRenderer.1140792044) {
                            if (1124321889 < TextRenderer.-275655162) {
                                final int 1124321890 = this.colorCode[1124321889];
                                color = invokedynamic(-144190759:(Ljava/lang/Object;IF)Ljava/awt/Color;, this, 1124321890, n);
                                1124321885 = (TextRenderer.855298866 != 0);
                                1124321886 = (TextRenderer.345945934 != 0);
                                1124321884 = (TextRenderer.291148946 != 0);
                                1124321887 = (TextRenderer.1858682380 != 0);
                                b2 = (TextRenderer.-1223988382 != 0);
                            }
                            else if (1124321889 == TextRenderer.1797660803) {
                                1124321884 = (TextRenderer.1892003498 != 0);
                            }
                            else if (1124321889 == TextRenderer.-1025963001) {
                                1124321885 = (TextRenderer.2006181473 != 0);
                            }
                            else if (1124321889 == TextRenderer.1180032116) {
                                b2 = (TextRenderer.1713415775 != 0);
                            }
                            else if (1124321889 == TextRenderer.-800515210) {
                                1124321887 = (TextRenderer.800371133 != 0);
                            }
                            else if (1124321889 == TextRenderer.-1557118310) {
                                1124321886 = (TextRenderer.-351748070 != 0);
                            }
                            else if (1124321889 == TextRenderer.580152762) {
                                1124321885 = (TextRenderer.634792260 != 0);
                                1124321886 = (TextRenderer.257856234 != 0);
                                1124321884 = (TextRenderer.-121624570 != 0);
                                1124321887 = (TextRenderer.1409373178 != 0);
                                b2 = (TextRenderer.847285085 != 0);
                                color = 1124321881;
                            }
                            else if (1124321889 > TextRenderer.-1208356195) {
                                final Color color2 = this.customColorCodes[c];
                                color = new Color((float)invokedynamic(199178956:(Ljava/lang/Object;)I, color2) / TextRenderer.-134832007, (float)invokedynamic(1516961087:(Ljava/lang/Object;)I, color2) / TextRenderer.-688349825, (float)invokedynamic(1056835913:(Ljava/lang/Object;)I, color2) / TextRenderer.1534924353, n);
                            }
                        }
                        if (1124321885 && 1124321886) {
                            // invokedynamic(1182583487:(Ljava/lang/Object;Ljava/lang/Object;DDLjava/lang/Object;Z)V, this.boldItalicFont, 1124321884 ? this.toRandom(customFont, s) : s, (double)1124321883, 0.0, color, -519966170)
                            customFont = this.boldItalicFont;
                        }
                        else if (1124321885) {
                            // invokedynamic(1743283167:(Ljava/lang/Object;Ljava/lang/Object;DDLjava/lang/Object;Z)V, this.boldFont, 1124321884 ? this.toRandom(customFont, s) : s, (double)1124321883, 0.0, color, -519966170)
                            customFont = this.boldFont;
                        }
                        else if (1124321886) {
                            // invokedynamic(1754391767:(Ljava/lang/Object;Ljava/lang/Object;DDLjava/lang/Object;Z)V, this.italicFont, 1124321884 ? this.toRandom(customFont, s) : s, (double)1124321883, 0.0, color, -519966170)
                            customFont = this.italicFont;
                        }
                        else {
                            // invokedynamic(-678390761:(Ljava/lang/Object;Ljava/lang/Object;DDLjava/lang/Object;Z)V, this.font, 1124321884 ? this.toRandom(customFont, s) : s, (double)1124321883, 0.0, color, -519966170)
                            customFont = this.font;
                        }
                        final float n2 = (float)invokedynamic(325749808:(Ljava/lang/Object;)I, this.font) / TextRenderer.1112505734;
                        final int 1124321891 = invokedynamic(1445967488:(Ljava/lang/Object;Ljava/lang/Object;)I, customFont, s);
                        if (b2) {
                            this.drawLine(1124321883 / TextRenderer.1323859217 + 1.0, 1124321891 / TextRenderer.279292722, (double)(1124321883 + invokedynamic(-24228358:(Ljava/lang/Object;Ljava/lang/Object;)I, customFont, s)) / TextRenderer.1048097905 + 1.0, 1124321891 / TextRenderer.-736018880, n2);
                        }
                        if (1124321887) {
                            this.drawLine(1124321883 / TextRenderer.600114688 + 1.0, 1124321891 / TextRenderer.-886211835, (double)(1124321883 + invokedynamic(432615861:(Ljava/lang/Object;Ljava/lang/Object;)I, customFont, s)) / TextRenderer.-340444438 + 1.0, 1124321891 / TextRenderer.-272650087, n2);
                        }
                        1124321883 += invokedynamic(-737548735:(Ljava/lang/Object;Ljava/lang/Object;)I, customFont, s);
                    }
                }
            }
        }
        else {
        }
        // invokedynamic(-875466652:(Ljava/lang/Object;Ljava/lang/Object;DDLjava/lang/Object;Z)V, this.font, 1124321878, 0.0, 0.0, 1124321881, -519966170)
        if (!b) {
        }
        // invokedynamic(-1913549566:(I)V, TextRenderer.1273995437)
        // invokedynamic(-1520611466:()V)
        // invokedynamic(-1308796897:(FFFF)V, 1.0f, 1.0f, 1.0f, 1.0f)
        return (int)(-1188634643 + (float)invokedynamic(-2092566687:(Ljava/lang/Object;Ljava/lang/Object;)I, this, 1124321878));
    }
    
    private String toRandom(final CustomFont -989286840, final String 675211839) {
        String s = invokedynamic(1876595638:(IJ)Ljava/lang/String;, TextRenderer.1283200411, TextRenderer.2003660710 ^ TextRenderer.1071336356);
        final String 675211840 = invokedynamic(-1777109660:(IJ)Ljava/lang/String;, TextRenderer.621225094 & TextRenderer.539579897, TextRenderer.-430094675);
        final char[] array = (char[])invokedynamic(594830467:(Ljava/lang/Object;)[C, 675211839);
        for (int length = array.length, i = TextRenderer.1262246656; i < length; ++i) {
            final char 675211841 = array[i];
            if (invokedynamic(1001775796:(C)Z, 675211841)) {
                final int 675211842 = invokedynamic(1019243207:(Ljava/lang/Object;I)I, this.field_78289_c, invokedynamic(-699130407:(Ljava/lang/Object;)I, invokedynamic(-284178877:(IJ)Ljava/lang/String;, TextRenderer.-1403325930 & TextRenderer.-1470895736, TextRenderer.969334599)));
                s = invokedynamic(545019001:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-1718696474:(Ljava/lang/Object;C)Ljava/lang/StringBuilder;, invokedynamic(-1035532798:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), s), ((char[])invokedynamic(1698569654:(Ljava/lang/Object;)[C, invokedynamic(1712740952:(IJ)Ljava/lang/String;, TextRenderer.-2126706212, TextRenderer.25262731 ^ TextRenderer.-1654477283)))[675211842]));
            }
        }
        return s;
    }
    
    public int getStringHeight(final String 1166759625) {
        if (1166759625 == null) {
            return TextRenderer.-1282569876;
        }
        return invokedynamic(1627965752:(Ljava/lang/Object;Ljava/lang/Object;)I, this.font, 1166759625) / TextRenderer.960816026;
    }
    
    public int getHeight() {
        return invokedynamic(1866209553:(Ljava/lang/Object;)I, this.font) / TextRenderer.1669463769;
    }
    
    public static String getFormatFromString(final String 75659241) {
        String s = invokedynamic(332556437:(IJ)Ljava/lang/String;, TextRenderer.-24615174 & TextRenderer.-2068189607, TextRenderer.622444640);
        int 75659242 = TextRenderer.-2115613905;
        final int n = invokedynamic(326288970:(Ljava/lang/Object;)I, 75659241);
        while ((75659242 = invokedynamic(1676545665:(Ljava/lang/Object;II)I, 75659241, TextRenderer.-1008772484, 75659242 + TextRenderer.-220270196)) != TextRenderer.-1444362027) {
            if (75659242 < n - TextRenderer.526833044) {
                final char c = invokedynamic(1440888964:(Ljava/lang/Object;I)C, 75659241, 75659242 + TextRenderer.-819241858);
                if (invokedynamic(1104042189:(C)Z, c)) {
                    s = invokedynamic(-285185544:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-1903210392:(Ljava/lang/Object;C)Ljava/lang/StringBuilder;, invokedynamic(-2022940417:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), invokedynamic(-1136984764:(IJ)Ljava/lang/String;, TextRenderer.-1093407262, TextRenderer.-571505505 ^ TextRenderer.-462034986)), c));
                }
                else {
                    if (!invokedynamic(-1178388749:(C)Z, c)) {
                        continue;
                    }
                    s = invokedynamic(-903349951:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(2086454217:(Ljava/lang/Object;C)Ljava/lang/StringBuilder;, invokedynamic(-1529203530:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(383717542:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), s), invokedynamic(1623923997:(IJ)Ljava/lang/String;, TextRenderer.-1145035048, TextRenderer.1501600034)), c));
                }
            }
        }
        return s;
    }
    
    private static boolean isFormatSpecial(final char 2018642116) {
        return (((2018642116 >= TextRenderer.-1471905301 && 2018642116 <= TextRenderer.-1965430370) || (2018642116 >= TextRenderer.165544397 && 2018642116 <= TextRenderer.1731230478) || 2018642116 == TextRenderer.-1075610938 || 2018642116 == TextRenderer.956004388) ? TextRenderer.-504843774 : TextRenderer.-161356744) != 0;
    }
    
    public int func_175064_b(final char 1005338264) {
        return this.colorCode[invokedynamic(1646440793:(Ljava/lang/Object;I)I, invokedynamic(-605604846:(IJ)Ljava/lang/String;, TextRenderer.-1554763883 & TextRenderer.247018453, TextRenderer.-1327776929), 1005338264)];
    }
    
    public void func_78275_b(final boolean -675097452) {
        this.bidi = -675097452;
    }
    
    public boolean func_78260_a() {
        return this.bidi;
    }
    
    private int sizeStringToWidth(final String 15070873, final int 818209944) {
        final int n = invokedynamic(-785690428:(Ljava/lang/Object;)I, 15070873);
        int 818209947 = TextRenderer.959721934;
        int i = TextRenderer.-1453498832;
        int 818209945 = TextRenderer.-1201068070;
        boolean 818209946 = TextRenderer.-298994627 != 0;
        while (i < n) {
            final char c = invokedynamic(-431391458:(Ljava/lang/Object;I)C, 15070873, i);
            Label_0197: {
                switch (c) {
                    case '\n': {
                        --i;
                        break Label_0197;
                    }
                    case '§': {
                        if (i < n - TextRenderer.298306419) {
                            ++i;
                            final char c2 = invokedynamic(-891876026:(Ljava/lang/Object;I)C, 15070873, i);
                            if (c2 != TextRenderer.393230440 && c2 != TextRenderer.947573388) {
                                if (c2 == TextRenderer.867072764 || c2 == TextRenderer.-1104464188 || invokedynamic(-1126799055:(C)Z, c2)) {
                                    818209946 = (TextRenderer.1895894940 != 0);
                                }
                            }
                            else {
                                818209946 = (TextRenderer.898854063 != 0);
                            }
                        }
                        break Label_0197;
                    }
                    case ' ': {
                        818209945 = i;
                        break;
                    }
                }
                818209947 += invokedynamic(212032403:(Ljava/lang/Object;Ljava/lang/Object;)I, this, invokedynamic(-785623053:(C)Ljava/lang/String;, c));
                if (818209946) {
                    ++818209947;
                }
            }
            if (c == TextRenderer.188109048) {
                818209945 = ++i;
                break;
            }
            if (818209947 > 818209944) {
                break;
            }
            ++i;
        }
        return (i != n && 818209945 != TextRenderer.1156446089 && 818209945 < i) ? 818209945 : i;
    }
    
    private static boolean isFormatColor(final char 1650714287) {
        return (((1650714287 >= TextRenderer.28551019 && 1650714287 <= TextRenderer.2077667954) || (1650714287 >= TextRenderer.349259128 && 1650714287 <= TextRenderer.1175095018) || (1650714287 >= TextRenderer.-1459562744 && 1650714287 <= TextRenderer.-1542142093)) ? TextRenderer.-214635668 : TextRenderer.-407230057) != 0;
    }
    
    public int func_78263_a(final char 1376911317) {
        return invokedynamic(-1692583374:(Ljava/lang/Object;Ljava/lang/Object;)I, this, invokedynamic(-1117164758:(C)Ljava/lang/String;, 1376911317));
    }
    
    public int func_78256_a(final String 729714757) {
        if (729714757 == null) {
            return TextRenderer.-483402464;
        }
        if (invokedynamic(-519023002:(Ljava/lang/Object;Ljava/lang/Object;)Z, 729714757, invokedynamic(-208060257:(IJ)Ljava/lang/String;, TextRenderer.-201241341, TextRenderer.998031541))) {
            final String[] 729714758 = (String[])invokedynamic(-1061250459:(Ljava/lang/Object;Ljava/lang/Object;)[Ljava/lang/String;, 729714757, invokedynamic(-2091437020:(IJ)Ljava/lang/String;, TextRenderer.1722647463 & TextRenderer.1448781755, TextRenderer.1419963442));
            CustomFont 729714759 = this.font;
            int 729714762 = TextRenderer.1470837079;
            boolean b = TextRenderer.-1296219430 != 0;
            boolean 729714760 = TextRenderer.1021690385 != 0;
            for (int i = TextRenderer.468588310; i < 729714758.length; ++i) {
                if (invokedynamic(-1180517208:(Ljava/lang/Object;)I, 729714758[i]) > 0) {
                    if (i == 0) {
                        729714762 += invokedynamic(-84828702:(Ljava/lang/Object;Ljava/lang/Object;)I, 729714759, 729714758[i]);
                    }
                    else {
                        final String 729714761 = invokedynamic(116940359:(Ljava/lang/Object;I)Ljava/lang/String;, 729714758[i], TextRenderer.-2096988226);
                        final char c = invokedynamic(-123070086:(Ljava/lang/Object;I)C, 729714758[i], TextRenderer.1534401244);
                        final int n = invokedynamic(-1813660226:(Ljava/lang/Object;I)I, this.colorcodeIdentifiers, c);
                        if (n != TextRenderer.1739741210) {
                            if (n < TextRenderer.433415929) {
                                b = (TextRenderer.-1897999605 != 0);
                                729714760 = (TextRenderer.1143716891 != 0);
                            }
                            else if (n != TextRenderer.1678605331) {
                                if (n == TextRenderer.1205437945) {
                                    b = (TextRenderer.-2117968845 != 0);
                                }
                                else if (n != TextRenderer.562444384) {
                                    if (n != TextRenderer.-1735791789) {
                                        if (n == TextRenderer.-1024865711) {
                                            729714760 = (TextRenderer.1285986482 != 0);
                                        }
                                        else if (n == TextRenderer.-1552167533) {
                                            b = (TextRenderer.240906699 != 0);
                                            729714760 = (TextRenderer.1107588653 != 0);
                                        }
                                    }
                                }
                            }
                        }
                        if (b && 729714760) {
                            729714759 = this.boldItalicFont;
                        }
                        else if (b) {
                            729714759 = this.boldFont;
                        }
                        else if (729714760) {
                            729714759 = this.italicFont;
                        }
                        else {
                            729714759 = this.font;
                        }
                        729714762 += invokedynamic(13652516:(Ljava/lang/Object;Ljava/lang/Object;)I, 729714759, 729714761);
                    }
                }
            }
            return 729714762 / TextRenderer.-2133966555;
        }
        return invokedynamic(-542411576:(Ljava/lang/Object;Ljava/lang/Object;)I, this.font, 729714757) / TextRenderer.-1632922972;
    }
    
    public void setFont(final Font 2040280196, final boolean 1445869955, final int -1643483079) {
        synchronized (this) {
            this.font = new CustomFont(2040280196, 1445869955, -1643483079);
            this.boldFont = new CustomFont(invokedynamic(27837980:(Ljava/lang/Object;I)Ljava/awt/Font;, 2040280196, TextRenderer.-177996765), 1445869955, -1643483079);
            this.italicFont = new CustomFont(invokedynamic(-232355668:(Ljava/lang/Object;I)Ljava/awt/Font;, 2040280196, TextRenderer.616497467), 1445869955, -1643483079);
            this.boldItalicFont = new CustomFont(invokedynamic(-736254774:(Ljava/lang/Object;I)Ljava/awt/Font;, 2040280196, TextRenderer.629265458), 1445869955, -1643483079);
            this.field_78288_b = invokedynamic(-9425300:(Ljava/lang/Object;)I, this);
        }
    }
    
    public CustomFont getFont() {
        return this.font;
    }
    
    public String getFontName() {
        return invokedynamic(95666668:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(781648647:(Ljava/lang/Object;)Ljava/awt/Font;, this.font));
    }
    
    public int getSize() {
        return invokedynamic(-15766017:(Ljava/lang/Object;)I, invokedynamic(440101507:(Ljava/lang/Object;)Ljava/awt/Font;, this.font));
    }
    
    public List<String> wrapWords(final String 1832762398, final double -146761066) {
        final List<String> list = new ArrayList<String>();
        if ((double)invokedynamic(107639841:(Ljava/lang/Object;Ljava/lang/Object;)I, this, 1832762398) > -146761066) {
            final String[] array = (String[])invokedynamic(432215048:(Ljava/lang/Object;Ljava/lang/Object;)[Ljava/lang/String;, 1832762398, invokedynamic(-1599688757:(IJ)Ljava/lang/String;, TextRenderer.929629397, TextRenderer.-2009842092));
            String s = invokedynamic(-2021691101:(IJ)Ljava/lang/String;, TextRenderer.-1977451877, TextRenderer.619105736 ^ TextRenderer.1715088025);
            char 1832762401 = (char)TextRenderer.467447897;
            final String[] array2 = array;
            for (int length = array2.length, i = TextRenderer.731660032; i < length; ++i) {
                final String 1832762399 = array2[i];
                for (int j = TextRenderer.-396537524; j < ((char[])invokedynamic(522382953:(Ljava/lang/Object;)[C, 1832762399)).length; ++j) {
                    final char 1832762400 = ((char[])invokedynamic(1960398644:(Ljava/lang/Object;)[C, 1832762399))[j];
                    if (1832762400 == TextRenderer.1863857876 && j < ((char[])invokedynamic(2056278659:(Ljava/lang/Object;)[C, 1832762399)).length - TextRenderer.-1729217847) {
                        1832762401 = ((char[])invokedynamic(-2089161735:(Ljava/lang/Object;)[C, 1832762399))[j + TextRenderer.1756949701];
                    }
                }
                if ((double)invokedynamic(-1195228145:(Ljava/lang/Object;Ljava/lang/Object;)I, this, invokedynamic(-746287759:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-594578485:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-804559916:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(1435425960:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), s), 1832762399), invokedynamic(1318555777:(IJ)Ljava/lang/String;, TextRenderer.293633219, TextRenderer.1043472191 ^ TextRenderer.-1058239760)))) < -146761066) {
                    s = invokedynamic(1989677993:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(952644894:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(1761418416:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(521971811:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), s), 1832762399), invokedynamic(-851040628:(IJ)Ljava/lang/String;, TextRenderer.1452220936, TextRenderer.1379282016)));
                }
                else {
                    // invokedynamic(546901583:(Ljava/lang/Object;Ljava/lang/Object;)Z, list, s)
                    s = ((1832762401 == TextRenderer.-776840639) ? invokedynamic(-1241528097:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(711658162:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(1778655551:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), 1832762399), invokedynamic(941443080:(IJ)Ljava/lang/String;, TextRenderer.-428923347, TextRenderer.261785338 ^ TextRenderer.1171412605))) : invokedynamic(-1281173988:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-2086675461:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(1350687615:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(1009235138:(Ljava/lang/Object;C)Ljava/lang/StringBuilder;, invokedynamic(-122767744:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), invokedynamic(160957845:(IJ)Ljava/lang/String;, TextRenderer.-1892815939 & TextRenderer.-1246714602, TextRenderer.1086345729)), 1832762401), 1832762399), invokedynamic(1768800421:(IJ)Ljava/lang/String;, TextRenderer.1575123375 & TextRenderer.-1150836016, TextRenderer.-1349155928))));
                }
            }
            if (!invokedynamic(-1969788192:(Ljava/lang/Object;Ljava/lang/Object;)Z, s, invokedynamic(-1210717:(IJ)Ljava/lang/String;, TextRenderer.-422650121, TextRenderer.77510482))) {
                if ((double)invokedynamic(1163245854:(Ljava/lang/Object;Ljava/lang/Object;)I, this, s) < -146761066) {
                    // invokedynamic(139939126:(Ljava/lang/Object;Ljava/lang/Object;)Z, list, 1832762401 == TextRenderer...
                    s = invokedynamic(-427569275:(IJ)Ljava/lang/String;, TextRenderer.1679832179 & TextRenderer.560954202, TextRenderer.-12808746);
                }
                else {
                    final Iterator iterator = invokedynamic(253837554:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(1322155858:(Ljava/lang/Object;Ljava/lang/Object;D)Ljava/util/List;, this, s, -146761066));
                    while (invokedynamic(-701407971:(Ljava/lang/Object;)Z, iterator)) {
                        final String s2 = (String)invokedynamic(-1547915162:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
                    }
                    // invokedynamic(-1313313833:(Ljava/lang/Object;Ljava/lang/Object;)Z, list, s2)
                }
            }
        }
        else {
        }
        // invokedynamic(-370683252:(Ljava/lang/Object;Ljava/lang/Object;)Z, list, 1832762398)
        return list;
    }
    
    public List<String> formatString(final String -555553086, final double 1874187903) {
        final List<String> 1874187904 = new ArrayList<String>();
        String s = invokedynamic(2118191045:(IJ)Ljava/lang/String;, TextRenderer.1172830945 & TextRenderer.-1030214737, TextRenderer.731737085);
        char 1874187905 = (char)TextRenderer.454434941;
        for (int i = TextRenderer.2045970474; i < ((char[])invokedynamic(-247590755:(Ljava/lang/Object;)[C, -555553086)).length; ++i) {
            final char 1874187906 = ((char[])invokedynamic(-212891593:(Ljava/lang/Object;)[C, -555553086))[i];
            if (1874187906 == TextRenderer.575910128 && i < ((char[])invokedynamic(-1482812230:(Ljava/lang/Object;)[C, -555553086)).length - TextRenderer.-1065212208) {
                1874187905 = ((char[])invokedynamic(-1284185346:(Ljava/lang/Object;)[C, -555553086))[i + TextRenderer.840212455];
            }
            if ((double)invokedynamic(-1993879783:(Ljava/lang/Object;Ljava/lang/Object;)I, this, invokedynamic(741632208:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-1098784423:(Ljava/lang/Object;C)Ljava/lang/StringBuilder;, invokedynamic(-174962438:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), s), 1874187906))) < 1874187903) {
                s = invokedynamic(2099708835:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(744215733:(Ljava/lang/Object;C)Ljava/lang/StringBuilder;, invokedynamic(-517919772:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), s), 1874187906));
            }
            else {
                // invokedynamic(-797580717:(Ljava/lang/Object;Ljava/lang/Object;)Z, 1874187904, s)
                s = ((1874187905 == TextRenderer.1351428617) ? invokedynamic(-1809457151:(C)Ljava/lang/String;, 1874187906) : invokedynamic(-937616385:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-960157383:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-365478297:(Ljava/lang/Object;C)Ljava/lang/StringBuilder;, invokedynamic(2016784309:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), invokedynamic(-30231420:(IJ)Ljava/lang/String;, TextRenderer.-576252015, TextRenderer.-638011120 ^ TextRenderer.220657828)), 1874187905), invokedynamic(-2055349271:(C)Ljava/lang/String;, 1874187906))));
            }
        }
        if (!invokedynamic(1620738242:(Ljava/lang/Object;Ljava/lang/Object;)Z, s, invokedynamic(1660741687:(IJ)Ljava/lang/String;, TextRenderer.-1957932883, TextRenderer.-1711015879 ^ TextRenderer.1412429503))) {
        }
        // invokedynamic(305194686:(Ljava/lang/Object;Ljava/lang/Object;)Z, 1874187904, s)
        return 1874187904;
    }
    
    private void drawLine(final double 237422754, final double 2124490948, final double -1408675671, final double 1087615317, final float -967425031) {
    }
    // invokedynamic(730182868:(I)V, TextRenderer.-604646007)
    // invokedynamic(-2057979093:(F)V, -967425031)
    // invokedynamic(1297656154:(I)V, TextRenderer.-906485233)
    // invokedynamic(672966714:(DD)V, 237422754, 2124490948)
    // invokedynamic(-664720632:(DD)V, -1408675671, 1087615317)
    // invokedynamic(-1877446780:()V)
    // invokedynamic(-1035556075:(I)V, TextRenderer.-1108023608)
    
    public boolean isAntiAliasing() {
        return ((invokedynamic(-345951425:(Ljava/lang/Object;)Z, this.font) && invokedynamic(-679257030:(Ljava/lang/Object;)Z, this.boldFont) && invokedynamic(-757336948:(Ljava/lang/Object;)Z, this.italicFont) && invokedynamic(-994144611:(Ljava/lang/Object;)Z, this.boldItalicFont)) ? TextRenderer.384284647 : TextRenderer.-1227044741) != 0;
    }
    
    public void setAntiAliasing(final boolean 1776829308) {
    }
    // invokedynamic(1512559083:(Ljava/lang/Object;Z)V, this.font, 1776829308)
    // invokedynamic(1985801135:(Ljava/lang/Object;Z)V, this.boldFont, 1776829308)
    // invokedynamic(2076209575:(Ljava/lang/Object;Z)V, this.italicFont, 1776829308)
    // invokedynamic(-1705922906:(Ljava/lang/Object;Z)V, this.boldItalicFont, 1776829308)
    
    private void setupMinecraftColorcodes() {
        for (int 1284760429 = TextRenderer.-216393909; 1284760429 < TextRenderer.-1852796323; ++1284760429) {
            final int 1284760430 = (1284760429 >> TextRenderer.-329495761 & TextRenderer.-1900454571) * TextRenderer.-1588565646;
            int 1284760431 = (1284760429 >> TextRenderer.555696911 & TextRenderer.23355942) * TextRenderer.-329403804 + 1284760430;
            int n = (1284760429 >> TextRenderer.-2022385562 & TextRenderer.1268923485) * TextRenderer.-599995124 + 1284760430;
            int n2 = (1284760429 >> TextRenderer.-1479837102 & TextRenderer.-1291683283) * TextRenderer.-1402776840 + 1284760430;
            if (1284760429 == TextRenderer.1528190577) {
                1284760431 += 85;
            }
            if (1284760429 >= TextRenderer.-307465700) {
                1284760431 /= TextRenderer.-42688655;
                n /= TextRenderer.1676616534;
                n2 /= TextRenderer.-919469536;
            }
            this.colorCode[1284760429] = ((1284760431 & TextRenderer.-211178500) << TextRenderer.-2134199659 | (n & TextRenderer.-517061051) << TextRenderer.973333820 | (n2 & TextRenderer.-841216745));
        }
    }
    
    public String func_78269_a(final String -1362532018, final int -656422460) {
        return invokedynamic(63073038:(Ljava/lang/Object;Ljava/lang/Object;IZ)Ljava/lang/String;, this, -1362532018, -656422460, TextRenderer.1006897808);
    }
    
    public String func_78262_a(final String -2036674856, final int 1878950753, final boolean -1180559360) {
        final StringBuilder sb = new StringBuilder();
        int -2036674857 = TextRenderer.-670575659;
        final int 1878950754 = -1180559360 ? (invokedynamic(1283193065:(Ljava/lang/Object;)I, -2036674856) - TextRenderer.-1238475304) : TextRenderer.-160950069;
        final int 1878950755 = -1180559360 ? TextRenderer.-1316787022 : TextRenderer.-1495464135;
        boolean 1878950756 = TextRenderer.-1923643639 != 0;
        boolean b = TextRenderer.-1616082956 != 0;
        for (int n = 1878950754; n >= 0 && n < invokedynamic(-1724038599:(Ljava/lang/Object;)I, -2036674856) && -2036674857 < 1878950753; n += 1878950755) {
            final char c = invokedynamic(-731366059:(Ljava/lang/Object;I)C, -2036674856, n);
            final int 1878950757 = invokedynamic(-1873832913:(Ljava/lang/Object;Ljava/lang/Object;)I, this, invokedynamic(2114612760:(C)Ljava/lang/String;, c));
            if (1878950756) {
                1878950756 = (TextRenderer.-44566610 != 0);
                if (c != TextRenderer.390973373 && c != TextRenderer.1624207117) {
                    if (c == TextRenderer.-70435844 || c == TextRenderer.-1948100598) {
                        b = (TextRenderer.-442284508 != 0);
                    }
                }
                else {
                    b = (TextRenderer.166471570 != 0);
                }
            }
            else if (1878950757 < 0) {
                1878950756 = (TextRenderer.-1088943980 != 0);
            }
            else {
                -2036674857 += 1878950757;
                if (b) {
                    ++-2036674857;
                }
            }
            if (-2036674857 > 1878950753) {
                break;
            }
            if (-1180559360) {
            }
            // invokedynamic(1779820821:(Ljava/lang/Object;IC)Ljava/lang/StringBuilder;, sb, TextRenderer.-1595780306, c)
            else {
            }
            // invokedynamic(91101245:(Ljava/lang/Object;C)Ljava/lang/StringBuilder;, sb, c)
        }
        return invokedynamic(-1099130527:(Ljava/lang/Object;)Ljava/lang/String;, sb);
    }
    
    public Color getColor(final int 1286098691, final float 1685892507) {
        return new Color((1286098691 >> TextRenderer.714349745) / TextRenderer.-1192621739, (1286098691 >> TextRenderer.-420646673 & TextRenderer.1469388561) / TextRenderer.1444844923, (1286098691 & TextRenderer.1023710160) / TextRenderer.1163686187, 1685892507);
    }
    
    private String setupColorcodeIdentifier() {
        String 1742674025 = invokedynamic(-621881843:(IJ)Ljava/lang/String;, TextRenderer.-594520407, TextRenderer.2119417128);
        for (int 1742674026 = TextRenderer.1045240028; 1742674026 < this.customColorCodes.length; ++1742674026) {
            if (this.customColorCodes[1742674026] != null) {
                1742674025 = invokedynamic(2122256739:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-1397930925:(Ljava/lang/Object;C)Ljava/lang/StringBuilder;, invokedynamic(408068000:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), 1742674025), (char)1742674026));
            }
        }
        return 1742674025;
    }
    
    public void func_110549_a(final IResourceManager -421213921) {
    }
    
    static {
        TextRenderer.1566797085 = 604831421;
        TextRenderer.1765958926 = 184;
        TextRenderer.1205570811 = ((0 >>> 10 | 0 << -10) & -1);
        TextRenderer.591400605 = invokedynamic(-2002891752:(J)J, -6731833412519275477L);
        TextRenderer.1386259016 = invokedynamic(-169908032:(J)J, 3026418949592973312L);
        TextRenderer.-1041617931 = invokedynamic(1038756344:(I)I, false);
        TextRenderer.-1369366506 = invokedynamic(519567019:(I)I, 8388608);
        TextRenderer.201882089 = (134217728 >>> 150 | 134217728 << ~0x96 + 1);
        TextRenderer.503646832 = invokedynamic(-52040062:(I)I, Integer.MIN_VALUE);
        TextRenderer.-743861171 = invokedynamic(-977557291:(J)J, -6731833412519275477L);
        TextRenderer.2125254279 = invokedynamic(-246226868:(J)J, 3026418949592973312L);
        TextRenderer.-865314576 = ((-1006632959 >>> 90 | -1006632959 << -90) & -1);
        TextRenderer.-1479304347 = (0 >>> 75 | 0 << ~0x4B + 1);
        TextRenderer.739720435 = ((360 >>> 162 | 360 << -162) & -1);
        TextRenderer.43837774 = (170917888 >>> 116 | 170917888 << -116);
        TextRenderer.-903775476 = invokedynamic(-755056484:(I)I, false);
        TextRenderer.-1536221337 = (0 >>> 225 | 0 << ~0xE1 + 1);
        TextRenderer.1435784082 = invokedynamic(655440634:(I)I, 1073741824);
        TextRenderer.-225316734 = invokedynamic(774586293:(I)I, 1073741824);
        TextRenderer.-1209746971 = ((1048576 >>> 179 | 1048576 << ~0xB3 + 1) & -1);
        TextRenderer.-1403628503 = ((512 >>> 72 | 512 << ~0x48 + 1) & -1);
        TextRenderer.-476214552 = invokedynamic(909635794:(I)I, 1073741824);
        TextRenderer.2011898059 = (0 >>> 115 | 0 << ~0x73 + 1);
        TextRenderer.-1868667367 = invokedynamic(-374139123:(I)I, 1073741824);
        TextRenderer.1975458452 = invokedynamic(2103514827:(J)J, -8605330857505401813L);
        TextRenderer.-2057351931 = invokedynamic(1984315901:(I)I, false);
        TextRenderer.1352320227 = ((0 >>> 16 | 0 << -16) & -1);
        TextRenderer.1562634920 = invokedynamic(742771909:(J)D, invokedynamic(-1846009288:(J)J, 8188L));
        TextRenderer.-1374696347 = invokedynamic(-773745322:(J)D, invokedynamic(663958430:(J)J, 2044L));
        TextRenderer.366795344 = invokedynamic(86564169:(I)I, 1204813824);
        TextRenderer.191795280 = (24920064 >>> 141 | 24920064 << ~0x8D + 1);
        TextRenderer.-767571854 = ((-2147483456 >>> 158 | -2147483456 << ~0x9E + 1) & -1);
        TextRenderer.-63262953 = invokedynamic(1474223169:(I)I, -1061158912);
        TextRenderer.461977679 = ((909568 >>> 136 | 909568 << ~0x88 + 1) & -1);
        TextRenderer.2044993375 = invokedynamic(-1579873949:(I)I, 63);
        TextRenderer.1596593005 = ((8160 >>> 173 | 8160 << -173) & -1);
        TextRenderer.2083657632 = invokedynamic(-661022367:(I)I, 1061109504);
        TextRenderer.-1737304876 = invokedynamic(1557386253:(I)I, 1073741824);
        TextRenderer.1698150970 = (255 >>> 104 | 255 << -104);
        TextRenderer.2097184616 = ((1 >>> 188 | 1 << -188) & -1);
        TextRenderer.-1029409504 = invokedynamic(1578437935:(I)I, -16777216);
        TextRenderer.-1407704151 = invokedynamic(387738856:(I)F, 552928 >>> 149 | 552928 << -149);
        TextRenderer.568881206 = invokedynamic(424384036:(I)I, 268435456);
        TextRenderer.-188022729 = invokedynamic(1183090426:(I)I, -16777216);
        TextRenderer.668506476 = invokedynamic(316950624:(I)F, invokedynamic(979894949:(I)I, 65218));
        TextRenderer.1866684162 = invokedynamic(-646675978:(I)I, -16777216);
        TextRenderer.205122789 = invokedynamic(2084970217:(I)F, (234618881 >>> 130 | 234618881 << -130) & -1);
        TextRenderer.-387743090 = invokedynamic(198563038:(I)I, 402653184);
        TextRenderer.1596440965 = ((33423360 >>> 241 | 33423360 << ~0xF1 + 1) & -1);
        TextRenderer.85154669 = invokedynamic(1973773682:(I)F, invokedynamic(-756442153:(I)I, 65218));
        TextRenderer.1967926438 = invokedynamic(-2050866523:(I)I, -1073741824);
        TextRenderer.-1138114571 = invokedynamic(-1338341225:(J)J, -8605330857505401813L);
        TextRenderer.1484283241 = invokedynamic(1008437532:(I)I, 536870912);
        TextRenderer.-1680931627 = invokedynamic(271734659:(J)J, -6731833412519275477L);
        TextRenderer.-970863457 = invokedynamic(-1911798520:(J)J, 3026418949592973312L);
        TextRenderer.-1654493581 = ((0 >>> 171 | 0 << ~0xAB + 1) & -1);
        TextRenderer.1143000355 = invokedynamic(-2139125518:(I)I, false);
        TextRenderer.-1285183868 = invokedynamic(494843200:(I)I, false);
        TextRenderer.-892420004 = ((0 >>> 236 | 0 << ~0xEC + 1) & -1);
        TextRenderer.-620035338 = ((0 >>> 82 | 0 << ~0x52 + 1) & -1);
        TextRenderer.-1697946882 = invokedynamic(-722678002:(I)I, false);
        TextRenderer.1633394987 = invokedynamic(-115724309:(I)I, false);
        TextRenderer.-782821162 = invokedynamic(-261524214:(I)I, Integer.MIN_VALUE);
        TextRenderer.1089442789 = ((0 >>> 120 | 0 << -120) & -1);
        TextRenderer.1140792044 = invokedynamic(1388798271:(I)I, -1);
        TextRenderer.-275655162 = invokedynamic(1531004572:(I)I, 134217728);
        TextRenderer.855298866 = invokedynamic(-1546381832:(I)I, false);
        TextRenderer.345945934 = invokedynamic(-296134829:(I)I, false);
        TextRenderer.291148946 = (0 >>> 217 | 0 << -217);
        TextRenderer.1858682380 = ((0 >>> 107 | 0 << -107) & -1);
        TextRenderer.-1223988382 = ((0 >>> 24 | 0 << ~0x18 + 1) & -1);
        TextRenderer.1797660803 = invokedynamic(687115340:(I)I, 134217728);
        TextRenderer.1892003498 = invokedynamic(76327437:(I)I, Integer.MIN_VALUE);
        TextRenderer.-1025963001 = invokedynamic(-23902277:(I)I, -2013265920);
        TextRenderer.2006181473 = (Integer.MIN_VALUE >>> 95 | Integer.MIN_VALUE << -95);
        TextRenderer.1180032116 = (576 >>> 133 | 576 << ~0x85 + 1);
        TextRenderer.1713415775 = invokedynamic(-2051593035:(I)I, Integer.MIN_VALUE);
        TextRenderer.-800515210 = ((38 >>> 225 | 38 << -225) & -1);
        TextRenderer.800371133 = (524288 >>> 19 | 524288 << ~0x13 + 1);
        TextRenderer.-1557118310 = invokedynamic(-269523497:(I)I, 671088640);
        TextRenderer.-351748070 = invokedynamic(1613578666:(I)I, Integer.MIN_VALUE);
        TextRenderer.580152762 = (86016 >>> 172 | 86016 << -172);
        TextRenderer.634792260 = invokedynamic(-328730968:(I)I, false);
        TextRenderer.257856234 = ((0 >>> 120 | 0 << ~0x78 + 1) & -1);
        TextRenderer.-121624570 = invokedynamic(-1288200503:(I)I, false);
        TextRenderer.1409373178 = invokedynamic(747463454:(I)I, false);
        TextRenderer.847285085 = ((0 >>> 169 | 0 << ~0xA9 + 1) & -1);
        TextRenderer.-1208356195 = (-1476395008 >>> 155 | -1476395008 << ~0x9B + 1);
        TextRenderer.-134832007 = invokedynamic(421945109:(I)F, invokedynamic(-213301624:(I)I, 65218));
        TextRenderer.-688349825 = invokedynamic(2084716710:(I)F, invokedynamic(2121440784:(I)I, 65218));
        TextRenderer.1534924353 = invokedynamic(-1484869006:(I)F, invokedynamic(-140968536:(I)I, 65218));
        TextRenderer.1112505734 = invokedynamic(1798611792:(I)F, (-2147483583 >>> 136 | -2147483583 << ~0x88 + 1) & -1);
        TextRenderer.1323859217 = invokedynamic(-607630621:(J)D, invokedynamic(-1371167562:(J)J, 2L));
        TextRenderer.279292722 = invokedynamic(912561485:(I)I, -1073741824);
        TextRenderer.1048097905 = invokedynamic(469776217:(J)D, invokedynamic(-81024367:(J)J, 2L));
        TextRenderer.-736018880 = invokedynamic(1008812627:(I)I, -1073741824);
        TextRenderer.600114688 = invokedynamic(1752431037:(J)D, invokedynamic(1097127731:(J)J, 2L));
        TextRenderer.-886211835 = (33554432 >>> 248 | 33554432 << -248);
        TextRenderer.-340444438 = invokedynamic(-3327403:(J)D, invokedynamic(-1590824414:(J)J, 2L));
        TextRenderer.-272650087 = ((4194304 >>> 21 | 4194304 << ~0x15 + 1) & -1);
        TextRenderer.1273995437 = ((3042 >>> 128 | 3042 << -128) & -1);
        TextRenderer.1283200411 = invokedynamic(1551190844:(I)I, -1610612736);
        TextRenderer.2003660710 = invokedynamic(744771728:(J)J, -6731833412519275477L);
        TextRenderer.1071336356 = invokedynamic(2083646679:(J)J, 3026418949592973312L);
        TextRenderer.621225094 = invokedynamic(2123864006:(I)I, 1610612736);
        TextRenderer.539579897 = ((-1 >>> 40 | -1 << ~0x28 + 1) & -1);
        TextRenderer.-430094675 = invokedynamic(337587809:(J)J, -8605330857505401813L);
        TextRenderer.1262246656 = (0 >>> 174 | 0 << -174);
        TextRenderer.-1403325930 = (117440512 >>> 88 | 117440512 << ~0x58 + 1);
        TextRenderer.-1470895736 = invokedynamic(1593732711:(I)I, -1);
        TextRenderer.969334599 = invokedynamic(1946275042:(J)J, -8605330857505401813L);
        TextRenderer.-2126706212 = invokedynamic(-282244536:(I)I, 268435456);
        TextRenderer.25262731 = invokedynamic(307458040:(J)J, -6731833412519275477L);
        TextRenderer.-1654477283 = invokedynamic(-700501564:(J)J, 3026418949592973312L);
        TextRenderer.-1282569876 = invokedynamic(-576298686:(I)I, false);
        TextRenderer.960816026 = (1073741824 >>> 221 | 1073741824 << -221);
        TextRenderer.1669463769 = (1 >>> 31 | 1 << ~0x1F + 1);
        TextRenderer.-24615174 = (536870913 >>> 93 | 536870913 << -93);
        TextRenderer.-2068189607 = invokedynamic(-1359942458:(I)I, -1);
        TextRenderer.622444640 = invokedynamic(-1792906068:(J)J, -8605330857505401813L);
        TextRenderer.-2115613905 = invokedynamic(946338346:(I)I, -1);
        TextRenderer.-1008772484 = invokedynamic(-367852345:(I)I, -452984832);
        TextRenderer.-220270196 = invokedynamic(-1017801793:(I)I, Integer.MIN_VALUE);
        TextRenderer.-1444362027 = invokedynamic(-500126769:(I)I, -1);
        TextRenderer.526833044 = invokedynamic(1672408727:(I)I, Integer.MIN_VALUE);
        TextRenderer.-819241858 = ((4194304 >>> 182 | 4194304 << -182) & -1);
        TextRenderer.-1093407262 = invokedynamic(1605329459:(I)I, 1342177280);
        TextRenderer.-571505505 = invokedynamic(-541540465:(J)J, -6731833412519275477L);
        TextRenderer.-462034986 = invokedynamic(-1033092383:(J)J, 3026418949592973312L);
        TextRenderer.-1145035048 = invokedynamic(-1845487593:(I)I, -805306368);
        TextRenderer.1501600034 = invokedynamic(638638161:(J)J, -8605330857505401813L);
        TextRenderer.-1471905301 = invokedynamic(-65546925:(I)I, -704643072);
        TextRenderer.-1965430370 = (1862270976 >>> 120 | 1862270976 << -120);
        TextRenderer.165544397 = ((78643200 >>> 20 | 78643200 << -20) & -1);
        TextRenderer.1731230478 = (-1644167168 >>> 217 | -1644167168 << -217);
        TextRenderer.-1075610938 = invokedynamic(668554472:(I)I, 1308622848);
        TextRenderer.956004388 = invokedynamic(797584528:(I)I, 1241513984);
        TextRenderer.-504843774 = (512 >>> 169 | 512 << -169);
        TextRenderer.-161356744 = (0 >>> 235 | 0 << ~0xEB + 1);
        TextRenderer.-1554763883 = invokedynamic(-1268898786:(I)I, 805306368);
        TextRenderer.247018453 = invokedynamic(784643665:(I)I, -1);
        TextRenderer.-1327776929 = invokedynamic(-1514176016:(J)J, -8605330857505401813L);
        TextRenderer.959721934 = invokedynamic(-1266619335:(I)I, false);
        TextRenderer.-1453498832 = ((0 >>> 44 | 0 << ~0x2C + 1) & -1);
        TextRenderer.-1201068070 = (-1 >>> 139 | -1 << ~0x8B + 1);
        TextRenderer.-298994627 = invokedynamic(210719029:(I)I, false);
        TextRenderer.298306419 = invokedynamic(1527659873:(I)I, Integer.MIN_VALUE);
        TextRenderer.393230440 = (3538944 >>> 175 | 3538944 << -175);
        TextRenderer.947573388 = invokedynamic(-538801148:(I)I, 838860800);
        TextRenderer.867072764 = invokedynamic(-1142502049:(I)I, 1308622848);
        TextRenderer.-1104464188 = (5248 >>> 198 | 5248 << -198);
        TextRenderer.1895894940 = (0 >>> 178 | 0 << -178);
        TextRenderer.898854063 = (256 >>> 72 | 256 << ~0x48 + 1);
        TextRenderer.188109048 = invokedynamic(258780320:(I)I, 1342177280);
        TextRenderer.1156446089 = (-1 >>> 44 | -1 << ~0x2C + 1);
        TextRenderer.28551019 = invokedynamic(1039866390:(I)I, 201326592);
        TextRenderer.2077667954 = (14942208 >>> 82 | 14942208 << -82);
        TextRenderer.349259128 = invokedynamic(-1930825039:(I)I, -2046820352);
        TextRenderer.1175095018 = ((26112 >>> 40 | 26112 << -40) & -1);
        TextRenderer.-1459562744 = ((4160 >>> 102 | 4160 << ~0x66 + 1) & -1);
        TextRenderer.-1542142093 = invokedynamic(-1853552048:(I)I, 1644167168);
        TextRenderer.-214635668 = ((524288 >>> 243 | 524288 << ~0xF3 + 1) & -1);
        TextRenderer.-407230057 = ((0 >>> 43 | 0 << ~0x2B + 1) & -1);
        TextRenderer.-483402464 = (0 >>> 205 | 0 << ~0xCD + 1);
        TextRenderer.-201241341 = invokedynamic(1612343677:(I)I, -1342177280);
        TextRenderer.998031541 = invokedynamic(1723574041:(J)J, -8605330857505401813L);
        TextRenderer.1722647463 = (-536870912 >>> 124 | -536870912 << -124);
        TextRenderer.1448781755 = invokedynamic(273251017:(I)I, -1);
        TextRenderer.1419963442 = invokedynamic(-1489511103:(J)J, -8605330857505401813L);
        TextRenderer.1470837079 = invokedynamic(1653913741:(I)I, false);
        TextRenderer.-1296219430 = (0 >>> 82 | 0 << -82);
        TextRenderer.1021690385 = invokedynamic(-1963618030:(I)I, false);
        TextRenderer.468588310 = ((0 >>> 56 | 0 << -56) & -1);
        TextRenderer.-2096988226 = invokedynamic(196144727:(I)I, Integer.MIN_VALUE);
        TextRenderer.1534401244 = invokedynamic(1152514430:(I)I, false);
        TextRenderer.1739741210 = invokedynamic(-2099765262:(I)I, -1);
        TextRenderer.433415929 = ((16777216 >>> 244 | 16777216 << -244) & -1);
        TextRenderer.-1897999605 = (0 >>> 255 | 0 << -255);
        TextRenderer.1143716891 = (0 >>> 26 | 0 << ~0x1A + 1);
        TextRenderer.1678605331 = (524288 >>> 143 | 524288 << ~0x8F + 1);
        TextRenderer.1205437945 = ((8912896 >>> 211 | 8912896 << -211) & -1);
        TextRenderer.-2117968845 = (4 >>> 162 | 4 << ~0xA2 + 1);
        TextRenderer.562444384 = invokedynamic(1703137787:(I)I, 1207959552);
        TextRenderer.-1735791789 = invokedynamic(1260486237:(I)I, -939524096);
        TextRenderer.-1024865711 = invokedynamic(1724885763:(I)I, 671088640);
        TextRenderer.1285986482 = (268435456 >>> 252 | 268435456 << ~0xFC + 1);
        TextRenderer.-1552167533 = (5505024 >>> 242 | 5505024 << ~0xF2 + 1);
        TextRenderer.240906699 = invokedynamic(-256746339:(I)I, false);
        TextRenderer.1107588653 = invokedynamic(1907999157:(I)I, false);
        TextRenderer.-2133966555 = (536870912 >>> 252 | 536870912 << ~0xFC + 1);
        TextRenderer.-1632922972 = invokedynamic(1877371526:(I)I, 1073741824);
        TextRenderer.-177996765 = invokedynamic(-867069298:(I)I, Integer.MIN_VALUE);
        TextRenderer.616497467 = (4096 >>> 11 | 4096 << -11);
        TextRenderer.629265458 = ((24 >>> 163 | 24 << ~0xA3 + 1) & -1);
        TextRenderer.929629397 = (245760 >>> 110 | 245760 << ~0x6E + 1);
        TextRenderer.-2009842092 = invokedynamic(-62449237:(J)J, -8605330857505401813L);
        TextRenderer.-1977451877 = invokedynamic(-1115174508:(I)I, 134217728);
        TextRenderer.619105736 = invokedynamic(-1727854956:(J)J, -6731833412519275477L);
        TextRenderer.1715088025 = invokedynamic(-1289267618:(J)J, 3026418949592973312L);
        TextRenderer.467447897 = invokedynamic(-709340257:(I)I, -65536);
        TextRenderer.731660032 = (0 >>> 139 | 0 << ~0x8B + 1);
        TextRenderer.-396537524 = invokedynamic(1244002901:(I)I, false);
        TextRenderer.1863857876 = (42752 >>> 200 | 42752 << ~0xC8 + 1);
        TextRenderer.-1729217847 = invokedynamic(-794658573:(I)I, Integer.MIN_VALUE);
        TextRenderer.1756949701 = invokedynamic(-722189062:(I)I, Integer.MIN_VALUE);
        TextRenderer.293633219 = ((34816 >>> 203 | 34816 << -203) & -1);
        TextRenderer.1043472191 = invokedynamic(-1932655056:(J)J, -6731833412519275477L);
        TextRenderer.-1058239760 = invokedynamic(1053536066:(J)J, 3026418949592973312L);
        TextRenderer.1452220936 = invokedynamic(1050415066:(I)I, 1207959552);
        TextRenderer.1379282016 = invokedynamic(718733805:(J)J, -8605330857505401813L);
        TextRenderer.-776840639 = (-1 >>> 125 | -1 << -125);
        TextRenderer.-428923347 = ((622592 >>> 47 | 622592 << -47) & -1);
        TextRenderer.261785338 = invokedynamic(657727408:(J)J, -6731833412519275477L);
        TextRenderer.1171412605 = invokedynamic(-1846512876:(J)J, 3026418949592973312L);
        TextRenderer.-1892815939 = invokedynamic(1956248233:(I)I, 671088640);
        TextRenderer.-1246714602 = (-1 >>> 102 | -1 << ~0x66 + 1);
        TextRenderer.1086345729 = invokedynamic(-726083808:(J)J, -8605330857505401813L);
        TextRenderer.1575123375 = (672 >>> 229 | 672 << ~0xE5 + 1);
        TextRenderer.-1150836016 = ((-1 >>> 146 | -1 << -146) & -1);
        TextRenderer.-1349155928 = invokedynamic(41392492:(J)J, -8605330857505401813L);
        TextRenderer.-422650121 = ((1441792 >>> 208 | 1441792 << -208) & -1);
        TextRenderer.77510482 = invokedynamic(-990103799:(J)J, -8605330857505401813L);
        TextRenderer.634529583 = invokedynamic(1726557213:(I)I, -1);
        TextRenderer.1571746717 = invokedynamic(-749326297:(I)I, -402653184);
        TextRenderer.1320878182 = invokedynamic(815476030:(J)J, -8605330857505401813L);
        TextRenderer.-1204774033 = (50331648 >>> 21 | 50331648 << -21);
        TextRenderer.-960184905 = invokedynamic(-1808449088:(J)J, -8605330857505401813L);
        TextRenderer.1117272510 = ((419430400 >>> 24 | 419430400 << -24) & -1);
        TextRenderer.250234333 = invokedynamic(-104439934:(J)J, -8605330857505401813L);
        TextRenderer.1679832179 = ((-805306368 >>> 123 | -805306368 << ~0x7B + 1) & -1);
        TextRenderer.560954202 = invokedynamic(-108404791:(I)I, -1);
        TextRenderer.-12808746 = invokedynamic(-1374827710:(J)J, -8605330857505401813L);
        TextRenderer.1172830945 = invokedynamic(392477894:(I)I, -671088640);
        TextRenderer.-1030214737 = ((-1 >>> 220 | -1 << -220) & -1);
        TextRenderer.731737085 = invokedynamic(593378675:(J)J, -8605330857505401813L);
        TextRenderer.454434941 = invokedynamic(1748036631:(I)I, -65536);
        TextRenderer.2045970474 = invokedynamic(553964002:(I)I, false);
        TextRenderer.575910128 = invokedynamic(1345574948:(I)I, -452984832);
        TextRenderer.-1065212208 = (262144 >>> 210 | 262144 << ~0xD2 + 1);
        TextRenderer.840212455 = invokedynamic(-1280376276:(I)I, Integer.MIN_VALUE);
        TextRenderer.1351428617 = ((-1 >>> 73 | -1 << ~0x49 + 1) & -1);
        TextRenderer.-576252015 = invokedynamic(215556533:(I)I, 939524096);
        TextRenderer.-638011120 = invokedynamic(1275430125:(J)J, -6731833412519275477L);
        TextRenderer.220657828 = invokedynamic(692254046:(J)J, 3026418949592973312L);
        TextRenderer.-1957932883 = invokedynamic(392529508:(I)I, -1207959552);
        TextRenderer.-1711015879 = invokedynamic(1518663774:(J)J, -6731833412519275477L);
        TextRenderer.1412429503 = invokedynamic(1377384817:(J)J, 3026418949592973312L);
        TextRenderer.-604646007 = invokedynamic(-1192792639:(I)I, -2018508800);
        TextRenderer.-906485233 = (134217728 >>> 187 | 134217728 << ~0xBB + 1);
        TextRenderer.-1108023608 = ((1819136 >>> 9 | 1819136 << ~0x9 + 1) & -1);
        TextRenderer.384284647 = (8388608 >>> 55 | 8388608 << -55);
        TextRenderer.-1227044741 = ((0 >>> 197 | 0 << ~0xC5 + 1) & -1);
        TextRenderer.-216393909 = invokedynamic(-2113053903:(I)I, false);
        TextRenderer.-1852796323 = ((Integer.MIN_VALUE >>> 58 | Integer.MIN_VALUE << -58) & -1);
        TextRenderer.-329495761 = (12 >>> 34 | 12 << ~0x22 + 1);
        TextRenderer.-1900454571 = ((8192 >>> 13 | 8192 << ~0xD + 1) & -1);
        TextRenderer.-1588565646 = ((43520 >>> 169 | 43520 << -169) & -1);
        TextRenderer.555696911 = ((4 >>> 225 | 4 << -225) & -1);
        TextRenderer.23355942 = invokedynamic(113329829:(I)I, Integer.MIN_VALUE);
        TextRenderer.-329403804 = invokedynamic(157284550:(I)I, 1426063360);
        TextRenderer.-2022385562 = invokedynamic(-818126159:(I)I, Integer.MIN_VALUE);
        TextRenderer.1268923485 = invokedynamic(-750957954:(I)I, Integer.MIN_VALUE);
        TextRenderer.-599995124 = invokedynamic(277892347:(I)I, 1426063360);
        TextRenderer.-1479837102 = invokedynamic(-1488558897:(I)I, false);
        TextRenderer.-1291683283 = ((134217728 >>> 59 | 134217728 << -59) & -1);
        TextRenderer.-1402776840 = (5570560 >>> 175 | 5570560 << -175);
        TextRenderer.1528190577 = (201326592 >>> 25 | 201326592 << ~0x19 + 1);
        TextRenderer.-307465700 = ((2097152 >>> 81 | 2097152 << -81) & -1);
        TextRenderer.-42688655 = invokedynamic(-1259774484:(I)I, 536870912);
        TextRenderer.1676616534 = invokedynamic(-325727179:(I)I, 536870912);
        TextRenderer.-919469536 = invokedynamic(988065422:(I)I, 536870912);
        TextRenderer.-211178500 = invokedynamic(1705152648:(I)I, -16777216);
        TextRenderer.-2134199659 = invokedynamic(401020105:(I)I, 134217728);
        TextRenderer.-517061051 = invokedynamic(-1816132935:(I)I, -16777216);
        TextRenderer.973333820 = (134217728 >>> 88 | 134217728 << -88);
        TextRenderer.-841216745 = invokedynamic(-240923135:(I)I, -16777216);
        TextRenderer.1006897808 = invokedynamic(-787239567:(I)I, false);
        TextRenderer.-670575659 = invokedynamic(1388812245:(I)I, false);
        TextRenderer.-1238475304 = (512 >>> 105 | 512 << ~0x69 + 1);
        TextRenderer.-160950069 = invokedynamic(485768740:(I)I, false);
        TextRenderer.-1316787022 = invokedynamic(2098663708:(I)I, -1);
        TextRenderer.-1495464135 = ((32768 >>> 15 | 32768 << ~0xF + 1) & -1);
        TextRenderer.-1923643639 = ((0 >>> 252 | 0 << -252) & -1);
        TextRenderer.-1616082956 = invokedynamic(409762221:(I)I, false);
        TextRenderer.-44566610 = (0 >>> 75 | 0 << -75);
        TextRenderer.390973373 = ((1811939328 >>> 248 | 1811939328 << ~0xF8 + 1) & -1);
        TextRenderer.1624207117 = invokedynamic(-585140959:(I)I, 838860800);
        TextRenderer.-70435844 = invokedynamic(-243272600:(I)I, 1308622848);
        TextRenderer.-1948100598 = invokedynamic(164731862:(I)I, 1241513984);
        TextRenderer.-442284508 = invokedynamic(1167686752:(I)I, false);
        TextRenderer.166471570 = invokedynamic(2094984809:(I)I, Integer.MIN_VALUE);
        TextRenderer.-1088943980 = invokedynamic(450756962:(I)I, Integer.MIN_VALUE);
        TextRenderer.-1595780306 = invokedynamic(-64383005:(I)I, false);
        TextRenderer.714349745 = (536870912 >>> 121 | 536870912 << -121);
        TextRenderer.-1192621739 = invokedynamic(1116611338:(I)F, (1876951048 >>> 197 | 1876951048 << ~0xC5 + 1) & -1);
        TextRenderer.-420646673 = invokedynamic(-830287609:(I)I, 268435456);
        TextRenderer.1469388561 = (8355840 >>> 79 | 8355840 << ~0x4F + 1);
        TextRenderer.1444844923 = invokedynamic(-1303972524:(I)F, 283099136 >>> 62 | 283099136 << -62);
        TextRenderer.1023710160 = invokedynamic(1135993396:(I)I, -16777216);
        TextRenderer.1163686187 = invokedynamic(-1435557685:(I)F, invokedynamic(1919547416:(I)I, 65218));
        TextRenderer.-594520407 = invokedynamic(-310223902:(I)I, 2013265920);
        TextRenderer.2119417128 = invokedynamic(-1758519621:(J)J, -8605330857505401813L);
        TextRenderer.1045240028 = invokedynamic(1590620:(I)I, false);
        TextRenderer.1848236100 = invokedynamic(-141808925:(I)I, -134217728);
        TextRenderer.1189419463 = ((507904 >>> 78 | 507904 << ~0x4E + 1) & -1);
        TextRenderer.-1514998616 = new String[TextRenderer.1848236100];
        TextRenderer.-1385459114 = new String[TextRenderer.1189419463];
    }
    // invokedynamic(1125847494:()V)
    
    private static Object -2038044391(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(TextRenderer.class, "1896965492", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", TextRenderer.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/utils/TextRenderer:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String 1896965492(final int n, long n2) {
        n2 ^= 0x54L;
        n2 ^= 0x8E7DD2DDD4187C26L;
        if (TextRenderer.-1514998616[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/utils/TextRenderer");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            TextRenderer.-1514998616[n] = new String(instance.doFinal(Base64.getDecoder().decode(TextRenderer.-1385459114[n])));
        }
        return TextRenderer.-1514998616[n];
    }
    
    private static void -906298668() {
        TextRenderer.811770822 = -3158301067052201659L;
        final long n = TextRenderer.811770822 ^ 0x8E7DD2DDD4187C26L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    TextRenderer.-1385459114[0] = "4xyZ04/k85F2IB/P0944NHbjzgPFtKos";
                    TextRenderer.-1385459114[1] = "LVESMy73OJshzWjU/vkhj9pIZ7DsDcMh";
                    TextRenderer.-1385459114[2] = "2ZuwVUu2x0U=";
                    TextRenderer.-1385459114[3] = "5J18ahwHQ6A=";
                    TextRenderer.-1385459114[4] = "5J18ahwHQ6A=";
                    TextRenderer.-1385459114[5] = "JW15HWzz62U=";
                    TextRenderer.-1385459114[6] = "wVQGkDT9arFAgCBnWGEPZh/Qba9xB1z4dQUvRdigb5c3KnM8cwUcXeltLiqdLjqanfsZUybHmu0x5U6nwHmPWuE7OnVJD+YXIZJ7zLs4/vjs4dquv6lIitQv+9muWeq5W26kU+DJNLu9sWnkOMnIaSatWv0ZIwobAuXVUQm3kvrYVJS7ybOc5PEuwxOM5fIjH5BdxgXi4KkvUCiU77gAof52HO5ov4BC5qyjZzjI12Jh07blXRF5uMBvig4APUwJ0tmRfv+RoOpl/w93VGdWl4kLTfTArLG7f1Wg0mkMeY5vAGXI2w0z4661/kbEAKMgUwlswFOOgGFWN53kIiYNMUakb9jJZMk6MNR8Qsxyg3Mh8J5d/F8Fdy5ExaMecvI0MB4J4ICHQe9eD2kTyhGIg5fCu7g+rhCA/5ulxyq/GkV8JtPrQX1xvGqFJz55ya7lypZ6P19IQmeQb2UBL271Vj4p162T23HKhL+PDcjeoSbxJbRf4Tz074xGhBX/wBtUm8GRrAyQwt4Y0HowoG3Y5d0ZGUprf4rQrg0ru3zpt0w9MlFRxBpB63f2EnBJKM3h902xhzYVhRN4FCoSM6LO9ObzN9vjUM0H22YTHvCQm0ZYI89p33sCEw==";
                    TextRenderer.-1385459114[7] = "wVQGkDT9arFAgCBnWGEPZh/Qba9xB1z4dQUvRdigb5c3KnM8cwUcXeltLiqdLjqanfsZUybHmu0x5U6nwHmPWuE7OnVJD+YXIZJ7zLs4/vjs4dquv6lIitQv+9muWeq5W26kU+DJNLu9sWnkOMnIaSatWv0ZIwobAuXVUQm3kvrYVJS7ybOc5PEuwxOM5fIjH5BdxgXi4KkvUCiU77gAof52HO5ov4BC5qyjZzjI12Jh07blXRF5uMBvig4APUwJ0tmRfv+RoOpl/w93VGdWl4kLTfTArLG7f1Wg0mkMeY5vAGXI2w0z4661/kbEAKMgUwlswFOOgGFWN53kIiYNMUakb9jJZMk6MNR8Qsxyg3Mh8J5d/F8Fdy5ExaMecvI0MB4J4ICHQe9eD2kTyhGIg5fCu7g+rhCA/5ulxyq/GkV8JtPrQX1xvGqFJz55ya7lypZ6P19IQmeQb2UBL271Vj4p162T23HKhL+PDcjeoSbxJbRf4Tz074xGhBX/wBtUm8GRrAyQwt4Y0HowoG3Y5d0ZGUprf4rQrg0ru3zpt0w9MlFRxBpB63f2EnBJKM3h902xhzYVhRN4FCoSM6LO9ObzN9vjUM0H22YTHvCQm0ZYI89p33sCEw==";
                    TextRenderer.-1385459114[8] = "wVQGkDT9arFAgCBnWGEPZh/Qba9xB1z4dQUvRdigb5c3KnM8cwUcXeltLiqdLjqanfsZUybHmu0x5U6nwHmPWuE7OnVJD+YXIZJ7zLs4/vjs4dquv6lIitQv+9muWeq5W26kU+DJNLu9sWnkOMnIaSatWv0ZIwobAuXVUQm3kvrYVJS7ybOc5PEuwxOM5fIjH5BdxgXi4KkvUCiU77gAof52HO5ov4BC5qyjZzjI12Jh07blXRF5uMBvig4APUwJ0tmRfv+RoOpl/w93VGdWl4kLTfTArLG7f1Wg0mkMeY5vAGXI2w0z4661/kbEAKMgUwlswFOOgGFWN53kIiYNMUakb9jJZMk6MNR8Qsxyg3Mh8J5d/F8Fdy5ExaMecvI0MB4J4ICHQe9eD2kTyhGIg5fCu7g+rhCA/5ulxyq/GkV8JtPrQX1xvGqFJz55ya7lypZ6P19IQmeQb2UBL271Vj4p162T23HKhL+PDcjeoSbxJbRf4Tz074xGhBX/wBtUm8GRrAyQwt4Y0HowoG3Y5d0ZGUprf4rQrg0ru3zpt0w9MlFRxBpB63f2EnBJKM3h902xhzYVhRN4FCoSM6LO9ObzN9vjUM0H22YTHvCQm0ZYI89p33sCEw==";
                    TextRenderer.-1385459114[9] = "JW15HWzz62U=";
                    TextRenderer.-1385459114[10] = "5J18ahwHQ6A=";
                    TextRenderer.-1385459114[11] = "5J18ahwHQ6A=";
                    TextRenderer.-1385459114[12] = "LVESMy73OJshzWjU/vkhj6diNi3ahWN6";
                    TextRenderer.-1385459114[13] = "5J18ahwHQ6A=";
                    TextRenderer.-1385459114[14] = "5J18ahwHQ6A=";
                    TextRenderer.-1385459114[15] = "StsMSgSvaCI=";
                    TextRenderer.-1385459114[16] = "JW15HWzz62U=";
                    TextRenderer.-1385459114[17] = "StsMSgSvaCI=";
                    TextRenderer.-1385459114[18] = "StsMSgSvaCI=";
                    TextRenderer.-1385459114[19] = "StsMSgSvaCI=";
                    TextRenderer.-1385459114[20] = "5J18ahwHQ6A=";
                    TextRenderer.-1385459114[21] = "StsMSgSvaCI=";
                    TextRenderer.-1385459114[22] = "JW15HWzz62U=";
                    TextRenderer.-1385459114[23] = "StsMSgSvaCI=";
                    TextRenderer.-1385459114[24] = "5J18ahwHQ6A=";
                    TextRenderer.-1385459114[25] = "StsMSgSvaCI=";
                    TextRenderer.-1385459114[26] = "JW15HWzz62U=";
                    TextRenderer.-1385459114[27] = "JW15HWzz62U=";
                    TextRenderer.-1385459114[28] = "5J18ahwHQ6A=";
                    TextRenderer.-1385459114[29] = "JW15HWzz62U=";
                    TextRenderer.-1385459114[30] = "LVESMy73OJshzWjU/vkhj9pIZ7DsDcMh";
                    break;
                }
                case 1: {
                    TextRenderer.-1385459114[0] = "4xyZ04/k85F2IB/P0944NNN+WugJDhhMlDZRq3CRUxk=";
                    TextRenderer.-1385459114[1] = "LVESMy73OJshzWjU/vkhjxmv/RSSG1uiaN+rXrsNFfo=";
                    TextRenderer.-1385459114[2] = "VnwYkebNUBo=";
                    TextRenderer.-1385459114[3] = "jRU5v1z0eMY=";
                    TextRenderer.-1385459114[4] = "JHySjfjYENM=";
                    TextRenderer.-1385459114[5] = "2iK0nW6jAII=";
                    TextRenderer.-1385459114[6] = "wVQGkDT9arFAgCBnWGEPZh/Qba9xB1z4dQUvRdigb5c3KnM8cwUcXeltLiqdLjqanfsZUybHmu0x5U6nwHmPWuE7OnVJD+YXIZJ7zLs4/vjs4dquv6lIitQv+9muWeq5W26kU+DJNLu9sWnkOMnIaSatWv0ZIwobAuXVUQm3kvrYVJS7ybOc5PEuwxOM5fIjH5BdxgXi4KkvUCiU77gAof52HO5ov4BC5qyjZzjI12Jh07blXRF5uMBvig4APUwJ0tmRfv+RoOpl/w93VGdWl4kLTfTArLG7f1Wg0mkMeY5vAGXI2w0z4661/kbEAKMgUwlswFOOgGFWN53kIiYNMUakb9jJZMk6MNR8Qsxyg3Mh8J5d/F8Fdy5ExaMecvI0MB4J4ICHQe9eD2kTyhGIg5fCu7g+rhCA/5ulxyq/GkV8JtPrQX1xvGqFJz55ya7lypZ6P19IQmeQb2UBL271Vj4p162T23HKhL+PDcjeoSbxJbRf4Tz074xGhBX/wBtUm8GRrAyQwt4Y0HowoG3Y5d0ZGUprf4rQrg0ru3zpt0w9MlFRxBpB63f2EnBJKM3h902xhzYVhRN4FCoSM6LO9ObzN9vjUM0H22YTHvCQm0bQ7NauhEbgoLgQjWXAIzQL";
                    TextRenderer.-1385459114[7] = "wVQGkDT9arFAgCBnWGEPZh/Qba9xB1z4dQUvRdigb5c3KnM8cwUcXeltLiqdLjqanfsZUybHmu0x5U6nwHmPWuE7OnVJD+YXIZJ7zLs4/vjs4dquv6lIitQv+9muWeq5W26kU+DJNLu9sWnkOMnIaSatWv0ZIwobAuXVUQm3kvrYVJS7ybOc5PEuwxOM5fIjH5BdxgXi4KkvUCiU77gAof52HO5ov4BC5qyjZzjI12Jh07blXRF5uMBvig4APUwJ0tmRfv+RoOpl/w93VGdWl4kLTfTArLG7f1Wg0mkMeY5vAGXI2w0z4661/kbEAKMgUwlswFOOgGFWN53kIiYNMUakb9jJZMk6MNR8Qsxyg3Mh8J5d/F8Fdy5ExaMecvI0MB4J4ICHQe9eD2kTyhGIg5fCu7g+rhCA/5ulxyq/GkV8JtPrQX1xvGqFJz55ya7lypZ6P19IQmeQb2UBL271Vj4p162T23HKhL+PDcjeoSbxJbRf4Tz074xGhBX/wBtUm8GRrAyQwt4Y0HowoG3Y5d0ZGUprf4rQrg0ru3zpt0w9MlFRxBpB63f2EnBJKM3h902xhzYVhRN4FCoSM6LO9ObzN9vjUM0H22YTHvCQm0Z29h/oIkkcUL/Ib3Ckyrfc";
                    TextRenderer.-1385459114[8] = "wVQGkDT9arFAgCBnWGEPZh/Qba9xB1z4dQUvRdigb5c3KnM8cwUcXeltLiqdLjqanfsZUybHmu0x5U6nwHmPWuE7OnVJD+YXIZJ7zLs4/vjs4dquv6lIitQv+9muWeq5W26kU+DJNLu9sWnkOMnIaSatWv0ZIwobAuXVUQm3kvrYVJS7ybOc5PEuwxOM5fIjH5BdxgXi4KkvUCiU77gAof52HO5ov4BC5qyjZzjI12Jh07blXRF5uMBvig4APUwJ0tmRfv+RoOpl/w93VGdWl4kLTfTArLG7f1Wg0mkMeY5vAGXI2w0z4661/kbEAKMgUwlswFOOgGFWN53kIiYNMUakb9jJZMk6MNR8Qsxyg3Mh8J5d/F8Fdy5ExaMecvI0MB4J4ICHQe9eD2kTyhGIg5fCu7g+rhCA/5ulxyq/GkV8JtPrQX1xvGqFJz55ya7lypZ6P19IQmeQb2UBL271Vj4p162T23HKhL+PDcjeoSbxJbRf4Tz074xGhBX/wBtUm8GRrAyQwt4Y0HowoG3Y5d0ZGUprf4rQrg0ru3zpt0w9MlFRxBpB63f2EnBJKM3h902xhzYVhRN4FCoSM6LO9ObzN9vjUM0H22YTHvCQm0bZqG5pJLbOi1DxpTVlCWyL";
                    TextRenderer.-1385459114[9] = "yQVhy9Hq+YY=";
                    TextRenderer.-1385459114[10] = "b1BkeC8C6D4=";
                    TextRenderer.-1385459114[11] = "4tsuveahEec=";
                    TextRenderer.-1385459114[12] = "LVESMy73OJshzWjU/vkhj5AHXaYe/8Nx";
                    TextRenderer.-1385459114[13] = "yfwr94pLp9Q=";
                    TextRenderer.-1385459114[14] = "XDyQxYolwEg=";
                    TextRenderer.-1385459114[15] = "yZqHE/hrPvw=";
                    TextRenderer.-1385459114[16] = "Omfuf54ICDs=";
                    TextRenderer.-1385459114[17] = "Nr2y863WK7U=";
                    TextRenderer.-1385459114[18] = "xJMN0L5Q21Y=";
                    TextRenderer.-1385459114[19] = "a6OqMWMAe+g=";
                    TextRenderer.-1385459114[20] = "dgneJ8B4fYY=";
                    TextRenderer.-1385459114[21] = "kTOxOzUnjTM=";
                    TextRenderer.-1385459114[22] = "vXGu71GKjKY=";
                    TextRenderer.-1385459114[23] = "HkswrclOLBY=";
                    TextRenderer.-1385459114[24] = "8rFLYZeQsBk=";
                    TextRenderer.-1385459114[25] = "ovNkC2ytrfU=";
                    TextRenderer.-1385459114[26] = "MbJlwi4my8Y=";
                    TextRenderer.-1385459114[27] = "YVIjktwsuqE=";
                    TextRenderer.-1385459114[28] = "8IUw+ETKvGs=";
                    TextRenderer.-1385459114[29] = "l7Y538/tKNk=";
                    TextRenderer.-1385459114[30] = "LVESMy73OJshzWjU/vkhj7JlW8kK/CmU4kIsQ3GSGRA=";
                    break;
                }
                case 2: {
                    TextRenderer.-1385459114[0] = "GGQ+JrVN8J0=";
                    break;
                }
                case 4: {
                    TextRenderer.-1385459114[0] = "a32gQzdLDthE4HTTzmRa6A==";
                    break;
                }
            }
        }
    }
    
    public static Object 1947710780(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7, final Object o8) throws Exception {
        final int n = ((int)o ^ TextRenderer.1566797085) & 0xFF;
        final Integer value = TextRenderer.1765958926;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

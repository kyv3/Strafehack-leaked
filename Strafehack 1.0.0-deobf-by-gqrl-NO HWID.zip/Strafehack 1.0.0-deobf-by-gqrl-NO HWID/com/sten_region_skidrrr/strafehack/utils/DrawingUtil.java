// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.utils;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import net.minecraft.util.math.AxisAlignedBB;
import com.sten_region_skidrrr.strafehack.StrafeHack;
import com.sten_region_skidrrr.strafehack.module.settings.BooleanSetting;
import net.minecraft.client.Minecraft;

public class DrawingUtil
{
    private static Minecraft mc;
    private static String[] -325370648;
    private static String[] 901208665;
    private static long 1416162074;
    private static int 146530896;
    private static int 1735874847;
    private static long 232223846;
    private static int 112829851;
    private static int -357647820;
    private static long -683095753;
    private static int 1941029928;
    private static int -282013279;
    private static long 944286154;
    private static int -238409303;
    private static long 424155548;
    private static int 661633932;
    private static int -1644457314;
    private static long 1758992657;
    private static long -934497989;
    private static int 473194351;
    private static int -1126637294;
    private static long -659399806;
    private static long 887427810;
    private static int 1587417765;
    private static int 1747818629;
    private static long 487440289;
    private static int -696258036;
    private static long -2013704985;
    private static int 680306475;
    private static int -132000661;
    private static int -2102736690;
    private static long 1928865301;
    private static int -2052823268;
    private static int -22564903;
    private static long -1652919673;
    private static long 1440527043;
    private static int -1155069146;
    private static int -1693156484;
    private static long 211437051;
    private static int 126407558;
    private static int -779629622;
    private static int -2069628878;
    private static long -657162527;
    private static int -1002772835;
    private static long 1057564331;
    private static long -2030437308;
    private static int -401232914;
    private static int 1202675339;
    private static long -1877613435;
    private static long 511413632;
    private static int -1382281226;
    private static int 1671962258;
    private static long 81582253;
    private static long -1202766905;
    private static int 1288651581;
    private static int 1694583438;
    private static long 1067533280;
    private static long -768917537;
    private static int -240011281;
    private static int -380932080;
    private static int -1382225580;
    private static long -964238649;
    private static long 1215643472;
    private static int 673223365;
    private static int 1748184105;
    private static int -676688473;
    private static long 1246419210;
    private static int -573953166;
    private static int -2119320964;
    private static long 1312488821;
    private static int -210167250;
    private static int 1404153035;
    private static long 1148958525;
    private static int 656202599;
    private static int -517897021;
    private static long -2057604607;
    private static int 2135639413;
    private static int 1637620522;
    private static long 783390311;
    private static long -963489516;
    private static int 1915329184;
    private static int -7874506;
    private static int -1477133308;
    private static int 1043751605;
    private static long 119210373;
    private static long -772758476;
    private static int -184015084;
    private static int 478971170;
    private static int 1927629568;
    private static int 1844069144;
    private static int -673578919;
    private static int 2004375985;
    private static int -1443786813;
    private static int -1014250876;
    private static int -1588823820;
    private static int 1687181281;
    private static int -1377850252;
    private static int -1455442954;
    private static float -237941987;
    private static float 1248466997;
    private static float 1812651290;
    private static float -1766408723;
    private static int -1615317900;
    private static int -782778306;
    private static int 1543048175;
    private static int 25728372;
    private static int -1254427241;
    private static int 871369973;
    private static int 901818763;
    private static int 563599895;
    private static int -518529994;
    private static int 1766111249;
    private static int -1152268424;
    private static int -1404517900;
    private static int -1628014924;
    private static int -1976973126;
    private static int 842683983;
    private static int 2085737722;
    private static int -1810645489;
    private static int -1249648508;
    private static int 2016322942;
    private static int -461383173;
    private static int 1190943289;
    
    public static void drawString(final String -2063794630, final int 514830642, final int 975109689, final int 1640610913) {
        if (!invokedynamic(-1224346524:(Ljava/lang/Object;)Z, (BooleanSetting)invokedynamic(759096221:(Ljava/lang/Object;I)Ljava/lang/Object;, invokedynamic(157874676:(Ljava/lang/Object;)Ljava/util/List;, invokedynamic(-913662702:(Ljava/lang/Object;)Lcom/sten_region_skidrrr/strafehack/module/Module;, invokedynamic(-1136666143:(IJ)Ljava/lang/String;, DrawingUtil.146530896 & DrawingUtil.1735874847, DrawingUtil.232223846))), DrawingUtil.112829851))) {
        }
        // invokedynamic(124141592:(Ljava/lang/Object;Ljava/lang/Object;III)I, StrafeHack.instance.textRenderer, invokedynamic(154258552:(Ljava/lang/Object;)Z, (BooleanSetting)invokedynamic(942690208:(Ljava/lang/Object;I)Ljava/lang/Object;, invokedynamic(-172855719:(Ljava/lang/Object;)Ljava/util/List;, invokedynamic(-197516871:(Ljava/lang/Object;)Lcom/sten_region_skidrrr/strafehack/module/Module;, invokedynamic(-497493490:(IJ)Ljava/lang/String;, DrawingUtil.-357647820, DrawingUtil.-683095753))), DrawingUtil.1941029928)) ? -2063794630 : invokedynamic(-733027325:(IJ)Ljava/lang/String;, DrawingUtil.-282013279, DrawingUtil.944286154), 514830642, 975109689, 1640610913)
        // invokedynamic(-2022186752:(Ljava/lang/Object;Ljava/lang/Object;III)I, StrafeHack.instance.fr, invokedynamic(-961837657:(Ljava/lang/Object;)Z, (BooleanSetting)invokedynamic(-1980763679:(Ljava/lang/Object;I)Ljava/lang/Object;, invokedynamic(1590836876:(Ljava/lang/Object;)Ljava/util/List;, invokedynamic(-1476497014:(Ljava/lang/Object;)Lcom/sten_region_skidrrr/strafehack/module/Module;, invokedynamic(-1787946053:(IJ)Ljava/lang/String;, DrawingUtil.-238409303, DrawingUtil.424155548))), DrawingUtil.661633932)) ? invokedynamic(-1460458032:(IJ)Ljava/lang/String;, DrawingUtil.-1644457314, DrawingUtil.1758992657 ^ DrawingUtil.-934497989) : -2063794630, 514830642, 975109689 + DrawingUtil.473194351, 1640610913)
        else {
        }
        // invokedynamic(1175509367:(Ljava/lang/Object;Ljava/lang/Object;FFI)I, StrafeHack.instance.textRenderer, invokedynamic(-219088815:(Ljava/lang/Object;)Z, (BooleanSetting)invokedynamic(-911953115:(Ljava/lang/Object;I)Ljava/lang/Object;, invokedynamic(2061935266:(Ljava/lang/Object;)Ljava/util/List;, invokedynamic(-484499636:(Ljava/lang/Object;)Lcom/sten_region_skidrrr/strafehack/module/Module;, invokedynamic(-4555539:(IJ)Ljava/lang/String;, DrawingUtil.-1126637294, DrawingUtil.-659399806 ^ DrawingUtil.887427810))), DrawingUtil.1587417765)) ? -2063794630 : invokedynamic(-692603718:(IJ)Ljava/lang/String;, DrawingUtil.1747818629, DrawingUtil.487440289), (float)514830642, (float)975109689, 1640610913)
        // invokedynamic(816534857:(Ljava/lang/Object;Ljava/lang/Object;FFI)I, StrafeHack.instance.fr, invokedynamic(-78254508:(Ljava/lang/Object;)Z, (BooleanSetting)invokedynamic(353031873:(Ljava/lang/Object;I)Ljava/lang/Object;, invokedynamic(1531677899:(Ljava/lang/Object;)Ljava/util/List;, invokedynamic(703841931:(Ljava/lang/Object;)Lcom/sten_region_skidrrr/strafehack/module/Module;, invokedynamic(-1517774500:(IJ)Ljava/lang/String;, DrawingUtil.-696258036, DrawingUtil.-2013704985))), DrawingUtil.680306475)) ? invokedynamic(-2099847384:(IJ)Ljava/lang/String;, DrawingUtil.-132000661 & DrawingUtil.-2102736690, DrawingUtil.1928865301) : -2063794630, (float)514830642, (float)975109689 + DrawingUtil.-2052823268, 1640610913)
    }
    
    public static void drawCenteredString(final String 1648327038, final int 1109960049, final int -105929298, final int -523080028) {
        if (!invokedynamic(1580121028:(Ljava/lang/Object;)Z, (BooleanSetting)invokedynamic(-1012411882:(Ljava/lang/Object;I)Ljava/lang/Object;, invokedynamic(855876397:(Ljava/lang/Object;)Ljava/util/List;, invokedynamic(-1313103371:(Ljava/lang/Object;)Lcom/sten_region_skidrrr/strafehack/module/Module;, invokedynamic(-1022071094:(IJ)Ljava/lang/String;, DrawingUtil.-22564903, DrawingUtil.-1652919673 ^ DrawingUtil.1440527043))), DrawingUtil.-1155069146))) {
        }
        // invokedynamic(-2113730385:(Ljava/lang/Object;Ljava/lang/Object;III)V, StrafeHack.instance.textRenderer, invokedynamic(-1662292498:(Ljava/lang/Object;)Z, (BooleanSetting)invokedynamic(-693941872:(Ljava/lang/Object;I)Ljava/lang/Object;, invokedynamic(1792302102:(Ljava/lang/Object;)Ljava/util/List;, invokedynamic(1919772845:(Ljava/lang/Object;)Lcom/sten_region_skidrrr/strafehack/module/Module;, invokedynamic(1529567150:(IJ)Ljava/lang/String;, DrawingUtil.-1693156484, DrawingUtil.211437051))), DrawingUtil.126407558)) ? 1648327038 : invokedynamic(1798561957:(IJ)Ljava/lang/String;, DrawingUtil.-779629622 & DrawingUtil.-2069628878, DrawingUtil.-657162527), 1109960049, -105929298, -523080028)
        // invokedynamic(349860927:(Ljava/lang/Object;Ljava/lang/Object;III)I, StrafeHack.instance.fr, invok...
        else {
        }
        // invokedynamic(1442869269:(Ljava/lang/Object;Ljava/lang/Object;III)V, StrafeHack.instance.textRenderer, invokedynamic(1598723904:(Ljava/lang/Object;)Z, (BooleanSetting)invokedynamic(2128331160:(Ljava/lang/Object;I)Ljava/lang/Object;, invokedynamic(1095305489:(Ljava/lang/Object;)Ljava/util/List;, invokedynamic(-1687419369:(Ljava/lang/Object;)Lcom/sten_region_skidrrr/strafehack/module/Module;, invokedynamic(-1930743160:(IJ)Ljava/lang/String;, DrawingUtil.-1382225580, DrawingUtil.-964238649 ^ DrawingUtil.1215643472))), DrawingUtil.673223365)) ? 1648327038 : invokedynamic(816378439:(IJ)Ljava/lang/String;, DrawingUtil.1748184105 & DrawingUtil.-676688473, DrawingUtil.1246419210), 1109960049, -105929298, -523080028)
        // invokedynamic(1246518097:(Ljava/lang/Object;Ljava/lang/Object;FFIZ)I, StrafeHack.instance.fr, inv...
    }
    
    public static int getStringWidth(final String -1414810301) {
        if (invokedynamic(1811267612:(Ljava/lang/Object;)Z, (BooleanSetting)invokedynamic(150688596:(Ljava/lang/Object;I)Ljava/lang/Object;, invokedynamic(-199972528:(Ljava/lang/Object;)Ljava/util/List;, invokedynamic(883340121:(Ljava/lang/Object;)Lcom/sten_region_skidrrr/strafehack/module/Module;, invokedynamic(1231105220:(IJ)Ljava/lang/String;, DrawingUtil.1043751605, DrawingUtil.119210373 ^ DrawingUtil.-772758476))), DrawingUtil.-184015084))) {
            return invokedynamic(1833973409:(Ljava/lang/Object;Ljava/lang/Object;)I, StrafeHack.instance.textRenderer, -1414810301);
        }
        return invokedynamic(842942346:(Ljava/lang/Object;Ljava/lang/Object;)I, DrawingUtil.mc.field_71466_p, -1414810301);
    }
    
    public static void drawRect(final int -414756736, final int 1700926494, final int 199885956, final int 969034044, final int -110723006, final int 1890606806) {
    }
    // invokedynamic(1804771936:(IIIII)V, -414756736, 1700926494, -414756736 + 199885956, 1700926494 + 969034044, -110723006)
    // invokedynamic(-253758714:(IIII)V, -414756736, -414756736 + 199885956, 1700926494, 1890606806)
    // invokedynamic(787071318:(IIII)V, -414756736, -414756736 + 199885956, 1700926494 + 969034044, 1890606806)
    // invokedynamic(-155202979:(IIII)V, -414756736, 1700926494, 1700926494 + 969034044, 1890606806)
    // invokedynamic(-89713471:(IIII)V, -414756736 + 199885956, 1700926494, 1700926494 + 969034044, 1890606806)
    
    public static void drawHorizontalLine(int 1700017138, int 807387532, final int 1773252413, final int 403462494) {
        if (807387532 < 1700017138) {
            final int n = 1700017138;
            1700017138 = 807387532;
            807387532 = n;
        }
    }
    // invokedynamic(679904777:(IIIII)V, 1700017138, 1773252413, 807387532 + DrawingUtil.478971170, 1773252413 + DrawingUtil.1927629568, 403462494)
    
    public static void drawVerticalLine(final int -1353551789, int 684287896, int -1960563931, final int 783310333) {
        if (-1960563931 < 684287896) {
            final int n = 684287896;
            684287896 = -1960563931;
            -1960563931 = n;
        }
    }
    // invokedynamic(-1715754287:(IIIII)V, -1353551789, 684287896 + DrawingUtil.1844069144, -1353551789 + DrawingUtil.-673578919, -1960563931, 783310333)
    
    public static void drawESP(final AxisAlignedBB -284696432, final float -1953510346, final float -1311015174, final float -231014293, final float -87825149) {
    }
    // invokedynamic(530108566:()V)
    // invokedynamic(1910916941:(I)V, DrawingUtil.2004375985)
    // invokedynamic(1954534282:(II)V, DrawingUtil.-1443786813, DrawingUtil.-1014250876)
    // invokedynamic(-1713970518:(I)V, DrawingUtil.-1588823820)
    // invokedynamic(-29006882:(I)V, DrawingUtil.1687181281)
    // invokedynamic(670813178:(I)V, DrawingUtil.-1377850252)
    // invokedynamic(-1157788517:(Z)V, DrawingUtil.-1455442954)
    // invokedynamic(630528169:(FFFF)V, -1953510346 / DrawingUtil.-237941987, -1311015174 / DrawingUtil.1248466997, -231014293 / DrawingUtil.1812651290, -87825149 / DrawingUtil.-1766408723)
    // invokedynamic(1896782897:(Ljava/lang/Object;)V, -284696432)
    // invokedynamic(-1906843359:(I)V, DrawingUtil.-1615317900)
    // invokedynamic(565683696:(I)V, DrawingUtil.-782778306)
    // invokedynamic(-878461762:(I)V, DrawingUtil.1543048175)
    // invokedynamic(-1799766546:(Z)V, DrawingUtil.25728372)
    // invokedynamic(1784531417:(I)V, DrawingUtil.-1254427241)
    // invokedynamic(-489849859:()V)
    // invokedynamic(-294629266:(FFFF)V, 1.0f, 1.0f, 1.0f, 1.0f)
    
    public static void drawBox(final AxisAlignedBB 1508240227) {
        if (1508240227 == null) {
            return;
        }
    }
    // invokedynamic(1452806848:(I)V, DrawingUtil.871369973)
    // invokedynamic(-210861312:(FFF)V, (float)1508240227.field_72340_a, (float)1508240227.field_72338_b, (float)1508240227.field_72334_f)
    // invokedynamic(-104468098:(FFF)V, (float)1508240227.field_72336_d, (float)1508240227.field_72338_b, (float)1508240227.field_72334_f)
    // invokedynamic(1621038078:(FFF)V, (float)1508240227.field_72336_d, (float)1508240227.field_72337_e, (float)1508240227.field_72334_f)
    // invokedynamic(-2083480464:(FFF)V, (float)1508240227.field_72340_a, (float)1508240227.field_72337_e, (float)1508240227.field_72334_f)
    // invokedynamic(-2119565163:()V)
    // invokedynamic(455329457:(I)V, DrawingUtil.901818763)
    // invokedynamic(-1859437741:(FFF)V, (float)1508240227.field_72336_d, (float)1508240227.field_72338_b, (float)1508240227.field_72334_f)
    // invokedynamic(-1545961483:(FFF)V, (float)1508240227.field_72340_a, (float)1508240227.field_72338_b, (float)1508240227.field_72334_f)
    // invokedynamic(1249797076:(FFF)V, (float)1508240227.field_72340_a, (float)1508240227.field_72337_e, (float)1508240227.field_72334_f)
    // invokedynamic(1076559259:(FFF)V, (float)1508240227.field_72336_d, (float)1508240227.field_72337_e, (float)1508240227.field_72334_f)
    // invokedynamic(673631626:()V)
    // invokedynamic(473984091:(I)V, DrawingUtil.563599895)
    // invokedynamic(-1277182110:(FFF)V, (float)1508240227.field_72340_a, (float)1508240227.field_72338_b, (float)1508240227.field_72339_c)
    // invokedynamic(888810019:(FFF)V, (float)1508240227.field_72340_a, (float)1508240227.field_72338_b, (float)1508240227.field_72334_f)
    // invokedynamic(-2133805950:(FFF)V, (float)1508240227.field_72340_a, (float)1508240227.field_72337_e, (float)1508240227.field_72334_f)
    // invokedynamic(2135220741:(FFF)V, (float)1508240227.field_72340_a, (float)1508240227.field_72337_e, (float)1508240227.field_72339_c)
    // invokedynamic(-1949863714:()V)
    // invokedynamic(-36189242:(I)V, DrawingUtil.-518529994)
    // invokedynamic(1180701892:(FFF)V, (float)1508240227.field_72340_a, (float)1508240227.field_72338_b, (float)1508240227.field_72334_f)
    // invokedynamic(240233571:(FFF)V, (float)1508240227.field_72340_a, (float)1508240227.field_72338_b, (float)1508240227.field_72339_c)
    // invokedynamic(-280124266:(FFF)V, (float)1508240227.field_72340_a, (float)1508240227.field_72337_e, (float)1508240227.field_72339_c)
    // invokedynamic(-1889930496:(FFF)V, (float)1508240227.field_72340_a, (float)1508240227.field_72337_e, (float)1508240227.field_72334_f)
    // invokedynamic(679086930:()V)
    // invokedynamic(2055875387:(I)V, DrawingUtil.1766111249)
    // invokedynamic(1620260006:(FFF)V, (float)1508240227.field_72336_d, (float)1508240227.field_72338_b, (float)1508240227.field_72334_f)
    // invokedynamic(-1283060760:(FFF)V, (float)1508240227.field_72336_d, (float)1508240227.field_72338_b, (float)1508240227.field_72339_c)
    // invokedynamic(1335888468:(FFF)V, (float)1508240227.field_72336_d, (float)1508240227.field_72337_e, (float)1508240227.field_72339_c)
    // invokedynamic(-1592153267:(FFF)V, (float)1508240227.field_72336_d, (float)1508240227.field_72337_e, (float)1508240227.field_72334_f)
    // invokedynamic(1772193977:()V)
    // invokedynamic(-157639853:(I)V, DrawingUtil.-1152268424)
    // invokedynamic(998656278:(FFF)V, (float)1508240227.field_72336_d, (float)1508240227.field_72338_b, (float)1508240227.field_72339_c)
    // invokedynamic(1709690750:(FFF)V, (float)1508240227.field_72336_d, (float)1508240227.field_72338_b, (float)1508240227.field_72334_f)
    // invokedynamic(2018303713:(FFF)V, (float)1508240227.field_72336_d, (float)1508240227.field_72337_e, (float)1508240227.field_72334_f)
    // invokedynamic(-261754895:(FFF)V, (float)1508240227.field_72336_d, (float)1508240227.field_72337_e, (float)1508240227.field_72339_c)
    // invokedynamic(1013631890:()V)
    // invokedynamic(-1942380336:(I)V, DrawingUtil.-1404517900)
    // invokedynamic(726352671:(FFF)V, (float)1508240227.field_72340_a, (float)1508240227.field_72338_b, (float)1508240227.field_72339_c)
    // invokedynamic(-1839923840:(FFF)V, (float)1508240227.field_72336_d, (float)1508240227.field_72338_b, (float)1508240227.field_72339_c)
    // invokedynamic(-1583685395:(FFF)V, (float)1508240227.field_72336_d, (float)1508240227.field_72337_e, (float)1508240227.field_72339_c)
    // invokedynamic(1302680347:(FFF)V, (float)1508240227.field_72340_a, (float)1508240227.field_72337_e, (float)1508240227.field_72339_c)
    // invokedynamic(893746376:()V)
    // invokedynamic(-939512036:(I)V, DrawingUtil.-1628014924)
    // invokedynamic(743074965:(FFF)V, (float)1508240227.field_72336_d, (float)1508240227.field_72338_b, (float)1508240227.field_72339_c)
    // invokedynamic(1814480565:(FFF)V, (float)1508240227.field_72340_a, (float)1508240227.field_72338_b, (float)1508240227.field_72339_c)
    // invokedynamic(-685754622:(FFF)V, (float)1508240227.field_72340_a, (float)1508240227.field_72337_e, (float)1508240227.field_72339_c)
    // invokedynamic(933307655:(FFF)V, (float)1508240227.field_72336_d, (float)1508240227.field_72337_e, (float)1508240227.field_72339_c)
    // invokedynamic(-724952821:()V)
    // invokedynamic(-633702202:(I)V, DrawingUtil.-1976973126)
    // invokedynamic(1875301957:(FFF)V, (float)1508240227.field_72340_a, (float)1508240227.field_72337_e, (float)1508240227.field_72339_c)
    // invokedynamic(423386301:(FFF)V, (float)1508240227.field_72336_d, (float)1508240227.field_72337_e, (float)1508240227.field_72339_c)
    // invokedynamic(-1857797616:(FFF)V, (float)1508240227.field_72336_d, (float)1508240227.field_72337_e, (float)1508240227.field_72334_f)
    // invokedynamic(-142147489:(FFF)V, (float)1508240227.field_72340_a, (float)1508240227.field_72337_e, (float)1508240227.field_72334_f)
    // invokedynamic(-183212320:()V)
    // invokedynamic(-1870480149:(I)V, DrawingUtil.842683983)
    // invokedynamic(-86735865:(FFF)V, (float)1508240227.field_72336_d, (float)1508240227.field_72337_e, (float)1508240227.field_72339_c)
    // invokedynamic(-945453266:(FFF)V, (float)1508240227.field_72340_a, (float)1508240227.field_72337_e, (float)1508240227.field_72339_c)
    // invokedynamic(-1954749075:(FFF)V, (float)1508240227.field_72340_a, (float)1508240227.field_72337_e, (float)1508240227.field_72334_f)
    // invokedynamic(-683040696:(FFF)V, (float)1508240227.field_72336_d, (float)1508240227.field_72337_e, (float)1508240227.field_72334_f)
    // invokedynamic(-1314306013:()V)
    // invokedynamic(938066041:(I)V, DrawingUtil.2085737722)
    // invokedynamic(-1716090478:(FFF)V, (float)1508240227.field_72340_a, (float)1508240227.field_72338_b, (float)1508240227.field_72339_c)
    // invokedynamic(495305430:(FFF)V, (float)1508240227.field_72336_d, (float)1508240227.field_72338_b, (float)1508240227.field_72339_c)
    // invokedynamic(1740427826:(FFF)V, (float)1508240227.field_72336_d, (float)1508240227.field_72338_b, (float)1508240227.field_72334_f)
    // invokedynamic(-458391986:(FFF)V, (float)1508240227.field_72340_a, (float)1508240227.field_72338_b, (float)1508240227.field_72334_f)
    // invokedynamic(-2081369531:()V)
    // invokedynamic(-1651192102:(I)V, DrawingUtil.-1810645489)
    // invokedynamic(1477968183:(FFF)V, (float)1508240227.field_72336_d, (float)1508240227.field_72338_b, (float)1508240227.field_72339_c)
    // invokedynamic(548702973:(FFF)V, (float)1508240227.field_72340_a, (float)1508240227.field_72338_b, (float)1508240227.field_72339_c)
    // invokedynamic(2098358807:(FFF)V, (float)1508240227.field_72340_a, (float)1508240227.field_72338_b, (float)1508240227.field_72334_f)
    // invokedynamic(1416058443:(FFF)V, (float)1508240227.field_72336_d, (float)1508240227.field_72338_b, (float)1508240227.field_72334_f)
    // invokedynamic(-1084575501:()V)
    
    static {
        DrawingUtil.-461383173 = -1745292680;
        DrawingUtil.1190943289 = 184;
        DrawingUtil.146530896 = (0 >>> 49 | 0 << -49);
        DrawingUtil.1735874847 = (-1 >>> 3 | -1 << ~0x3 + 1);
        DrawingUtil.232223846 = invokedynamic(-207927336:(J)J, 732432049895463063L);
        DrawingUtil.112829851 = ((32768 >>> 14 | 32768 << -14) & -1);
        DrawingUtil.-357647820 = (268435456 >>> 188 | 268435456 << ~0xBC + 1);
        DrawingUtil.-683095753 = invokedynamic(-1998788813:(J)J, 732432049895463063L);
        DrawingUtil.1941029928 = invokedynamic(1734294989:(I)I, Integer.MIN_VALUE);
        DrawingUtil.-282013279 = invokedynamic(1927161135:(I)I, 1073741824);
        DrawingUtil.944286154 = invokedynamic(-138247392:(J)J, 732432049895463063L);
        DrawingUtil.-238409303 = invokedynamic(-1189974722:(I)I, -1073741824);
        DrawingUtil.424155548 = invokedynamic(-930192602:(J)J, 732432049895463063L);
        DrawingUtil.661633932 = invokedynamic(220033888:(I)I, Integer.MIN_VALUE);
        DrawingUtil.-1644457314 = invokedynamic(662271150:(I)I, 536870912);
        DrawingUtil.1758992657 = invokedynamic(481336096:(J)J, 1453007990274742423L);
        DrawingUtil.-934497989 = invokedynamic(1428515338:(J)J, 2161727821137838080L);
        DrawingUtil.473194351 = invokedynamic(-231154723:(I)I, -1073741824);
        DrawingUtil.-1126637294 = invokedynamic(65863064:(I)I, -1610612736);
        DrawingUtil.-659399806 = invokedynamic(2021641470:(J)J, 1453007990274742423L);
        DrawingUtil.887427810 = invokedynamic(441743967:(J)J, 2161727821137838080L);
        DrawingUtil.1587417765 = (67108864 >>> 186 | 67108864 << -186);
        DrawingUtil.1747818629 = invokedynamic(-1347957190:(I)I, 1610612736);
        DrawingUtil.487440289 = invokedynamic(1439173196:(J)J, 732432049895463063L);
        DrawingUtil.-696258036 = invokedynamic(-1254675989:(I)I, -536870912);
        DrawingUtil.-2013704985 = invokedynamic(-935043915:(J)J, 732432049895463063L);
        DrawingUtil.680306475 = invokedynamic(-37578393:(I)I, Integer.MIN_VALUE);
        DrawingUtil.-132000661 = (2 >>> 126 | 2 << ~0x7E + 1);
        DrawingUtil.-2102736690 = ((-1 >>> 195 | -1 << ~0xC3 + 1) & -1);
        DrawingUtil.1928865301 = invokedynamic(612903822:(J)J, 732432049895463063L);
        DrawingUtil.-2052823268 = invokedynamic(-776333549:(I)I, -1073741824);
        DrawingUtil.-22564903 = invokedynamic(1679036937:(I)I, -1879048192);
        DrawingUtil.-1652919673 = invokedynamic(-421271790:(J)J, 1453007990274742423L);
        DrawingUtil.1440527043 = invokedynamic(953616800:(J)J, 2161727821137838080L);
        DrawingUtil.-1155069146 = ((32768 >>> 206 | 32768 << -206) & -1);
        DrawingUtil.-1693156484 = invokedynamic(-489754422:(I)I, 1342177280);
        DrawingUtil.211437051 = invokedynamic(1997966909:(J)J, 732432049895463063L);
        DrawingUtil.126407558 = invokedynamic(-349044714:(I)I, Integer.MIN_VALUE);
        DrawingUtil.-779629622 = ((46137344 >>> 214 | 46137344 << -214) & -1);
        DrawingUtil.-2069628878 = invokedynamic(1121927454:(I)I, -1);
        DrawingUtil.-657162527 = invokedynamic(-1903004127:(J)J, 732432049895463063L);
        DrawingUtil.-1002772835 = ((-2147483647 >>> 253 | -2147483647 << -253) & -1);
        DrawingUtil.1057564331 = invokedynamic(408879599:(J)J, 1453007990274742423L);
        DrawingUtil.-2030437308 = invokedynamic(287965692:(J)J, 2161727821137838080L);
        DrawingUtil.-401232914 = ((65536 >>> 16 | 65536 << ~0x10 + 1) & -1);
        DrawingUtil.1202675339 = ((208 >>> 100 | 208 << -100) & -1);
        DrawingUtil.-1877613435 = invokedynamic(637289361:(J)J, 1453007990274742423L);
        DrawingUtil.511413632 = invokedynamic(1861683099:(J)J, 2161727821137838080L);
        DrawingUtil.-1382281226 = (4194304 >>> 22 | 4194304 << ~0x16 + 1);
        DrawingUtil.1671962258 = (-1073741823 >>> 29 | -1073741823 << ~0x1D + 1);
        DrawingUtil.81582253 = invokedynamic(165414375:(J)J, 1453007990274742423L);
        DrawingUtil.-1202766905 = invokedynamic(1496097409:(J)J, 2161727821137838080L);
        DrawingUtil.1288651581 = invokedynamic(-848699614:(I)I, Integer.MIN_VALUE);
        DrawingUtil.1694583438 = invokedynamic(-187818730:(I)I, -268435456);
        DrawingUtil.1067533280 = invokedynamic(948365914:(J)J, 1453007990274742423L);
        DrawingUtil.-768917537 = invokedynamic(-1311721456:(J)J, 2161727821137838080L);
        DrawingUtil.-240011281 = invokedynamic(-96243095:(I)I, 1073741824);
        DrawingUtil.-380932080 = ((536870912 >>> 220 | 536870912 << -220) & -1);
        DrawingUtil.-1382225580 = (262144 >>> 78 | 262144 << -78);
        DrawingUtil.-964238649 = invokedynamic(53213025:(J)J, 1453007990274742423L);
        DrawingUtil.1215643472 = invokedynamic(-161462818:(J)J, 2161727821137838080L);
        DrawingUtil.673223365 = ((536870912 >>> 125 | 536870912 << ~0x7D + 1) & -1);
        DrawingUtil.1748184105 = ((8912896 >>> 19 | 8912896 << -19) & -1);
        DrawingUtil.-676688473 = invokedynamic(1822558574:(I)I, -1);
        DrawingUtil.1246419210 = invokedynamic(-958630547:(J)J, 732432049895463063L);
        DrawingUtil.-573953166 = invokedynamic(-984188460:(I)I, 1207959552);
        DrawingUtil.-2119320964 = (-1 >>> 181 | -1 << ~0xB5 + 1);
        DrawingUtil.1312488821 = invokedynamic(-793347156:(J)J, 732432049895463063L);
        DrawingUtil.-210167250 = invokedynamic(363736677:(I)I, Integer.MIN_VALUE);
        DrawingUtil.1404153035 = (1245184 >>> 176 | 1245184 << ~0xB0 + 1);
        DrawingUtil.1148958525 = invokedynamic(381942747:(J)J, 732432049895463063L);
        DrawingUtil.656202599 = invokedynamic(-44919145:(I)I, Integer.MIN_VALUE);
        DrawingUtil.-517897021 = (81920 >>> 172 | 81920 << -172);
        DrawingUtil.-2057604607 = invokedynamic(-1618441391:(J)J, 732432049895463063L);
        DrawingUtil.2135639413 = invokedynamic(1961392747:(I)I, Integer.MIN_VALUE);
        DrawingUtil.1637620522 = invokedynamic(86372925:(I)I, -1476395008);
        DrawingUtil.783390311 = invokedynamic(-2087225452:(J)J, 1453007990274742423L);
        DrawingUtil.-963489516 = invokedynamic(1062730882:(J)J, 2161727821137838080L);
        DrawingUtil.1915329184 = invokedynamic(247680050:(I)I, 1073741824);
        DrawingUtil.-7874506 = invokedynamic(-1127696351:(I)I, 1073741824);
        DrawingUtil.-1477133308 = invokedynamic(1654851188:(I)I, Integer.MIN_VALUE);
        DrawingUtil.1043751605 = (46137344 >>> 85 | 46137344 << -85);
        DrawingUtil.119210373 = invokedynamic(-530375494:(J)J, 1453007990274742423L);
        DrawingUtil.-772758476 = invokedynamic(1541483245:(J)J, 2161727821137838080L);
        DrawingUtil.-184015084 = invokedynamic(1985896149:(I)I, Integer.MIN_VALUE);
        DrawingUtil.478971170 = invokedynamic(-647120960:(I)I, Integer.MIN_VALUE);
        DrawingUtil.1927629568 = ((131072 >>> 177 | 131072 << ~0xB1 + 1) & -1);
        DrawingUtil.1844069144 = invokedynamic(-160472555:(I)I, Integer.MIN_VALUE);
        DrawingUtil.-673578919 = invokedynamic(-1207986786:(I)I, Integer.MIN_VALUE);
        DrawingUtil.2004375985 = (1073742204 >>> 125 | 1073742204 << ~0x7D + 1);
        DrawingUtil.-1443786813 = invokedynamic(1439975525:(I)I, 1086324736);
        DrawingUtil.-1014250876 = invokedynamic(-1263861989:(I)I, -1061158912);
        DrawingUtil.-1588823820 = (56848 >>> 164 | 56848 << -164);
        DrawingUtil.1687181281 = ((356 >>> 29 | 356 << ~0x1D + 1) & -1);
        DrawingUtil.-1377850252 = ((11716 >>> 130 | 11716 << ~0x82 + 1) & -1);
        DrawingUtil.-1455442954 = invokedynamic(1910152520:(I)I, false);
        DrawingUtil.-237941987 = invokedynamic(-719212881:(I)F, 17279 >>> 144 | 17279 << -144);
        DrawingUtil.1248466997 = invokedynamic(1785422546:(I)F, (283099136 >>> 158 | 283099136 << ~0x9E + 1) & -1);
        DrawingUtil.1812651290 = invokedynamic(-478771746:(I)F, invokedynamic(-1280510218:(I)I, 65218));
        DrawingUtil.-1766408723 = invokedynamic(-795864354:(I)F, (17279 >>> 144 | 17279 << ~0x90 + 1) & -1);
        DrawingUtil.-1615317900 = (1073741846 >>> 57 | 1073741846 << ~0x39 + 1);
        DrawingUtil.-782778306 = ((2017460227 >>> 86 | 2017460227 << -86) & -1);
        DrawingUtil.1543048175 = ((749824 >>> 104 | 749824 << ~0x68 + 1) & -1);
        DrawingUtil.25728372 = invokedynamic(1706645484:(I)I, Integer.MIN_VALUE);
        DrawingUtil.-1254427241 = (12460032 >>> 44 | 12460032 << ~0x2C + 1);
        DrawingUtil.871369973 = invokedynamic(1100826799:(I)I, -536870912);
        DrawingUtil.901818763 = invokedynamic(739057687:(I)I, -536870912);
        DrawingUtil.563599895 = (28 >>> 194 | 28 << ~0xC2 + 1);
        DrawingUtil.-518529994 = ((114688 >>> 174 | 114688 << ~0xAE + 1) & -1);
        DrawingUtil.1766111249 = invokedynamic(1666626372:(I)I, -536870912);
        DrawingUtil.-1152268424 = invokedynamic(554464351:(I)I, -536870912);
        DrawingUtil.-1404517900 = ((1835008 >>> 210 | 1835008 << -210) & -1);
        DrawingUtil.-1628014924 = ((14680064 >>> 21 | 14680064 << ~0x15 + 1) & -1);
        DrawingUtil.-1976973126 = (14336 >>> 203 | 14336 << ~0xCB + 1);
        DrawingUtil.842683983 = (14 >>> 161 | 14 << -161);
        DrawingUtil.2085737722 = invokedynamic(-246010108:(I)I, -536870912);
        DrawingUtil.-1810645489 = invokedynamic(-1688455519:(I)I, -536870912);
        DrawingUtil.-1249648508 = invokedynamic(74549607:(I)I, -402653184);
        DrawingUtil.2016322942 = invokedynamic(610796577:(I)I, -402653184);
        DrawingUtil.-325370648 = new String[DrawingUtil.-1249648508];
        DrawingUtil.901208665 = new String[DrawingUtil.2016322942];
        // invokedynamic(1300094870:()V)
        DrawingUtil.mc = invokedynamic(-1198264900:()Lnet/minecraft/client/Minecraft;);
    }
    
    private static Object -483515692(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(DrawingUtil.class, "1519580685", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", DrawingUtil.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/utils/DrawingUtil:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String 1519580685(final int n, long n2) {
        n2 ^= 0x78L;
        n2 ^= 0x23B2146327E54A08L;
        if (DrawingUtil.-325370648[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/utils/DrawingUtil");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            DrawingUtil.-325370648[n] = new String(instance.doFinal(Base64.getDecoder().decode(DrawingUtil.901208665[n])));
        }
        return DrawingUtil.-325370648[n];
    }
    
    private static void 1153815424() {
        DrawingUtil.1416162074 = -1649860930831887320L;
        final long n = DrawingUtil.1416162074 ^ 0x23B2146327E54A08L;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    DrawingUtil.901208665[0] = "CntBp6ruKds=";
                    DrawingUtil.901208665[1] = "CntBp6ruKds=";
                    DrawingUtil.901208665[2] = "AovXIgmOChY=";
                    DrawingUtil.901208665[3] = "CntBp6ruKds=";
                    DrawingUtil.901208665[4] = "AovXIgmOChY=";
                    DrawingUtil.901208665[5] = "CntBp6ruKds=";
                    DrawingUtil.901208665[6] = "AovXIgmOChY=";
                    DrawingUtil.901208665[7] = "CntBp6ruKds=";
                    DrawingUtil.901208665[8] = "AovXIgmOChY=";
                    DrawingUtil.901208665[9] = "CntBp6ruKds=";
                    DrawingUtil.901208665[10] = "CntBp6ruKds=";
                    DrawingUtil.901208665[11] = "AovXIgmOChY=";
                    DrawingUtil.901208665[12] = "CntBp6ruKds=";
                    DrawingUtil.901208665[13] = "AovXIgmOChY=";
                    DrawingUtil.901208665[14] = "CntBp6ruKds=";
                    DrawingUtil.901208665[15] = "AovXIgmOChY=";
                    DrawingUtil.901208665[16] = "CntBp6ruKds=";
                    DrawingUtil.901208665[17] = "AovXIgmOChY=";
                    DrawingUtil.901208665[18] = "CntBp6ruKds=";
                    DrawingUtil.901208665[19] = "AovXIgmOChY=";
                    DrawingUtil.901208665[20] = "CntBp6ruKds=";
                    DrawingUtil.901208665[21] = "AovXIgmOChY=";
                    DrawingUtil.901208665[22] = "CntBp6ruKds=";
                    break;
                }
                case 1: {
                    DrawingUtil.901208665[0] = "iZYfsX7zYEs=";
                    DrawingUtil.901208665[1] = "AEZhJEAdqMI=";
                    DrawingUtil.901208665[2] = "aLQqfCTtBzs=";
                    DrawingUtil.901208665[3] = "Sei2WdWp78c=";
                    DrawingUtil.901208665[4] = "8fkU8qukDlU=";
                    DrawingUtil.901208665[5] = "9g7rprFbrJw=";
                    DrawingUtil.901208665[6] = "FMuHeiqhbtg=";
                    DrawingUtil.901208665[7] = "Cz2m7Px4HxI=";
                    DrawingUtil.901208665[8] = "YFDzN2HGHZs=";
                    DrawingUtil.901208665[9] = "otkVpqsRFPw=";
                    DrawingUtil.901208665[10] = "cYDgP0c/9/I=";
                    DrawingUtil.901208665[11] = "r74rKLslf9A=";
                    DrawingUtil.901208665[12] = "ZDemIuCGf+k=";
                    DrawingUtil.901208665[13] = "XRc38fvrz4M=";
                    DrawingUtil.901208665[14] = "4BffDsbZOn8=";
                    DrawingUtil.901208665[15] = "d58PlVHItp0=";
                    DrawingUtil.901208665[16] = "+8il1bpOsFA=";
                    DrawingUtil.901208665[17] = "nQKaO35/mRA=";
                    DrawingUtil.901208665[18] = "BzCDlRtJ19M=";
                    DrawingUtil.901208665[19] = "eY+peBjVK6c=";
                    DrawingUtil.901208665[20] = "5bi/oQpaASA=";
                    DrawingUtil.901208665[21] = "NnsbkAi1mwE=";
                    DrawingUtil.901208665[22] = "z/1Wg45I7lA=";
                    break;
                }
                case 2: {
                    DrawingUtil.901208665[0] = "p0vwbjPrDZY=";
                    break;
                }
                case 4: {
                    DrawingUtil.901208665[0] = "bfTo2PUvhF0=";
                    break;
                }
            }
        }
    }
    
    public static Object -161823807(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7, final Object o8) throws Exception {
        final int n = ((int)o ^ DrawingUtil.-461383173) & 0xFF;
        final Integer value = DrawingUtil.1190943289;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

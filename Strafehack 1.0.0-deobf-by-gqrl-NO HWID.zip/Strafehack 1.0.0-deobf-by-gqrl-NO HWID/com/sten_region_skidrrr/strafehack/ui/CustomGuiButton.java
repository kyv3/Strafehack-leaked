// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.ui;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import net.minecraft.init.SoundEvents;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.client.gui.Gui;

@SideOnly(Side.CLIENT)
public class CustomGuiButton extends Gui
{
    protected static final ResourceLocation BUTTON_TEXTURES;
    public int width;
    public int height;
    public int x;
    public int y;
    public String displayString;
    public int id;
    public boolean enabled;
    public boolean visible;
    protected boolean hovered;
    public int packedFGColour;
    private static String[] 394710321;
    private static String[] -1251174549;
    private static long -1113113649;
    private static int 1301008097;
    private static int 728006428;
    private static int -74013082;
    private static int -1132002806;
    private static int -411361302;
    private static int -1169916309;
    private static int 781557307;
    private static int 1508874744;
    private static int -849605547;
    private static int -1220535023;
    private static int 898600668;
    private static int 1260205164;
    private static int -1198346047;
    private static int 386774585;
    private static int 719715557;
    private static int 1206417882;
    private static int 873268257;
    private static int 1532795293;
    private static int 652055246;
    private static int 896935157;
    private static int 1141145245;
    private static int -176047881;
    private static int -1300505700;
    private static int -430158866;
    private static int 350461266;
    private static int -1028664172;
    private static int -1250458975;
    private static int -1543339516;
    private static int -959056159;
    private static int -174812173;
    private static int 51836009;
    private static int 2103669228;
    private static long 997688278;
    private static int 1674735088;
    private static int 1735261054;
    
    public CustomGuiButton(final int 1511347192, final int 1444171165, final int -887759198, final String 1185769179) {
        this(1511347192, 1444171165, -887759198, CustomGuiButton.1301008097, CustomGuiButton.728006428, 1185769179);
    }
    
    public CustomGuiButton(final int 25473434, final int 535251639, final int 274506660, final int -211323401, final int -353887473, final String 1912570021) {
        this.width = CustomGuiButton.-74013082;
        this.height = CustomGuiButton.-1132002806;
        this.enabled = (CustomGuiButton.-411361302 != 0);
        this.visible = (CustomGuiButton.-1169916309 != 0);
        this.id = 25473434;
        this.x = 535251639;
        this.y = 274506660;
        this.width = -211323401;
        this.height = -353887473;
        this.displayString = 1912570021;
    }
    
    protected int getHoverState(final boolean -2137377932) {
        int n = CustomGuiButton.781557307;
        if (!this.enabled) {
            n = CustomGuiButton.1508874744;
        }
        else if (-2137377932) {
            n = CustomGuiButton.-849605547;
        }
        return n;
    }
    
    public void drawButton(final Minecraft 2077837563, final int 1002431027, final int 1915488559, final float 776605874) {
        if (this.visible) {
            final FontRenderer 2077837564 = 2077837563.field_71466_p;
            // invokedynamic(-638834551:(Ljava/lang/Object;Ljava/lang/Object;)V, invokedynamic(-72525160:(Ljava/lang/Object;)Lnet/minecraft/client/renderer/texture/TextureManager;, 2077837563), CustomGuiButton.BUTTON_TEXTURES)
            // invokedynamic(641505631:(FFFF)V, 1.0f, 1.0f, 1.0f, 1.0f)
            this.hovered = (((1002431027 >= this.x && 1915488559 >= this.y && 1002431027 < this.x + this.width && 1915488559 < this.y + this.height) ? CustomGuiButton.-1220535023 : CustomGuiButton.898600668) != 0);
            final int 2077837565 = invokedynamic(-1747647019:(Ljava/lang/Object;Z)I, this, this.hovered);
            // invokedynamic(-1800431049:()V)
            // invokedynamic(-1981175923:(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V, GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO)
            // invokedynamic(-747151028:(Ljava/lang/Object;Ljava/lang/Object;)V, GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA)
            // invokedynamic(-1435721783:(Ljava/lang/Object;IIIIII)V, this, this.x, this.y, CustomGuiButton.1260205164, CustomGuiButton.-1198346047 + 2077837565 * CustomGuiButton.386774585, this.width / CustomGuiButton.719715557, this.height)
            // invokedynamic(632138939:(Ljava/lang/Object;IIIIII)V, this, this.x + this.width / CustomGuiButton.1206417882, this.y, CustomGuiButton.873268257 - this.width / CustomGuiButton.1532795293, CustomGuiButton.652055246 + 2077837565 * CustomGuiButton.896935157, this.width / CustomGuiButton.1141145245, this.height)
            // invokedynamic(-622664658:(Ljava/lang/Object;Ljava/lang/Object;II)V, this, 2077837563, 1002431027, 1915488559)
            int 2077837566 = CustomGuiButton.-176047881;
            if (this.packedFGColour != 0) {
                2077837566 = this.packedFGColour;
            }
            else if (!this.enabled) {
                2077837566 = CustomGuiButton.-1300505700;
            }
            else if (this.hovered) {
                2077837566 = CustomGuiButton.-430158866;
            }
        }
        // invokedynamic(-1943653986:(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;III)V, this, 2077837564, this.displayString, this.x + this.width / CustomGuiButton.350461266, this.y + this.height - CustomGuiButton.-1028664172 / CustomGuiButton.-1250458975, 2077837566)
    }
    
    protected void mouseDragged(final Minecraft 174093052, final int -1531254900, final int 276151629) {
    }
    
    public void mouseReleased(final int 1502291894, final int 372501632) {
    }
    
    public boolean mousePressed(final Minecraft 539424442, final int -1744439766, final int -2127655706) {
        return ((this.enabled && this.visible && -1744439766 >= this.x && -2127655706 >= this.y && -1744439766 < this.x + this.width && -2127655706 < this.y + this.height) ? CustomGuiButton.-1543339516 : CustomGuiButton.-959056159) != 0;
    }
    
    public boolean isMouseOver() {
        return this.hovered;
    }
    
    public void drawButtonForegroundLayer(final int 1843447647, final int 1095296348) {
    }
    
    public void playPressSound(final SoundHandler -1007302852) {
    }
    // invokedynamic(1266520051:(Ljava/lang/Object;Ljava/lang/Object;)V, -1007302852, invokedynamic(-146887772:(Ljava/lang/Object;F)Lnet/minecraft/client/audio/PositionedSoundRecord;, SoundEvents.field_187909_gi, 1.0f))
    
    public int getButtonWidth() {
        return this.width;
    }
    
    public void setWidth(final int 1092886598) {
        this.width = 1092886598;
    }
    
    static {
        CustomGuiButton.1674735088 = 52778841;
        CustomGuiButton.1735261054 = 184;
        CustomGuiButton.1301008097 = (-1879048191 >>> 25 | -1879048191 << -25);
        CustomGuiButton.728006428 = ((40 >>> 97 | 40 << -97) & -1);
        CustomGuiButton.-74013082 = invokedynamic(-1065697275:(I)I, 318767104);
        CustomGuiButton.-1132002806 = invokedynamic(-1038641306:(I)I, 671088640);
        CustomGuiButton.-411361302 = invokedynamic(-1408030687:(I)I, Integer.MIN_VALUE);
        CustomGuiButton.-1169916309 = (262144 >>> 114 | 262144 << -114);
        CustomGuiButton.781557307 = ((1073741824 >>> 126 | 1073741824 << -126) & -1);
        CustomGuiButton.1508874744 = invokedynamic(1281199020:(I)I, false);
        CustomGuiButton.-849605547 = (256 >>> 71 | 256 << ~0x47 + 1);
        CustomGuiButton.-1220535023 = (16384 >>> 78 | 16384 << -78);
        CustomGuiButton.898600668 = ((0 >>> 156 | 0 << -156) & -1);
        CustomGuiButton.1260205164 = ((0 >>> 3 | 0 << -3) & -1);
        CustomGuiButton.-1198346047 = (385875968 >>> 247 | 385875968 << -247);
        CustomGuiButton.386774585 = ((10240 >>> 201 | 10240 << -201) & -1);
        CustomGuiButton.719715557 = ((16384 >>> 205 | 16384 << -205) & -1);
        CustomGuiButton.1206417882 = ((2 >>> 96 | 2 << ~0x60 + 1) & -1);
        CustomGuiButton.873268257 = ((6553600 >>> 79 | 6553600 << ~0x4F + 1) & -1);
        CustomGuiButton.1532795293 = ((268435456 >>> 91 | 268435456 << -91) & -1);
        CustomGuiButton.652055246 = ((1507328 >>> 79 | 1507328 << -79) & -1);
        CustomGuiButton.896935157 = invokedynamic(-523229684:(I)I, 671088640);
        CustomGuiButton.1141145245 = invokedynamic(-1848437579:(I)I, 1073741824);
        CustomGuiButton.-176047881 = invokedynamic(1096436355:(I)I, 117901056);
        CustomGuiButton.-1300505700 = invokedynamic(-1414890440:(I)I, 84215040);
        CustomGuiButton.-430158866 = invokedynamic(-619430988:(I)I, 100663040);
        CustomGuiButton.350461266 = ((268435456 >>> 27 | 268435456 << -27) & -1);
        CustomGuiButton.-1028664172 = invokedynamic(456062966:(I)I, 268435456);
        CustomGuiButton.-1250458975 = invokedynamic(-1936920334:(I)I, 1073741824);
        CustomGuiButton.-1543339516 = invokedynamic(-1934054652:(I)I, Integer.MIN_VALUE);
        CustomGuiButton.-959056159 = invokedynamic(-1909684809:(I)I, false);
        CustomGuiButton.-174812173 = (8 >>> 195 | 8 << ~0xC3 + 1);
        CustomGuiButton.51836009 = (1024 >>> 234 | 1024 << -234);
        CustomGuiButton.2103669228 = invokedynamic(-1614702672:(I)I, false);
        CustomGuiButton.997688278 = invokedynamic(424666050:(J)J, 3173554387082783541L);
        CustomGuiButton.394710321 = new String[CustomGuiButton.-174812173];
        CustomGuiButton.-1251174549 = new String[CustomGuiButton.51836009];
        // invokedynamic(159074963:()V)
        BUTTON_TEXTURES = new ResourceLocation(invokedynamic(872515719:(IJ)Ljava/lang/String;, CustomGuiButton.2103669228, CustomGuiButton.997688278));
    }
    
    private static Object -2057615955(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(CustomGuiButton.class, "-1072248200", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", CustomGuiButton.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/ui/CustomGuiButton:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String -1072248200(final int n, long n2) {
        n2 ^= 0x4FL;
        n2 ^= 0x919F392B0BCBD77AL;
        if (CustomGuiButton.394710321[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/ui/CustomGuiButton");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            CustomGuiButton.394710321[n] = new String(instance.doFinal(Base64.getDecoder().decode(CustomGuiButton.-1251174549[n])));
        }
        return CustomGuiButton.394710321[n];
    }
    
    private static void 1658025288() {
        CustomGuiButton.-1113113649 = -5992656433448136581L;
        final long n = CustomGuiButton.-1113113649 ^ 0x919F392B0BCBD77AL;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    CustomGuiButton.-1251174549[0] = "P/JYS7PumIoFqRV6AtkkfPmczLGrGbS3U6x4d+xdqdM=";
                    break;
                }
                case 1: {
                    CustomGuiButton.-1251174549[0] = "P/JYS7PumIoFqRV6AtkkfPmczLGrGbS3FLb5/PNCD7I=";
                    break;
                }
                case 2: {
                    CustomGuiButton.-1251174549[0] = "on9ajwgmPXQWBdkz/N7Mjw==";
                    break;
                }
                case 4: {
                    CustomGuiButton.-1251174549[0] = "sqczXFMUv2YqGCc1R+S9BQ==";
                    break;
                }
            }
        }
    }
    
    public static Object -846858968(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4) throws Exception {
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if ((int)o == 184) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.ui.hud;

import java.lang.invoke.MutableCallSite;
import javax.xml.bind.DatatypeConverter;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import net.minecraft.client.gui.ScaledResolution;
import com.google.gson.annotations.Expose;
import net.minecraft.client.Minecraft;

public class ScreenPosition
{
    @Expose(serialize = false)
    private static final Minecraft mc;
    private double x;
    private double y;
    private static int -751132453;
    private static int 1249160516;
    
    public ScreenPosition(final double -820909692, final double -965845822) {
    }
    // invokedynamic(618463588:(Ljava/lang/Object;DD)V, this, -820909692, -965845822)
    
    public ScreenPosition(final int -1382971049, final int 1492155803) {
    }
    // invokedynamic(2011883886:(Ljava/lang/Object;II)V, this, -1382971049, 1492155803)
    
    public static ScreenPosition fromRelativePosition(final double -374968259, final double -1859576657) {
        return new ScreenPosition(-374968259, -1859576657);
    }
    
    public static ScreenPosition fromAbsolutePosition(final int 722647452, final int -1933353604) {
        return new ScreenPosition(722647452, -1933353604);
    }
    
    public int getAbsoluteX() {
        final ScaledResolution 980402065 = new ScaledResolution(ScreenPosition.mc);
        return (int)(this.x * (double)invokedynamic(1395824700:(Ljava/lang/Object;)I, 980402065));
    }
    
    public int getAbsoluteY() {
        final ScaledResolution 383876731 = new ScaledResolution(ScreenPosition.mc);
        return (int)(this.y * (double)invokedynamic(-2074624956:(Ljava/lang/Object;)I, 383876731));
    }
    
    public double getRelativeX() {
        return this.x;
    }
    
    public double getRelativeY() {
        return this.y;
    }
    
    public void setRelative(final double -1767104157, final double 1116796094) {
        this.x = -1767104157;
        this.y = 1116796094;
    }
    
    public void setAbsolute(final int 1081111733, final int -1708819507) {
        final ScaledResolution 1081111734 = new ScaledResolution(ScreenPosition.mc);
        this.x = 1081111733 / (double)invokedynamic(-1497435882:(Ljava/lang/Object;)I, 1081111734);
        this.y = -1708819507 / (double)invokedynamic(661924308:(Ljava/lang/Object;)I, 1081111734);
    }
    
    static {
        ScreenPosition.-751132453 = 1237100076;
        ScreenPosition.1249160516 = 184;
        mc = invokedynamic(971320308:()Lnet/minecraft/client/Minecraft;);
    }
    
    public static Object -692570284(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7, final Object o8) throws Exception {
        final int n = ((int)o ^ ScreenPosition.-751132453) & 0xFF;
        final Integer value = ScreenPosition.1249160516;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.ui.hud;

public interface IRenderer extends IRenderConfig
{
    int getWidth();
    
    int getHeight();
    
    void render(final ScreenPosition p0);
    
    default void renderDummy(final ScreenPosition -2089246750) {
        this.render(-2089246750);
    }
    
    default boolean isEnabled() {
        return true;
    }
}

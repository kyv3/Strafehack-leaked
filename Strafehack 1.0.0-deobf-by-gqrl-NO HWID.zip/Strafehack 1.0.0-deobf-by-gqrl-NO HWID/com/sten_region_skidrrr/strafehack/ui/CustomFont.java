// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.ui;

import java.lang.invoke.MutableCallSite;
import javax.xml.bind.DatatypeConverter;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import java.awt.FontMetrics;
import java.awt.RenderingHints;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.Font;

public class CustomFont
{
    public int IMAGE_WIDTH;
    public int IMAGE_HEIGHT;
    private int texID;
    private final IntObject[] chars;
    private final Font font;
    private boolean antiAlias;
    private int fontHeight;
    private int charOffset;
    private static int 1182535819;
    private static int -689612706;
    private static int 925632764;
    private static int -940227215;
    private static int -268964240;
    private static int -2093740951;
    private static int 849217814;
    private static int -1997656364;
    private static int -572032129;
    private static int 1848494424;
    private static int 869656514;
    private static int 277892472;
    private static int -1597493743;
    private static int -1720636508;
    private static int 1553887661;
    private static int -192169567;
    private static int -1388745527;
    private static int 1465052582;
    private static int -1762329402;
    private static int 1228266241;
    private static int 1781258587;
    private static int -1210297871;
    private static int 67982387;
    private static int -998115633;
    private static int -756785069;
    private static int -1505018185;
    private static int 731328555;
    private static int -1048538055;
    private static int -2142641529;
    private static int 157903461;
    private static int 1403622338;
    private static int -141463583;
    private static int -1056159024;
    private static int -1767660929;
    private static int 1163340302;
    private static int 958801719;
    private static int -1911275907;
    private static int -1090671903;
    private static int 1035915914;
    private static int 1870953995;
    private static int 170410077;
    private static int 554148302;
    private static int -1459581582;
    private static int 2045300042;
    private static int 1065809170;
    private static int 1403199198;
    private static int 1030872263;
    private static int 221459709;
    private static int -1493097238;
    private static int 751256463;
    private static double 53520444;
    private static double -633001325;
    private static double -646024889;
    private static double -233056242;
    private static double 1380448351;
    private static double 2121889055;
    private static float 1434928727;
    private static float -155281291;
    private static float 23256029;
    private static float 469932868;
    private static int 830964933;
    private static float 1294339627;
    private static float 1499338881;
    private static float -1592530817;
    private static float -1151331600;
    private static int -1350454607;
    private static int -972277298;
    private static int 12913050;
    private static int 1055296207;
    private static int 1626427441;
    private static int -1975520487;
    private static int 1920822016;
    private static int 1279774874;
    private static int 1944776385;
    private static int 1781353719;
    
    public CustomFont(final Font 1806591043, final boolean -1369551561, final int -712314587) {
        this.IMAGE_WIDTH = CustomFont.1182535819;
        this.IMAGE_HEIGHT = CustomFont.-689612706;
        this.chars = new IntObject[CustomFont.925632764];
        this.fontHeight = CustomFont.-940227215;
        this.charOffset = CustomFont.-268964240;
        this.font = 1806591043;
        this.antiAlias = -1369551561;
        this.charOffset = -712314587;
        this.setupTexture(-1369551561);
    }
    
    public CustomFont(final Font 329650937, final boolean -1660878369) {
        this.IMAGE_WIDTH = CustomFont.-2093740951;
        this.IMAGE_HEIGHT = CustomFont.849217814;
        this.chars = new IntObject[CustomFont.-1997656364];
        this.fontHeight = CustomFont.-572032129;
        this.charOffset = CustomFont.1848494424;
        this.font = 329650937;
        this.antiAlias = -1660878369;
        this.charOffset = CustomFont.869656514;
        this.setupTexture(-1660878369);
    }
    
    private void setupTexture(final boolean -1293559958) {
        if (invokedynamic(1040349055:(Ljava/lang/Object;)I, this.font) <= CustomFont.277892472) {
            this.IMAGE_WIDTH = CustomFont.-1597493743;
            this.IMAGE_HEIGHT = CustomFont.-1720636508;
        }
        if (invokedynamic(-1820099102:(Ljava/lang/Object;)I, this.font) <= CustomFont.1553887661) {
            this.IMAGE_WIDTH = CustomFont.-192169567;
            this.IMAGE_HEIGHT = CustomFont.-1388745527;
        }
        else if (invokedynamic(26288047:(Ljava/lang/Object;)I, this.font) <= CustomFont.1465052582) {
            this.IMAGE_WIDTH = CustomFont.-1762329402;
            this.IMAGE_HEIGHT = CustomFont.1228266241;
        }
        else {
            this.IMAGE_WIDTH = CustomFont.1781258587;
            this.IMAGE_HEIGHT = CustomFont.-1210297871;
        }
        final BufferedImage bufferedImage = new BufferedImage(this.IMAGE_WIDTH, this.IMAGE_HEIGHT, CustomFont.67982387);
        final Graphics2D 933286372 = (Graphics2D)invokedynamic(609739450:(Ljava/lang/Object;)Ljava/awt/Graphics;, bufferedImage);
        // invokedynamic(793787654:(Ljava/lang/Object;Ljava/lang/Object;)V, 933286372, this.font)
        // invokedynamic(771365557:(Ljava/lang/Object;Ljava/lang/Object;)V, 933286372, new Color(CustomFont.-998115633, CustomFont.-756785069, CustomFont.-1505018185, CustomFont.731328555))
        // invokedynamic(139809892:(Ljava/lang/Object;IIII)V, 933286372, CustomFont.-1048538055, CustomFont.-2142641529, this.IMAGE_WIDTH, this.IMAGE_HEIGHT)
        // invokedynamic(-302707361:(Ljava/lang/Object;Ljava/lang/Object;)V, 933286372, Color.white)
        int n = CustomFont.157903461;
        int storedX = CustomFont.1403622338;
        int -1293559959 = CustomFont.-141463583;
        for (int 933286373 = CustomFont.-1056159024; 933286373 < CustomFont.-1767660929; ++933286373) {
            final char 933286375 = (char)933286373;
            final BufferedImage 933286374 = this.getFontImage(933286375, -1293559958);
            final IntObject intObject = new IntObject();
            intObject.width = invokedynamic(872559828:(Ljava/lang/Object;)I, 933286374);
            intObject.height = invokedynamic(609300962:(Ljava/lang/Object;)I, 933286374);
            if (storedX + intObject.width >= this.IMAGE_WIDTH) {
                storedX = CustomFont.1163340302;
                -1293559959 += n;
                n = CustomFont.958801719;
            }
            intObject.storedX = storedX;
            intObject.storedY = -1293559959;
            if (intObject.height > this.fontHeight) {
                this.fontHeight = intObject.height;
            }
            if (intObject.height > n) {
                n = intObject.height;
            }
            this.chars[933286373] = intObject;
            // invokedynamic(-1644611151:(Ljava/lang/Object;Ljava/lang/Object;IILjava/lang/Object;)Z, 933286372, 933286374, storedX, -1293559959, null)
            storedX += intObject.width;
        }
        try {
            this.texID = invokedynamic(785150354:(ILjava/lang/Object;ZZ)I, invokedynamic(156919496:()I), bufferedImage, CustomFont.-1911275907, CustomFont.-1090671903);
        }
        catch (NullPointerException ex) {
        }
        // invokedynamic(-1830468997:(Ljava/lang/Object;)V, ex)
    }
    
    private BufferedImage getFontImage(final char 518979, final boolean -1900985204) {
        final BufferedImage 518980 = new BufferedImage(CustomFont.1035915914, CustomFont.1870953995, CustomFont.170410077);
        final Graphics2D graphics2D = (Graphics2D)invokedynamic(1633586439:(Ljava/lang/Object;)Ljava/awt/Graphics;, 518980);
        if (-1900985204) {
        }
        // invokedynamic(-17506441:(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V, graphics2D, RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON)
        else {
        }
        // invokedynamic(519632814:(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V, graphics2D, RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF)
        // invokedynamic(-533073346:(Ljava/lang/Object;Ljava/lang/Object;)V, graphics2D, this.font)
        final FontMetrics fontMetrics = invokedynamic(-1711833045:(Ljava/lang/Object;)Ljava/awt/FontMetrics;, graphics2D);
        int -1900985205 = invokedynamic(1556165673:(Ljava/lang/Object;C)I, fontMetrics, 518979) + CustomFont.554148302;
        if (-1900985205 <= 0) {
            -1900985205 = CustomFont.-1459581582;
        }
        int height = invokedynamic(399624319:(Ljava/lang/Object;)I, fontMetrics) + CustomFont.2045300042;
        if (height <= 0) {
            height = invokedynamic(331950076:(Ljava/lang/Object;)I, this.font);
        }
        final BufferedImage bufferedImage = new BufferedImage(-1900985205, height, CustomFont.1065809170);
        final Graphics2D 518981 = (Graphics2D)invokedynamic(867221937:(Ljava/lang/Object;)Ljava/awt/Graphics;, bufferedImage);
        if (-1900985204) {
        }
        // invokedynamic(-927586065:(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V, 518981, RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON)
        else {
        }
        // invokedynamic(1970572970:(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V, 518981, RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF)
        // invokedynamic(1558581164:(Ljava/lang/Object;Ljava/lang/Object;)V, 518981, this.font)
        // invokedynamic(646267457:(Ljava/lang/Object;Ljava/lang/Object;)V, 518981, Color.WHITE)
        final int 518982 = CustomFont.1403199198;
        final int 518983 = CustomFont.1030872263;
        // invokedynamic(-1623406555:(Ljava/lang/Object;Ljava/lang/Object;II)V, 518981, invokedynamic(-196778753:(C)Ljava/lang/String;, 518979), CustomFont.221459709, CustomFont.-1493097238 + invokedynamic(159419780:(Ljava/lang/Object;)I, fontMetrics))
        return bufferedImage;
    }
    
    public void drawChar(final char -1415352368, final float -1533954264, final float 71811072) throws ArrayIndexOutOfBoundsException {
        try {
            this.drawQuad(-1533954264, 71811072, (float)this.chars[-1415352368].width, (float)this.chars[-1415352368].height, (float)this.chars[-1415352368].storedX, (float)this.chars[-1415352368].storedY, (float)this.chars[-1415352368].width, (float)this.chars[-1415352368].height);
        }
        catch (Exception 71811073) {
        }
        // invokedynamic(1448645477:(Ljava/lang/Object;)V, 71811073)
    }
    
    private void drawQuad(final float -977637332, final float -556931566, final float -941431459, final float 1435375352, final float 1259419250, final float 2055940452, final float -1459121704, final float -822226076) {
        final float 2055940453 = 1259419250 / this.IMAGE_WIDTH;
        final float 2055940454 = 2055940452 / this.IMAGE_HEIGHT;
        final float n = -1459121704 / this.IMAGE_WIDTH;
        final float 2055940455 = -822226076 / this.IMAGE_HEIGHT;
    }
    // invokedynamic(-1211641831:(I)V, CustomFont.751256463)
    // invokedynamic(1437284492:(FF)V, 2055940453 + n, 2055940454)
    // invokedynamic(1576699811:(DD)V, (double)-977637332 + -941431459, (double)-556931566)
    // invokedynamic(-1726147456:(FF)V, 2055940453, 2055940454)
    // invokedynamic(-1641750638:(DD)V, (double)-977637332, (double)-556931566)
    // invokedynamic(281861046:(FF)V, 2055940453, 2055940454 + 2055940455)
    // invokedynamic(-578331452:(DD)V, (double)-977637332, (double)-556931566 + 1435375352)
    // invokedynamic(1265039660:(FF)V, 2055940453, 2055940454 + 2055940455)
    // invokedynamic(1262609196:(DD)V, (double)-977637332, (double)-556931566 + 1435375352)
    // invokedynamic(-1981305403:(FF)V, 2055940453 + n, 2055940454 + 2055940455)
    // invokedynamic(1264200274:(DD)V, (double)-977637332 + -941431459, (double)-556931566 + 1435375352)
    // invokedynamic(1907176333:(FF)V, 2055940453 + n, 2055940454)
    // invokedynamic(489141813:(DD)V, (double)-977637332 + -941431459, (double)-556931566)
    // invokedynamic(-1497269001:()V)
    
    public void drawString(final String 2119169004, double 1403919971, double -1668720525, final Color -1897764463, final boolean 947158682) {
        1403919971 *= CustomFont.53520444;
        -1668720525 = -1668720525 * CustomFont.-633001325 - CustomFont.-646024889;
        // invokedynamic(326284936:(DDD)V, CustomFont.-233056242, CustomFont.1380448351, CustomFont.2121889055)
        // invokedynamic(-411050105:(I)V, this.texID)
        // invokedynamic(-1384915159:(Ljava/lang/Object;Ljava/lang/Object;)V, this, 947158682 ? new Color(CustomFont.1434928727, CustomFont.-155281291, CustomFont.23256029, (float)invokedynamic(136732683:(Ljava/lang/Object;)I, -1897764463) / CustomFont.469932868) : -1897764463)
        for (int n = invokedynamic(1203212208:(Ljava/lang/Object;)I, 2119169004), 2119169005 = CustomFont.830964933; 2119169005 < n; ++2119169005) {
            final char c = invokedynamic(878269129:(Ljava/lang/Object;I)C, 2119169004, 2119169005);
            if (c < this.chars.length && c >= '\0') {
                // invokedynamic(1949837709:(Ljava/lang/Object;CFF)V, this, c, (float)1403919971, (float)-1668720525)
                1403919971 += this.chars[c].width - this.charOffset;
            }
        }
    }
    
    public void glColor(final Color -2064468475) {
        final float 1202081392 = (float)invokedynamic(-672352197:(Ljava/lang/Object;)I, -2064468475) / CustomFont.1294339627;
        final float n = (float)invokedynamic(-990454178:(Ljava/lang/Object;)I, -2064468475) / CustomFont.1499338881;
        final float 1202081393 = (float)invokedynamic(1286595812:(Ljava/lang/Object;)I, -2064468475) / CustomFont.-1592530817;
        final float 1202081394 = (float)invokedynamic(-1368764592:(Ljava/lang/Object;)I, -2064468475) / CustomFont.-1151331600;
    }
    // invokedynamic(-1775624353:(FFFF)V, 1202081392, n, 1202081393, 1202081394)
    
    public int getStringHeight(final String 407558027) {
        int 407558028 = CustomFont.-1350454607;
        final char[] array = (char[])invokedynamic(1245669080:(Ljava/lang/Object;)[C, 407558027);
        for (int length = array.length, i = CustomFont.-972277298; i < length; ++i) {
            final char c = array[i];
            if (c == CustomFont.12913050) {
                ++407558028;
            }
        }
        return (this.fontHeight - this.charOffset) / CustomFont.1055296207 * 407558028;
    }
    
    public int getHeight() {
        return (this.fontHeight - this.charOffset) / CustomFont.1626427441;
    }
    
    public int getStringWidth(final String -1164821670) {
        int -1164821671 = CustomFont.-1975520487;
        final char[] array = (char[])invokedynamic(-826900592:(Ljava/lang/Object;)[C, -1164821670);
        for (int length = array.length, i = CustomFont.1920822016; i < length; ++i) {
            final char 1737609464 = array[i];
            if (1737609464 < this.chars.length && 1737609464 >= '\0') {
                -1164821671 += this.chars[1737609464].width - this.charOffset;
            }
        }
        return -1164821671 / CustomFont.1279774874;
    }
    
    public boolean isAntiAlias() {
        return this.antiAlias;
    }
    
    public void setAntiAlias(final boolean -438946200) {
        if (this.antiAlias != -438946200) {
            this.setupTexture(this.antiAlias = -438946200);
        }
    }
    
    public Font getFont() {
        return this.font;
    }
    
    static {
        CustomFont.1944776385 = 513720080;
        CustomFont.1781353719 = 184;
        CustomFont.1182535819 = invokedynamic(1571098604:(I)I, 2097152);
        CustomFont.-689612706 = invokedynamic(-1889561451:(I)I, 2097152);
        CustomFont.925632764 = invokedynamic(1628064315:(I)I, 1048576);
        CustomFont.-940227215 = ((-1 >>> 13 | -1 << ~0xD + 1) & -1);
        CustomFont.-268964240 = invokedynamic(-357032116:(I)I, 268435456);
        CustomFont.-2093740951 = invokedynamic(763597163:(I)I, 2097152);
        CustomFont.849217814 = ((4 >>> 120 | 4 << ~0x78 + 1) & -1);
        CustomFont.-1997656364 = invokedynamic(-1796495080:(I)I, 1048576);
        CustomFont.-572032129 = (-1 >>> 135 | -1 << ~0x87 + 1);
        CustomFont.1848494424 = (Integer.MIN_VALUE >>> 60 | Integer.MIN_VALUE << ~0x3C + 1);
        CustomFont.869656514 = invokedynamic(1076787546:(I)I, 268435456);
        CustomFont.277892472 = (15 >>> 160 | 15 << -160);
        CustomFont.-1597493743 = (16384 >>> 38 | 16384 << -38);
        CustomFont.-1720636508 = invokedynamic(249132349:(I)I, 8388608);
        CustomFont.1553887661 = (2752 >>> 166 | 2752 << -166);
        CustomFont.-192169567 = (Integer.MIN_VALUE >>> 22 | Integer.MIN_VALUE << -22);
        CustomFont.-1388745527 = invokedynamic(-2004528878:(I)I, 4194304);
        CustomFont.1465052582 = invokedynamic(1874713099:(I)I, -637534208);
        CustomFont.-1762329402 = invokedynamic(1833231331:(I)I, 2097152);
        CustomFont.1228266241 = invokedynamic(-2133566853:(I)I, 2097152);
        CustomFont.1781258587 = ((4 >>> 247 | 4 << ~0xF7 + 1) & -1);
        CustomFont.-1210297871 = ((16384 >>> 131 | 16384 << ~0x83 + 1) & -1);
        CustomFont.67982387 = invokedynamic(1199252433:(I)I, 1073741824);
        CustomFont.-998115633 = invokedynamic(77991575:(I)I, -16777216);
        CustomFont.-756785069 = invokedynamic(-1155332948:(I)I, -16777216);
        CustomFont.-1505018185 = ((-33554431 >>> 249 | -33554431 << ~0xF9 + 1) & -1);
        CustomFont.731328555 = ((0 >>> 101 | 0 << -101) & -1);
        CustomFont.-1048538055 = (0 >>> 87 | 0 << ~0x57 + 1);
        CustomFont.-2142641529 = ((0 >>> 235 | 0 << -235) & -1);
        CustomFont.157903461 = ((0 >>> 173 | 0 << ~0xAD + 1) & -1);
        CustomFont.1403622338 = invokedynamic(-55471632:(I)I, false);
        CustomFont.-141463583 = (0 >>> 143 | 0 << ~0x8F + 1);
        CustomFont.-1056159024 = (0 >>> 147 | 0 << ~0x93 + 1);
        CustomFont.-1767660929 = ((1024 >>> 159 | 1024 << ~0x9F + 1) & -1);
        CustomFont.1163340302 = ((0 >>> 105 | 0 << ~0x69 + 1) & -1);
        CustomFont.958801719 = (0 >>> 228 | 0 << ~0xE4 + 1);
        CustomFont.-1911275907 = (16384 >>> 238 | 16384 << -238);
        CustomFont.-1090671903 = invokedynamic(-2105282661:(I)I, Integer.MIN_VALUE);
        CustomFont.1035915914 = (67108864 >>> 186 | 67108864 << ~0xBA + 1);
        CustomFont.1870953995 = (8 >>> 163 | 8 << ~0xA3 + 1);
        CustomFont.170410077 = ((1073741824 >>> 157 | 1073741824 << -157) & -1);
        CustomFont.554148302 = (32 >>> 226 | 32 << ~0xE2 + 1);
        CustomFont.-1459581582 = ((14 >>> 193 | 14 << ~0xC1 + 1) & -1);
        CustomFont.2045300042 = invokedynamic(1006177046:(I)I, -1073741824);
        CustomFont.1065809170 = (2048 >>> 202 | 2048 << ~0xCA + 1);
        CustomFont.1403199198 = invokedynamic(-139391444:(I)I, -1073741824);
        CustomFont.1030872263 = (536870912 >>> 189 | 536870912 << -189);
        CustomFont.221459709 = (1536 >>> 169 | 1536 << ~0xA9 + 1);
        CustomFont.-1493097238 = ((64 >>> 38 | 64 << -38) & -1);
        CustomFont.751256463 = invokedynamic(-1276360109:(I)I, 536870912);
        CustomFont.53520444 = invokedynamic(-776132560:(J)D, invokedynamic(-822947493:(J)J, 2L));
        CustomFont.-633001325 = invokedynamic(1425907416:(J)D, invokedynamic(-1609943709:(J)J, 2L));
        CustomFont.-646024889 = invokedynamic(-159313757:(J)D, invokedynamic(-1816599798:(J)J, 2L));
        CustomFont.-233056242 = invokedynamic(1455527058:(J)D, invokedynamic(-1620748937:(J)J, 3068L));
        CustomFont.1380448351 = invokedynamic(804091742:(J)D, invokedynamic(-1826291107:(J)J, 3068L));
        CustomFont.2121889055 = invokedynamic(-500627112:(J)D, invokedynamic(-1942375725:(J)J, 3068L));
        CustomFont.1434928727 = invokedynamic(-924250631:(I)F, -1717065319 >>> 181 | -1717065319 << -181);
        CustomFont.-155281291 = invokedynamic(659207934:(I)F, invokedynamic(1751303058:(I)I, -1288490308));
        CustomFont.23256029 = invokedynamic(-224486303:(I)F, invokedynamic(-1949967442:(I)I, -1288490308));
        CustomFont.469932868 = invokedynamic(912779796:(I)F, invokedynamic(1805598298:(I)I, 65218));
        CustomFont.830964933 = invokedynamic(-129616039:(I)I, false);
        CustomFont.1294339627 = invokedynamic(-1550551343:(I)F, invokedynamic(1737867725:(I)I, 65218));
        CustomFont.1499338881 = invokedynamic(-209092532:(I)F, (17693696 >>> 90 | 17693696 << ~0x5A + 1) & -1);
        CustomFont.-1592530817 = invokedynamic(-210483438:(I)F, 69116 >>> 242 | 69116 << ~0xF2 + 1);
        CustomFont.-1151331600 = invokedynamic(-1339162731:(I)F, invokedynamic(-1311160550:(I)I, 65218));
        CustomFont.-1350454607 = invokedynamic(517107190:(I)I, Integer.MIN_VALUE);
        CustomFont.-972277298 = ((0 >>> 181 | 0 << ~0xB5 + 1) & -1);
        CustomFont.12913050 = invokedynamic(834151975:(I)I, 1342177280);
        CustomFont.1055296207 = (16384 >>> 45 | 16384 << ~0x2D + 1);
        CustomFont.1626427441 = invokedynamic(-150934245:(I)I, 1073741824);
        CustomFont.-1975520487 = ((0 >>> 211 | 0 << -211) & -1);
        CustomFont.1920822016 = (0 >>> 196 | 0 << ~0xC4 + 1);
        CustomFont.1279774874 = invokedynamic(2112551090:(I)I, 1073741824);
    }
    
    public static Object 1298624787(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5, final Object o6, final Object o7, final Object o8, final Object o9) throws Exception {
        final int n = ((int)o ^ CustomFont.1944776385) & 0xFF;
        final Integer value = CustomFont.1781353719;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
    
    private class IntObject
    {
        public int width;
        public int height;
        public int storedX;
        public int storedY;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package com.sten_region_skidrrr.strafehack.ui;

import javax.xml.bind.DatatypeConverter;
import java.util.Base64;
import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import java.security.spec.KeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.Cipher;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import net.minecraft.client.gui.GuiButton;
import com.sten_region_skidrrr.strafehack.module.settings.NumberSetting;
import com.sten_region_skidrrr.strafehack.module.Category;
import java.io.IOException;
import java.util.Iterator;
import com.sten_region_skidrrr.strafehack.module.settings.ModeSetting;
import com.sten_region_skidrrr.strafehack.module.settings.BooleanSetting;
import com.sten_region_skidrrr.strafehack.module.settings.KeybindSetting;
import com.sten_region_skidrrr.strafehack.module.settings.Setting;
import com.sten_region_skidrrr.strafehack.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;

public class ClickGui extends GuiScreen
{
    private Minecraft mc;
    private int key;
    private static String[] -1945320144;
    private static String[] -561302429;
    private static long 1712342544;
    private static int -2007587438;
    private static int -1200577479;
    private static int 1399712331;
    private static int 552600383;
    private static int -417916894;
    private static int -104040803;
    private static int 240895914;
    private static int 1139240061;
    private static int -1671028522;
    private static int 2061144448;
    private static int -1998845427;
    private static long -2040231206;
    private static long -1547232832;
    private static int -1478990231;
    private static int 2035737234;
    private static int 270831351;
    private static int -275721858;
    private static long 313719307;
    private static long 1439162146;
    private static int -14197661;
    private static int 731749466;
    private static int -2092868214;
    private static int 138335343;
    private static int -837163603;
    private static int 1076598953;
    private static int 214854800;
    private static float 170772227;
    private static int -374375859;
    private static int 2112403521;
    private static int -1001823122;
    private static int 1510798112;
    private static int 1104612807;
    private static int 537259646;
    private static int 1825697655;
    private static int 737161623;
    private static int 1919512525;
    private static int -557872974;
    private static int 888185852;
    private static int -693939360;
    private static int 626254859;
    private static int 1506713399;
    private static int -375944755;
    private static int -1285623898;
    private static int 1312872465;
    private static int -1207472016;
    private static int -1568741162;
    private static int -1926420638;
    private static int 1249442171;
    private static int -672735119;
    private static int -735603163;
    private static int 1686127469;
    private static int 1619967089;
    private static int 1146487515;
    private static int -1190641561;
    private static int -323311328;
    private static int 66754060;
    private static int -1260810654;
    private static int -1277308355;
    private static int -1828149380;
    private static int -1137294540;
    private static int 509891028;
    private static int 292702354;
    private static int -934757870;
    private static int -1292800666;
    private static int -777499873;
    private static int 1397111327;
    private static int 2049263147;
    private static int -1809397232;
    private static int -333138335;
    private static int 1527524935;
    private static int -591586101;
    private static int 83064448;
    private static int 281690484;
    private static int 1983109276;
    private static int -681072085;
    private static int -994468883;
    private static int -1524359069;
    private static int 1385123129;
    private static int -1788762074;
    private static int 1823653674;
    private static int -802602245;
    private static int 1227345960;
    private static int -2127208993;
    private static int 1141469203;
    private static int -1751404878;
    private static int -127001682;
    private static int -1891574811;
    private static int 332492160;
    private static int 1376027647;
    private static int 1676157856;
    private static int 545829451;
    private static int -74539119;
    private static int -1111035439;
    private static int 833745756;
    private static int -911524189;
    private static int 84520113;
    private static int 455696857;
    private static int 387415689;
    private static long -276117199;
    private static long 1562496724;
    private static int 2085968702;
    private static int -1655550087;
    private static long 1278782390;
    private static int -643616726;
    private static long 32889523;
    private static int 1049487753;
    private static int 2130123214;
    private static long 739727558;
    private static int -817268683;
    private static int -1462173845;
    private static int 482420514;
    private static int -807849066;
    private static int 732461659;
    private static int -349840140;
    private static int 1797854330;
    private static int -774048274;
    private static int -1733264989;
    private static int 1897836201;
    private static int 1067787897;
    private static int 1695813234;
    private static int 600874266;
    private static int 1674860695;
    private static int 727308767;
    private static int -701865151;
    private static long 726868566;
    private static int -1356278208;
    private static int 2017444855;
    private static int -1402027834;
    private static long -1074058620;
    private static long -940554793;
    private static int -1409000525;
    private static int 1855208602;
    private static int -940397816;
    private static int 1733353745;
    private static int -600637765;
    private static int 304068866;
    private static int -1931428223;
    private static long 2027683830;
    private static int 1008965750;
    private static int -485218549;
    private static int -1775405337;
    private static int -1953963072;
    private static long 1732154193;
    private static long 1737630367;
    private static int 1464370502;
    private static int 1482515323;
    private static int 213163787;
    private static int -1401460534;
    private static int -669970952;
    private static int -365321580;
    private static long 1168347302;
    private static long -280605849;
    private static int -1772315181;
    private static int -1638563026;
    private static int 520121686;
    private static int -106306137;
    private static int -1295826159;
    private static int 1922262177;
    private static long 1298403467;
    private static long -2002191522;
    private static int -806749014;
    private static int -1426466175;
    private static int -545225590;
    private static int -1571654858;
    private static int -1067246669;
    private static int -765718137;
    private static int -734222173;
    private static int 287772925;
    private static int 958766410;
    private static int -616898337;
    private static int 350308173;
    private static int 1807863324;
    private static int 950803616;
    private static int -799828441;
    private static int -815339872;
    private static int -2137883177;
    private static int -844616279;
    private static int -1196526983;
    private static int -1115646804;
    private static int -1012629845;
    private static int -227218233;
    private static int -1637772439;
    private static int 1333645306;
    private static int -1098608221;
    private static int 1889965627;
    private static int -1442577413;
    private static int -78143229;
    private static int 114629077;
    private static int -1753771277;
    private static int -1131002612;
    private static int -1244881957;
    private static int -891459751;
    private static int 2095586730;
    private static int 966014949;
    
    public ClickGui() {
        this.mc = invokedynamic(643711517:()Lnet/minecraft/client/Minecraft;);
        this.key = ClickGui.-2007587438;
    }
    
    public void func_73869_a(final char 81123133, final int 1949122451) throws IOException {
        super.func_73869_a(81123133, 1949122451);
        final Iterator iterator = invokedynamic(1688757947:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(29503725:()Ljava/util/ArrayList;));
        while (invokedynamic(-1731437046:(Ljava/lang/Object;)Z, iterator)) {
            final Module 1949122452 = (Module)invokedynamic(-1620828304:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
            if (invokedynamic(-1927652338:(Ljava/lang/Object;)Z, 1949122452)) {
                final Iterator iterator2 = invokedynamic(-869457949:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(-1666518684:(Ljava/lang/Object;)Ljava/util/List;, 1949122452));
                while (invokedynamic(1951825854:(Ljava/lang/Object;)Z, iterator2)) {
                    final Setting 1949122453 = (Setting)invokedynamic(-109157092:(Ljava/lang/Object;)Ljava/lang/Object;, iterator2);
                    if (1949122453 instanceof KeybindSetting) {
                        if (!1949122453.focussed) {
                            continue;
                        }
                        if (1949122451 == ClickGui.-1200577479) {
                            1949122453.focussed = (ClickGui.1399712331 != 0);
                        }
                        else if (1949122451 == ClickGui.552600383) {
                            ((KeybindSetting)1949122453).code = ClickGui.-417916894;
                            1949122453.focussed = (ClickGui.-104040803 != 0);
                        }
                        else {
                            // invokedynamic(706644768:(Ljava/lang/Object;I)V, 1949122452, 1949122451)
                            1949122453.focussed = (ClickGui.240895914 != 0);
                        }
                    }
                    else if (1949122453 instanceof BooleanSetting) {
                        final BooleanSetting booleanSetting = (BooleanSetting)1949122453;
                        if (!booleanSetting.focussed) {
                            continue;
                        }
                        if (1949122451 == ClickGui.1139240061) {
                            // invokedynamic(244101624:(Ljava/lang/Object;Z)V, booleanSetting, ClickGui.-1671028522)
                            1949122453.focussed = (ClickGui.2061144448 != 0);
                        }
                        // invokedynamic(-1992677859:(Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;, 1949122452.properties.settings, invokedynamic(138254610:(Ljava/lang/Object;Ljava/lang/Object;)I, invokedynamic(300253334:(Ljava/lang/Object;)Ljava/util/List;, 1949122452), booleanSetting), invokedynamic(1203643354:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-1493124742:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(1123884185:(Ljava/lang/Object;Z)Ljava/lang/StringBuilder;, new StringBuilder(), invokedynamic(-1589477253:(Ljava/lang/Object;)Z, booleanSetting)), invokedynamic(1650759481:(IJ)Ljava/lang/String;, ClickGui.-1998845427, ClickGui.-2040231206 ^ ClickGui.-1547232832))))
                        else {
                            if (1949122451 != ClickGui.-1478990231) {
                                continue;
                            }
                            // invokedynamic(634153796:(Ljava/lang/Object;Z)V, booleanSetting, ClickGui.2035737234)
                            1949122453.focussed = (ClickGui.270831351 != 0);
                        }
                        // invokedynamic(935758912:(Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;, 1949122452.properties.settings, invokedynamic(-8573677:(Ljava/lang/Object;Ljava/lang/Object;)I, invokedynamic(866672373:(Ljava/lang/Object;)Ljava/util/List;, 1949122452), booleanSetting), invokedynamic(-1191178009:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(1418058607:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-344471311:(Ljava/lang/Object;Z)Ljava/lang/StringBuilder;, new StringBuilder(), invokedynamic(-1710611296:(Ljava/lang/Object;)Z, booleanSetting)), invokedynamic(-1885198598:(IJ)Ljava/lang/String;, ClickGui.-275721858, ClickGui.313719307 ^ ClickGui.1439162146))))
                    }
                    else {
                        if (!(1949122453 instanceof ModeSetting)) {
                            continue;
                        }
                        final ModeSetting modeSetting = (ModeSetting)1949122453;
                        if (!modeSetting.focussed) {
                            continue;
                        }
                        if (1949122451 != ClickGui.-14197661) {
                            if (1949122451 != ClickGui.-2092868214) {
                                continue;
                            }
                        }
                        // invokedynamic(-1293107243:(Ljava/lang/Object;I)V, modeSetting, ClickGui.138335343)
                        // invokedynamic(-1808202409:(Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;, 1949122452.properties.settings, invokedynamic(1991244340:(Ljava/lang/Object;Ljava/lang/Object;)I, invokedynamic(-301030174:(Ljava/lang/Object;)Ljava/util/List;, 1949122452), modeSetting), modeSetting.value)
                    }
                }
            }
        }
    }
    
    public void ResetFocussed() {
        final Iterator iterator = invokedynamic(2112311440:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(-2019593831:()Ljava/util/ArrayList;));
        while (invokedynamic(-758147170:(Ljava/lang/Object;)Z, iterator)) {
            final Module module = (Module)invokedynamic(1714506374:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
            final Iterator iterator2 = invokedynamic(843014609:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(963446823:(Ljava/lang/Object;)Ljava/util/List;, module));
            while (invokedynamic(1298605818:(Ljava/lang/Object;)Z, iterator2)) {
                final Setting setting = (Setting)invokedynamic(1409271078:(Ljava/lang/Object;)Ljava/lang/Object;, iterator2);
                setting.focussed = (ClickGui.-837163603 != 0);
            }
        }
    }
    
    public void ResetModules() {
        final Iterator iterator = invokedynamic(2123939379:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(-1905462458:()Ljava/util/ArrayList;));
        while (invokedynamic(1374411157:(Ljava/lang/Object;)Z, iterator)) {
            final Module module = (Module)invokedynamic(-104325260:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
            final Iterator iterator2 = invokedynamic(502088305:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(1614116841:(Ljava/lang/Object;)Ljava/util/List;, module));
            while (invokedynamic(1390151189:(Ljava/lang/Object;)Z, iterator2)) {
                final Setting setting = (Setting)invokedynamic(-2110449535:(Ljava/lang/Object;)Ljava/lang/Object;, iterator2);
                setting.focussed = (ClickGui.1076598953 != 0);
            }
        }
        // invokedynamic(401235704:(Ljava/lang/Object;Z)V, module, ClickGui.214854800)
    }
    
    public static int returnDarkerColor(final int -887397600) {
        final float 254201335 = ClickGui.170772227;
        final int n = -887397600 >> ClickGui.-374375859 & ClickGui.2112403521;
        final int 254201336 = (int)((-887397600 >> ClickGui.-1001823122 & ClickGui.1510798112) * 254201335);
        final int 254201337 = (int)((-887397600 >> ClickGui.1104612807 & ClickGui.537259646) * 254201335);
        final int n2 = (int)((-887397600 & ClickGui.1825697655) * 254201335);
        return n << ClickGui.737161623 | 254201336 << ClickGui.1919512525 | 254201337 << ClickGui.-557872974 | n2;
    }
    
    public void func_73863_a(final int 200689512, final int 866386503, final float 1748281788) {
        // invokedynamic(-872115984:(IIIII)V, ClickGui.888185852, ClickGui.-693939360, ClickGui.626254859, ClickGui.1506713399, ClickGui.-375944755)
        // invokedynamic(-61355778:(IIIII)V, ClickGui.-1285623898, ClickGui.1312872465, ClickGui.-1207472016, ClickGui.-1568741162, ClickGui.-1926420638)
        // invokedynamic(-1025784720:(IIIII)V, ClickGui.1249442171, ClickGui.-672735119, ClickGui.-735603163, ClickGui.1686127469, ClickGui.1619967089)
        // invokedynamic(711469981:(IIIII)V, ClickGui.1146487515, ClickGui.-1190641561, ClickGui.-323311328, ClickGui.66754060, ClickGui.-1260810654)
        // invokedynamic(422648049:(IIIII)V, ClickGui.-1277308355, ClickGui.-1828149380, ClickGui.-1137294540, ClickGui.509891028, ClickGui.292702354)
        // invokedynamic(609335798:(IIIII)V, ClickGui.-934757870, ClickGui.-1292800666, ClickGui.-777499873, ClickGui.1397111327, ClickGui.2049263147)
        // invokedynamic(1696099818:(IIIII)V, ClickGui.-1809397232, ClickGui.-333138335, ClickGui.1527524935, ClickGui.-591586101, ClickGui.83064448)
        // invokedynamic(1927204094:(IIIII)V, ClickGui.281690484, ClickGui.1983109276, ClickGui.-681072085, ClickGui.-994468883, ClickGui.-1524359069)
        // invokedynamic(-257755628:(IIIII)V, ClickGui.1385123129, ClickGui.-1788762074, ClickGui.1823653674, ClickGui.-802602245, ClickGui.1227345960)
        // invokedynamic(2052109678:(IIIII)V, ClickGui.-2127208993, ClickGui.1141469203, ClickGui.-1751404878, ClickGui.-127001682, ClickGui.-1891574811)
        int 1748281789 = ClickGui.332492160;
        final Category[] array = (Category[])invokedynamic(2017170049:()[Lcom/sten_region_skidrrr/strafehack/module/Category;);
        for (int length = array.length, i = ClickGui.1376027647; i < length; ++i) {
            final Category 1748281790 = array[i];
            // invokedynamic(133743986:(Ljava/lang/Object;III)V, invokedynamic(1397863179:(Ljava/lang/Object;)Ljava/lang/String;, 1748281790), ClickGui.1676157856 + 1748281789 * ClickGui.545829451, ClickGui.-74539119, ClickGui.-1111035439)
            ++1748281789;
        }
        super.func_73863_a(200689512, 866386503, 1748281788);
        final Iterator iterator = invokedynamic(2009935812:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(592091755:()Ljava/util/ArrayList;));
        while (invokedynamic(-1988302483:(Ljava/lang/Object;)Z, iterator)) {
            final Module module = (Module)invokedynamic(593516568:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
            if (invokedynamic(-714220071:(Ljava/lang/Object;)Z, module)) {
                int 1748281791 = ClickGui.833745756;
                final Iterator iterator2 = invokedynamic(1974179451:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(-1084350288:(Ljava/lang/Object;)Ljava/util/List;, module));
                while (invokedynamic(1559456290:(Ljava/lang/Object;)Z, iterator2)) {
                    final Setting setting = (Setting)invokedynamic(-1691031681:(Ljava/lang/Object;)Ljava/lang/Object;, iterator2);
                    final int n = invokedynamic(1759656393:(Ljava/lang/Object;Ljava/lang/Object;)I, this, module) + ClickGui.-911524189;
                    final int n2 = invokedynamic(852916196:(Ljava/lang/Object;Ljava/lang/Object;)I, this, module) + 1748281791 * ClickGui.84520113;
                    int 1748281792 = ClickGui.455696857;
                    final Iterator iterator3 = invokedynamic(2060532702:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(829704711:(Ljava/lang/Object;)Ljava/util/List;, module));
                    while (invokedynamic(828560532:(Ljava/lang/Object;)Z, iterator3)) {
                        final Setting 1748281793 = (Setting)invokedynamic(-1099806360:(Ljava/lang/Object;)Ljava/lang/Object;, iterator3);
                        final String 1748281794 = (1748281793 instanceof BooleanSetting) ? invokedynamic(1384845877:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-1045337939:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(761205548:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-780939058:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), 1748281793.name), invokedynamic(-615825181:(IJ)Ljava/lang/String;, ClickGui.387415689, ClickGui.-276117199 ^ ClickGui.1562496724)), ((BooleanSetting)1748281793).value)) : ((1748281793 instanceof NumberSetting) ? invokedynamic(637743944:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(1407553038:(Ljava/lang/Object;D)Ljava/lang/StringBuilder;, invokedynamic(-2026268320:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-334424278:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), 1748281793.name), invokedynamic(165812949:(IJ)Ljava/lang/String;, ClickGui.2085968702 & ClickGui.-1655550087, ClickGui.1278782390)), invokedynamic(-326493603:(Ljava/lang/Object;)D, (NumberSetting)1748281793))) : ((1748281793 instanceof KeybindSetting) ? invokedynamic(-1039484077:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(2057014280:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-1006322890:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(1137288195:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), 1748281793.name), invokedynamic(-1651340321:(IJ)Ljava/lang/String;, ClickGui.-643616726, ClickGui.32889523)), invokedynamic(-27660266:(I)Ljava/lang/String;, ((KeybindSetting)1748281793).code))) : ((1748281793 instanceof ModeSetting) ? invokedynamic(-137533401:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-737088674:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(15430477:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), 1748281793.name), invokedynamic(295605797:(Ljava/lang/Object;)Ljava/lang/String;, (ModeSetting)1748281793))) : invokedynamic(-342252308:(IJ)Ljava/lang/String;, ClickGui.1049487753 & ClickGui.2130123214, ClickGui.739727558))));
                        if (invokedynamic(-1299045259:(Ljava/lang/Object;)I, 1748281794) > 1748281792) {
                            1748281792 = invokedynamic(1246033003:(Ljava/lang/Object;)I, 1748281794);
                        }
                    }
                    final int 1748281795 = invokedynamic(1346195581:(Ljava/lang/Object;Ljava/lang/Object;)I, this, module) + 1748281792 + ClickGui.-817268683;
                    final int n3 = invokedynamic(-1830989284:(Ljava/lang/Object;Ljava/lang/Object;)I, this, module) + ClickGui.-1462173845 + 1748281791 * ClickGui.482420514;
                    if (setting.focussed) {
                    }
                    // invokedynamic(-1308515781:(IIIII)V, n, n2, 1748281795, n3, ClickGui.-807849066)
                    // invokedynamic(-1529278330:(Ljava/lang/Object;IIII)V, this, n, 1748281795 - ClickGui.732461659, n2, ClickGui.-349840140)
                    // invokedynamic(1300301507:(Ljava/lang/Object;IIII)V, this, n, 1748281795 - ClickGui.1797854330, n3 - ClickGui.-774048274, ClickGui.-1733264989)
                    // invokedynamic(-1623779615:(Ljava/lang/Object;IIII)V, this, n, n2, n3, ClickGui.1897836201)
                    // invokedynamic(-1433773191:(Ljava/lang/Object;IIII)V, this, 1748281795 - ClickGui.1067787897, n2, n3, ClickGui.1695813234)
                    else {
                    }
                    // invokedynamic(1747960207:(IIIII)V, n, n2, 1748281795, n3, invokedynamic(2085154191:(I)I, ClickGui.600874266))
                    if (setting instanceof NumberSetting) {
                        final NumberSetting 1748281796 = (NumberSetting)setting;
                        if (invokedynamic(-1001687263:(I)Z, ClickGui.1674860695) && 200689512 > n && 866386503 > n2 && 200689512 < 1748281795 && 866386503 < n3) {
                            final int 1748281797 = 200689512 - n;
                            final int n4 = 1748281795 - n;
                        }
                        // invokedynamic(2072085571:(Ljava/lang/Object;D)V, 1748281796, (double)1748281797 / (double)n4 * invokedynamic(-1718452755:(Ljava/lang/Object;)D, 1748281796) + invokedynamic(-299690155:(Ljava/lang/Object;)D, 1748281796))
                        // invokedynamic(-1352177789:(Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;, module.properties.settings, invokedynamic(967658369:(Ljava/lang/Object;Ljava/lang/Object;)I, invokedynamic(-819949345:(Ljava/lang/Object;)Ljava/util/List;, module), 1748281796), invokedynamic(828658559:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-1025307592:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-2130144979:(Ljava/lang/Object;D)Ljava/lang/StringBuilder;, new StringBuilder(), invokedynamic(1072997327:(Ljava/lang/Object;)D, 1748281796)), invokedynamic(-1823357752:(IJ)Ljava/lang/String;, ClickGui.727308767 & ClickGui.-701865151, ClickGui.726868566))))
                    }
                    // invokedynamic(-1492180834:(IIIII)V, n, n3 - ClickGui.-1356278208, (int)invokedynamic(728201438:(Ljava/lang/Object;)D, 1748281796) / invokedynamic(1240617076:(Ljava/lang/Object;)D, 1748281796) * (double)1748281795 - n + n, n3, ClickGui.2017444855)
                    // invokedynamic(892597521:(Ljava/lang/Object;III)V, invokedynamic(1452986213:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(2142882635:(Ljava/lang/Object;D)Ljava/lang/StringBuilder;, invokedynamic(-1893431537:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-1620421093:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), 1748281796.name), invokedynamic(-1606483521:(IJ)Ljava/lang/String;, ClickGui.-1402027834, ClickGui.-1074058620 ^ ClickGui.-940554793)), invokedynamic(341749342:(Ljava/lang/Object;)D, 1748281796))), invokedynamic(1986242519:(Ljava/lang/Object;Ljava/lang/Object;)I, this, module) + ClickGui.-1409000525, invokedynamic(-449818341:(Ljava/lang/Object;Ljava/lang/Object;)I, this, module) + 1748281791 * ClickGui.1855208602, ClickGui.-940397816)
                    else if (setting instanceof KeybindSetting) {
                        final KeybindSetting keybindSetting = (KeybindSetting)setting;
                        if (invokedynamic(1128963343:(I)Z, ClickGui.1733353745) && 200689512 > n && 866386503 > n2 && 200689512 < 1748281795 && 866386503 < n3) {
                            // invokedynamic(-556221214:(Ljava/lang/Object;)V, this)
                            keybindSetting.focussed = (ClickGui.-600637765 != 0);
                        }
                        if (keybindSetting.code == 0) {
                        }
                        // invokedynamic(823982650:(Ljava/lang/Object;III)V, invokedynamic(1599116739:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-1155475696:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-1028127168:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), keybindSetting.name), invokedynamic(531622963:(IJ)Ljava/lang/String;, ClickGui.304068866 & ClickGui.-1931428223, ClickGui.2027683830))), invokedynamic(-886981017:(Ljava/lang/Object;Ljava/lang/Object;)I, this, module) + ClickGui.1008965750, invokedynamic(144137901:(Ljava/lang/Object;Ljava/lang/Object;)I, this, module) + 1748281791 * ClickGui.-485218549, ClickGui.-1775405337)
                        else {
                        }
                        // invokedynamic(-278797563:(Ljava/lang/Object;III)V, invokedynamic(-1595825865:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(-594832871:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-1186426075:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-1989430645:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), keybindSetting.name), invokedynamic(1150693779:(IJ)Ljava/lang/String;, ClickGui.-1953963072, ClickGui.1732154193 ^ ClickGui.1737630367)), invokedynamic(-1604160170:(I)Ljava/lang/String;, keybindSetting.code))), invokedynamic(-1392576091:(Ljava/lang/Object;Ljava/lang/Object;)I, this, module) + ClickGui.1464370502, invokedynamic(873540000:(Ljava/lang/Object;Ljava/lang/Object;)I, this, module) + 1748281791 * ClickGui.1482515323, ClickGui.213163787)
                    }
                    else if (setting instanceof BooleanSetting) {
                        final BooleanSetting 1748281798 = (BooleanSetting)setting;
                        if (invokedynamic(-20505074:(I)Z, ClickGui.-1401460534) && 200689512 > n && 866386503 > n2 && 200689512 < 1748281795 && 866386503 < n3) {
                            // invokedynamic(2009365400:(Ljava/lang/Object;)V, this)
                            1748281798.focussed = (ClickGui.-669970952 != 0);
                        }
                    }
                    // invokedynamic(839766215:(Ljava/lang/Object;III)V, invokedynamic(554275994:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(2102805369:(Ljava/lang/Object;Z)Ljava/lang/StringBuilder;, invokedynamic(-1773493085:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-1059319988:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), 1748281798.name), invokedynamic(-792582122:(IJ)Ljava/lang/String;, ClickGui.-365321580, ClickGui.1168347302 ^ ClickGui.-280605849)), invokedynamic(1111721257:(Ljava/lang/Object;)Z, 1748281798))), invokedynamic(-724018651:(Ljava/lang/Object;Ljava/lang/Object;)I, this, module) + ClickGui.-1772315181, invokedynamic(-1316496558:(Ljava/lang/Object;Ljava/lang/Object;)I, this, module) + 1748281791 * ClickGui.-1638563026, ClickGui.520121686)
                    else if (setting instanceof ModeSetting) {
                        final ModeSetting 1748281799 = (ModeSetting)setting;
                        if (invokedynamic(1893409223:(I)Z, ClickGui.-106306137) && 200689512 > n && 866386503 > n2 && 200689512 < 1748281795 && 866386503 < n3) {
                            // invokedynamic(1868846587:(Ljava/lang/Object;)V, this)
                            1748281799.focussed = (ClickGui.-1295826159 != 0);
                        }
                    }
                    // invokedynamic(1345258105:(Ljava/lang/Object;III)V, invokedynamic(1538006461:(Ljava/lang/Object;)Ljava/lang/String;, invokedynamic(871837124:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-733456715:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, invokedynamic(-1664110405:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuilder;, new StringBuilder(), 1748281799.name), invokedynamic(1638822205:(IJ)Ljava/lang/String;, ClickGui.1922262177, ClickGui.1298403467 ^ ClickGui.-2002191522)), invokedynamic(585635641:(Ljava/lang/Object;)Ljava/lang/String;, 1748281799))), invokedynamic(981535337:(Ljava/lang/Object;Ljava/lang/Object;)I, this, module) + ClickGui.-806749014, invokedynamic(1658341384:(Ljava/lang/Object;Ljava/lang/Object;)I, this, module) + 1748281791 * ClickGui.-1426466175, ClickGui.-545225590)
                    ++1748281791;
                }
            }
        }
        final Iterator iterator4 = invokedynamic(-275795541:(Ljava/lang/Object;)Ljava/util/Iterator;, this.field_146292_n);
        while (invokedynamic(1094116742:(Ljava/lang/Object;)Z, iterator4)) {
            final GuiButton guiButton = (GuiButton)invokedynamic(-1025893928:(Ljava/lang/Object;)Ljava/lang/Object;, iterator4);
            if (200689512 >= guiButton.field_146128_h && 866386503 >= guiButton.field_146129_i && 200689512 < guiButton.field_146128_h + guiButton.field_146120_f && 866386503 < guiButton.field_146129_i + guiButton.field_146121_g) {
                final Iterator iterator5 = invokedynamic(2010695368:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(588855910:()Ljava/util/ArrayList;));
                while (invokedynamic(-394181891:(Ljava/lang/Object;)Z, iterator5)) {
                    final Module 1748281800 = (Module)invokedynamic(-1901055661:(Ljava/lang/Object;)Ljava/lang/Object;, iterator5);
                    if (guiButton.field_146126_j == invokedynamic(-1713808168:(Ljava/lang/Object;)Ljava/lang/String;, 1748281800)) {
                    }
                    // invokedynamic(440449530:(IIIII)V, 200689512, 866386503 + ClickGui.-1571654858, 200689512 + invokedynamic(-1075036873:(Ljava/lang/Object;)I, invokedynamic(-547621438:(Ljava/lang/Object;)Ljava/lang/String;, 1748281800)) + ClickGui.-1067246669, 866386503 + this.mc.field_71466_p.field_78288_b + ClickGui.-765718137, ClickGui.-734222173)
                    // invokedynamic(-1332175296:(Ljava/lang/Object;III)V, invokedynamic(312426526:(Ljava/lang/Object;)Ljava/lang/String;, 1748281800), 200689512 + ClickGui.287772925, 866386503 + ClickGui.958766410, ClickGui.-616898337)
                }
            }
        }
    }
    
    public boolean func_73868_f() {
        return ClickGui.350308173 != 0;
    }
    
    public int placeForHackY(final Module 1592868111) {
        return invokedynamic(350789964:(Ljava/lang/Object;Ljava/lang/Object;)I, 1592868111, invokedynamic(-1792849825:(Ljava/lang/Object;)Lcom/sten_region_skidrrr/strafehack/module/Category;, 1592868111)) * ClickGui.1807863324 + ClickGui.950803616;
    }
    
    public int placeForHackX(final Module -1516135300) {
        if (invokedynamic(-118507086:(Ljava/lang/Object;)Lcom/sten_region_skidrrr/strafehack/module/Category;, -1516135300) == Category.Combat) {
            return ClickGui.-799828441;
        }
        if (invokedynamic(-2062395887:(Ljava/lang/Object;)Lcom/sten_region_skidrrr/strafehack/module/Category;, -1516135300) == Category.Movement) {
            return ClickGui.-815339872;
        }
        if (invokedynamic(1646049569:(Ljava/lang/Object;)Lcom/sten_region_skidrrr/strafehack/module/Category;, -1516135300) == Category.Player) {
            return ClickGui.-2137883177;
        }
        if (invokedynamic(-196353982:(Ljava/lang/Object;)Lcom/sten_region_skidrrr/strafehack/module/Category;, -1516135300) == Category.Render) {
            return ClickGui.-844616279;
        }
        if (invokedynamic(1239834015:(Ljava/lang/Object;)Lcom/sten_region_skidrrr/strafehack/module/Category;, -1516135300) == Category.Other) {
            return ClickGui.-1196526983;
        }
        return ClickGui.-1115646804;
    }
    
    public void func_73866_w_() {
        int -1012629845 = ClickGui.-1012629845;
        final Iterator iterator = invokedynamic(767652106:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(20580632:()Ljava/util/ArrayList;));
        while (invokedynamic(-859747289:(Ljava/lang/Object;)Z, iterator)) {
            final Module module = (Module)invokedynamic(571310194:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
            final Button 564863279 = new Button(-1012629845, invokedynamic(-1232373919:(Ljava/lang/Object;Ljava/lang/Object;)I, this, module), invokedynamic(-1507912933:(Ljava/lang/Object;Ljava/lang/Object;)I, this, module), ClickGui.-227218233, ClickGui.-1637772439, invokedynamic(-713721236:(Ljava/lang/Object;)Ljava/lang/String;, module));
            564863279.backColor = ClickGui.1333645306;
            564863279.borderColor = ClickGui.-1098608221;
            // invokedynamic(-953010824:(Ljava/lang/Object;Ljava/lang/Object;)Z, this.field_146292_n, 564863279)
            ++-1012629845;
        }
    }
    
    public void func_146281_b() {
    }
    // invokedynamic(-807024139:()V)
    // invokedynamic(1580161800:(Ljava/lang/Object;)V, this)
    
    protected void func_73864_a(final int -347575935, final int -192872091, final int -1545742880) throws IOException {
        for (int 598702493 = ClickGui.1889965627; 598702493 < invokedynamic(160363631:(Ljava/lang/Object;)I, this.field_146292_n); ++598702493) {
            final GuiButton 598702494 = (GuiButton)invokedynamic(-1373927689:(Ljava/lang/Object;I)Ljava/lang/Object;, this.field_146292_n, 598702493);
            if (invokedynamic(-2102864518:(Ljava/lang/Object;Ljava/lang/Object;II)Z, 598702494, this.mc, -347575935, -192872091)) {
                int -1545742881 = ClickGui.-1442577413;
                final Iterator iterator = invokedynamic(-2090781286:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(1661349447:()Ljava/util/ArrayList;));
                while (invokedynamic(-1363633466:(Ljava/lang/Object;)Z, iterator)) {
                    final Module module = (Module)invokedynamic(-2036535736:(Ljava/lang/Object;)Ljava/lang/Object;, iterator);
                    if (598702494.field_146127_k == -1545742881) {
                        if (-1545742880 != 0) {
                            if (-1545742880 == ClickGui.-78143229) {
                                final Iterator iterator2 = invokedynamic(2002001160:(Ljava/lang/Object;)Ljava/util/Iterator;, invokedynamic(-166183531:(Ljava/lang/Object;)Ljava/util/List;, module));
                                while (invokedynamic(-112351654:(Ljava/lang/Object;)Z, iterator2)) {
                                    final Setting setting = (Setting)invokedynamic(-2145289227:(Ljava/lang/Object;)Ljava/lang/Object;, iterator2);
                                    setting.focussed = (ClickGui.114629077 != 0);
                                }
                            }
                            // invokedynamic(-477695892:(Ljava/lang/Object;Z)V, module, invokedynamic(334351975:(Ljava/lang/Object;)Z, module) ? ClickGui.-1131002612 : ClickGui.-1753771277)
                        }
                    }
                    ++-1545742881;
                }
            }
        }
    }
    
    static {
        ClickGui.2095586730 = -895959503;
        ClickGui.966014949 = 184;
        ClickGui.-2007587438 = invokedynamic(-1883621799:(I)I, -1);
        ClickGui.-1200577479 = (32 >>> 101 | 32 << ~0x65 + 1);
        ClickGui.1399712331 = (0 >>> 249 | 0 << -249);
        ClickGui.552600383 = invokedynamic(-844115590:(I)I, 1879048192);
        ClickGui.-417916894 = (0 >>> 202 | 0 << ~0xCA + 1);
        ClickGui.-104040803 = invokedynamic(-1844572549:(I)I, false);
        ClickGui.240895914 = ((0 >>> 6 | 0 << -6) & -1);
        ClickGui.1139240061 = (132 >>> 194 | 132 << -194);
        ClickGui.-1671028522 = (0 >>> 56 | 0 << -56);
        ClickGui.2061144448 = invokedynamic(-1203325988:(I)I, false);
        ClickGui.-1998845427 = ((0 >>> 7 | 0 << ~0x7 + 1) & -1);
        ClickGui.-2040231206 = invokedynamic(1636592911:(J)J, -2711866721105500650L);
        ClickGui.-1547232832 = invokedynamic(719332896:(J)J, 8070450532247928832L);
        ClickGui.-1478990231 = invokedynamic(1067359043:(I)I, 671088640);
        ClickGui.2035737234 = invokedynamic(-845689661:(I)I, Integer.MIN_VALUE);
        ClickGui.270831351 = invokedynamic(-2048980242:(I)I, false);
        ClickGui.-275721858 = ((4 >>> 66 | 4 << ~0x42 + 1) & -1);
        ClickGui.313719307 = invokedynamic(179117520:(J)J, -2711866721105500650L);
        ClickGui.1439162146 = invokedynamic(1295074389:(J)J, 8070450532247928832L);
        ClickGui.-14197661 = invokedynamic(-95736500:(I)I, -754974720);
        ClickGui.731749466 = invokedynamic(-494108824:(I)I, -1);
        ClickGui.-2092868214 = invokedynamic(-1671483814:(I)I, -1291845632);
        ClickGui.138335343 = invokedynamic(-974806277:(I)I, Integer.MIN_VALUE);
        ClickGui.-837163603 = (0 >>> 171 | 0 << ~0xAB + 1);
        ClickGui.1076598953 = ((0 >>> 197 | 0 << ~0xC5 + 1) & -1);
        ClickGui.214854800 = ((0 >>> 18 | 0 << ~0x12 + 1) & -1);
        ClickGui.170772227 = invokedynamic(-282945216:(I)F, (-77175191 >>> 99 | -77175191 << -99) & -1);
        ClickGui.-374375859 = invokedynamic(-138753315:(I)I, 402653184);
        ClickGui.2112403521 = invokedynamic(366726158:(I)I, -16777216);
        ClickGui.-1001823122 = (2 >>> 157 | 2 << ~0x9D + 1);
        ClickGui.1510798112 = invokedynamic(1929044226:(I)I, -16777216);
        ClickGui.1104612807 = invokedynamic(-480059752:(I)I, 268435456);
        ClickGui.537259646 = invokedynamic(-1081736923:(I)I, -16777216);
        ClickGui.1825697655 = invokedynamic(557351008:(I)I, -16777216);
        ClickGui.737161623 = ((25165824 >>> 180 | 25165824 << -180) & -1);
        ClickGui.1919512525 = (64 >>> 34 | 64 << -34);
        ClickGui.-557872974 = (128 >>> 68 | 128 << -68);
        ClickGui.888185852 = ((41943040 >>> 214 | 41943040 << ~0xD6 + 1) & -1);
        ClickGui.-693939360 = ((0 >>> 74 | 0 << ~0x4A + 1) & -1);
        ClickGui.626254859 = (5 >>> 156 | 5 << ~0x9C + 1);
        ClickGui.1506713399 = ((1792 >>> 39 | 1792 << -39) & -1);
        ClickGui.-375944755 = (1216348032 >>> 79 | 1216348032 << -79);
        ClickGui.-1285623898 = invokedynamic(458021501:(I)I, 1509949440);
        ClickGui.1312872465 = invokedynamic(172754814:(I)I, false);
        ClickGui.-1207472016 = ((41943040 >>> 178 | 41943040 << -178) & -1);
        ClickGui.-1568741162 = invokedynamic(1638406551:(I)I, 1879048192);
        ClickGui.-1926420638 = ((-133920769 >>> 3 | -133920769 << ~0x3 + 1) & -1);
        ClickGui.1249442171 = invokedynamic(739601552:(I)I, 1426063360);
        ClickGui.-672735119 = (0 >>> 42 | 0 << ~0x2A + 1);
        ClickGui.-735603163 = invokedynamic(1078054975:(I)I, 251658240);
        ClickGui.1686127469 = invokedynamic(-1585751241:(I)I, 1879048192);
        ClickGui.1619967089 = invokedynamic(1544646748:(I)I, -16187137);
        ClickGui.1146487515 = ((128000 >>> 41 | 128000 << -41) & -1);
        ClickGui.-1190641561 = invokedynamic(-103706772:(I)I, false);
        ClickGui.-323311328 = (5 >>> 58 | 5 << -58);
        ClickGui.66754060 = (917504 >>> 16 | 917504 << ~0x10 + 1);
        ClickGui.-1260810654 = ((-66960385 >>> 34 | -66960385 << -34) & -1);
        ClickGui.-1277308355 = (337920 >>> 170 | 337920 << -170);
        ClickGui.-1828149380 = invokedynamic(-620564295:(I)I, false);
        ClickGui.-1137294540 = invokedynamic(-257419891:(I)I, 159383552);
        ClickGui.509891028 = ((117440512 >>> 119 | 117440512 << ~0x77 + 1) & -1);
        ClickGui.292702354 = ((304087008 >>> 173 | 304087008 << ~0xAD + 1) & -1);
        ClickGui.-934757870 = invokedynamic(-1851912013:(I)I, 1342177280);
        ClickGui.-1292800666 = invokedynamic(-1671579403:(I)I, -1342177280);
        ClickGui.-777499873 = ((655360 >>> 237 | 655360 << -237) & -1);
        ClickGui.1397111327 = (7 >>> 95 | 7 << -95);
        ClickGui.2049263147 = ((-1 >>> 54 | -1 << ~0x36 + 1) & -1);
        ClickGui.-1809397232 = invokedynamic(2095468234:(I)I, 1509949440);
        ClickGui.-333138335 = invokedynamic(-414767478:(I)I, -1342177280);
        ClickGui.1527524935 = invokedynamic(-511231931:(I)I, 83886080);
        ClickGui.-591586101 = (114688 >>> 13 | 114688 << -13);
        ClickGui.83064448 = invokedynamic(74354675:(I)I, -1);
        ClickGui.281690484 = ((22282240 >>> 113 | 22282240 << -113) & -1);
        ClickGui.1983109276 = (13631488 >>> 20 | 13631488 << -20);
        ClickGui.-681072085 = ((960 >>> 194 | 960 << -194) & -1);
        ClickGui.-994468883 = (-2147483645 >>> 254 | -2147483645 << ~0xFE + 1);
        ClickGui.-1524359069 = (-1 >>> 183 | -1 << -183);
        ClickGui.1385123129 = invokedynamic(-828635652:(I)I, 1593835520);
        ClickGui.-1788762074 = ((872415232 >>> 250 | 872415232 << -250) & -1);
        ClickGui.1823653674 = (81920 >>> 72 | 81920 << -72);
        ClickGui.-802602245 = ((7 >>> 95 | 7 << -95) & -1);
        ClickGui.1227345960 = (-1 >>> 128 | -1 << ~0x80 + 1);
        ClickGui.-2127208993 = (671088645 >>> 58 | 671088645 << -58);
        ClickGui.1141469203 = invokedynamic(-1585232747:(I)I, -1342177280);
        ClickGui.-1751404878 = (6553600 >>> 110 | 6553600 << ~0x6E + 1);
        ClickGui.-127001682 = invokedynamic(-1725096361:(I)I, 1879048192);
        ClickGui.-1891574811 = (-1 >>> 66 | -1 << ~0x42 + 1);
        ClickGui.332492160 = invokedynamic(1621424908:(I)I, false);
        ClickGui.1376027647 = (0 >>> 146 | 0 << -146);
        ClickGui.1676157856 = ((5760 >>> 71 | 5760 << ~0x47 + 1) & -1);
        ClickGui.545829451 = (671088640 >>> 215 | 671088640 << ~0xD7 + 1);
        ClickGui.-74539119 = invokedynamic(-1895417334:(I)I, -1);
        ClickGui.-1111035439 = (-32641 >>> 79 | -32641 << -79);
        ClickGui.833745756 = (0 >>> 190 | 0 << ~0xBE + 1);
        ClickGui.-911524189 = invokedynamic(1798779567:(I)I, 1644167168);
        ClickGui.84520113 = invokedynamic(1113451251:(I)I, 1879048192);
        ClickGui.455696857 = invokedynamic(1567383195:(I)I, false);
        ClickGui.387415689 = ((8388608 >>> 54 | 8388608 << ~0x36 + 1) & -1);
        ClickGui.-276117199 = invokedynamic(-1786546749:(J)J, -2711866721105500650L);
        ClickGui.1562496724 = invokedynamic(-269541435:(J)J, 8070450532247928832L);
        ClickGui.2085968702 = (3 >>> 96 | 3 << ~0x60 + 1);
        ClickGui.-1655550087 = ((-1 >>> 146 | -1 << -146) & -1);
        ClickGui.1278782390 = invokedynamic(-719736912:(J)J, -6170631234926041578L);
        ClickGui.-643616726 = (16 >>> 130 | 16 << -130);
        ClickGui.32889523 = invokedynamic(2142116494:(J)J, -6170631234926041578L);
        ClickGui.1049487753 = ((1310720 >>> 178 | 1310720 << ~0xB2 + 1) & -1);
        ClickGui.2130123214 = invokedynamic(-360225303:(I)I, -1);
        ClickGui.739727558 = invokedynamic(-1064820035:(J)J, -6170631234926041578L);
        ClickGui.-817268683 = (4800 >>> 230 | 4800 << ~0xE6 + 1);
        ClickGui.-1462173845 = (114688 >>> 237 | 114688 << ~0xED + 1);
        ClickGui.482420514 = invokedynamic(1000567934:(I)I, 1879048192);
        ClickGui.-807849066 = invokedynamic(-1790134969:(I)I, true);
        ClickGui.732461659 = invokedynamic(-297809947:(I)I, Integer.MIN_VALUE);
        ClickGui.-349840140 = (-1046257 >>> 188 | -1046257 << ~0xBC + 1);
        ClickGui.1797854330 = invokedynamic(953921965:(I)I, Integer.MIN_VALUE);
        ClickGui.-774048274 = invokedynamic(1420322931:(I)I, Integer.MIN_VALUE);
        ClickGui.-1733264989 = ((-1862271232 >>> 176 | -1862271232 << -176) & -1);
        ClickGui.1897836201 = ((9502719 >>> 8 | 9502719 << -8) & -1);
        ClickGui.1067787897 = (4096 >>> 76 | 4096 << -76);
        ClickGui.1695813234 = (2147450952 >>> 55 | 2147450952 << -55);
        ClickGui.600874266 = invokedynamic(-1958297649:(I)I, true);
        ClickGui.1674860695 = ((0 >>> 228 | 0 << -228) & -1);
        ClickGui.727308767 = invokedynamic(1967579929:(I)I, 1610612736);
        ClickGui.-701865151 = ((-1 >>> 139 | -1 << ~0x8B + 1) & -1);
        ClickGui.726868566 = invokedynamic(518943809:(J)J, -6170631234926041578L);
        ClickGui.-1356278208 = invokedynamic(1523511085:(I)I, Integer.MIN_VALUE);
        ClickGui.2017444855 = invokedynamic(1633266510:(I)I, -1);
        ClickGui.-1402027834 = invokedynamic(792840790:(I)I, -536870912);
        ClickGui.-1074058620 = invokedynamic(-2027182504:(J)J, -2711866721105500650L);
        ClickGui.-940554793 = invokedynamic(841805863:(J)J, 8070450532247928832L);
        ClickGui.-1409000525 = ((536870913 >>> 250 | 536870913 << -250) & -1);
        ClickGui.1855208602 = invokedynamic(524400584:(I)I, 1879048192);
        ClickGui.-940397816 = invokedynamic(11063351:(I)I, -256);
        ClickGui.1733353745 = invokedynamic(-770458145:(I)I, false);
        ClickGui.-600637765 = invokedynamic(1170973650:(I)I, Integer.MIN_VALUE);
        ClickGui.304068866 = ((8388608 >>> 148 | 8388608 << -148) & -1);
        ClickGui.-1931428223 = invokedynamic(-1196595456:(I)I, -1);
        ClickGui.2027683830 = invokedynamic(730052317:(J)J, -6170631234926041578L);
        ClickGui.1008965750 = invokedynamic(1008055593:(I)I, 301989888);
        ClickGui.-485218549 = (-536870912 >>> 60 | -536870912 << -60);
        ClickGui.-1775405337 = ((1073741760 >>> 166 | 1073741760 << -166) & -1);
        ClickGui.-1953963072 = ((36864 >>> 108 | 36864 << ~0x6C + 1) & -1);
        ClickGui.1732154193 = invokedynamic(-2132352145:(J)J, -2711866721105500650L);
        ClickGui.1737630367 = invokedynamic(-1145708162:(J)J, 8070450532247928832L);
        ClickGui.1464370502 = ((603979776 >>> 23 | 603979776 << -23) & -1);
        ClickGui.1482515323 = invokedynamic(-2127778193:(I)I, 1879048192);
        ClickGui.213163787 = ((-4177921 >>> 54 | -4177921 << ~0x36 + 1) & -1);
        ClickGui.-1401460534 = invokedynamic(-609256890:(I)I, false);
        ClickGui.-669970952 = (33554432 >>> 57 | 33554432 << -57);
        ClickGui.-365321580 = invokedynamic(-1277784548:(I)I, 1342177280);
        ClickGui.1168347302 = invokedynamic(-2043535554:(J)J, -2711866721105500650L);
        ClickGui.-280605849 = invokedynamic(742554251:(J)J, 8070450532247928832L);
        ClickGui.-1772315181 = invokedynamic(1953819098:(I)I, 301989888);
        ClickGui.-1638563026 = (7168 >>> 73 | 7168 << ~0x49 + 1);
        ClickGui.520121686 = invokedynamic(-1857727806:(I)I, -256);
        ClickGui.-106306137 = invokedynamic(670599204:(I)I, false);
        ClickGui.-1295826159 = (8 >>> 35 | 8 << -35);
        ClickGui.1922262177 = ((2883584 >>> 242 | 2883584 << ~0xF2 + 1) & -1);
        ClickGui.1298403467 = invokedynamic(1458160112:(J)J, -2711866721105500650L);
        ClickGui.-2002191522 = invokedynamic(-540363228:(J)J, 8070450532247928832L);
        ClickGui.-806749014 = (603979776 >>> 247 | 603979776 << -247);
        ClickGui.-1426466175 = ((1879048192 >>> 59 | 1879048192 << -59) & -1);
        ClickGui.-545225590 = invokedynamic(-75289102:(I)I, -256);
        ClickGui.-1571654858 = ((-1610612736 >>> 28 | -1610612736 << -28) & -1);
        ClickGui.-1067246669 = ((1073741824 >>> 252 | 1073741824 << ~0xFC + 1) & -1);
        ClickGui.-765718137 = invokedynamic(241503752:(I)I, 805306368);
        ClickGui.-734222173 = invokedynamic(-586736976:(I)I, true);
        ClickGui.287772925 = invokedynamic(1891870287:(I)I, 1073741824);
        ClickGui.958766410 = invokedynamic(800398764:(I)I, -1879048192);
        ClickGui.-616898337 = ((-1069547521 >>> 190 | -1069547521 << -190) & -1);
        ClickGui.350308173 = invokedynamic(1428853824:(I)I, false);
        ClickGui.1807863324 = invokedynamic(-1922106555:(I)I, 1879048192);
        ClickGui.950803616 = invokedynamic(1635912244:(I)I, 1879048192);
        ClickGui.-799828441 = (2560 >>> 104 | 2560 << ~0x68 + 1);
        ClickGui.-815339872 = (1509949440 >>> 56 | 1509949440 << -56);
        ClickGui.-2137883177 = ((340 >>> 193 | 340 << -193) & -1);
        ClickGui.-844616279 = invokedynamic(1953985927:(I)I, 1593835520);
        ClickGui.-1196526983 = ((-1526726656 >>> 119 | -1526726656 << ~0x77 + 1) & -1);
        ClickGui.-1115646804 = invokedynamic(-1563766236:(I)I, false);
        ClickGui.-1012629845 = invokedynamic(1065649314:(I)I, Integer.MIN_VALUE);
        ClickGui.-227218233 = invokedynamic(-5096885:(I)I, 1644167168);
        ClickGui.-1637772439 = invokedynamic(-1690742415:(I)I, 1879048192);
        ClickGui.1333645306 = (49152 >>> 18 | 49152 << -18);
        ClickGui.-1098608221 = invokedynamic(-1471103860:(I)I, -16187137);
        ClickGui.1889965627 = ((0 >>> 179 | 0 << -179) & -1);
        ClickGui.-1442577413 = (4194304 >>> 246 | 4194304 << -246);
        ClickGui.-78143229 = invokedynamic(-701254729:(I)I, Integer.MIN_VALUE);
        ClickGui.114629077 = invokedynamic(-1599138684:(I)I, false);
        ClickGui.-1753771277 = invokedynamic(-997571339:(I)I, Integer.MIN_VALUE);
        ClickGui.-1131002612 = invokedynamic(886452277:(I)I, false);
        ClickGui.-1244881957 = invokedynamic(1261233186:(I)I, 805306368);
        ClickGui.-891459751 = invokedynamic(-1731260149:(I)I, 805306368);
        ClickGui.-1945320144 = new String[ClickGui.-1244881957];
        ClickGui.-561302429 = new String[ClickGui.-891459751];
    }
    // invokedynamic(1392446941:()V)
    
    private static Object 1871835095(final MethodHandles.Lookup lookup, final String str, final MethodType newType) {
        try {
            return new MutableCallSite(lookup.findStatic(ClickGui.class, "-1714254065", MethodType.fromMethodDescriptorString("(IJ)Ljava/lang/String;", ClickGui.class.getClassLoader())).asType(newType));
        }
        catch (Exception cause) {
            throw new RuntimeException("com/sten_region_skidrrr/strafehack/ui/ClickGui:" + str + ":" + newType.toString(), cause);
        }
    }
    
    private static String -1714254065(final int n, long n2) {
        n2 ^= 0xEL;
        n2 ^= 0xDD4E2B72B8D96D0AL;
        if (ClickGui.-1945320144[n] == null) {
            Cipher instance;
            SecretKeyFactory instance2;
            try {
                instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
                instance2 = SecretKeyFactory.getInstance("DES");
            }
            catch (Exception ex) {
                throw new RuntimeException("com/sten_region_skidrrr/strafehack/ui/ClickGui");
            }
            final byte[] key = new byte[8];
            key[0] = (byte)(n2 >>> 56);
            for (int i = 1; i < 8; ++i) {
                key[i] = (byte)(n2 << i * 8 >>> 56);
            }
            instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
            ClickGui.-1945320144[n] = new String(instance.doFinal(Base64.getDecoder().decode(ClickGui.-561302429[n])));
        }
        return ClickGui.-1945320144[n];
    }
    
    private static void 1007277849() {
        ClickGui.1712342544 = 7522614790632618587L;
        final long n = ClickGui.1712342544 ^ 0xDD4E2B72B8D96D0AL;
        final Cipher instance = Cipher.getInstance("DES/CBC/PKCS5Padding");
        final SecretKeyFactory instance2 = SecretKeyFactory.getInstance("DES");
        final byte[] key = new byte[8];
        key[0] = (byte)(n >>> 56);
        for (int i = 1; i < 8; ++i) {
            key[i] = (byte)(n << i * 8 >>> 56);
        }
        instance.init(2, instance2.generateSecret(new DESKeySpec(key)), new IvParameterSpec(new byte[8]));
        for (int n2 = 1, j = 0; j < n2; ++j) {
            switch (j) {
                case 0: {
                    ClickGui.-561302429[0] = "ALax07UK2XA=";
                    ClickGui.-561302429[1] = "ALax07UK2XA=";
                    ClickGui.-561302429[2] = "ZI9GL6fe5eo=";
                    ClickGui.-561302429[3] = "ZI9GL6fe5eo=";
                    ClickGui.-561302429[4] = "ZI9GL6fe5eo=";
                    ClickGui.-561302429[5] = "ALax07UK2XA=";
                    ClickGui.-561302429[6] = "ALax07UK2XA=";
                    ClickGui.-561302429[7] = "ZI9GL6fe5eo=";
                    ClickGui.-561302429[8] = "sN+3gpxF3Ws=";
                    ClickGui.-561302429[9] = "ZI9GL6fe5eo=";
                    ClickGui.-561302429[10] = "ZI9GL6fe5eo=";
                    ClickGui.-561302429[11] = "ZI9GL6fe5eo=";
                    break;
                }
                case 1: {
                    ClickGui.-561302429[0] = "wm6npoSRIyM=";
                    ClickGui.-561302429[1] = "4W2ak9tL2LE=";
                    ClickGui.-561302429[2] = "RiCXWEDDJ5U=";
                    ClickGui.-561302429[3] = "nhH+5mr+EfI=";
                    ClickGui.-561302429[4] = "qRgApJ7iu5g=";
                    ClickGui.-561302429[5] = "EzJivMxAj1w=";
                    ClickGui.-561302429[6] = "+GzA5KCc9VE=";
                    ClickGui.-561302429[7] = "v0ub36GLx6E=";
                    ClickGui.-561302429[8] = "4+WbaMqE/0Jj0+Q23Lq5GQ==";
                    ClickGui.-561302429[9] = "39KNAVmdvaA=";
                    ClickGui.-561302429[10] = "42U3K2yDD7Y=";
                    ClickGui.-561302429[11] = "2sFQV4tyKY4=";
                    break;
                }
                case 2: {
                    ClickGui.-561302429[0] = "jm3AFhwo4wnsmR5W8qXJlw==";
                    break;
                }
                case 4: {
                    ClickGui.-561302429[0] = "77BBuRpV7G5UwDUX3M5uOA==";
                    break;
                }
            }
        }
    }
    
    public static Object -1806118248(final MethodHandles.Lookup lookup, final String s, final MethodType methodType, final Object o, final Object o2, final Object o3, final Object o4, final Object o5) throws Exception {
        final int n = ((int)o ^ ClickGui.2095586730) & 0xFF;
        final Integer value = ClickGui.966014949;
        final Class<?> forName = Class.forName(new String(DatatypeConverter.parseBase64Binary((String)o2)));
        final MethodType fromMethodDescriptorString = MethodType.fromMethodDescriptorString((String)o4, forName.getClassLoader());
        if (n == value) {
            return new MutableCallSite(lookup.findStatic(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
        }
        return new MutableCallSite(lookup.findVirtual(forName, new String(DatatypeConverter.parseBase64Binary((String)o3)), fromMethodDescriptorString).asType(methodType));
    }
}
